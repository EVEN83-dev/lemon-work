# -*- coding: utf-8 -*-
"""生成大赛提交用「源码与部署材料」压缩包（<300MB，不含内置 Python 运行时）"""
import os
import shutil
import zipfile

ROOT = r'D:\YH-lemon\LemonWork'
BANK = r'D:\虚拟系统软件模拟\数字银行'
OUT = r'D:\YH-lemon\release'
NAME = 'LemonWork-v1.0.0-src'
STAGE = os.path.join(OUT, NAME)

SKIP_DIRS = {'_py312', '.git', 'release', 'node_modules', 'bin', 'dist',
             'outputs', '__pycache__', '.lemon', 'data'}


def copy_tree(src, dst, skip=(), skip_files=()):
    n = 0
    for dp, dns, fns in os.walk(src):
        dns[:] = [d for d in dns if d not in skip and d != '__pycache__'
                  and not d.startswith('.git')]
        rel = os.path.relpath(dp, src)
        for f in fns:
            if f in skip_files or f.endswith(('.pyc', '.log', '.tmp')):
                continue
            s = os.path.join(dp, f)
            d = os.path.join(dst, rel, f) if rel != '.' else os.path.join(dst, f)
            os.makedirs(os.path.dirname(d), exist_ok=True)
            try:
                shutil.copy2(s, d)
                n += 1
            except (OSError, PermissionError):
                pass
    return n


def main():
    if os.path.exists(STAGE):
        shutil.rmtree(STAGE, ignore_errors=True)
    os.makedirs(STAGE, exist_ok=True)

    print('[1/4] 复制 LemonWork 源码…')
    n1 = copy_tree(ROOT, os.path.join(STAGE, 'LemonWork'), skip=SKIP_DIRS,
                   skip_files={'custom_models.json'})
    print('    %d files' % n1)

    print('[2/4] 复制数字银行…')
    n2 = copy_tree(BANK, os.path.join(STAGE, 'DigitalBank'),
                   skip={'__pycache__', '.idea', 'data'})
    os.makedirs(os.path.join(STAGE, 'DigitalBank', 'data'), exist_ok=True)
    print('    %d files' % n2)

    print('[3/4] 写启动器与文档…')
    os.makedirs(os.path.join(STAGE, 'docs'), exist_ok=True)
    for md in ('银行办理指令-可复制.md', '深圳金融科技大赛-测试指令.md'):
        p = os.path.join(ROOT, md)
        if os.path.exists(p):
            shutil.copy2(p, os.path.join(STAGE, 'docs', md))
    if os.path.exists(os.path.join(BANK, 'README.md')):
        shutil.copy2(os.path.join(BANK, 'README.md'),
                     os.path.join(STAGE, 'docs', '数字银行说明.md'))
    for f in ('LICENSE', 'requirements.txt'):
        p = os.path.join(ROOT, f)
        if os.path.exists(p):
            shutil.copy2(p, os.path.join(STAGE, f))
    p = os.path.join(ROOT, '技术文档报告.pdf')
    if os.path.exists(p):
        shutil.copy2(p, os.path.join(STAGE, 'docs', '技术文档报告.pdf'))
    p = os.path.join(ROOT, '安全自评报告.docx')
    if os.path.exists(p):
        shutil.copy2(p, os.path.join(STAGE, 'docs', '安全自评报告.docx'))

    readme = '''# Lemon Work · 源码与部署材料

AI 智能工作助手 + 数字银行沙箱 · 2026 深圳国际金融科技大赛参赛作品

仓库: https://github.com/EVEN83-dev/lemon-work

## 一、目录说明

| 目录 | 说明 |
|------|------|
| `LemonWork/` | 桌面客户端 + Agent 引擎全部源码（Python / JS / HTML / CSS） |
| `LemonWork/scripts/` | 自动化测试用例（白盒 / 巡航 / 端到端 / 六场景合规 / 契约审计） |
| `LemonWork/shared/skills_builtin/` | 内置技能包（含 20+ 数字银行技能） |
| `DigitalBank/` | 数字银行沙箱服务（server.py + bank_core.py + 前端） |
| `docs/` | 技术文档、安全自评报告、银行指令用例 |
| `README.md` / `部署说明.md` | 本文件与部署指引 |

## 二、运行方式

### 方式 A：免安装绿色包（推荐）

本压缩包不含 Python 运行时（为满足 300MB 上传限制）。
如需解压即用版本，请从 GitHub Release 下载：

https://github.com/EVEN83-dev/lemon-work/releases/download/v1.0.0/LemonWork-v1.0.0-win64-portable.zip

（371MB，内置 Python 3.12 + PyQt5，双击 `启动LemonWork.bat` 即可）

### 方式 B：源码运行

环境要求：Windows 10/11 + Python 3.12

```bat
cd LemonWork
pip install -r ..\\requirements.txt
python yh_main.py
```

数字银行沙箱随主程序自动拉起；也可单独启动：

```bat
cd DigitalBank
python server.py
```

访问 http://127.0.0.1:8090 查看银行操作台。

### 配置模型

启动后进入「模型中心」，填入 DeepSeek API Key；或选择 Ollama 本地引擎离线使用。

## 三、测试用例

```bat
cd LemonWork
python scripts\\gui_whitebox_test.py       :: 白盒化回归（30 项）
python scripts\\gui_patrol_test.py         :: 巡航稳定性（11 项）
python scripts\\gui_bank_e2e_test.py       :: 端到端（12 项）
python scripts\\gui_competition_test.py    :: 六场景合规（26 项断言）
python scripts\\audit_broken_links.py      :: 空连接/假实现契约审计
python scripts\\gui_demo_six_scenarios.py  :: 六大场景演示（供录屏/截图）
```

## 四、核心能力

1. **全链白盒**：思考链分节点、工具调用明细、过程时间线、用量卡全程可见
2. **多引擎调度**：DeepSeek / Ollama / 自定义 OpenAI 兼容端点，失联自动降级
3. **数字银行沙箱**：六大业务场景（转账 / 账单 / 理财 / 卡片 / 订阅 / 跨场景联动）
4. **页面跟随联动**：Agent 办理业务时银行页面自动切页高亮
5. **安全分级**：技能 L0-L3 四级授权，高危操作需确认

详见 `docs/技术文档报告.pdf`。
'''
    with open(os.path.join(STAGE, 'README.md'), 'w', encoding='utf-8') as f:
        f.write(readme)

    deploy = '''# 部署说明

## 环境要求
- Windows 10 / 11（64 位）
- Python 3.12（源码方式）

## 源码部署步骤

1. 安装 Python 3.12（勾选 Add to PATH）
2. 安装依赖：
   ```
   cd LemonWork
   pip install -r ..\\requirements.txt
   ```
3. 启动主程序：
   ```
   python yh_main.py
   ```
4. 首次启动进入「模型中心」配置 DeepSeek API Key（或选择 Ollama 本地模型）

## 免安装方式
从 GitHub Release 下载绿色包（内置运行时，双击启动）：
https://github.com/EVEN83-dev/lemon-work/releases

## 常见问题
- 数字银行未启动：主程序会自动拉起；如失败可手动 `cd DigitalBank && python server.py`
- 端口占用：银行默认 8090，可在 `DigitalBank/server.py` 中调整
- 模型不可用：检查 API Key 与网络，或在模型中心切换到 Ollama 本地引擎
'''
    with open(os.path.join(STAGE, '部署说明.md'), 'w', encoding='utf-8') as f:
        f.write(deploy)

    with open(os.path.join(STAGE, '启动LemonWork.bat'), 'w',
              encoding='gbk', errors='ignore') as f:
        f.write('@echo off\r\n'
                'chcp 65001 >nul\r\n'
                'cd /d "%~dp0LemonWork"\r\n'
                'echo [提示] 源码包需先安装依赖：pip install -r ..\\requirements.txt\r\n'
                'start "" python yh_main.py\r\n'
                'pause\r\n')
    with open(os.path.join(STAGE, '启动数字银行.bat'), 'w',
              encoding='gbk', errors='ignore') as f:
        f.write('@echo off\r\n'
                'chcp 65001 >nul\r\n'
                'cd /d "%~dp0DigitalBank"\r\n'
                'start "数字银行" python server.py\r\n'
                'pause\r\n')

    print('[4/4] 压缩…')
    zpath = os.path.join(OUT, NAME + '.zip')
    if os.path.exists(zpath):
        os.remove(zpath)
    with zipfile.ZipFile(zpath, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for dp, dns, fns in os.walk(STAGE):
            for f in fns:
                fp = os.path.join(dp, f)
                z.write(fp, os.path.relpath(fp, OUT))

    mb = os.path.getsize(zpath) / 1048576
    print('=' * 56)
    print('OK: %s  (%.1f MB)' % (zpath, mb))
    print('stage: %s' % STAGE)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
