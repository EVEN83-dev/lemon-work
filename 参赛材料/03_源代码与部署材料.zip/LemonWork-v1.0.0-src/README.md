# Lemon Work · 源码与部署材料

AI 智能工作助手 + 数字银行沙箱 · 2026 深圳国际金融科技大赛参赛作品

仓库: https://github.com/EVEN83-dev/lemon-work

## 一、目录说明

| 目录 | 说明 |
|------|------|
| `LemonWork/` | 桌面客户端 + Agent 引擎全部源码（Python / JS / HTML / CSS） |
| `LemonWork/scripts/` | 自动化测试用例（白盒 / 巡航 / 端到端 / 六场景合规 / 契约审计） |
| `LemonWork/shared/skills_builtin/` | 内置技能包（含 20+ 数字银行技能） |
| `DigitalBank/` | 数字银行沙箱服务（server.py + bank_core.py + 前端） |
| `docs/` | 技术文档、安全自评报告、银行指令用例 |
| `README.md` / `部署说明.md` | 本文件与部署指引 |

## 二、运行方式

### 方式 A：免安装绿色包（推荐）

本压缩包不含 Python 运行时（为满足 300MB 上传限制）。
如需解压即用版本，请从 GitHub Release 下载：

https://github.com/EVEN83-dev/lemon-work/releases/download/v1.0.0/LemonWork-v1.0.0-win64-portable.zip

（371MB，内置 Python 3.12 + PyQt5，双击 `启动LemonWork.bat` 即可）

### 方式 B：源码运行

环境要求：Windows 10/11 + Python 3.12

```bat
cd LemonWork
pip install -r ..\requirements.txt
python yh_main.py
```

数字银行沙箱随主程序自动拉起；也可单独启动：

```bat
cd DigitalBank
python server.py
```

访问 http://127.0.0.1:8090 查看银行操作台。

### 配置模型

启动后进入「模型中心」，填入 DeepSeek API Key；或选择 Ollama 本地引擎离线使用。

## 三、测试用例

```bat
cd LemonWork
python scripts\gui_whitebox_test.py       :: 白盒化回归（30 项）
python scripts\gui_patrol_test.py         :: 巡航稳定性（11 项）
python scripts\gui_bank_e2e_test.py       :: 端到端（12 项）
python scripts\gui_competition_test.py    :: 六场景合规（26 项断言）
python scripts\audit_broken_links.py      :: 空连接/假实现契约审计
python scripts\gui_demo_six_scenarios.py  :: 六大场景演示（供录屏/截图）
```

## 四、核心能力

1. **全链白盒**：思考链分节点、工具调用明细、过程时间线、用量卡全程可见
2. **多引擎调度**：DeepSeek / Ollama / 自定义 OpenAI 兼容端点，失联自动降级
3. **数字银行沙箱**：六大业务场景（转账 / 账单 / 理财 / 卡片 / 订阅 / 跨场景联动）
4. **页面跟随联动**：Agent 办理业务时银行页面自动切页高亮
5. **安全分级**：技能 L0-L3 四级授权，高危操作需确认

详见 `docs/技术文档报告.pdf`。
