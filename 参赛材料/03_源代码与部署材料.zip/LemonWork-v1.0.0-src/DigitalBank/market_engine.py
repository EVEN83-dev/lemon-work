# -*- coding: utf-8 -*-
"""数字银行沙箱 · 虚拟行情引擎（market_engine.py）
═══════════════════════════════════════════════════════════════
确定性虚拟行情生成器（参考 marketforge/synthetick/mplfinance 社区经验）：
  · 种子固定 → 同一标的每次启动曲线完全一致（可复现=可审计）
  · 趋势项：正弦+余弦叠加（有形态、非纯噪声）
  · OHLC 构造：open=昨收；close=open±方向*振幅；high/low 包络 open/close+影线
  · 成交量：lognormal（量簇效应）
仅标准库（random/math/datetime），零第三方依赖。
"""
import math
import os
import random
import threading
import time
import zlib
from datetime import date, timedelta

# ---------- 虚拟标的清单（股票盘 + 基金池） ----------
STOCKS = [
    {"code": "LM600001", "name": "柠檬科技",   "base": 24.80, "vol": 0.028, "industry": "科技"},
    {"code": "LM600002", "name": "橘子银行",   "base": 12.60, "vol": 0.014, "industry": "金融"},
    {"code": "LM600003", "name": "西柚能源",   "base": 8.35,  "vol": 0.022, "industry": "能源"},
    {"code": "LM600004", "name": "蜜柚消费",   "base": 36.20, "vol": 0.019, "industry": "消费"},
    {"code": "LM600005", "name": "青柠半导体", "base": 58.00, "vol": 0.036, "industry": "半导体"},
    {"code": "LM600006", "name": "柚子医药",   "base": 19.45, "vol": 0.025, "industry": "医药"},
]
FUNDS = [
    {"code": "NF0001", "name": "柠檬货币增利A", "base": 1.0520, "vol": 0.0004, "type": "货币型", "mgr": "数字基金"},
    {"code": "NF0002", "name": "柑橘稳健债券",  "base": 1.1870, "vol": 0.0022, "type": "债券型", "mgr": "数字基金"},
    {"code": "NF0003", "name": "柚香混合成长",  "base": 1.6420, "vol": 0.0110, "type": "混合型", "mgr": "数字资产"},
    {"code": "NF0004", "name": "青柠科创精选",  "base": 2.3150, "vol": 0.0190, "type": "股票型", "mgr": "数字资产"},
    {"code": "NF0005", "name": "橙意指数增强",  "base": 0.9860, "vol": 0.0150, "type": "指数型", "mgr": "数字基金"},
]


def _trend(i: int, seed: int) -> float:
    """趋势项：正弦+余弦叠加（形态感）+ 缓慢随机漂移。"""
    r = random.Random(seed)
    p1, p2 = r.choice((17, 23, 30, 41)), r.choice((11, 19, 28))
    a1, a2 = r.uniform(0.02, 0.05), r.uniform(0.015, 0.04)
    drift = r.uniform(-0.0008, 0.0012)
    return (a1 * math.sin(2 * math.pi * i / p1) +
            a2 * math.cos(2 * math.pi * i / p2) + drift * i)


# ═══════════ ★第436章 动态 tick 引擎（LiveMarket）——行情"活"起来 ═══════════
TICK_SECONDS = float(os.environ.get("MARKET_TICK_SECONDS", "3"))
ALWAYS_OPEN = os.environ.get("MARKET_ALWAYS_OPEN", "1") == "1"  # 周末休市可豁免（演示友好）


class LiveMarket:
    """日内实时行情演化器（后台 daemon 线程，每 TICK 演化一次现价）。

    分层设计（可审计性不破坏）：
      · 日线历史仍由 gen_kline 确定性生成（种子固定=审计可复现）
      · 日内层由本引擎动态演化：微波动(gauss vol*0.22) + 均值回归(锚=日线末收盘)
        ——有生命节奏的实时跳动，又不脱离确定性趋势锚
      · 基金净值同步微演化（波动率按基金类型缩放）
    """

    def __init__(self):
        self._lock = threading.RLock()
        self._px: dict = {}    # code -> {price,open,high,low,volume}
        self._nav: dict = {}   # code -> 实时净值
        self._vol: dict = {}
        self._anchor: dict = {}
        self._started = False

    # ---- 启动（首次访问时懒加载；boot 期无并发，boot 后 _tick 持锁演化） ----
    def _boot(self):
        for s in STOCKS:
            kl = gen_kline(s["code"], bars=2)
            anchor = kl[-1]["close"]
            self._px[s["code"]] = {"price": anchor, "open": anchor, "high": anchor,
                                   "low": anchor, "volume": int(kl[-1]["volume"] * 0.12)}
            self._anchor[s["code"]] = anchor
            self._vol[s["code"]] = s["vol"]
        for f in FUNDS:
            self._nav[f["code"]] = gen_nav_series(f["code"], days=2)[-1]["nav"]
            self._vol[f["code"]] = f["vol"]
        threading.Thread(target=self._loop, daemon=True,
                         name="live-market").start()
        self._started = True

    def _loop(self):
        while True:
            time.sleep(TICK_SECONDS)
            try:
                self._tick()
            except Exception:
                pass  # 后台演化单次失败不影响服务（下轮自愈）

    def _tick(self):
        with self._lock:
            if not ALWAYS_OPEN and date.today().weekday() >= 5:
                return  # 周末休市：行情静止（真实市场形态）
            for code, px in self._px.items():
                vol, anchor = self._vol[code], self._anchor[code]
                ret = random.gauss(0, vol * 0.22) + (anchor - px["price"]) / anchor * 0.02
                new = max(px["price"] * (1 + ret), 0.01)
                px["high"] = max(px["high"], new)
                px["low"] = min(px["low"], new)
                px["volume"] += int(math.exp(random.gauss(9.2, 0.4)))  # 日内量持续堆积
                px["price"] = round(new, 2)
            for code, nav in self._nav.items():
                m = next(f for f in FUNDS if f["code"] == code)
                self._nav[code] = round(
                    max(nav * (1 + random.gauss(0, m["vol"] * 0.15)), 0.05), 4)

    # ---- 对外读取 ----
    def quote(self) -> list:
        if not self._started:
            self._boot()
        with self._lock:
            out = []
            for s in STOCKS:
                px = self._px[s["code"]]
                chg = (px["price"] - px["open"]) / px["open"] * 100 if px["open"] else 0.0
                out.append({"code": s["code"], "name": s["name"],
                            "industry": s["industry"],
                            "price": px["price"], "change_pct": round(chg, 2),
                            "high": round(px["high"], 2), "low": round(px["low"], 2),
                            "open": px["open"], "volume": px["volume"]})
            return out

    def nav_of(self, code: str) -> float | None:
        if not self._started:
            self._boot()
        with self._lock:
            return self._nav.get(code)

    def fund(self) -> list:
        if not self._started:
            self._boot()
        with self._lock:
            out = []
            for f in FUNDS:
                live = self._nav[f["code"]]
                week = gen_nav_series(f["code"], days=8)[-8]["nav"]  # 基线仍确定性
                out.append({"code": f["code"], "name": f["name"], "type": f["type"],
                            "mgr": f["mgr"], "nav": live,
                            "week_pct": round((live - week) / week * 100, 2)})
            return out


LIVE = LiveMarket()  # 模块级单例（bank_core/server 共享同一行情）


def gen_kline(code: str, bars: int = 90, base: float = 0, vol: float = 0) -> list:
    """生成日线 OHLCV。种子=code 的稳定哈希 → 曲线确定性可复现。"""
    meta = next((s for s in STOCKS if s["code"] == code), None)
    base = base or (meta["base"] if meta else 10.0)
    vol = vol or (meta["vol"] if meta else 0.02)
    seed = zlib.crc32(f"kl_{code}".encode())  # ★稳定哈希：跨进程可复现（str.hash 受随机化影响）
    rng = random.Random(seed)
    today = date.today()
    rows, price = [], base
    for i in range(bars):
        d = today - timedelta(days=bars - 1 - i)
        if d.weekday() >= 5:  # 周末休市
            continue
        openp = price
        chg = rng.gauss(0, vol) + _trend(i, seed) * 0.35
        close = max(openp * (1 + chg), 0.01)
        body_hi, body_lo = max(openp, close), min(openp, close)
        high = body_hi + abs(rng.gauss(0, vol * 0.6)) * body_hi
        low = body_lo - abs(rng.gauss(0, vol * 0.6)) * body_lo
        volume = int(math.exp(rng.gauss(13.5, 0.55)) * (1 + abs(chg) * 18))
        rows.append({"date": d.isoformat(), "open": round(openp, 2), "high": round(high, 2),
                     "low": round(low, 2), "close": round(close, 2), "volume": volume})
        price = close
    return rows


def gen_nav_series(code: str, days: int = 90, base: float = 0, vol: float = 0) -> list:
    """基金净值曲线（日频，含非交易日顺延——货币基金波动极小）。"""
    meta = next((f for f in FUNDS if f["code"] == code), None)
    base = base or (meta["base"] if meta else 1.0)
    vol = vol or (meta["vol"] if meta else 0.01)
    seed = zlib.crc32(f"nav_{code}".encode())  # ★稳定哈希（跨进程可复现）
    rng = random.Random(seed)
    today = date.today()
    rows, nav = [], base
    for i in range(days):
        d = today - timedelta(days=days - 1 - i)
        nav = max(nav * (1 + rng.gauss(0, vol) + _trend(i, seed) * 0.3), 0.05)
        rows.append({"date": d.isoformat(), "nav": round(nav, 4),
                     "acc_nav": round(nav * (1 + 0.012 * i / 365), 4)})
    return rows


def quote_snapshot() -> list:
    """行情快照：★436 优先实时引擎（日内 tick 演化）；引擎不可用时回退静态 K 线。"""
    try:
        return LIVE.quote()
    except Exception:
        out = []
        for s in STOCKS:
            kl = gen_kline(s["code"], bars=30)
            last, prev = kl[-1], kl[-2]
            chg = (last["close"] - prev["close"]) / prev["close"] * 100
            out.append({"code": s["code"], "name": s["name"], "industry": s["industry"],
                        "price": last["close"], "change_pct": round(chg, 2),
                        "high": last["high"], "low": last["low"],
                        "open": last["open"], "volume": last["volume"]})
        return out


def fund_snapshot() -> list:
    """基金快照：★436 优先实时引擎（净值微演化）；不可用时回退静态序列。"""
    try:
        return LIVE.fund()
    except Exception:
        out = []
        for f in FUNDS:
            nav = gen_nav_series(f["code"], days=14)
            last, week = nav[-1]["nav"], nav[-8]["nav"] if len(nav) > 7 else nav[0]["nav"]
            out.append({"code": f["code"], "name": f["name"], "type": f["type"], "mgr": f["mgr"],
                        "nav": last, "week_pct": round((last - week) / week * 100, 2)})
        return out


def live_price(code: str) -> float | None:
    """★436 实时成交价（股票市价委托用）：实时引擎优先，回退日线末收盘。"""
    try:
        q = LIVE.quote()
        p = next((x["price"] for x in q if x["code"] == code), None)
        if p is not None:
            return p
    except Exception:
        pass
    kl = gen_kline(code, bars=2)
    return kl[-1]["close"] if kl else None


# ★ 开盘即启动：首次 quote 才 _boot 会导致"服务刚起、第一个行情请求全是 0.0%"，
#   看起来像行情引擎坏了。模块加载完成即开盘，tick 线程随服务启动一起跑。
#   注意：必须放在 gen_kline/gen_nav_series 定义之后（_boot 依赖它们）。
try:
    LIVE.quote()
except Exception:
    pass


if __name__ == "__main__":
    # 自检：确定性（两次生成一致）+ 形态合理
    a, b = gen_kline("LM600001", 30), gen_kline("LM600001", 30)
    assert a == b, "K线生成不可复现！"
    assert all(k["high"] >= max(k["open"], k["close"]) >= min(k["open"], k["close"]) >= k["low"]
               for k in a), "OHLC 关系非法！"
    print(f"market_engine 自检 OK：{len(a)} 根 K 线，末收 {a[-1]['close']}，"
          f"基金 {len(FUNDS)} 只、股票 {len(STOCKS)} 只")
