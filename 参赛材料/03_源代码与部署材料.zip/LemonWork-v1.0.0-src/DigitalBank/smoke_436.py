# -*- coding: utf-8 -*-
"""★第436章 冒烟：动态银行全链（tick 行情 / 日切生命周期 / 异步交易 / 守恒）
═══════════════════════════════════════════════════════════════════════
1. py_compile 四文件（含 Lemon 侧技能包）
2. LiveMarket tick：两次 quote 间隔后现价演化（行情"活"）
3. 日切生命周期（SIM_DAY_SECONDS=2 加速）：利息计提 / 定期到期兑付 / 订阅扣费 / 事件流
4. 异步交易：transfer 返回 pending → 2s 后 success（处理中形态）
5. 对账守恒：日切利息+兑付+代扣+转账后账实相符（内部划转流水成对）
6. 实时成交价：股票买入价来自 tick 现价
"""
import os
import sys
import tempfile
import time

os.environ["SIM_DAY_SECONDS"] = "2"   # ★必须在 import 前：2 真实秒 = 1 银行日
os.environ["MARKET_TICK_SECONDS"] = "1"

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  {'✅' if cond else '❌'} {name}" + (f" —— {detail}" if detail else ""))


print("=" * 70)
print("第436章冒烟：动态银行（tick行情/日切生命周期/异步交易/守恒）")
print("=" * 70)

print("\n[1] py_compile")
import py_compile
for f in ("market_engine.py", "bank_core.py", "server.py"):
    try:
        py_compile.compile(os.path.join(HERE, f), doraise=True)
        check(f"compile {f}", True)
    except Exception as e:
        check(f"compile {f}", False, str(e)[:100])
try:
    py_compile.compile(r"D:\xiaomi_temp\lemon_agent\shared\skills_builtin\remote_bank_skills.py",
                       doraise=True)
    check("compile remote_bank_skills.py (Lemon侧)", True)
except Exception as e:
    check("compile remote_bank_skills.py (Lemon侧)", False, str(e)[:100])

print("\n[2] LiveMarket tick 演化")
import market_engine
q1 = market_engine.LIVE.quote()
p1 = {x["code"]: x["price"] for x in q1}
time.sleep(2.6)
q2 = market_engine.LIVE.quote()
p2 = {x["code"]: x["price"] for x in q2}
moved = sum(1 for c in p1 if p2[c] != p1[c])
check("2.1 tick 后价格演化（行情活）", moved >= 3, f"{moved}/6 只发生变动")
check("2.2 快照结构完整", all(("change_pct" in x and "volume" in x) for x in q2))
nav1 = market_engine.LIVE.nav_of("NF0003")
check("2.3 基金实时净值在场", nav1 is not None and nav1 > 0, f"NF0003 nav={nav1}")

print("\n[3] 日切生命周期（SIM_DAY_SECONDS=2）")
db = os.path.join(tempfile.gettempdir(), "bank_436_smoke.db")
if os.path.exists(db):
    os.remove(db)
for suf in ("-wal", "-shm"):
    if os.path.exists(db + suf):
        os.remove(db + suf)
import bank_core
CORE = bank_core.BankCore(db_path=db)
time.sleep(7.5)  # ≥3 个银行日（2s/日 + 启动开销）
sim = CORE.sim_info()
check("3.1 银行日推进≥2", sim["sim_day"] >= 2, sim["message"])
ev = CORE.bank_events(30)
kinds = {e["kind"] for e in ev["items"]}
check("3.2 利息计提事件", "利息" in kinds, f"事件种类: {sorted(kinds)}")
dep = CORE.deposits()
seed_matured = any(d["status"] == "已兑付" for d in dep["items"])
check("3.3 定期到期自动兑付（种子第2日到期）", seed_matured,
      "；".join(f"#{d['deposit_id']} {d['status']}" for d in dep["items"]))
sub = CORE.subscriptions()
tx = CORE.transactions(limit=40)
has_deduct = any(t["kind"] == "代扣" for t in tx["items"])
check("3.4 订阅自动扣费落流水", has_deduct)
has_int = any(t["kind"] == "利息" for t in tx["items"])
check("3.5 利息入账落流水", has_int)

print("\n[4] 异步交易状态机")
# ★用 ACC002 发起：日切代扣已让 ACC001 攒了 3 笔流水，再用它会触发高频风控（风控正确工作的副产品）
r = CORE.transfer("ACC002", "ACC004", 100_00, note="436 异步冒烟")
check("4.1 受理即返回 pending", r.get("status") == "pending", r.get("message", "")[:50])
tx_id = r.get("tx_id")
time.sleep(2.2)
after = [t for t in CORE.transactions(limit=10)["items"] if t["tx_id"] == tx_id]
check("4.2 2s 后落账 success", after and after[0]["status"] == "success")
r2 = CORE.reverse(tx_id, "436 冒 验回滚")
check("4.3 落账后可冲正", r2.get("success"), (r2.get("message") or r2.get("error", ""))[:40])

print("\n[5] 对账守恒（含日切/兑付/代扣/转账/冲正全部扰动后）")
rec = CORE.reconcile()
check("5.1 全账户账实相符", rec["balanced"],
      "；".join(f"{x['account_id']}:{'平' if x['ok'] else '不平'}" for x in rec["accounts"]))

print("\n[6] 实时成交价")
price_a = market_engine.live_price("LM600001")
price_b = market_engine.live_price("LM600001")
check("6.1 live_price 可用", price_a is not None and price_a > 0, f"LM600001={price_a}")
buyp = market_engine.live_price("LM600002")
rb = CORE.stock_buy("ACC001", "LM600002", 100)
check("6.2 股票买入成交（实时价）", rb.get("success"), (rb.get("message") or rb.get("error", ""))[:50])

print("\n" + "=" * 70)
print(f"结果: {len(PASS)} PASS / {len(FAIL)} FAIL")
if FAIL:
    print("失败项:", FAIL)
    sys.exit(1)
print("第436章冒烟全绿 ✅ —— 银行从静态沙箱升级为有生命节奏的动态银行")
