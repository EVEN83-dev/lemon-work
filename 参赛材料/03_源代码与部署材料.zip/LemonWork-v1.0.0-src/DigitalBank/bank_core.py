# -*- coding: utf-8 -*-
"""数字银行沙箱 · 账本核心（bank_core.py）
═══════════════════════════════════════════════════════════════
定位：独立可部署的银行服务模拟器核心（供 Agent 对接测试 / 教学演示）。
语义与 Lemon Agent 的 shared/mock_bank.py 对齐（五段式转账/冲正状态机/
对账守恒/风控三规则），但实现独立、零第三方依赖（仅 Python 标准库）。

金额单位：分（整数），显示时 //100 转元——避免浮点误差，银行惯例。
"""
from __future__ import annotations

import json
import os
import sqlite3
import threading
import time
from decimal import Decimal, ROUND_HALF_EVEN

import market_engine  # ★第421章 虚拟行情引擎（股票K线/基金净值）

_BANK_NAME = "数字银行沙箱"
_BANK_VERSION = "3.0.0"  # ★第437章 社会级银行（对公/发薪/税社保公积金/公共事业/收单）

_SCHEMA = """
CREATE TABLE IF NOT EXISTS accounts(
  account_id TEXT PRIMARY KEY, owner TEXT NOT NULL,
  balance INTEGER NOT NULL DEFAULT 0,   -- 分
  frozen INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS cards(
  card_no TEXT PRIMARY KEY, account_id TEXT, status TEXT, limit_amount INTEGER);
CREATE TABLE IF NOT EXISTS transactions(
  tx_id INTEGER PRIMARY KEY AUTOINCREMENT,
  from_acc TEXT, to_acc TEXT, amount INTEGER NOT NULL,
  status TEXT NOT NULL,                 -- success / reversed
  kind TEXT NOT NULL,                   -- 转账 / 冲正 / seed
  note TEXT DEFAULT '', idem_key TEXT UNIQUE,
  ts TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS risk_events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id TEXT, level TEXT, rule TEXT, detail TEXT, ts TEXT);
CREATE TABLE IF NOT EXISTS audit_log(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id TEXT, action TEXT, params TEXT,
  result TEXT, ts TEXT);
CREATE TABLE IF NOT EXISTS products(
  prod_id TEXT PRIMARY KEY, name TEXT, annual_rate REAL,
  risk_level INTEGER, term TEXT);
CREATE TABLE IF NOT EXISTS subscriptions(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id TEXT, merchant TEXT, amount INTEGER, cycle TEXT, next_charge TEXT);
CREATE TABLE IF NOT EXISTS loans(
  loan_id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id TEXT, principal INTEGER NOT NULL, rate REAL, term_months INTEGER,
  remaining INTEGER NOT NULL, status TEXT NOT NULL, ts TEXT);
CREATE TABLE IF NOT EXISTS fund_holdings(
  account_id TEXT, code TEXT, shares REAL NOT NULL, cost INTEGER NOT NULL,
  PRIMARY KEY(account_id, code));
CREATE TABLE IF NOT EXISTS stock_holdings(
  account_id TEXT, code TEXT, shares INTEGER NOT NULL, cost INTEGER NOT NULL,
  PRIMARY KEY(account_id, code));
-- ★第436章 动态银行：定期存款 / 银行动态事件 / 模拟时钟状态
CREATE TABLE IF NOT EXISTS deposits(
  deposit_id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id TEXT, prod_id TEXT, amount INTEGER NOT NULL,
  rate REAL NOT NULL, term_days INTEGER NOT NULL,
  start_day INTEGER NOT NULL, end_day INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT '存续中', ts TEXT);
CREATE TABLE IF NOT EXISTS bank_events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT NOT NULL, detail TEXT NOT NULL, ts TEXT);
CREATE TABLE IF NOT EXISTS sim_state(
  key TEXT PRIMARY KEY, value TEXT);
-- ★第438章 AI Banking 六场景积木
CREATE TABLE IF NOT EXISTS scheduled_transfers(
  st_id INTEGER PRIMARY KEY AUTOINCREMENT,
  from_acc TEXT, to_acc TEXT, amount INTEGER NOT NULL,
  note TEXT DEFAULT '', exec_day INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT '待执行', ts TEXT);
CREATE TABLE IF NOT EXISTS mall_items(
  item_id TEXT PRIMARY KEY, name TEXT NOT NULL, price INTEGER NOT NULL,
  merchant TEXT NOT NULL DEFAULT 'ACC-C002', category TEXT DEFAULT '礼品');
CREATE TABLE IF NOT EXISTS mall_orders(
  order_id INTEGER PRIMARY KEY AUTOINCREMENT,
  item_id TEXT, account TEXT, amount INTEGER NOT NULL,
  note TEXT DEFAULT '', ts TEXT);
-- ★第440章 拟真银行卡 + 业务办事流程单
CREATE TABLE IF NOT EXISTS service_orders(
  so_id INTEGER PRIMARY KEY AUTOINCREMENT,
  account TEXT NOT NULL, biz_type TEXT NOT NULL,
  title TEXT NOT NULL, steps TEXT NOT NULL,      -- JSON: [步骤名,...]
  current_step INTEGER NOT NULL DEFAULT 0,       -- 已完成步数
  payload TEXT DEFAULT '{}',                     -- JSON: 业务参数
  result TEXT DEFAULT '', status TEXT NOT NULL DEFAULT '办理中',
  created_day INTEGER, ts TEXT);
-- ★第441章 电子回执单（业务凭据）
CREATE TABLE IF NOT EXISTS receipts(
  rid INTEGER PRIMARY KEY AUTOINCREMENT,
  account TEXT NOT NULL, biz TEXT NOT NULL, title TEXT NOT NULL,
  ref TEXT NOT NULL,                             -- 关联凭据（tx_id/SO号/回执引用）
  lines TEXT NOT NULL,                           -- JSON: [[项目,值],...]
  ts TEXT NOT NULL);
"""

# ═══════════ ★第437章 社会级银行生态：主体/员工/费率（教学工具参数表） ═══════════
# 账户类型：PERSONAL 个人 / CORP 企业·商户 / GOV 政府机构
_ACC_TYPES = {
    "ACC001": "PERSONAL", "ACC002": "PERSONAL", "ACC003": "PERSONAL",
    "ACC004": "PERSONAL", "ACC005": "PERSONAL",
    "ACC-C001": "CORP", "ACC-C002": "CORP",
    "ACC-G001": "GOV", "ACC-G002": "GOV", "ACC-G003": "GOV",
    "ACC-G004": "GOV", "ACC-G005": "GOV", "ACC-G006": "GOV",
}
# 社会主体种子（企业/机构首启开户：VOID 注资，kind='seed' 不参与守恒净额双计）
_SOCIAL_SEEDS = [
    ("ACC-C001", "柠檬科技有限公司", 500000_00),   # 发薪企业 · 对公贷款对象
    ("ACC-C002", "柚子商贸行",       80000_00),     # 商户收单（市民 POS 消费流入）
    ("ACC-G001", "市自来水公司",     0),
    ("ACC-G002", "市供电公司",       0),
    ("ACC-G003", "市燃气集团",       0),
    ("ACC-G004", "市税务局",         0),
    ("ACC-G005", "市社保局",         0),
    ("ACC-G006", "市住房公积金中心", 0),
]
# 发薪名册（企业 ACC-C001 员工：月薪·分）
_EMPLOYEES = [
    ("ACC001", 8000_00), ("ACC002", 6000_00),
    ("ACC004", 6500_00), ("ACC005", 7000_00),
]
# 社保公积金费率（教学简化口径）
RATE_SOCIAL_PERSON = 0.105   # 社保个人 10.5%
RATE_SOCIAL_CORP = 0.25      # 社保企业 25%
RATE_FUND_PERSON = 0.07      # 公积金个人 7%
RATE_FUND_CORP = 0.07        # 公积金企业 7%
TAX_THRESHOLD = 5000_00      # 个税起征点（月·分）
TAX_BRACKETS = [(3000_00, 0.03), (float("inf"), 0.10)]  # 两档简化累计
PAYROLL_EVERY = 5            # 每 5 银行日发一次薪
RENT_MONTHLY = 150000        # ACC002 → 房东 ACC003 月租（分）
RENT_EVERY = 30              # 房租/公共事业周期（银行日）
SALARY_TITLES = {"ACC001": "产品经理", "ACC002": "运营专员",
                 "ACC004": "测试工程师", "ACC005": "行政专员"}

_SINGLE_LIMIT = 5000 * 100     # 单笔限额：5000 元（HIGH）
_NIGHT_LIMIT = 2000 * 100      # 夜间(22-7点)大额：2000 元（MEDIUM）

# ★第436章 动态银行参数
DEMAND_RATE = 0.30             # 活期年利率 %（日切计提）
_SIM_DAY_SECONDS = float(os.environ.get("SIM_DAY_SECONDS", "30"))  # 银行日加速：30 真实秒=1 银行日；0=真实时钟
_ASYNC_TX = os.environ.get("BANK_ASYNC_TX", "1") == "1"            # 交易异步状态机（处理中形态）
_PRODUCT_TERM_DAYS = {"90天": 90, "365天": 365, "活期": 0}          # 产品期限 → 银行日


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _yuan(fen: int) -> str:
    return f"{fen // 100}.{fen % 100:02d}"


class BankCore:
    """线程安全的账本核心（RLock 全包裹，SQLite WAL）。"""

    def __init__(self, db_path: str | None = None):
        base = os.path.dirname(os.path.abspath(__file__))
        self._path = db_path or os.path.join(base, "data", "bank.db")
        os.makedirs(os.path.dirname(self._path), exist_ok=True)
        self._lock = threading.RLock()
        self._db = sqlite3.connect(self._path, check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.executescript(_SCHEMA)
        self._migrate_438()             # ★438 老库增量迁移（phone/birthday/订阅状态列）
        self._db.commit()
        self._seed_if_empty()
        self._seed_dynamic_if_empty()   # ★436 动态银行种子（定期/时钟状态）
        self._seed_social_if_empty()    # ★437 社会主体开户（企业/商户/政府机构）
        self._seed_438_if_empty()       # ★438 手机号/生日/商场商品
        self._start_lifecycle()         # ★436 后台生命周期（日切：利息/到期/扣费/计息）

    # ---------- ★第436章 动态银行：种子 / 事件 / 模拟时钟 / 日切生命周期 ----------
    def _seed_dynamic_if_empty(self):
        """436 种子（独立幂等——老库升级也生效）：
        sim_day 状态初始化 + 给 ACC001 一笔 88 银行日前存的 90 天定期
        （→ 开服约 2 个银行日后到期兑付，演示"理财到期自动入账"动态形态）。"""
        with self._lock:
            self._db.execute(
                "INSERT OR IGNORE INTO sim_state(key,value) VALUES('sim_day','0')")
            self._db.execute(
                "INSERT OR IGNORE INTO sim_state(key,value) VALUES('day_seconds',?)",
                (str(_SIM_DAY_SECONDS),))
            n = self._db.execute("SELECT COUNT(*) c FROM deposits").fetchone()["c"]
            if n == 0:
                self._db.execute(
                    "INSERT INTO deposits(account_id,prod_id,amount,rate,term_days,"
                    "start_day,end_day,status,ts) VALUES('ACC001','P002',8000_00,3.2,90,"
                    "-88,2,'存续中',?)", (_now(),))
                self._event("系统", "动态银行初始化",
                            "定期存款种子就位（8000 元 · 90天 · 第 2 银行日到期自动兑付）")
            self._db.commit()

    def _event(self, kind: str, title: str, detail: str):
        """动态事件流（日切/利息/到期/扣费/异动——银行'活着'的证据链）。"""
        self._db.execute("INSERT INTO bank_events(kind,detail,ts) VALUES(?,?,?)",
                         (kind, f"{title}｜{detail}", _now()))

    # ---------- ★第437章 社会级生态：主体开户 / 代发工资 / 公共事业 / 商户收单 ----------
    def _seed_social_if_empty(self):
        """437 社会主体开户（独立幂等）：企业/商户/政府机构 + VOID 注资流水（kind='seed'）。"""
        with self._lock:
            created = []
            for aid, owner, bal in _SOCIAL_SEEDS:
                if self._db.execute("SELECT 1 FROM accounts WHERE account_id=?", (aid,)).fetchone():
                    continue
                self._db.execute(
                    "INSERT INTO accounts(account_id,owner,balance,frozen) VALUES(?,?,?,0)",
                    (aid, owner, bal))
                if bal > 0:  # 注资流水（seed 不参与守恒净额双计，reconcile 排除）
                    self._db.execute(
                        "INSERT INTO transactions(from_acc,to_acc,amount,status,kind,note,ts)"
                        " VALUES('VOID', ?, ?, 'success', 'seed', '开户注资', ?)",
                        (aid, bal, _now()))
                created.append(f"{owner}({aid})")
            if created:
                self._event("社会开户", "对公/机构主体入网",
                            "、".join(created) + "——社会资金循环启动")
            self._db.commit()

    def _social_transfer(self, from_acc: str, to_acc: str, amount: int,
                         kind: str, note: str):
        """社会资金流内部划转（绕过零售风控——对公/机构/代收为银行受理业务）。"""
        self._db.execute("UPDATE accounts SET balance=balance-? WHERE account_id=?",
                         (amount, from_acc))
        self._db.execute("UPDATE accounts SET balance=balance+? WHERE account_id=?",
                         (amount, to_acc))
        self._db.execute(
            "INSERT INTO transactions(from_acc,to_acc,amount,status,kind,note,ts)"
            " VALUES(?,?,?,?,?,?,?)", (from_acc, to_acc, amount, "success", kind, note, _now()))

    def _income_tax(self, taxable: int) -> int:
        """个税两档简化累计（应税=月薪−起征−社保−公积金；单位分）。"""
        if taxable <= 0:
            return 0
        tax = 0
        left = taxable
        for cap, rate in TAX_BRACKETS:
            seg = min(left, cap)
            if seg <= 0:
                break
            tax += int(seg * rate)
            left -= seg
        return tax

    def _payroll(self, day: int):
        """★代发工资（每 PAYROLL_EVERY 银行日）：企业→员工四分流——
        工资净额入个人户；个税→税务局；社保(个人+企业)→社保局；公积金(个人+企业)→公积金中心。"""
        total_gross = total_tax = total_social = total_fund = total_net = 0
        lines = []
        for aid, gross in _EMPLOYEES:
            social_p = int(gross * RATE_SOCIAL_PERSON)
            fund_p = int(gross * RATE_FUND_PERSON)
            social_c = int(gross * RATE_SOCIAL_CORP)
            fund_c = int(gross * RATE_FUND_CORP)
            tax = self._income_tax(gross - TAX_THRESHOLD - social_p - fund_p)
            net = gross - social_p - fund_p - tax
            title = SALARY_TITLES.get(aid, "员工")
            owner = self._db.execute("SELECT owner FROM accounts WHERE account_id=?",
                                     (aid,)).fetchone()["owner"]
            self._social_transfer("ACC-C001", aid, net, "工资",
                                  f"{title} {owner} 代发工资（税后）")
            if tax > 0:
                self._social_transfer(aid, "ACC-G004", tax, "个税代扣",
                                      f"{owner} 工资个税（两档累计）")
            if social_p > 0:
                self._social_transfer(aid, "ACC-G005", social_p, "社保代扣",
                                      f"{owner} 社保个人部分")
            if fund_p > 0:
                self._social_transfer(aid, "ACC-G006", fund_p, "公积金代扣",
                                      f"{owner} 公积金个人部分")
            if social_c > 0:
                self._social_transfer("ACC-C001", "ACC-G005", social_c, "社保缴存",
                                      "企业部分")
            if fund_c > 0:
                self._social_transfer("ACC-C001", "ACC-G006", fund_c, "公积金缴存",
                                      "企业部分")
            total_gross += gross
            total_tax += tax
            total_social += social_p + social_c
            total_fund += fund_p + fund_c
            total_net += net
            lines.append(f"{owner} 税后 {_yuan(net)} 元")
        # 企业侧总支出 = Σ税后净额（工资从企业户出）+ 企业社保 + 企业公积金
        # （个人社保/公积金/个税由员工户分流至机构户，不重复计企业成本）
        self._event("代发工资", f"第 {day} 银行日发薪（{len(_EMPLOYEES)} 名员工）",
                    f"毛薪 {_yuan(total_gross)} 元｜个税入库 {_yuan(total_tax)} 元｜"
                    f"社保归集 {_yuan(total_social)} 元｜公积金归集 {_yuan(total_fund)} 元｜"
                    + "；".join(lines))

    def _utilities(self, day: int):
        """★公共事业代收（每 RENT_EVERY 银行日）：水/电/燃气随机账单自动扣缴。"""
        import random as _r
        bills = [("ACC-G001", "水费", 2000, 8000),
                 ("ACC-G002", "电费", 5000, 20000),
                 ("ACC-G003", "燃气费", 3000, 9000)]
        payers = [a for a, _ in _EMPLOYEES] + ["ACC003"]
        lines = []
        for gov, name, lo, hi in bills:
            sum_amt = 0
            for aid in payers:
                amt = _r.randint(lo, hi)
                acc = self._db.execute("SELECT balance,owner FROM accounts WHERE account_id=?",
                                       (aid,)).fetchone()
                if acc["balance"] < amt:
                    self._risk_event(aid, "MEDIUM", "代收失败",
                                     f"{name} {_yuan(amt)} 元余额不足，待补缴")
                    continue
                self._social_transfer(aid, gov, amt, "公共事业", f"{name} 自动代收")
                sum_amt += amt
                lines.append(f"{acc['owner']}{name} {_yuan(amt)} 元")
            if sum_amt:
                lines.append(f"{name}合计 {_yuan(sum_amt)} 元入 {gov}")
        # 房租（生活服务：租客→房东）
        rent_ok = True
        acc2 = self._db.execute("SELECT balance FROM accounts WHERE account_id='ACC002'").fetchone()
        if acc2 and acc2["balance"] >= RENT_MONTHLY:
            self._social_transfer("ACC002", "ACC003", RENT_MONTHLY, "房租",
                                  "月度房租（柚子小区）")
            lines.append(f"房租 {_yuan(RENT_MONTHLY)} 元（妈妈→房东）")
        else:
            rent_ok = False
        self._event("公共事业", f"第 {day} 银行日代收批次", "；".join(lines) if lines else "本期无账单")

    def _consumption(self, day: int):
        """★商户收单生态（每银行日）：市民随机 POS 消费 → 商户户，让'人口'活起来。"""
        import random as _r
        payers = [a for a, _ in _EMPLOYEES] + ["ACC003"]
        n = _r.randint(3, 6)
        sum_amt, done = 0, []
        for _ in range(n):
            aid = _r.choice(payers)
            amt = _r.randint(800, 30000)
            acc = self._db.execute("SELECT balance,owner FROM accounts WHERE account_id=?",
                                   (aid,)).fetchone()
            if acc["balance"] < amt:
                continue
            self._social_transfer(aid, "ACC-C002", amt, "POS消费",
                                  f"柚子超市·{acc['owner']} 刷卡消费")
            sum_amt += amt
            done.append(f"{acc['owner']} {_yuan(amt)} 元")
        if done:
            self._event("商户收单", f"第 {day} 银行日 柚子商贸行收单 {len(done)} 笔",
                        f"合计 {_yuan(sum_amt)} 元｜" + "；".join(done))

    def corp_accounts(self) -> dict:
        """★437 对公/机构主体一览（企业+政府，含类型/余额/近期流向）。"""
        with self._lock:
            rows = self._db.execute(
                "SELECT * FROM accounts WHERE account_id LIKE 'ACC-C%' OR account_id LIKE 'ACC-G%'"
                " ORDER BY account_id").fetchall()
            items = []
            for r in rows:
                inflow = self._db.execute(
                    "SELECT COALESCE(SUM(amount),0) s FROM transactions WHERE to_acc=?"
                    " AND status='success' AND kind NOT IN ('冲正','seed')", (r["account_id"],)).fetchone()["s"]
                items.append({"account_id": r["account_id"], "owner": r["owner"],
                              "acc_type": _ACC_TYPES.get(r["account_id"], "PERSONAL"),
                              "balance": r["balance"], "balance_yuan": _yuan(r["balance"]),
                              "cumulative_inflow": inflow,
                              "cumulative_inflow_yuan": _yuan(inflow)})
            return {"success": True, "count": len(items), "items": items}

    def social_summary(self) -> dict:
        """★437 社会服务统计：工资/税/社保/公积金/公共事业/消费各口径累计+近期事件。"""
        with self._lock:
            def _sum(kind, direction):
                col = "to_acc" if direction == "in" else "from_acc"
                target = {"税": "ACC-G004", "社保": "ACC-G005", "公积金": "ACC-G006",
                          "工资": None, "公共事业": None, "POS消费": "ACC-C002",
                          "房租": "ACC003"}.get(kind)
                if target:
                    return self._db.execute(
                        f"SELECT COALESCE(SUM(amount),0) s FROM transactions WHERE kind=?"
                        f" AND {col}=? AND status='success'", (kind, target)).fetchone()["s"]
                return self._db.execute(
                    f"SELECT COALESCE(SUM(amount),0) s FROM transactions WHERE kind=?"
                    f" AND status='success'", (kind,)).fetchone()["s"]
            ev = self._db.execute(
                "SELECT * FROM bank_events WHERE kind IN ('代发工资','公共事业','商户收单','对公贷款')"
                " ORDER BY id DESC LIMIT 8").fetchall()
            return {"success": True,
                    "stats": {
                        "工资发放": _sum("工资", "in"),
                        "个税入库": _sum("个税代扣", "in"),
                        "社保归集": _sum("社保代扣", "in") + _sum("社保缴存", "in"),
                        "公积金归集": _sum("公积金代扣", "in") + _sum("公积金缴存", "in"),
                        "公共事业代收": _sum("公共事业", "in"),
                        "商户收单": _sum("POS消费", "in"),
                        "房租": _sum("房租", "in"),
                    },
                    "recent": [dict(e) for e in ev],
                    "message": "社会服务统计（累计口径）"}

    # ---------- ★第438章 AI Banking 六场景积木：迁移 / 种子 / 查询 / 操作 ----------
    _PHONES = {
        "ACC001": "138-2000-0001", "ACC002": "139-2000-0002",
        "ACC003": "137-2000-0003", "ACC004": "136-2000-0004",
        "ACC005": "135-2000-0005",
    }

    def _migrate_438(self):
        """老库增量迁移：accounts.phone / accounts.birthday / subscriptions.status。"""
        for tbl, col, ddl in (
                ("accounts", "phone", "TEXT DEFAULT ''"),
                ("accounts", "birthday", "TEXT DEFAULT ''"),
                ("subscriptions", "status", "TEXT DEFAULT 'active'")):
            cols = {r["name"] for r in self._db.execute(f"PRAGMA table_info({tbl})")}
            if col not in cols:
                self._db.execute(f"ALTER TABLE {tbl} ADD COLUMN {col} {ddl}")
        # ★440 拟真银行卡列：有效期/CVV/持卡人/发卡时间
        for col, ddl in (("expiry", "TEXT DEFAULT ''"), ("cvv", "TEXT DEFAULT ''"),
                         ("holder", "TEXT DEFAULT ''"), ("issued", "TEXT DEFAULT ''")):
            cols = {r["name"] for r in self._db.execute("PRAGMA table_info(cards)")}
            if col not in cols:
                self._db.execute(f"ALTER TABLE cards ADD COLUMN {col} {ddl}")
        # ★442 微信绑定
        cols = {r["name"] for r in self._db.execute("PRAGMA table_info(accounts)")}
        if "wx" not in cols:
            self._db.execute("ALTER TABLE accounts ADD COLUMN wx TEXT DEFAULT ''")
        # 老卡回填（幂等）
        import random as _r
        for c in self._db.execute("SELECT card_no,account_id FROM cards WHERE expiry=''").fetchall():
            owner = self._db.execute("SELECT owner FROM accounts WHERE account_id=?",
                                     (c["account_id"],)).fetchone()
            self._db.execute(
                "UPDATE cards SET expiry=?, cvv=?, holder=?, issued=? WHERE card_no=?",
                ("12/29", f"{_r.randint(100,999)}",
                 (owner["owner"] if owner else "CUSTOMER"), _now(), c["card_no"]))

    def _seed_438_if_empty(self):
        """438 种子（幂等）：手机号/生日（妈妈生日=2 天后，跨场景演示钩子）/
        商户商品（鲜花/蛋糕/贺卡）。"""
        with self._lock:
            for aid, ph in self._PHONES.items():
                self._db.execute("UPDATE accounts SET phone=? WHERE account_id=? AND (phone='' OR phone IS NULL)",
                                 (ph, aid))
            if not self._db.execute(
                    "SELECT 1 FROM accounts WHERE account_id='ACC002' AND birthday!=''").fetchone():
                mmdd = time.strftime("%m-%d", time.localtime(time.time() + 2 * 86400))
                self._db.execute("UPDATE accounts SET birthday=? WHERE account_id='ACC002'", (mmdd,))
            if self._db.execute("SELECT COUNT(*) c FROM mall_items").fetchone()["c"] == 0:
                for iid, n, p, cat in (("M001", "生日鲜花花束", 9900, "鲜花"),
                                        ("M002", "生日蛋糕（8寸）", 19800, "蛋糕"),
                                        ("M003", "手工贺卡", 990, "礼品")):
                    self._db.execute("INSERT INTO mall_items VALUES(?,?,?,?,?)",
                                     (iid, n, p, "ACC-C002", cat))
            self._db.commit()

    def find_account(self, query: str) -> dict:
        """★场景1 智能转账解析：按账号/户名/手机号模糊定位收款人。"""
        q = (query or "").strip()
        if not q:
            return {"success": False, "error": "请提供人名/手机号/账号"}
        with self._lock:
            rows = self._db.execute(
                "SELECT account_id,owner,phone FROM accounts WHERE"
                " account_id LIKE ? OR owner LIKE ? OR phone LIKE ?",
                (f"%{q}%", f"%{q}%", f"%{q}%")).fetchall()
            items = [{"account_id": r["account_id"], "owner": r["owner"], "phone": r["phone"]}
                     for r in rows]
            return {"success": True, "query": q, "count": len(items), "items": items,
                    "message": (f"找到 {len(items)} 个匹配主体" if items
                                else f"未找到与「{q}」匹配的收款人（可按人名/手机号/账号检索）")}

    def schedule_transfer(self, from_acc: str, to_acc: str, amount: int,
                          after_days: int, note: str = "") -> dict:
        """★场景1 定时转账：N 个银行日后自动执行（日切引擎驱动）。"""
        amount = int(amount)
        if amount <= 0:
            return {"success": False, "error": "金额必须为正"}
        if not self._db.execute("SELECT 1 FROM accounts WHERE account_id=?", (from_acc,)).fetchone() \
                or not self._db.execute("SELECT 1 FROM accounts WHERE account_id=?", (to_acc,)).fetchone():
            return {"success": False, "error": "付款或收款账户不存在"}
        day = int(self._sim_get("sim_day", "0"))
        cur = self._db.execute(
            "INSERT INTO scheduled_transfers(from_acc,to_acc,amount,note,exec_day,status,ts)"
            " VALUES(?,?,?,?,?,'待执行',?)",
            (from_acc, to_acc, amount, note, day + max(int(after_days), 0), _now()))
        self._audit(from_acc, "schedule_transfer",
                    {"to": to_acc, "amount": amount, "after_days": after_days},
                    f"定时转账预约 st{cur.lastrowid}")
        self._event("定时转账", f"预约 st{cur.lastrowid}",
                    f"{from_acc}→{to_acc} {_yuan(amount)} 元，第 {day + max(int(after_days), 0)} 银行日执行")
        self._db.commit()
        return {"success": True, "st_id": cur.lastrowid, "exec_day": day + max(int(after_days), 0),
                "message": f"定时转账已预约：第 {day + max(int(after_days), 0)} 银行日"
                           f"向 {to_acc} 转 {_yuan(amount)} 元"}

    def scheduled_list(self, account_id: str = "") -> dict:
        with self._lock:
            if account_id:
                rows = self._db.execute(
                    "SELECT * FROM scheduled_transfers WHERE from_acc=? OR to_acc=?"
                    " ORDER BY st_id DESC", (account_id, account_id)).fetchall()
            else:
                rows = self._db.execute(
                    "SELECT * FROM scheduled_transfers ORDER BY st_id DESC").fetchall()
            return {"success": True, "items": [dict(r) | {"amount_yuan": _yuan(r["amount"])}
                                                for r in rows]}

    def aa_collect(self, from_acc: str, members: list, amount_each: int, note: str = "") -> dict:
        """★场景1 拆分AA收款：向多名成员各收 amount_each（发起人=payer）。"""
        amount_each = int(amount_each)
        if amount_each <= 0 or not members:
            return {"success": False, "error": "需要 members（参与人账号列表）和正数 amount_each"}
        ok_list, fail_list = [], []
        for m in members:
            r = self.transfer(str(m).strip(), from_acc, amount_each,
                              note=f"AA收款·{note}" if note else "AA收款",
                              _bypass_risk=True)  # 批量业务指令，绕零售高频窗口
            (ok_list if r.get("success") else fail_list).append(
                f"{m}:{'成功' if r.get('success') else r.get('error', '失败')}")
        return {"success": len(fail_list) == 0,
                "collected": amount_each * len(ok_list),
                "ok": ok_list, "failed": fail_list,
                "message": (f"AA 收款完成：{len(ok_list)}/{len(members)} 人各 {_yuan(amount_each)} 元"
                            + (f"；失败：{'；'.join(fail_list)}" if fail_list else ""))}

    def bill_summary(self, account_id: str = "ACC001", days: int = 30) -> dict:
        """★场景2 账单分析：收支分类统计。"""
        with self._lock:
            rows = self._db.execute(
                "SELECT kind,from_acc,to_acc,amount FROM transactions"
                " WHERE (from_acc=? OR to_acc=?) AND status='success'",
                (account_id, account_id)).fetchall()
            cats, income, expense = {}, 0, 0
            for r in rows:
                if r["to_acc"] == account_id and r["from_acc"] != account_id:
                    cats[r["kind"]] = cats.get(r["kind"], 0) + r["amount"]
                    income += r["amount"]
                elif r["from_acc"] == account_id:
                    k = "消费" if r["kind"] in ("POS消费",) else r["kind"]
                    cats[k] = cats.get(k, 0) - r["amount"]
                    expense += r["amount"]
            items = sorted(({"kind": k, "net": v} for k, v in cats.items()),
                           key=lambda x: -abs(x["net"]))
            return {"success": True, "account": account_id,
                    "total_income": income, "total_income_yuan": _yuan(income),
                    "total_expense": expense, "total_expense_yuan": _yuan(expense),
                    "categories": items,
                    "message": f"累计：收入 {_yuan(income)} 元 / 支出 {_yuan(expense)} 元，"
                               f"共 {len(items)} 类"}

    def bill_anomalies(self, account_id: str = "ACC001") -> dict:
        """★场景2 异常交易识别：大额偏离 3 倍/单日高频/风控命中。"""
        with self._lock:
            rows = self._db.execute(
                "SELECT * FROM transactions WHERE (from_acc=? OR to_acc=?)"
                " AND status='success' AND kind IN ('转账','POS消费')"
                " ORDER BY tx_id DESC LIMIT 60", (account_id, account_id)).fetchall()
            if not rows:
                return {"success": True, "count": 0, "items": [], "message": "近期无交易"}
            avg = sum(r["amount"] for r in rows) / len(rows)
            out, seen_day = [], {}
            for r in rows:
                tag = []
                if r["amount"] > avg * 3 and r["amount"] > 100000:
                    tag.append(f"单笔 {_yuan(r['amount'])} 元超均值 3 倍")
                d = r["ts"][:10]
                seen_day[d] = seen_day.get(d, 0) + 1
                if seen_day[d] >= 3:
                    tag.append("单日高频（≥3 笔）")
                if tag:
                    out.append({"tx_id": r["tx_id"], "amount_yuan": _yuan(r["amount"]),
                                "note": r["note"], "ts": r["ts"], "flags": tag})
            rk = self._db.execute(
                "SELECT * FROM risk_events WHERE account_id=? ORDER BY id DESC LIMIT 5",
                (account_id,)).fetchall()
            return {"success": True, "count": len(out), "items": out[:10],
                    "risk_hits": [dict(x) for x in rk],
                    "message": f"识别 {len(out)} 笔异常交易（另有 {len(rk)} 条风控命中记录）"}

    def risk_assess(self, account_id: str, answers: list) -> dict:
        """★场景3 风险评估：1-5 分答案均值 → R1-R5 等级（存档）。"""
        try:
            vals = [max(1, min(5, int(x))) for x in answers][:10]
            if not vals:
                raise ValueError
            level = round(sum(vals) / len(vals))
        except (ValueError, TypeError):
            return {"success": False, "error": "answers 需为 1-5 分数组（如 [3,4,4,2]）"}
        names = {1: "R1 保守型", 2: "R2 稳健型", 3: "R3 平衡型",
                 4: "R4 成长型", 5: "R5 进取型"}
        self._sim_set(f"risk_level_{account_id}", str(level))
        self._audit(account_id, "risk_assess", {"answers": vals}, names[level])
        self._db.commit()
        return {"success": True, "account": account_id, "level": level,
                "risk_level": names[level],
                "message": f"风险评估完成：{names[level]}（可推荐 R{level} 及以下产品）"}

    def product_recommend(self, account_id: str = "ACC001") -> dict:
        """★场景3 产品推荐与对比：按风险等级匹配 + 万元 90 天复利预期收益。"""
        with self._lock:
            lv = int(self._sim_get(f"risk_level_{account_id}", "3") or 3)
        recs = []
        for p in self.products()["items"]:
            if p["risk_level"] <= lv:
                comp = self.compound(10000, p["annual_rate"], 90)
                recs.append({"prod_id": p["prod_id"], "name": p["name"],
                             "annual_rate": p["annual_rate"], "risk_level": p["risk_level"],
                             "term": p["term"], "term_days": _PRODUCT_TERM_DAYS.get(p["term"], 0),
                             "yuan_1w_90d_interest": comp.get("interest_yuan")})
        recs.sort(key=lambda x: -x["annual_rate"])
        return {"success": True, "account": account_id, "risk_level": lv,
                "items": recs,
                "message": f"按 R{lv} 风险等级推荐 {len(recs)} 款产品（万元 90 天复利参考收益已附）"}

    def card_list(self, account_id: str = "ACC001") -> dict:
        with self._lock:
            rows = self._db.execute("SELECT * FROM cards WHERE account_id=?",
                                    (account_id,)).fetchall()
            return {"success": True, "count": len(rows), "items": [dict(r) for r in rows]}

    def card_apply(self, account_id: str) -> dict:
        """★场景4 卡申请（即时核发）：拟真卡号四位分组 + 有效期/CVV/持卡人。"""
        with self._lock:
            if not self._db.execute("SELECT 1 FROM accounts WHERE account_id=?",
                                    (account_id,)).fetchone():
                return {"success": False, "error": "账户不存在"}
            import random as _r
            raw = f"6222880{int(time.time()) % 10000000:07d}{_r.randint(10, 99)}"
            no = " ".join(raw[i:i + 4] for i in range(0, 16, 4))
            owner = self._db.execute("SELECT owner FROM accounts WHERE account_id=?",
                                     (account_id,)).fetchone()["owner"]
            self._db.execute(
                "INSERT INTO cards(card_no,account_id,status,limit_amount,expiry,cvv,holder,issued)"
                " VALUES(?,?,?,?,?,?,?,?)",
                (no, account_id, "正常", 5000_00, "12/29", f"{_r.randint(100, 999)}",
                 owner, _now()))
            self._event("卡片管理", f"{account_id} 新卡核发", f"卡号 {no}（额度 5000 元）")
            self._db.commit()
            return {"success": True, "card_no": no,
                    "message": f"已为您核发银行卡 {no}（有效期 12/29，初始额度 5000 元，状态正常）"}

    # ---------- ★第440章 业务办事流程单（申请→审核→办理→生效，日切逐步推进） ----------
    _BIZ_TEMPLATES = {
        "card_apply": ("银行卡申请", ["提交申请", "银行审核", "制卡中", "发卡激活"]),
        "card_reissue": ("挂失补卡", ["挂失登记", "风险审核", "制新卡", "新卡发放·旧卡作废"]),
        "loan_apply": ("贷款申请", ["提交申请", "授信评估", "签约确认", "放款入账"]),
        "sub_cancel": ("订阅退订", ["退订申请", "确认处理", "退订生效"]),
        "open_account": ("注册开户", ["提交开户申请", "身份核验", "开户审核", "开户成功·发放开户礼"]),
    }

    def create_service_order(self, account_id: str, biz_type: str,
                             payload: dict | None = None) -> dict:
        """★440 提交业务办事单：按模板生成步骤，日切引擎每日推进一步。"""
        tpl = self._BIZ_TEMPLATES.get(biz_type)
        if tpl is None:
            return {"success": False,
                    "error": f"biz_type 需为 {list(self._BIZ_TEMPLATES)}"}
        with self._lock:
            if not self._db.execute("SELECT 1 FROM accounts WHERE account_id=?",
                                    (account_id,)).fetchone():
                return {"success": False, "error": "账户不存在"}
            day = int(self._sim_get("sim_day", "0"))
            cur = self._db.execute(
                "INSERT INTO service_orders(account,biz_type,title,steps,current_step,"
                "payload,status,created_day,ts) VALUES(?,?,?,?,?,?, '办理中', ?, ?)",
                (account_id, biz_type, tpl[0], json_dumps(list(tpl[1])), 0,
                 json_dumps(payload or {}), day, _now()))
            self._event("业务办理", f"{tpl[0]} 受理（单号 SO{cur.lastrowid}）",
                        f"{account_id} 已提交，流程共 {len(tpl[1])} 步（每银行日推进一步）")
            self._db.commit()
            return {"success": True, "so_id": cur.lastrowid, "biz_type": biz_type,
                    "steps": list(tpl[1]), "current_step": 0,
                    "message": f"{tpl[0]}已受理（SO{cur.lastrowid}）："
                               f"{'→'.join(tpl[1])}，每银行日自动推进"}

    def service_orders(self, account_id: str = "") -> dict:
        with self._lock:
            if account_id:
                rows = self._db.execute(
                    "SELECT * FROM service_orders WHERE account=? ORDER BY so_id DESC",
                    (account_id,)).fetchall()
            else:
                rows = self._db.execute(
                    "SELECT * FROM service_orders ORDER BY so_id DESC").fetchall()
            items = []
            for r in rows:
                m = dict(r)
                m["steps"] = json.loads(m["steps"])
                m["payload"] = json.loads(m["payload"] or "{}")
                items.append(m)
            return {"success": True, "items": items}

    def _advance_service_orders(self, day: int):
        """★440 日切推进办事单：每单每日进一步；末步落地真实业务效果。"""
        for so in self._db.execute(
                "SELECT * FROM service_orders WHERE status='办理中'").fetchall():
            steps = json.loads(so["steps"])
            payload = json.loads(so["payload"] or "{}")
            nxt = so["current_step"] + 1
            result_note = ""
            if nxt >= len(steps):  # 末步：真实生效
                acc, effect = so["account"], "完成"
                if so["biz_type"] == "card_apply":
                    r = self.card_apply(acc)
                    effect = f"已核发 {r.get('card_no', '')}"
                elif so["biz_type"] == "card_reissue":
                    old = payload.get("card_no")
                    if old:
                        self.card_op(old, "loss", None)
                    r = self.card_apply(acc)
                    effect = f"旧卡 {old} 作废，新卡 {r.get('card_no', '')} 已发放"
                elif so["biz_type"] == "loan_apply":
                    r = self.apply_loan(acc, float(payload.get("amount_yuan", 0)),
                                        int(payload.get("term_months", 12)))
                    effect = (f"放款成功 {r.get('amount_yuan', '')} 元" if r.get("success")
                              else f"放款失败：{r.get('reason') or r.get('error', '')}")
                    result_note = r.get("message") or r.get("reason") or r.get("error", "")
                elif so["biz_type"] == "sub_cancel":
                    r = self.subscription_cancel(int(payload.get("sub_id", 0)))
                    effect = r.get("message", "已退订")
                elif so["biz_type"] == "open_account":
                    effect = self._finalize_open_account(payload)
                self._db.execute(
                    "UPDATE service_orders SET current_step=?, status='办结', result=?"
                    " WHERE so_id=?", (len(steps), result_note or effect, so["so_id"]))
                self._event("业务办结", f"SO{so['so_id']} {so['title']}办结", effect)
            else:
                self._db.execute(
                    "UPDATE service_orders SET current_step=? WHERE so_id=?",
                    (nxt, so["so_id"]))
                self._event("业务办理", f"SO{so['so_id']} 进度：{steps[nxt - 1]} 完成",
                            f"当前步骤 {nxt}/{len(steps)}")

    def card_op(self, card_no: str, action: str, value=None) -> dict:
        """★场景4 卡片管理统一入口：limit(调额)/restrict(限制)/unrestrict(解锁)/loss(挂失)。"""
        with self._lock:
            card = self._db.execute("SELECT * FROM cards WHERE card_no=?", (card_no,)).fetchone()
            if card is None:
                return {"success": False, "error": f"卡 {card_no} 不存在"}
            if action == "limit":
                v = int(value or 0)
                if v <= 0:
                    return {"success": False, "error": "额度需为正数（分）"}
                self._db.execute("UPDATE cards SET limit_amount=? WHERE card_no=?", (v, card_no))
                msg = f"卡 {card_no} 额度已调整为 {_yuan(v)} 元"
            elif action == "restrict":
                self._db.execute("UPDATE cards SET status='交易限制' WHERE card_no=?", (card_no,))
                msg = f"卡 {card_no} 已限制交易（可随时解锁）"
            elif action == "unrestrict":
                self._db.execute("UPDATE cards SET status='正常' WHERE card_no=?", (card_no,))
                msg = f"卡 {card_no} 已解除限制"
            elif action == "loss":
                self._db.execute("UPDATE cards SET status='挂失' WHERE card_no=?", (card_no,))
                msg = f"卡 {card_no} 已挂失（挂失卡不可交易，可申请补卡）"
            else:
                return {"success": False, "error": "action 需为 limit/restrict/unrestrict/loss"}
            self._event("卡片管理", action, msg)
            self._db.commit()
            return {"success": True, "message": msg}

    def subscription_cancel(self, sub_id: int) -> dict:
        """★场景5 一键取消订阅。"""
        with self._lock:
            s = self._db.execute("SELECT * FROM subscriptions WHERE id=?", (sub_id,)).fetchone()
            if s is None:
                return {"success": False, "error": f"订阅 {sub_id} 不存在"}
            if s["status"] != "active":
                return {"success": False, "error": "订阅已取消"}
            self._db.execute("UPDATE subscriptions SET status='cancelled' WHERE id=?", (sub_id,))
            self._event("订阅管理", f"取消订阅：{s['merchant']}",
                        f"{s['account_id']} 已退订（月费 {_yuan(s['amount'])} 元不再扣取）")
            self._db.commit()
            return {"success": True,
                    "message": f"已取消「{s['merchant']}」订阅（{_yuan(s['amount'])} 元/期），"
                               f"下期起不再扣费"}

    def mall_items(self) -> dict:
        with self._lock:
            rows = self._db.execute("SELECT * FROM mall_items").fetchall()
            return {"success": True, "items": [dict(r) | {"price_yuan": _yuan(r["price"])}
                                                for r in rows]}

    def mall_order(self, item_id: str, account_id: str, note: str = "") -> dict:
        """★场景6 跨场景商品下单：鲜花/蛋糕/贺卡 → 商户收款 + 订购事件。"""
        with self._lock:
            item = self._db.execute("SELECT * FROM mall_items WHERE item_id=?", (item_id,)).fetchone()
            acc = self._db.execute("SELECT * FROM accounts WHERE account_id=?",
                                   (account_id,)).fetchone()
            if item is None or acc is None:
                return {"success": False, "error": "商品或账户不存在"}
            if acc["balance"] < item["price"]:
                return {"success": False, "error": (f"余额不足：需 {_yuan(item['price'])} 元"
                                                    f"（{item['name']}）")}
            self._social_transfer(account_id, item["merchant"], item["price"],
                                  "POS消费", f"商城订购·{item['name']}")
            cur = self._db.execute(
                "INSERT INTO mall_orders(item_id,account,amount,note,ts) VALUES(?,?,?,?,?)",
                (item_id, account_id, item["price"], note, _now()))
            self._event("商品订购", f"{acc['owner']} 订购 {item['name']}",
                        f"{_yuan(item['price'])} 元（订单 {cur.lastrowid}）"
                        + (f"｜备注：{note}" if note else ""))
            self._db.commit()
            return {"success": True, "order_id": cur.lastrowid, "item": item["name"],
                    "price_yuan": _yuan(item["price"]),
                    "message": f"已下单「{item['name']}」（{_yuan(item['price'])} 元，"
                               f"柚子商贸行配送）"}

    def birthdays(self) -> dict:
        """★场景6 生日档案（跨场景联动的检测源）。"""
        with self._lock:
            rows = self._db.execute(
                "SELECT account_id,owner,birthday,phone FROM accounts"
                " WHERE birthday!='' ORDER BY birthday").fetchall()
            return {"success": True, "items": [dict(r) for r in rows]}

    # ---------- ★第441章 现金存取 + 电子回执单（业务反馈载体） ----------
    def _receipt(self, account: str, biz: str, title: str, ref: str,
                 lines: list) -> int:
        """电子回执：核心业务的正式凭据（盖章回单）。"""
        cur = self._db.execute(
            "INSERT INTO receipts(account,biz,title,ref,lines,ts) VALUES(?,?,?,?,?,?)",
            (account, biz, title, ref, json_dumps(lines), _now()))
        return cur.lastrowid

    def receipt(self, rid: int) -> dict:
        with self._lock:
            r = self._db.execute("SELECT * FROM receipts WHERE rid=?", (rid,)).fetchone()
            if r is None:
                return {"success": False, "error": f"回执 {rid} 不存在"}
            m = dict(r)
            m["lines"] = json.loads(m["lines"])
            return {"success": True, **m}

    def receipts(self, account_id: str = "", limit: int = 20) -> dict:
        with self._lock:
            if account_id:
                rows = self._db.execute(
                    "SELECT rid,biz,title,ref,ts FROM receipts WHERE account=?"
                    " ORDER BY rid DESC LIMIT ?", (account_id, limit)).fetchall()
            else:
                rows = self._db.execute(
                    "SELECT rid,biz,title,ref,ts FROM receipts"
                    " ORDER BY rid DESC LIMIT ?", (limit,)).fetchall()
            return {"success": True, "items": [dict(r) for r in rows]}

    def deposit_cash(self, account_id: str, amount: int, note: str = "柜面存款") -> dict:
        """★现金存款（柜面/ATM 存入）：CASH 池→账户，守恒成立。"""
        amount = int(amount)
        with self._lock:
            acc = self._db.execute("SELECT * FROM accounts WHERE account_id=?",
                                   (account_id,)).fetchone()
            if acc is None or amount <= 0:
                return {"success": False, "error": "账户不存在或金额需为正"}
            self._db.execute("UPDATE accounts SET balance=balance+? WHERE account_id=?",
                             (amount, account_id))
            cur = self._db.execute(
                "INSERT INTO transactions(from_acc,to_acc,amount,status,kind,note,ts)"
                " VALUES('CASH',?,?, 'success','现金存款',?,?)",
                (account_id, amount, note, _now()))
            tx_id = cur.lastrowid
            bal = self._db.execute("SELECT balance FROM accounts WHERE account_id=?",
                                   (account_id,)).fetchone()["balance"]
            rid = self._receipt(account_id, "现金存款", "现金存款回执", f"TX{tx_id}",
                                [["账号", f"{acc['owner']}（{account_id}）"],
                                 ["存入金额", f"¥ {_yuan(amount)}"],
                                 ["存款后余额", f"¥ {_yuan(bal)}"],
                                 ["摘要", note]])
            self._event("现金存款", f"{acc['owner']} 存入 {_yuan(amount)} 元",
                        f"余额 {_yuan(bal)} 元（回执 R{rid}）")
            self._db.commit()
            return {"success": True, "tx_id": tx_id, "receipt_id": rid,
                    "balance_yuan": _yuan(bal),
                    "message": f"存入 {_yuan(amount)} 元成功，余额 {_yuan(bal)} 元（回执 R{rid}）"}

    def withdraw_cash(self, account_id: str, amount: int, note: str = "柜面取款") -> dict:
        """★现金取款：账户→CASH 池；卡状态校验+余额校验。"""
        amount = int(amount)
        with self._lock:
            acc = self._db.execute("SELECT * FROM accounts WHERE account_id=?",
                                   (account_id,)).fetchone()
            if acc is None or amount <= 0:
                return {"success": False, "error": "账户不存在或金额需为正"}
            normal = self._db.execute(
                "SELECT COUNT(*) c FROM cards WHERE account_id=? AND status='正常'",
                (account_id,)).fetchone()["c"]
            all_cards = self._db.execute(
                "SELECT COUNT(*) c FROM cards WHERE account_id=?",
                (account_id,)).fetchone()["c"]
            if all_cards > 0 and normal == 0:
                return {"success": False, "error": "名下银行卡均已挂失/限制，不可取现——请先解锁"}
            if acc["balance"] < amount:
                return {"success": False, "error": (f"余额不足：当前 {_yuan(acc['balance'])} 元，"
                                                    f"取款 {_yuan(amount)} 元")}
            if amount > 20000_00:
                return {"success": False, "error": "单笔取现上限 20000 元（大额请预约）"}
            self._db.execute("UPDATE accounts SET balance=balance-? WHERE account_id=?",
                             (amount, account_id))
            cur = self._db.execute(
                "INSERT INTO transactions(from_acc,to_acc,amount,status,kind,note,ts)"
                " VALUES(?, 'CASH', ?, 'success','现金取款',?,?)",
                (account_id, amount, note, _now()))
            tx_id = cur.lastrowid
            bal = self._db.execute("SELECT balance FROM accounts WHERE account_id=?",
                                   (account_id,)).fetchone()["balance"]
            rid = self._receipt(account_id, "现金取款", "现金取款回执", f"TX{tx_id}",
                                [["账号", f"{acc['owner']}（{account_id}）"],
                                 ["取款金额", f"¥ {_yuan(amount)}"],
                                 ["取款后余额", f"¥ {_yuan(bal)}"],
                                 ["摘要", note]])
            self._event("现金取款", f"{acc['owner']} 取出 {_yuan(amount)} 元",
                        f"余额 {_yuan(bal)} 元（回执 R{rid}）")
            self._db.commit()
            return {"success": True, "tx_id": tx_id, "receipt_id": rid,
                    "balance_yuan": _yuan(bal),
                    "message": f"取出 {_yuan(amount)} 元成功，余额 {_yuan(bal)} 元（回执 R{rid}）"}

    def calibrate(self) -> dict:
        """★441 对账基准校准（一次性）：把历史存量差异并入 seed_adj——
        436 修复流水前的老操作（股票/理财无流水期）在活库里留下的存量不平面，
        校准后对账恒等式从当下起算严格成立。"""
        with self._lock:
            fixed = []
            for acc in self._db.execute("SELECT * FROM accounts").fetchall():
                aid = acc["account_id"]
                inflow = self._db.execute(
                    "SELECT COALESCE(SUM(amount),0) s FROM transactions WHERE to_acc=?"
                    " AND status='success' AND kind NOT IN ('冲正','seed')",
                    (aid,)).fetchone()["s"]
                outflow = self._db.execute(
                    "SELECT COALESCE(SUM(amount),0) s FROM transactions WHERE from_acc=?"
                    " AND status='success' AND kind NOT IN ('冲正','seed')",
                    (aid,)).fetchone()["s"]
                diff = acc["balance"] - (self._SEED_BALANCES.get(aid, 0)
                                         + int(self._sim_get(f"seed_adj_{aid}", "0"))
                                         + inflow - outflow)
                if diff != 0:
                    self._sim_set(f"seed_adj_{aid}",
                                  str(int(self._sim_get(f"seed_adj_{aid}", "0")) + diff))
                    fixed.append(f"{aid} 校准 {diff / 100:.2f} 元")
            self._audit("SYSTEM", "calibrate", {}, "；".join(fixed) or "全部平衡，无需校准")
            self._db.commit()
            return {"success": True, "fixed": fixed,
                    "message": ("校准完成：" + "；".join(fixed)) if fixed else "全部平衡，无需校准"}

    # ---------- ★第442章 注册开户 / 微信绑定 / 个人资料 / 我的订单 ----------
    OPEN_GIFT = 100000  # 开户礼：1000 元虚拟货币

    def open_account_flow(self, name: str, phone: str = "", birthday: str = "") -> dict:
        """★注册开户：走办事流程单（提交→身份核验→开户审核→开户成功），
        末步真实开户 + 发放开户礼 + 自动生成银行卡。"""
        name = (name or "").strip()
        if not name:
            return {"success": False, "error": "请填写客户姓名"}
        with self._lock:
            dup = self._db.execute("SELECT 1 FROM accounts WHERE owner=?", (name,)).fetchone()
            if dup:
                return {"success": False, "error": f"客户「{name}」已存在（同名请直接登录）"}
            r = self.create_service_order("ACC001", "open_account",  # 挂在主账户名下走流程
                                          {"name": name, "phone": phone, "birthday": birthday})
            return r

    def _finalize_open_account(self, payload: dict) -> str:
        """开户末步真实生效：新账号 ACC00x 递增 + 开户礼 + 自动发卡。"""
        name = payload.get("name", "新客户")
        n = self._db.execute("SELECT COUNT(*) c FROM accounts").fetchone()["c"]
        aid = f"ACC{n + 1:03d}"
        while self._db.execute("SELECT 1 FROM accounts WHERE account_id=?", (aid,)).fetchone():
            n += 1
            aid = f"ACC{n + 1:03d}"
        self._db.execute(
            "INSERT INTO accounts(account_id,owner,balance,frozen,phone,birthday)"
            " VALUES(?,?,?,?,?,?)",
            (aid, name, self.OPEN_GIFT, 0, payload.get("phone", ""),
             payload.get("birthday", "")))
        self._SEED_BALANCES[aid] = self.OPEN_GIFT  # 动态基准：开户礼即初始 seed
        self._db.execute(
            "INSERT INTO transactions(from_acc,to_acc,amount,status,kind,note,ts)"
            " VALUES('VOID', ?, ?, 'success', 'seed', '开户礼发放', ?)",
            (aid, self.OPEN_GIFT, _now()))
        self.card_apply(aid)
        _ACC_TYPES[aid] = "PERSONAL"  # ★442 修复：_ACC_TYPES 是模块级变量（self. 引用曾致办结分支反复炸→12个重复户）
        return f"客户「{name}」开户成功（{aid}），开户礼 {self.OPEN_GIFT // 100} 元已入账，借记卡已同步核发"

    def bind_wx(self, account_id: str, wxname: str) -> dict:
        """★微信绑定：账号与微信昵称关联（教学仿真——模拟扫码授权）。"""
        wxname = (wxname or "").strip()
        if not wxname:
            return {"success": False, "error": "请提供微信昵称"}
        with self._lock:
            acc = self._db.execute("SELECT 1 FROM accounts WHERE account_id=?",
                                   (account_id,)).fetchone()
            if not acc:
                return {"success": False, "error": "账户不存在"}
            taken = self._db.execute("SELECT account_id FROM accounts WHERE wx=? AND account_id!=?",
                                     (wxname, account_id)).fetchone()
            if taken:
                return {"success": False, "error": f"该微信已绑定账户 {taken['account_id']}"}
            self._db.execute("UPDATE accounts SET wx=? WHERE account_id=?", (wxname, account_id))
            rid = self._receipt(account_id, "微信绑定", "微信绑定回执", f"WX{wxname}",
                                [["银行账户", account_id], ["绑定微信", wxname],
                                 ["生效时间", _now()]])
            self._db.commit()
            return {"success": True, "receipt_id": rid,
                    "message": f"微信「{wxname}」绑定成功（回执 R{rid}）"}

    def update_profile(self, account_id: str, phone: str = None, birthday: str = None) -> dict:
        with self._lock:
            acc = self._db.execute("SELECT 1 FROM accounts WHERE account_id=?",
                                   (account_id,)).fetchone()
            if not acc:
                return {"success": False, "error": "账户不存在"}
            if phone is not None:
                self._db.execute("UPDATE accounts SET phone=? WHERE account_id=?",
                                 (phone.strip(), account_id))
            if birthday is not None:
                self._db.execute("UPDATE accounts SET birthday=? WHERE account_id=?",
                                 (birthday.strip(), account_id))
            self._db.commit()
            return {"success": True, "message": "资料已更新"}

    def mall_orders(self, account_id: str = "") -> dict:
        with self._lock:
            if account_id:
                rows = self._db.execute(
                    "SELECT o.*,i.name FROM mall_orders o LEFT JOIN mall_items i"
                    " ON o.item_id=i.item_id WHERE o.account=? ORDER BY o.order_id DESC",
                    (account_id,)).fetchall()
            else:
                rows = self._db.execute(
                    "SELECT o.*,i.name FROM mall_orders o LEFT JOIN mall_items i"
                    " ON o.item_id=i.item_id ORDER BY o.order_id DESC").fetchall()
            return {"success": True, "items": [dict(r) | {"amount_yuan": _yuan(r["amount"])}
                                                for r in rows]}

    def account_detail(self, account_id: str = "ACC001") -> dict:
        """★第439章 客户视角聚合：账户档案+虚拟货币量+银行卡明细+近期流水（我的账户页）。"""
        with self._lock:
            acc = self._db.execute("SELECT * FROM accounts WHERE account_id=?",
                                   (account_id,)).fetchone()
            if acc is None:
                return {"success": False, "error": f"账户 {account_id} 不存在"}
            cards = self._db.execute("SELECT * FROM cards WHERE account_id=? ORDER BY card_no",
                                     (account_id,)).fetchall()
            txs = self._db.execute(
                "SELECT * FROM transactions WHERE from_acc=? OR to_acc=?"
                " ORDER BY tx_id DESC LIMIT 25", (account_id, account_id)).fetchall()
            deposits = self._db.execute(
                "SELECT COUNT(*) c FROM deposits WHERE account_id=? AND status='存续中'",
                (account_id,)).fetchone()["c"]
            return {"success": True,
                    "account_id": acc["account_id"], "owner": acc["owner"],
                    "acc_type": _ACC_TYPES.get(account_id, "PERSONAL"),
                    "phone": acc["phone"] if "phone" in acc.keys() else "",
                    "birthday": acc["birthday"] if "birthday" in acc.keys() else "",
                    "wx": acc["wx"] if "wx" in acc.keys() else "",
                    "balance": acc["balance"], "balance_yuan": _yuan(acc["balance"]),
                    "frozen": acc["frozen"], "frozen_yuan": _yuan(acc["frozen"]),
                    "active_deposits": deposits,
                    "cards": [dict(c) | {"limit_yuan": _yuan(c["limit_amount"])} for c in cards],
                    "recent_txs": [dict(t) | {"amount_yuan": _yuan(t["amount"])} for t in txs],
                    "message": f"{acc['owner']}（{account_id}）余额 {_yuan(acc['balance'])} 元"}

    def _sim_get(self, key: str, default: str = "") -> str:
        r = self._db.execute("SELECT value FROM sim_state WHERE key=?", (key,)).fetchone()
        return r["value"] if r else default

    def _sim_set(self, key: str, value: str):
        self._db.execute("INSERT INTO sim_state(key,value) VALUES(?,?)"
                         " ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))

    def sim_info(self) -> dict:
        with self._lock:
            day = int(self._sim_get("sim_day", "0"))
            secs = float(self._sim_get("day_seconds", str(_SIM_DAY_SECONDS)))
            return {"success": True, "sim_day": day,
                    "mode": "加速时钟" if secs > 0 else "真实时钟",
                    "seconds_per_day": secs,
                    "async_tx": _ASYNC_TX,
                    "message": f"银行日第 {day} 天（{('每 ' + str(secs) + ' 秒切一日') if secs > 0 else '按真实日期切日'}）"}

    def set_sim_speed(self, seconds_per_day: float) -> dict:
        """演示时可实时调时钟（0=切回真实时钟）。"""
        try:
            v = max(0.0, float(seconds_per_day))
        except (TypeError, ValueError):
            return {"success": False, "error": "seconds_per_day 需为非负数（0=真实时钟）"}
        with self._lock:
            self._sim_set("day_seconds", str(v))
            self._event("时钟", "时钟调整", f"银行日节奏 → 每 {v} 秒切一日" if v > 0 else "→ 真实时钟")
            self._db.commit()
        return {"success": True, "seconds_per_day": v,
                "message": f"银行日节奏已调整为 {v} 秒/日" if v > 0 else "已切换为真实时钟"}

    def bank_events(self, limit: int = 30) -> dict:
        with self._lock:
            rows = self._db.execute(
                "SELECT * FROM bank_events ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
            return {"success": True, "count": len(rows), "items": [dict(r) for r in rows]}

    def _start_lifecycle(self):
        """后台生命周期线程：模拟时钟推进 + 日切批量账务（daemon，异常自愈）。"""
        def _loop():
            while True:
                time.sleep(1.0)
                try:
                    with self._lock:
                        secs = float(self._sim_get("day_seconds", str(_SIM_DAY_SECONDS)))
                        if secs <= 0:
                            continue  # 真实时钟模式：日切由真实日期变化驱动（演示场景默认加速）
                        last = float(self._sim_get("_last_cut_ts", "0") or 0)
                        if time.time() - last >= secs:
                            self._sim_set("_last_cut_ts", str(time.time()))
                            self._day_cut()
                except Exception as e:
                    # ★436: 日切异常必须留痕（静默吞错曾导致兑付流水丢失→守恒破坏无迹可查）
                    print(f"[bank-lifecycle] 日切异常: {e}", flush=True)
        threading.Thread(target=_loop, daemon=True, name="bank-lifecycle").start()

    def _day_cut(self):
        """日切：一个银行日的批量后台账务（持锁调用）。
        1) 商户收单（市民消费）  2) 代发工资(每5日)  3) 公共事业+房租(每30日)
        4) 活期利息  5) 定期兑付  6) 订阅扣费  7) 贷款计息  8) 日切事件"""
        day = int(self._sim_get("sim_day", "0")) + 1
        self._sim_set("sim_day", str(day))
        today = time.strftime("%Y-%m-%d")
        # ★437 社会资金循环（先于利息，保证事件顺序：白天经济活动→日切计息）
        self._consumption(day)
        if day % PAYROLL_EVERY == 0:
            self._payroll(day)
        if day % RENT_EVERY == 0:
            self._utilities(day)
        # ★438 场景1 定时转账执行（exec_day<=今天）
        for st in self._db.execute(
                "SELECT * FROM scheduled_transfers WHERE status='待执行' AND exec_day<=?",
                (day,)).fetchall():
            r = self.transfer(st["from_acc"], st["to_acc"], st["amount"],
                              note=f"[定时 st{st['st_id']}] {st['note']}",
                              _bypass_risk=True)
            self._db.execute("UPDATE scheduled_transfers SET status=? WHERE st_id=?",
                             ("已执行" if r.get("success") else f"失败:{(r.get('error') or '')[:30]}",
                              st["st_id"]))
            self._event("定时转账", f"st{st['st_id']} 到期执行",
                        (f"{st['from_acc']}→{st['to_acc']} {_yuan(st['amount'])} 元"
                         f"{'成功' if r.get('success') else '失败'}"))
        # ★438 场景5 续费提醒（next_charge 明天到期且订阅有效）
        tomorrow = time.strftime("%Y-%m-%d", time.localtime(time.time() + 86400))
        for s in self._db.execute(
                "SELECT * FROM subscriptions WHERE status='active' AND next_charge=?",
                (tomorrow,)).fetchall():
            self._event("续费提醒", f"{s['merchant']} 明日扣费",
                        f"{s['account_id']} 将扣 {_yuan(s['amount'])} 元"
                        f"（如需退订请对我说『取消订阅』）")
        # ★440 业务办事单推进（每银行日进一步，末步真实生效）
        self._advance_service_orders(day)
        acts = []
        # 1) 活期利息（余额×年化0.3%/365，分取整≥1 分才入账）
        for acc in self._db.execute("SELECT * FROM accounts").fetchall():
            interest = int(acc["balance"] * DEMAND_RATE / 100 / 365)
            if interest >= 1:
                self._db.execute("UPDATE accounts SET balance=balance+? WHERE account_id=?",
                                 (interest, acc["account_id"]))
                self._db.execute(
                    "INSERT INTO transactions(from_acc,to_acc,amount,status,kind,note,ts)"
                    " VALUES('BANK',?,?, 'success','利息',?,?)",
                    (acc["account_id"], interest, f"第{day}银行日活期利息", _now()))
                acts.append(f"{acc['owner']} 利息 {_yuan(interest)} 元")
        if acts:
            self._event("利息", f"第 {day} 银行日活期利息入账", "；".join(acts))
        # 2) 定期到期兑付（本金回余额 + 约定利率利息；事件+流水）
        for d in self._db.execute(
                "SELECT * FROM deposits WHERE status='存续中' AND end_day<=?", (day,)).fetchall():
            interest = int(d["amount"] * d["rate"] / 100 / 365 * d["term_days"])
            self._db.execute("UPDATE deposits SET status='已兑付' WHERE deposit_id=?",
                             (d["deposit_id"],))
            self._db.execute("UPDATE accounts SET frozen=MAX(frozen-?,0), balance=balance+? "
                             "WHERE account_id=?", (d["amount"], d["amount"] + interest,
                                                    d["account_id"]))
            self._db.execute(
                "INSERT INTO transactions(from_acc,to_acc,amount,status,kind,note,ts)"
                " VALUES('BANK', ?, ?, 'success', '理财兑付', ?, ?)",
                (d["account_id"], d["amount"] + interest,
                 f"定期 {d['term_days']} 天到期本息", _now()))
            self._event("理财兑付", f"定期到期自动兑付",
                        f"{d['account_id']} 本金 {_yuan(d['amount'])} 元 + 利息 {_yuan(interest)} 元已入账")
            self._audit(d["account_id"], "deposit_mature",
                        {"deposit": d["deposit_id"]},
                        f"到期兑付本息 {_yuan(d['amount'] + interest)} 元")
        # 3) 订阅自动扣费（next_charge<=今天 且订阅有效：★438 cancelled 不扣）
        for s in self._db.execute(
                "SELECT * FROM subscriptions WHERE next_charge<=? AND status='active'",
                (today,)).fetchall():
            acc = self._db.execute("SELECT * FROM accounts WHERE account_id=?",
                                   (s["account_id"],)).fetchone()
            step = 30 if s["cycle"] == "每月" else 365
            self._db.execute(
                "UPDATE subscriptions SET next_charge=date(?, ?) WHERE id=?",
                (today, f"+{step} day", s["id"]))
            if acc is None or acc["balance"] < s["amount"]:
                self._risk_event(s["account_id"], "MEDIUM", "代扣失败",
                                 f"{s['merchant']} 自动扣费 {_yuan(s['amount'])} 元余额不足")
                self._event("代扣失败", f"{s['merchant']} 周期扣费",
                            f"{s['account_id']} 余额不足，待补扣")
                continue
            self._db.execute("UPDATE accounts SET balance=balance-? WHERE account_id=?",
                             (s["amount"], s["account_id"]))
            self._db.execute(
                "INSERT INTO transactions(from_acc,to_acc,amount,status,kind,note,ts)"
                " VALUES(?,'MERCHANT',?,'success','代扣',?,?)",
                (s["account_id"], s["amount"], f"{s['merchant']} 周期扣费", _now()))
            self._event("自动扣费", f"{s['merchant']} 周期扣费成功",
                        f"{s['account_id']} 支出 {_yuan(s['amount'])} 元，下期 {step} 天后")
        # 4) 贷款日计息（remaining 按日计提，单利——真实银行等额本息的简化形态）
        for l in self._db.execute("SELECT * FROM loans WHERE status='还款中'").fetchall():
            interest = int(l["remaining"] * l["rate"] / 100 / 365)
            if interest >= 1:
                self._db.execute("UPDATE loans SET remaining=remaining+? WHERE loan_id=?",
                                 (interest, l["loan_id"]))
        # 5) 日切事件
        self._audit("SYSTEM", "day_cut", {"day": day}, f"日切完成（利息/到期/扣费/计息）")
        self._db.commit()

    # ---------- 种子（首启一次：5 账户/卡片/产品/订阅） ----------
    def _seed_if_empty(self):
        with self._lock:
            if self._db.execute("SELECT COUNT(*) c FROM accounts").fetchone()["c"]:
                return
            cur = self._db.cursor()
            for aid, owner, bal in (("ACC001", "陈奕汶", 25000_00), ("ACC002", "妈妈", 10000_00),
                                    ("ACC003", "房东", 500_00), ("ACC004", "李雷", 2000_00),
                                    ("ACC005", "王芳", 3000_00)):
                cur.execute("INSERT INTO accounts(account_id,owner,balance,frozen) VALUES(?,?,?,0)",
                            (aid, owner, bal))
            cur.execute("INSERT INTO cards VALUES('6222 0000 0001','ACC001','正常',500000)")
            for pid, n, r, rk, t in (("P001", "活期宝", 1.8, 1, "活期"),
                                     ("P002", "90天稳健", 3.2, 2, "90天"),
                                     ("P003", "成长优选", 5.6, 4, "365天")):
                cur.execute("INSERT INTO products VALUES(?,?,?,?,?)", (pid, n, r, rk, t))
            today = time.strftime("%Y-%m-%d")
            for m, amt, cyc in (("视频会员", 25_00, "每月"), ("云存储", 15_00, "每月"),
                                ("健身App", 199_00, "每年")):
                cur.execute("INSERT INTO subscriptions(account_id,merchant,amount,cycle,next_charge)"
                            " VALUES('ACC001',?,?,?,?)", (m, amt, cyc, today))
            self._db.commit()

    # ---------- 内部工具 ----------
    def _audit(self, account_id: str, action: str, params: dict, result: str):
        self._db.execute("INSERT INTO audit_log(account_id,action,params,result,ts) VALUES(?,?,?,?,?)",
                         (account_id, action, json_dumps(params), result, _now()))

    def _risk_scan(self, account_id: str, amount: int) -> dict | None:
        """风控三规则：单笔限额(HIGH 拒)/夜间大额(MEDIUM 记录)/5分钟高频(HIGH 拒)。

        ★v357: 三个拒返必须带 error 键 —— 此前只有 rule/reason，技能层读
        result['error'] 得空串 → Agent 看到无意义的「ERROR: 错误: 」，
        无法自诊断 → 盲目重试 → 熔断。错误可读性是赛题「体验」维度核心。"""
        hour = time.localtime().tm_hour
        if amount > _SINGLE_LIMIT:
            self._risk_event(account_id, "HIGH", "单笔限额",
                             f"单笔 {_yuan(amount)} 元超过 {_yuan(_SINGLE_LIMIT)} 元限额")
            return {"rejected": True, "rule": "单笔限额",
                    "reason": f"单笔 {_yuan(amount)} 元超过 {_yuan(_SINGLE_LIMIT)} 元限额，已拦截",
                    "error": (f"转账被风控拦截（单笔限额）：单笔 {_yuan(amount)} 元超过 "
                              f"{_yuan(_SINGLE_LIMIT)} 元限额。可建议用户调低金额或调整额度")}
        if (hour >= 22 or hour < 7) and amount > _NIGHT_LIMIT:
            self._risk_event(account_id, "MEDIUM", "夜间大额",
                             f"夜间 {_yuan(amount)} 元转账已记录并复核")
        recent = self._db.execute(
            "SELECT COUNT(*) c FROM transactions WHERE from_acc=? AND ts>=?"
            " AND kind='转账'",  # ★438 只计真实转账指令——POS 消费是银行模拟的市民生态，不占用户高频额度
            (account_id, time.strftime("%Y-%m-%d %H:%M", time.localtime(time.time() - 300)))).fetchone()["c"]
        if recent >= 3:
            self._risk_event(account_id, "HIGH", "高频交易",
                             f"5 分钟内第 {recent + 1} 笔交易，疑似异常")
            return {"rejected": True, "rule": "高频交易",
                    "reason": f"5 分钟内已发起 {recent} 笔交易，触发高频保护，请稍后再试",
                    "error": (f"转账被风控拦截（高频保护）：5 分钟内已发起 {recent} 笔转账。"
                              f"请等待几分钟后重试，或改用定时转账（预约类不受此限）")}
        return None

    def _risk_event(self, account_id: str, level: str, rule: str, detail: str):
        self._db.execute("INSERT INTO risk_events(account_id,level,rule,detail,ts) VALUES(?,?,?,?,?)",
                         (account_id, level, rule, detail, _now()))

    # ---------- 查询类 ----------
    def accounts(self) -> dict:
        with self._lock:
            rows = self._db.execute("SELECT * FROM accounts ORDER BY account_id").fetchall()
            return {"success": True, "bank": _BANK_NAME,
                    "items": [{"account_id": r["account_id"], "owner": r["owner"],
                               "balance": r["balance"], "balance_yuan": _yuan(r["balance"]),
                               "frozen": r["frozen"]} for r in rows]}

    def account(self, account_id: str) -> dict:
        with self._lock:
            r = self._db.execute("SELECT * FROM accounts WHERE account_id=?", (account_id,)).fetchone()
            if r is None:
                return {"success": False, "error": f"账户 {account_id} 不存在"}
            return {"success": True, "account_id": r["account_id"], "owner": r["owner"],
                    "balance": r["balance"], "balance_yuan": _yuan(r["balance"]),
                    "frozen": r["frozen"], "message": f"{r['owner']} 余额 {_yuan(r['balance'])} 元"}

    def transactions(self, account_id: str = "", limit: int = 20) -> dict:
        with self._lock:
            if account_id:
                rows = self._db.execute(
                    "SELECT * FROM transactions WHERE from_acc=? OR to_acc=?"
                    " ORDER BY tx_id DESC LIMIT ?", (account_id, account_id, limit)).fetchall()
            else:
                rows = self._db.execute(
                    "SELECT * FROM transactions ORDER BY tx_id DESC LIMIT ?", (limit,)).fetchall()
            return {"success": True, "count": len(rows),
                    "items": [dict(r) | {"amount_yuan": _yuan(r["amount"])} for r in rows]}

    def audit_log(self, limit: int = 50) -> dict:
        with self._lock:
            rows = self._db.execute(
                "SELECT * FROM audit_log ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
            return {"success": True, "count": len(rows),
                    "items": [dict(r) for r in rows]}

    def risk_events(self, limit: int = 50) -> dict:
        with self._lock:
            rows = self._db.execute(
                "SELECT * FROM risk_events ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
            return {"success": True, "count": len(rows),
                    "items": [dict(r) for r in rows]}

    def products(self) -> dict:
        with self._lock:
            rows = self._db.execute("SELECT * FROM products ORDER BY risk_level").fetchall()
            return {"success": True, "items": [dict(r) for r in rows]}

    def subscriptions(self, account_id: str = "ACC001") -> dict:
        with self._lock:
            rows = self._db.execute(
                "SELECT * FROM subscriptions WHERE account_id=?", (account_id,)).fetchall()
            return {"success": True, "count": len(rows),
                    "items": [dict(r) | {"amount_yuan": _yuan(r["amount"])} for r in rows]}

    # ---------- 转账（五段式：幂等→风控→原子守恒→审计） ----------
    def transfer(self, from_acc: str, to_acc: str, amount: int,
                 note: str = "", idem_key: str | None = None,
                 _bypass_risk: bool = False) -> dict:
        amount = int(amount)
        with self._lock:
            # 段1 幂等
            if idem_key:
                dup = self._db.execute("SELECT * FROM transactions WHERE idem_key=?",
                                       (idem_key,)).fetchone()
                if dup is not None:
                    return {"success": True, "idempotent": True, "tx_id": dup["tx_id"],
                            "message": f"幂等命中：该请求已处理过（tx {dup['tx_id']}），不会重复扣款"}
            # 参数校验
            src = self._db.execute("SELECT * FROM accounts WHERE account_id=?", (from_acc,)).fetchone()
            dst = self._db.execute("SELECT * FROM accounts WHERE account_id=?", (to_acc,)).fetchone()
            if src is None or dst is None:
                miss = from_acc if src is None else to_acc
                return {"success": False, "error": f"账户 {miss} 不存在"}
            if amount <= 0:
                return {"success": False, "error": "转账金额必须为正数（单位：分）"}
            if from_acc == to_acc:
                return {"success": False, "error": "不能向自己转账"}
            # 段2 风控（★438：预约类业务——定时转账执行/AA 批量——预约时已过风控，
            #   执行时绕过零售高频窗口，否则加速时钟下 POS 流水会误伤合法计划）
            rejected = None if _bypass_risk else self._risk_scan(from_acc, amount)
            if rejected:
                self._audit(from_acc, "transfer", {"to": to_acc, "amount": amount},
                            f"风控拦截: {rejected['rule']}")
                self._db.commit()
                return {"success": False, "rejected_by_risk": True, **rejected}
            # 段2.5 卡状态校验（★438 场景4：挂失/限制卡不可发起转账）
            bad_card = self._db.execute(
                "SELECT card_no,status FROM cards WHERE account_id=? AND status!='正常'",
                (from_acc,)).fetchall()
            all_cards = self._db.execute(
                "SELECT COUNT(*) c FROM cards WHERE account_id=?", (from_acc,)).fetchone()["c"]
            normal = self._db.execute(
                "SELECT COUNT(*) c FROM cards WHERE account_id=? AND status='正常'",
                (from_acc,)).fetchone()["c"]
            if all_cards > 0 and normal == 0:
                st = bad_card[0]["status"]
                self._audit(from_acc, "transfer", {"to": to_acc, "amount": amount},
                            f"卡片状态异常（{st}）拒绝")
                self._db.commit()
                return {"success": False, "error":
                        f"您名下银行卡状态为「{st}」，暂不可交易——"
                        f"请先解锁/补卡（可对我说『解除限制』或『申请新卡』）"}
            # 段3 余额检查
            if src["balance"] < amount:
                self._audit(from_acc, "transfer", {"to": to_acc, "amount": amount}, "余额不足")
                self._db.commit()
                return {"success": False, "error": (f"余额不足：当前 {_yuan(src['balance'])} 元，"
                                                    f"需 {_yuan(amount)} 元")}
            # 段4 原子守恒（一笔事务内双向更新+落流水）
            #   ★第436章 异步状态机：资金即时过账（守恒立即成立），交易状态
            #   pending→success 由后台 0.9~1.6s 落定——呈现真实银行"处理中"形态
            init_status = "pending" if _ASYNC_TX else "success"
            try:
                self._db.execute("UPDATE accounts SET balance=balance-? WHERE account_id=?",
                                 (amount, from_acc))
                self._db.execute("UPDATE accounts SET balance=balance+? WHERE account_id=?",
                                 (amount, to_acc))
                cur = self._db.execute(
                    "INSERT INTO transactions(from_acc,to_acc,amount,status,kind,note,idem_key,ts)"
                    " VALUES(?,?,?,?,?,?,?,?)",
                    (from_acc, to_acc, amount, init_status, "转账", note, idem_key, _now()))
                tx_id = cur.lastrowid
                bal_after = self._db.execute("SELECT balance FROM accounts WHERE account_id=?",
                                             (from_acc,)).fetchone()["balance"]
                self._db.commit()
            except sqlite3.IntegrityError as e:  # 幂等键冲突并发
                self._db.rollback()
                return {"success": False, "error": f"幂等键冲突: {e}"}
            if init_status == "pending":
                def _settle(_tx=tx_id):
                    time.sleep(0.9 + (_tx % 700) / 1000.0)  # 0.9~1.6s 落定（按 tx_id 伪随机）
                    with self._lock:
                        self._db.execute(
                            "UPDATE transactions SET status='success' WHERE tx_id=?"
                            " AND status='pending'", (_tx,))
                        self._db.commit()
                threading.Thread(target=_settle, daemon=True,
                                 name=f"tx-settle-{tx_id}").start()
            # 段5 审计
            self._audit(from_acc, "transfer", {"to": to_acc, "amount": amount, "tx": tx_id},
                        f"成功 {_yuan(amount)} 元")
            rid = self._receipt(from_acc, "转账汇款", "转账汇款回执", f"TX{tx_id}",
                                [["付款账户", f"{src['owner']}（{from_acc}）"],
                                 ["收款账户", f"{dst['owner']}（{to_acc}）"],
                                 ["转账金额", f"¥ {_yuan(amount)}"],
                                 ["付款后余额", f"¥ {_yuan(bal_after)}"],
                                 ["交易状态", "处理中" if init_status == "pending" else "成功"],
                                 ["摘要", note or "—"]])
            self._db.commit()
            state = "已受理，处理中（1~2 秒内落账）" if init_status == "pending" else "完成"
            return {"success": True, "tx_id": tx_id, "amount": amount, "amount_yuan": _yuan(amount),
                    "from": from_acc, "to": to_acc, "status": init_status,
                    "balance_after": bal_after,
                    "message": f"已向 {dst['owner']} 转账 {_yuan(amount)} 元（{state}），余额 {_yuan(bal_after)} 元"}

    # ---------- 冲正（状态机 success→reversed 双向回滚） ----------
    def reverse(self, tx_id: int, reason: str = "用户发起") -> dict:
        with self._lock:
            tx = self._db.execute("SELECT * FROM transactions WHERE tx_id=?", (tx_id,)).fetchone()
            if tx is None:
                return {"success": False, "error": f"交易 {tx_id} 不存在"}
            if tx["status"] != "success":
                return {"success": False, "error": f"交易 {tx_id} 状态为 {tx['status']}，不可冲正"}
            try:
                self._db.execute("UPDATE accounts SET balance=balance+? WHERE account_id=?",
                                 (tx["amount"], tx["from_acc"]))
                self._db.execute("UPDATE accounts SET balance=balance-? WHERE account_id=?",
                                 (tx["amount"], tx["to_acc"]))
                self._db.execute("UPDATE transactions SET status='reversed' WHERE tx_id=?", (tx_id,))
                cur = self._db.execute(
                    "INSERT INTO transactions(from_acc,to_acc,amount,status,kind,note,ts)"
                    " VALUES(?,?,?,?,?,?,?)",
                    (tx["to_acc"], tx["from_acc"], tx["amount"], "success", "冲正",
                     f"冲正 tx{tx_id}: {reason}", _now()))
                rev_id = cur.lastrowid
                self._db.commit()
            except sqlite3.Error as e:
                self._db.rollback()
                return {"success": False, "error": f"冲正失败: {e}"}
            self._audit(tx["from_acc"], "reverse", {"tx": tx_id, "reason": reason},
                        f"冲正成功，回滚 {_yuan(tx['amount'])} 元")
            self._db.commit()
            return {"success": True, "reversed_tx": tx_id, "reverse_tx": rev_id,
                    "amount_yuan": _yuan(tx["amount"]),
                    "message": f"交易 {tx_id} 已冲正，{_yuan(tx['amount'])} 元已双向回滚"}

    # ---------- 对账（冲正成对排除 + 种子基准现值；★437 扩社会主体） ----------
    _SEED_BALANCES = {
        "ACC001": 25000_00, "ACC002": 10000_00, "ACC003": 500_00,
        "ACC004": 2000_00, "ACC005": 3000_00,
        "ACC-C001": 500000_00, "ACC-C002": 80000_00,
        "ACC-G001": 0, "ACC-G002": 0, "ACC-G003": 0,
        "ACC-G004": 0, "ACC-G005": 0, "ACC-G006": 0,
    }

    def reconcile(self) -> dict:
        with self._lock:
            bad, report = [], []
            for acc in self._db.execute("SELECT * FROM accounts").fetchall():
                aid = acc["account_id"]
                inflow = self._db.execute(
                    "SELECT COALESCE(SUM(amount),0) s FROM transactions WHERE to_acc=?"
                    " AND status='success' AND kind NOT IN ('冲正','seed')",
                    (aid,)).fetchone()["s"]
                outflow = self._db.execute(
                    "SELECT COALESCE(SUM(amount),0) s FROM transactions WHERE from_acc=?"
                    " AND status='success' AND kind NOT IN ('冲正','seed')",
                    (aid,)).fetchone()["s"]
                expect = self._SEED_BALANCES.get(aid, 0) \
                    + int(self._sim_get(f"seed_adj_{aid}", "0")) \
                    + inflow - outflow
                ok = (expect == acc["balance"])
                if not ok:
                    bad.append(aid)
                report.append({"account_id": aid, "owner": acc["owner"],
                               "acc_type": _ACC_TYPES.get(aid, "PERSONAL"),
                               "balance": acc["balance"], "expect": expect,
                               "ok": ok})
            balanced = (not bad)
            self._audit("SYSTEM", "reconcile", {}, "平衡" if balanced else f"不平: {bad}")
            self._db.commit()
            return {"success": True, "balanced": balanced, "accounts": report,
                    "message": ("对账通过：全部账户账实相符（含对公/机构主体）" if balanced
                                else f"对账不平：{bad}，请检查")}

    # ---------- 复利试算（Decimal 日复利 · 银行家舍入） ----------
    def compound(self, principal: float, annual_rate: float, days: int) -> dict:
        try:
            p = Decimal(str(principal))
            rate = Decimal(str(annual_rate))
            d = int(days)
            if p <= 0 or d <= 0:
                raise ValueError
        except (ValueError, TypeError):
            return {"success": False, "error": "参数需为正数：principal(元)/annual_rate(%)/days(天)"}
        daily = (Decimal("1") + rate / Decimal("100") / Decimal("365")).quantize(Decimal("0.0000001"))
        amount = (p * (daily ** d)).quantize(Decimal("0.01"), ROUND_HALF_EVEN)
        interest = (amount - p).quantize(Decimal("0.01"), ROUND_HALF_EVEN)
        return {"success": True, "principal_yuan": float(p), "annual_rate": float(rate),
                "days": d, "final_amount_yuan": float(amount), "interest_yuan": float(interest),
                "message": (f"{float(p)} 元按年利率 {float(rate)}% 日复利 {d} 天，"
                            f"到期本息 {amount} 元（利息 {interest} 元，银行家舍入）")}

    # ---------- 理财申购/赎回（★436 升级：真定期生命周期+提前支取罚息规则） ----------
    def lock_deposit(self, account_id: str, amount: int, prod_id: str = "P001") -> dict:
        amount = int(amount)
        with self._lock:
            acc = self._db.execute("SELECT * FROM accounts WHERE account_id=?", (account_id,)).fetchone()
            prod = self._db.execute("SELECT * FROM products WHERE prod_id=?", (prod_id,)).fetchone()
            if acc is None or prod is None:
                return {"success": False, "error": "账户或产品不存在"}
            if acc["balance"] < amount:
                return {"success": False, "error": "余额不足"}
            self._db.execute("UPDATE accounts SET balance=balance-?, frozen=frozen+? WHERE account_id=?",
                             (amount, amount, account_id))
            # ★436 一致性修复：冻结划转落内部流水（否则对账守恒被打破——421 遗留）
            self._db.execute(
                "INSERT INTO transactions(from_acc,to_acc,amount,status,kind,note,ts)"
                " VALUES(?, 'FROZEN', ?, 'success','理财申购', ?, ?)",
                (account_id, amount, f"{prod['name']} 申购冻结", _now()))
            term_days = _PRODUCT_TERM_DAYS.get(prod["term"], 0)
            msg = f"已申购 {prod['name']} {_yuan(amount)} 元（年化 {prod['annual_rate']}%，冻结中）"
            if term_days > 0:
                day = int(self._sim_get("sim_day", "0"))
                self._db.execute(
                    "INSERT INTO deposits(account_id,prod_id,amount,rate,term_days,"
                    "start_day,end_day,status,ts) VALUES(?,?,?,?,?,?,?,?,?)",
                    (account_id, prod_id, amount, prod["annual_rate"], term_days,
                     day, day + term_days, "存续中", _now()))
                msg = (f"已存入 {prod['name']} {_yuan(amount)} 元（年化 {prod['annual_rate']}%，"
                       f"锁定期 {term_days} 银行日，到期自动兑付本息；提前支取按活期 {DEMAND_RATE}% 计息）")
            self._event("理财申购", f"{prod['name']} {_yuan(amount)} 元", f"{account_id} {msg}")
            self._audit(account_id, "lock_deposit", {"prod": prod_id, "amount": amount}, "申购完成")
            self._db.commit()
            return {"success": True, "term_days": term_days, "message": msg}

    def unlock_deposit(self, account_id: str, amount: int, prod_id: str = "P001") -> dict:
        """★436：先清算名下到期/未到期定期（FIFO），再活期冻结。到期按约定利率，
        提前支取按活期 {DEMAND_RATE}% 罚息形态计息（真实银行规则）。"""
        amount = int(amount)
        with self._lock:
            acc = self._db.execute("SELECT * FROM accounts WHERE account_id=?", (account_id,)).fetchone()
            if acc is None:
                return {"success": False, "error": "账户不存在"}
            if acc["frozen"] < amount:
                return {"success": False, "error": (f"冻结余额不足：冻结 {_yuan(acc['frozen'])} 元，"
                                                    f"赎回需 {_yuan(amount)} 元")}
            day = int(self._sim_get("sim_day", "0"))
            left, detail = amount, []
            for d in self._db.execute(
                    "SELECT * FROM deposits WHERE account_id=? AND status='存续中' ORDER BY end_day",
                    (account_id,)).fetchall():
                if left <= 0:
                    break
                take = min(left, d["amount"])
                if take >= d["amount"]:
                    self._db.execute("UPDATE deposits SET status='已支取' WHERE deposit_id=?",
                                     (d["deposit_id"],))
                days_held = max(day - d["start_day"], 0)
                if days_held >= d["term_days"]:
                    rate, tag = d["rate"], "到期"
                else:
                    rate, tag = DEMAND_RATE, "提前支取（按活期计息）"
                interest = int(take * rate / 100 / 365 * max(days_held, 1))
                self._db.execute("UPDATE accounts SET balance=balance+? WHERE account_id=?",
                                 (interest, account_id))
                self._db.execute(
                    "INSERT INTO transactions(from_acc,to_acc,amount,status,kind,note,ts)"
                    " VALUES('BANK',?,'success','理财赎回',?,?)",
                    (account_id, interest, f"{d['term_days']}天定期{tag}利息", _now()))
                detail.append(f"{tag}利息 {_yuan(interest)} 元")
                left -= take
            self._db.execute("UPDATE accounts SET frozen=frozen-?, balance=balance+? WHERE account_id=?",
                             (amount, amount, account_id))
            # ★436 一致性修复：本金回活期落内部流水（与申购冻结成对）
            self._db.execute(
                "INSERT INTO transactions(from_acc,to_acc,amount,status,kind,note,ts)"
                " VALUES('FROZEN', ?, ?, 'success','理财赎回本金', '定期/活期赎回到账', ?)",
                (account_id, amount, _now()))
            self._event("理财赎回", f"{account_id} 赎回 {_yuan(amount)} 元", "；".join(detail) or "活期随取")
            self._audit(account_id, "unlock_deposit", {"prod": prod_id, "amount": amount},
                        "赎回完成 " + ("；".join(detail) if detail else ""))
            self._db.commit()
            tail = ("；".join(detail)) if detail else "活期随取，无利息差"
            return {"success": True, "message": f"已赎回 {_yuan(amount)} 元至活期余额（{tail}）"}

    def deposits(self, account_id: str = "") -> dict:
        """★436 定期存款清单（含剩余天数/到期倒计时）。"""
        with self._lock:
            day = int(self._sim_get("sim_day", "0"))
            if account_id:
                rows = self._db.execute("SELECT * FROM deposits WHERE account_id=? ORDER BY deposit_id DESC",
                                        (account_id,)).fetchall()
            else:
                rows = self._db.execute("SELECT * FROM deposits ORDER BY deposit_id DESC").fetchall()
            items = []
            for d in rows:
                m = dict(d) | {"amount_yuan": _yuan(d["amount"])}
                if d["status"] == "存续中":
                    m["days_left"] = max(d["end_day"] - day, 0)
                items.append(m)
            return {"success": True, "sim_day": day, "count": len(items), "items": items}

    def health(self) -> dict:
        with self._lock:
            n = self._db.execute("SELECT COUNT(*) c FROM accounts").fetchone()["c"]
            return {"status": "up", "bank": _BANK_NAME, "version": _BANK_VERSION,
                    "accounts": n, "ts": _now()}

    # ═══════════ ★第427章 服务端渲染界面快照（零 JS，供 Agent 抓取呈现） ═══════════
    def console_html(self) -> str:
        """服务端渲染完整银行界面为静态 HTML（数据全内联、零脚本）——
        Agent 抓取后经 WebPageCard srcdoc 呈现，绕开 iframe/JS/混合内容所有坑。"""
        with self._lock:
            accs = self._db.execute("SELECT * FROM accounts ORDER BY account_id").fetchall()
            txs = self._db.execute(
                "SELECT * FROM transactions ORDER BY tx_id DESC LIMIT 15").fetchall()
            risks = self._db.execute(
                "SELECT * FROM risk_events ORDER BY id DESC LIMIT 8").fetchall()
            audits = self._db.execute(
                "SELECT * FROM audit_log ORDER BY id DESC LIMIT 8").fetchall()

        def esc(s):
            return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

        acc_rows = "".join(
            f"<tr><td>{esc(a['account_id'])}</td><td>{esc(a['owner'])}</td>"
            f"<td class='r'>{_yuan(a['balance'])}</td><td class='r'>{_yuan(a['frozen'])}</td></tr>"
            for a in accs)
        tx_rows = "".join(
            f"<tr><td>#{t['tx_id']}</td><td>{esc(t['from_acc'])} → {esc(t['to_acc'])}</td>"
            f"<td class='r'>{_yuan(t['amount'])}</td>"
            f"<td class='{('ok' if t['status'] == 'success' else 'rev')}'>"
            f"{'成功' if t['status'] == 'success' else '已冲正'}</td>"
            f"<td>{esc(t['note'] or '')}</td><td class='dim'>{esc(t['ts'])}</td></tr>"
            for t in txs)
        risk_rows = "".join(
            f"<tr><td class='{('err' if r['level'] == 'HIGH' else 'warn')}'>{esc(r['level'])}</td>"
            f"<td>{esc(r['rule'])}</td><td>{esc(r['detail'])}</td><td class='dim'>{esc(r['ts'])}</td></tr>"
            for r in risks) or "<tr><td colspan='4' class='dim'>暂无风控事件</td></tr>"
        audit_rows = "".join(
            f"<tr><td>{esc(a['action'])}</td><td>{esc(a['account_id'])}</td>"
            f"<td>{esc(a['result'])}</td><td class='dim'>{esc(a['ts'])}</td></tr>"
            for a in audits) or "<tr><td colspan='4' class='dim'>暂无审计记录</td></tr>"

        return f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="UTF-8"><title>数字银行沙箱 · 界面快照</title>
<style>
 body{{font-family:"Microsoft YaHei",sans-serif;margin:0;background:#f4f6f8;color:#222;font-size:13px}}
 header{{background:#1f4e79;color:#fff;padding:14px 22px}}
 header h1{{margin:0;font-size:19px}} header .t{{font-size:12px;opacity:.85}}
 .wrap{{max-width:1000px;margin:14px auto;padding:0 12px}}
 table{{width:100%;border-collapse:collapse;background:#fff}}
 th{{background:#eef2f6;padding:7px 10px;border:1px solid #e3e8ee;text-align:left}}
 td{{padding:7px 10px;border:1px solid #e9edf1}}
 .r{{text-align:right;font-family:Consolas,monospace}}
 .ok{{color:#178742;font-weight:bold}} .rev{{color:#b8860b}} .err{{color:#c0392b;font-weight:bold}}
 .warn{{color:#b8860b}} .dim{{color:#888;font-size:11px}}
 h2{{font-size:14px;margin:18px 0 8px;color:#1f4e79}}
 .foot{{text-align:center;color:#999;font-size:11px;margin:18px 0}}
</style></head><body>
<header><h1>🏦 数字银行沙箱 · 界面快照</h1>
<div class="t">{_BANK_NAME} v{_BANK_VERSION} · 快照时间 {_now()} · 数据为服务端实时渲染（静态）</div></header>
<div class="wrap">
<h2>◈ 账户总览</h2>
<table><tr><th>账号</th><th>户名</th><th>余额(元)</th><th>冻结(元)</th></tr>{acc_rows}</table>
<h2>◈ 最近交易（15 笔）</h2>
<table><tr><th>交易号</th><th>付款 → 收款</th><th>金额(元)</th><th>状态</th><th>备注</th><th>时间</th></tr>{tx_rows}</table>
<h2>◈ 风控事件</h2>
<table><tr><th>级别</th><th>规则</th><th>详情</th><th>时间</th></tr>{risk_rows}</table>
<h2>◈ 审计日志</h2>
<table><tr><th>动作</th><th>账户</th><th>结果</th><th>时间</th></tr>{audit_rows}</table>
<div class="foot">由数字银行沙箱服务端渲染 · Agent 可随时重新抓取获取最新状态 · 资金为仿真数据</div>
</div></body></html>"""

    # ═══════════ ★第421章 贷款融资（授信→放款→还款） ═══════════
    def loans(self, account_id: str = "") -> dict:
        with self._lock:
            if account_id:
                rows = self._db.execute("SELECT * FROM loans WHERE account_id=? ORDER BY loan_id DESC",
                                        (account_id,)).fetchall()
            else:
                rows = self._db.execute("SELECT * FROM loans ORDER BY loan_id DESC").fetchall()
            return {"success": True, "count": len(rows),
                    "items": [dict(r) | {"principal_yuan": _yuan(r["principal"]),
                                         "remaining_yuan": _yuan(r["remaining"])} for r in rows]}

    def apply_loan(self, account_id: str, amount_yuan: float, term_months: int = 12) -> dict:
        """授信三要素：账户余额 × 流水活跃度 → 额度；通过即放款（余额入账）。"""
        amount = int(round(float(amount_yuan) * 100))
        with self._lock:
            acc = self._db.execute("SELECT * FROM accounts WHERE account_id=?", (account_id,)).fetchone()
            if acc is None:
                return {"success": False, "error": f"账户 {account_id} 不存在"}
            if amount <= 0:
                return {"success": False, "error": "贷款金额必须为正"}
            tx_count = self._db.execute("SELECT COUNT(*) c FROM transactions WHERE from_acc=? OR to_acc=?",
                                        (account_id, account_id)).fetchone()["c"]
            # ★437 授信分档：个人=余额×3+流水加成；对公=余额×2+流水×10（营收流水权重更高）
            acc_type = _ACC_TYPES.get(account_id, "PERSONAL")
            if acc_type == "CORP":
                credit_limit = int(acc["balance"] * 2 + tx_count * 1000_00)
                basis = "对公授信（余额×2 + 流水×1万/笔）"
            else:
                credit_limit = int(acc["balance"] * 3 + tx_count * 500_00)
                basis = "个人授信（余额×3 + 流水加成）"
            if amount > credit_limit:
                self._risk_event(account_id, "MEDIUM", "授信不足",
                                 f"申请 {_yuan(amount)} 元超出授信额度 {_yuan(credit_limit)} 元")
                self._db.commit()
                return {"success": False, "rejected": True,
                        "reason": (f"授信额度不足：{basis}评估额度 {_yuan(credit_limit)} 元"
                                   f"，申请 {_yuan(amount)} 元")}
            rate = 4.5 + (term_months / 12) * 1.2  # 期限越长利率越高（对公上浮 0.3）
            if acc_type == "CORP":
                rate += 0.3
            cur = self._db.execute(
                "INSERT INTO loans(account_id,principal,rate,term_months,remaining,status,ts)"
                " VALUES(?,?,?,?,?,?,?)",
                (account_id, amount, round(rate, 2), term_months, amount, "还款中", _now()))
            loan_id = cur.lastrowid
            self._db.execute("UPDATE accounts SET balance=balance+? WHERE account_id=?",
                             (amount, account_id))
            # ★437 守恒闭环：放款=银行信贷资产→客户负债，balance 增额计入
            #   动态 seed 基准（seed_adj），还款时等额回冲——对账恒等式始终成立
            self._sim_set(f"seed_adj_{account_id}",
                          str(int(self._sim_get(f"seed_adj_{account_id}", "0")) + amount))
            self._event("对公放款" if acc_type == "CORP" else "个人放款",
                        f"{account_id} 放款 {_yuan(amount)} 元",
                        f"年化 {rate:.2f}% 期限 {term_months} 个月（日切自动计息）")
            self._audit(account_id, "loan_disburse", {"loan": loan_id, "amount": amount},
                        f"放款 {_yuan(amount)} 元，年化 {rate:.2f}%")
            self._db.commit()
            return {"success": True, "loan_id": loan_id, "amount_yuan": _yuan(amount),
                    "rate": round(rate, 2), "term_months": term_months,
                    "message": (f"授信通过：放款 {_yuan(amount)} 元已入账，"
                                f"年利率 {rate:.2f}%，期限 {term_months} 个月")}

    def repay_loan(self, loan_id: int, amount_yuan: float) -> dict:
        amount = int(round(float(amount_yuan) * 100))
        with self._lock:
            loan = self._db.execute("SELECT * FROM loans WHERE loan_id=?", (loan_id,)).fetchone()
            if loan is None:
                return {"success": False, "error": f"贷款 {loan_id} 不存在"}
            if loan["status"] != "还款中":
                return {"success": False, "error": f"贷款状态为 {loan['status']}，无需还款"}
            acc = self._db.execute("SELECT * FROM accounts WHERE account_id=?",
                                   (loan["account_id"],)).fetchone()
            if acc["balance"] < amount:
                return {"success": False, "error": "余额不足"}
            pay = min(amount, loan["remaining"])
            self._db.execute("UPDATE accounts SET balance=balance-? WHERE account_id=?",
                             (pay, loan["account_id"]))
            remaining = loan["remaining"] - pay
            status = "结清" if remaining <= 0 else "还款中"
            self._db.execute("UPDATE loans SET remaining=?, status=? WHERE loan_id=?",
                             (max(remaining, 0), status, loan_id))
            # ★437 守恒闭环：还款回冲动态 seed 基准（与放款对偶）
            self._sim_set(f"seed_adj_{loan['account_id']}",
                          str(int(self._sim_get(f"seed_adj_{loan['account_id']}", "0")) - pay))
            self._audit(loan["account_id"], "loan_repay", {"loan": loan_id, "amount": pay},
                        f"还款 {_yuan(pay)} 元，剩余 {_yuan(max(remaining, 0))} 元")
            self._db.commit()
            return {"success": True, "loan_id": loan_id, "paid_yuan": _yuan(pay),
                    "remaining_yuan": _yuan(max(remaining, 0)), "status": status,
                    "message": f"还款 {_yuan(pay)} 元成功，剩余本金 {_yuan(max(remaining, 0))} 元（{status}）"}

    # ═══════════ ★第421章 基金（净值申购/赎回） ═══════════
    def funds(self) -> dict:
        return {"success": True, "items": market_engine.fund_snapshot()}

    def fund_nav(self, code: str, days: int = 90) -> dict:
        rows = market_engine.gen_nav_series(code, days)
        if not rows:
            return {"success": False, "error": f"基金 {code} 不存在"}
        return {"success": True, "code": code, "count": len(rows), "items": rows}

    def fund_buy(self, account_id: str, code: str, amount_yuan: float) -> dict:
        amount = int(round(float(amount_yuan) * 100))
        with self._lock:
            acc = self._db.execute("SELECT * FROM accounts WHERE account_id=?", (account_id,)).fetchone()
            meta = next((f for f in market_engine.FUNDS if f["code"] == code), None)
            if acc is None or meta is None:
                return {"success": False, "error": "账户或基金不存在"}
            if acc["balance"] < amount:
                return {"success": False, "error": "余额不足"}
            nav = market_engine.gen_nav_series(code, days=1)[-1]["nav"]
            live = market_engine.LIVE.nav_of(code)
            if live:
                nav = live  # ★436 实时净值申购
            shares = round(amount / 100 / nav, 2)
            self._db.execute("UPDATE accounts SET balance=balance-? WHERE account_id=?",
                             (amount, account_id))
            # ★436 一致性：基金申购落内部流水
            self._db.execute(
                "INSERT INTO transactions(from_acc,to_acc,amount,status,kind,note,ts)"
                " VALUES(?, 'MARKET', ?, 'success','基金申购', ?, ?)",
                (account_id, amount, f"{meta['name']} {shares} 份 @ {nav}", _now()))
            exist = self._db.execute("SELECT * FROM fund_holdings WHERE account_id=? AND code=?",
                                     (account_id, code)).fetchone()
            if exist:
                self._db.execute("UPDATE fund_holdings SET shares=shares+?, cost=cost+? "
                                 "WHERE account_id=? AND code=?", (shares, amount, account_id, code))
            else:
                self._db.execute("INSERT INTO fund_holdings VALUES(?,?,?,?)",
                                 (account_id, code, shares, amount))
            self._audit(account_id, "fund_buy", {"code": code, "amount": amount},
                        f"申购 {shares} 份（净值 {nav}）")
            self._db.commit()
            return {"success": True, "code": code, "name": meta["name"], "nav": nav,
                    "shares": shares, "message": (f"已申购 {meta['name']} {shares} 份"
                                                  f"（净值 {nav}，{_yuan(amount)} 元）")}

    def fund_sell(self, account_id: str, code: str, shares: float) -> dict:
        with self._lock:
            hold = self._db.execute("SELECT * FROM fund_holdings WHERE account_id=? AND code=?",
                                    (account_id, code)).fetchone()
            meta = next((f for f in market_engine.FUNDS if f["code"] == code), None)
            if hold is None or meta is None:
                return {"success": False, "error": "无该基金持仓"}
            shares = min(float(shares), hold["shares"])
            nav = market_engine.gen_nav_series(code, days=1)[-1]["nav"]
            live = market_engine.LIVE.nav_of(code)
            if live:
                nav = live  # ★436 实时净值赎回
            amount = int(round(shares * nav * 100))
            self._db.execute("UPDATE fund_holdings SET shares=shares-?, cost=cost-? "
                             "WHERE account_id=? AND code=?",
                             (shares, min(int(round(hold["cost"] * shares / hold["shares"])), hold["cost"]),
                              account_id, code))
            self._db.execute("DELETE FROM fund_holdings WHERE account_id=? AND code=? AND shares<=0.001",
                             (account_id, code))
            self._db.execute("UPDATE accounts SET balance=balance+? WHERE account_id=?",
                             (amount, account_id))
            # ★436 一致性：基金赎回落内部流水
            self._db.execute(
                "INSERT INTO transactions(from_acc,to_acc,amount,status,kind,note,ts)"
                " VALUES('MARKET', ?, ?, 'success','基金赎回', ?, ?)",
                (account_id, amount, f"{meta['name']} {shares} 份 @ {nav}", _now()))
            self._audit(account_id, "fund_sell", {"code": code, "shares": shares},
                        f"赎回 {shares} 份，回款 {_yuan(amount)} 元")
            self._db.commit()
            return {"success": True, "message": (f"已赎回 {meta['name']} {shares} 份，"
                                                 f"回款 {_yuan(amount)} 元（净值 {nav}）")}

    def holdings(self, account_id: str = "ACC001") -> dict:
        with self._lock:
            fh = self._db.execute("SELECT * FROM fund_holdings WHERE account_id=?",
                                  (account_id,)).fetchall()
            sh = self._db.execute("SELECT * FROM stock_holdings WHERE account_id=?",
                                  (account_id,)).fetchall()
            return {"success": True,
                    "funds": [dict(r) for r in fh],
                    "stocks": [dict(r) | {"cost_yuan": _yuan(r["cost"])} for r in sh]}

    # ═══════════ ★第421章 股票（市价买卖 + K线行情） ═══════════
    def stock_list(self) -> dict:
        return {"success": True, "items": market_engine.quote_snapshot()}

    def stock_kline(self, code: str, bars: int = 60) -> dict:
        rows = market_engine.gen_kline(code, bars)
        if not rows:
            return {"success": False, "error": f"股票 {code} 不存在"}
        return {"success": True, "code": code, "count": len(rows), "items": rows}

    def stock_buy(self, account_id: str, code: str, shares: int) -> dict:
        shares = int(shares)
        with self._lock:
            acc = self._db.execute("SELECT * FROM accounts WHERE account_id=?", (account_id,)).fetchone()
            meta = next((s for s in market_engine.STOCKS if s["code"] == code), None)
            if acc is None or meta is None:
                return {"success": False, "error": "账户或股票不存在"}
            if shares <= 0 or shares % 100 != 0:
                return {"success": False, "error": "A股委托须为 100 股整数倍"}
            price = market_engine.live_price(code)  # ★436 实时成交价（日内 tick 演化）
            cost = int(round(price * shares * 100))
            if acc["balance"] < cost:
                return {"success": False, "error": (f"余额不足：需 {_yuan(cost)} 元"
                                                    f"（{price} 元 × {shares} 股）")}
            self._db.execute("UPDATE accounts SET balance=balance-? WHERE account_id=?",
                             (cost, account_id))
            # ★436 一致性：证券买入落内部流水（资金→市场池）
            self._db.execute(
                "INSERT INTO transactions(from_acc,to_acc,amount,status,kind,note,ts)"
                " VALUES(?, 'MARKET', ?, 'success','证券买入', ?, ?)",
                (account_id, cost, f"{meta['name']} {shares} 股 @ {price}", _now()))
            exist = self._db.execute("SELECT * FROM stock_holdings WHERE account_id=? AND code=?",
                                     (account_id, code)).fetchone()
            if exist:
                self._db.execute("UPDATE stock_holdings SET shares=shares+?, cost=cost+? "
                                 "WHERE account_id=? AND code=?", (shares, cost, account_id, code))
            else:
                self._db.execute("INSERT INTO stock_holdings VALUES(?,?,?,?)",
                                 (account_id, code, shares, cost))
            self._audit(account_id, "stock_buy", {"code": code, "shares": shares, "price": price},
                        f"买入 {shares} 股 @ {price}，{_yuan(cost)} 元")
            self._db.commit()
            return {"success": True, "code": code, "name": meta["name"], "price": price,
                    "shares": shares, "cost_yuan": _yuan(cost),
                    "message": f"已买入 {meta['name']} {shares} 股 @ {price} 元，成交 {_yuan(cost)} 元"}

    def stock_sell(self, account_id: str, code: str, shares: int) -> dict:
        shares = int(shares)
        with self._lock:
            hold = self._db.execute("SELECT * FROM stock_holdings WHERE account_id=? AND code=?",
                                    (account_id, code)).fetchone()
            meta = next((s for s in market_engine.STOCKS if s["code"] == code), None)
            if hold is None or meta is None:
                return {"success": False, "error": "无该股票持仓"}
            if shares > hold["shares"]:
                return {"success": False, "error": f"持仓仅 {hold['shares']} 股"}
            price = market_engine.live_price(code)  # ★436 实时成交价
            gain = int(round(price * shares * 100))
            self._db.execute("UPDATE stock_holdings SET shares=shares-?, cost=cost-? "
                             "WHERE account_id=? AND code=?",
                             (shares, min(int(round(hold["cost"] * shares / hold["shares"])), hold["cost"]),
                              account_id, code))
            self._db.execute("DELETE FROM stock_holdings WHERE account_id=? AND code=? AND shares<=0",
                             (account_id, code))
            self._db.execute("UPDATE accounts SET balance=balance+? WHERE account_id=?",
                             (gain, account_id))
            # ★436 一致性：证券卖出落内部流水（市场池→资金）
            self._db.execute(
                "INSERT INTO transactions(from_acc,to_acc,amount,status,kind,note,ts)"
                " VALUES('MARKET', ?, ?, 'success','证券卖出', ?, ?)",
                (account_id, gain, f"{meta['name']} {shares} 股 @ {price}", _now()))
            self._audit(account_id, "stock_sell", {"code": code, "shares": shares, "price": price},
                        f"卖出 {shares} 股 @ {price}，回款 {_yuan(gain)} 元")
            self._db.commit()
            return {"success": True, "message": (f"已卖出 {meta['name']} {shares} 股 @ {price} 元，"
                                                 f"回款 {_yuan(gain)} 元")}


def json_dumps(obj) -> str:
    import json
    return json.dumps(obj, ensure_ascii=False)
