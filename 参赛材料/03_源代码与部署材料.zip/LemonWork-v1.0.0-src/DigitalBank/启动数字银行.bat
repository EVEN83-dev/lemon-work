@echo off
chcp 65001 >nul
title 数字银行沙箱 v2.0.0 · 动态银行
cd /d "%~dp0"

rem ── Python 定位：优先 Lemon 沙箱解释器，回退系统 python ──
set "PY=D:\xiaomi_temp\lemon_agent\_py312\python.exe"
if not exist "%PY%" set "PY=python"

rem ── 动态银行节奏（秒/银行日；0=真实时钟；默认 30 秒一日，演示友好）──
if not defined SIM_DAY_SECONDS set "SIM_DAY_SECONDS=30"

rem ── 防重复启动：8090 已在监听则直接打开控制台 ──
netstat -ano | findstr ":8090" | findstr "LISTENING" >nul 2>&1
if %errorlevel%==0 (
  echo [数字银行] 服务已在运行（:8090），直接打开控制台。
  start "" http://127.0.0.1:8090/
  timeout /t 2 >nul
  exit /b 0
)

echo ══════════════════════════════════════════════════════
echo    数字银行沙箱 v2.0.0 · 动态银行
echo ══════════════════════════════════════════════════════
echo    ▸ 行情 tick 实时演化（每 3 秒，红涨绿跌）
echo    ▸ 银行日节奏：每 %SIM_DAY_SECONDS% 秒切一日（日切自动跑：
echo      活期利息 / 定期到期兑付 / 订阅扣费 / 贷款计息）
echo    ▸ 交易「处理中」形态 · 动态事件流留痕
echo ══════════════════════════════════════════════════════
echo    控制台:  http://127.0.0.1:8090/
echo    健康检查: http://127.0.0.1:8090/api/health
echo    银行时钟: http://127.0.0.1:8090/api/sim
echo    停止:    关闭本窗口 或 Ctrl+C
echo ══════════════════════════════════════════════════════

rem ── 2 秒后自动打开控制台（等服务起在前台）──
start "" cmd /c "timeout /t 2 >nul & start http://127.0.0.1:8090/"

"%PY%" server.py
echo.
echo [数字银行] 服务已停止。
pause
