# -*- coding: utf-8 -*-
"""★第438章 冒烟：AI Banking 六场景全链（iCAN 赛题对表）
═══════════════════════════════════════════════════════════════════════
场景1 智能转账：人名/手机号检索 → 定时转账（日切到期执行）→ AA 收款
场景2 账单分析：分类统计 + 异常交易识别
场景3 理财操作：风险评估 → 等级内产品推荐（含复利对比）
场景4 卡片管理：申请/调额/限制→交易拒绝/解锁→交易恢复/挂失
场景5 订阅管理：列有效订阅 → 一键取消 → 日切不再扣
场景6 跨场景联动：生日档案 → 锁定1000元活期 → 订购鲜花蛋糕
"""
import os
import sys
import tempfile
import time

os.environ["SIM_DAY_SECONDS"] = "2"
os.environ["MARKET_TICK_SECONDS"] = "1"

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  {'✅' if cond else '❌'} {name}" + (f" —— {detail}" if detail else ""))


print("=" * 70)
print("第438章冒烟：AI Banking 六场景（iCAN 赛题对表）")
print("=" * 70)

import bank_core
db = os.path.join(tempfile.gettempdir(), "bank_438_smoke.db")
for suf in ("", "-wal", "-shm"):
    if os.path.exists(db + suf):
        os.remove(db + suf)
CORE = bank_core.BankCore(db_path=db)

print("\n[场景1] 智能转账：检索 / 定时 / AA")
f = CORE.find_account("李雷")
check("1.1 按人名检索", f["count"] == 1 and f["items"][0]["account_id"] == "ACC004")
f2 = CORE.find_account("139-2000-0002")
check("1.2 按手机号检索", f2["count"] == 1 and f2["items"][0]["account_id"] == "ACC002")
st = CORE.schedule_transfer("ACC001", "ACC004", 300_00, 3, "三日后还款")
check("1.3 定时转账预约", st.get("success"), st.get("message", "")[:40])
CORE.set_sim_speed(0.5)  # 加速冲到执行日
day_now = CORE.sim_info()["sim_day"]
while CORE.sim_info()["sim_day"] < st["exec_day"] + 1:
    time.sleep(0.6)
lst = CORE.scheduled_list()
done = [x for x in lst["items"] if x["st_id"] == st["st_id"] and x["status"] == "已执行"]
check("1.4 定时转账到期自动执行", bool(done), done[0]["status"] if done else "未执行")
aa = CORE.aa_collect("ACC001", ["ACC004", "ACC005"], 50_00, "聚餐分摊")
check("1.5 AA 收款 2 人各 50 元", aa["success"] and aa["collected"] == 100_00,
      aa["message"][:50])
CORE.set_sim_speed(2)

print("\n[场景2] 账单分析")
b = CORE.bill_summary("ACC001")
check("2.1 收支分类统计", b["success"] and b["total_income"] > 0 and len(b["categories"]) >= 2,
      b["message"])
a = CORE.bill_anomalies("ACC001")
check("2.2 异常识别可运行", a["success"], a["message"][:50])

print("\n[场景3] 理财操作")
ra = CORE.risk_assess("ACC001", [4, 5, 4, 4])
check("3.1 风险评估 R4", ra.get("level") == 4, ra.get("risk_level"))
rec = CORE.product_recommend("ACC001")
check("3.2 等级内推荐（≤R4 全可售）", rec["success"] and len(rec["items"]) >= 2,
      "；".join(p["name"] for p in rec["items"][:3]))
check("3.3 附复利收益对比", all("yuan_1w_90d_interest" in p for p in rec["items"]))

print("\n[场景4] 卡片管理")
ca = CORE.card_apply("ACC001")
check("4.1 卡申请", ca.get("success"), ca.get("message", "")[:40])
no = ca["card_no"]
check("4.2 额度调整", CORE.card_op(no, "limit", 8000_00)["success"])
CORE.card_op(no, "loss", None)
check("4.3 挂失后状态", CORE.card_list("ACC001")["items"][-1]["status"] == "挂失")
CORE.card_op("6222 0000 0001", "loss", None)  # 老卡一并挂失 → 名下无可用卡
r = CORE.transfer("ACC001", "ACC004", 10_00)
check("4.4 全卡挂失 → 转账被拒", (not r.get("success")) and "挂失" in r.get("error", ""),
      (r.get("error") or "")[:40])
CORE.card_op(no, "unrestrict", None)
# 老卡仍是挂失 → 恢复老卡 6222 0001
old = CORE.card_list("ACC001")["items"][0]["card_no"]
CORE.card_op(old, "unrestrict", None)
r2 = CORE.transfer("ACC001", "ACC004", 10_00)
check("4.5 解锁 → 交易恢复", r2.get("success"))

print("\n[场景5] 订阅管理")
subs = [x for x in CORE.subscriptions()["items"] if x.get("status", "active") == "active"]
check("5.1 有效订阅清单", len(subs) >= 1, "；".join(f"#{s['id']}{s['merchant']}" for s in subs[:3]))
cx = CORE.subscription_cancel(subs[0]["id"])
check("5.2 一键取消", cx.get("success"), cx.get("message", "")[:40])
again = CORE.subscription_cancel(subs[0]["id"])
check("5.3 重复取消被拒", not again.get("success"))

print("\n[场景6] 跨场景联动（生日 → 锁活期 → 订鲜花蛋糕）")
bd = CORE.birthdays()
check("6.1 生日档案（妈妈生日已建档）", len(bd["items"]) >= 1,
      "；".join(f"{x['owner']} {x['birthday']}" for x in bd["items"]))
lock = CORE.lock_deposit("ACC001", 1000_00, "P001")
check("6.2 锁定 1000 元活期（生日专项资金）", lock.get("success"), lock.get("message", "")[:40])
m1 = CORE.mall_order("M001", "ACC001", "妈妈生日鲜花")
m2 = CORE.mall_order("M002", "ACC001", "妈妈生日蛋糕")
check("6.3 订购鲜花", m1.get("success"), m1.get("message", "")[:40])
check("6.4 订购蛋糕", m2.get("success"), m2.get("message", "")[:40])

print("\n[终] 全账户守恒（六场景全部扰动后）")
time.sleep(3)  # 等异步 settle 线程全部落账（0.9~1.6s + 余量）
fin = CORE.reconcile()
if not fin["balanced"]:  # 宽限重试一次（等待最后落账）
    time.sleep(3)
    fin = CORE.reconcile()
check("终.1 全账户账实相符", fin["balanced"],
      "；".join(f"{x['account_id']}不平" for x in fin["accounts"] if not x["ok"]))

print("\n" + "=" * 70)
print(f"结果: {len(PASS)} PASS / {len(FAIL)} FAIL")
if FAIL:
    print("失败项:", FAIL)
    sys.exit(1)
print("第438章冒烟全绿 ✅ —— AI Banking 六场景全覆盖")
