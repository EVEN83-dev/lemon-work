# -*- coding: utf-8 -*-
"""数字银行沙箱 · HTTP API 服务（server.py）
═══════════════════════════════════════════════════════════════
零第三方依赖（仅 Python 标准库）。启动：
    python server.py            # 默认 0.0.0.0:8090
    python server.py 8091       # 指定端口

API（REST JSON，详见 README.md）：
  GET  /                     → Web 操作台（index.html）
  GET  /api/health           → 健康检查（Agent 探测入口）
  GET  /api/accounts         → 账户列表
  GET  /api/accounts/{id}    → 单账户
  POST /api/transfer         → 转账 {from,to,amount,note,idem_key}（单位：分）
  POST /api/reverse          → 冲正 {tx_id,reason}
  GET  /api/transactions     → 流水 ?account=ACC001&limit=20
  GET  /api/audit            → 审计日志 ?limit=50
  GET  /api/risk-events      → 风控事件
  POST /api/reconcile        → 对账
  POST /api/compound         → 复利试算 {principal,annual_rate,days}
  GET  /api/products         → 理财产品
  POST /api/lock             → 申购 {amount,prod_id}（账户固定 ACC001）
  POST /api/unlock           → 赎回 {amount,prod_id}
  GET  /api/subscriptions    → 订阅列表
"""
import json
import os
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from bank_core import BankCore

CORE = BankCore()
HERE = os.path.dirname(os.path.abspath(__file__))
MAIN_ACCOUNT = "ACC001"

# ★v356 UI 状态总线（操作台页面跟随 Agent 业务跳动）：最近一次导航意图
_UI_STATE = {"view": "", "highlight": "", "msg": "", "ts": 0.0}


def _ok(obj, code=200):
    return code, obj


def _bad(msg, code=400):
    return code, {"success": False, "error": msg}


def handle(method: str, path: str, query: dict, body: dict):
    """路由总入口。返回 (http_code, dict)。"""
    # ---- 服务菜单（Agent 服务发现：抓取本行支持的全部可选操作） ----
    if path == "/api/menu" and method == "GET":
        return _ok({
            "success": True, "bank": CORE.health().get("bank"),
            "items": [
                {"name": "健康检查", "method": "GET", "path": "/api/health", "params": "-"},
                {"name": "账户列表", "method": "GET", "path": "/api/accounts", "params": "-"},
                {"name": "账户详情", "method": "GET", "path": "/api/accounts/{id}", "params": "-"},
                {"name": "转账", "method": "POST", "path": "/api/transfer",
                 "params": "to, amount(分), note?, idem_key?, from?=ACC001"},
                {"name": "冲正", "method": "POST", "path": "/api/reverse", "params": "tx_id, reason?"},
                {"name": "交易流水", "method": "GET", "path": "/api/transactions",
                 "params": "account?, limit?"},
                {"name": "审计日志", "method": "GET", "path": "/api/audit", "params": "limit?"},
                {"name": "风控事件", "method": "GET", "path": "/api/risk-events", "params": "limit?"},
                {"name": "对账", "method": "POST", "path": "/api/reconcile", "params": "-"},
                {"name": "复利试算", "method": "POST", "path": "/api/compound",
                 "params": "principal(元), annual_rate(%), days"},
                {"name": "理财产品", "method": "GET", "path": "/api/products", "params": "-"},
                {"name": "理财申购", "method": "POST", "path": "/api/lock",
                 "params": "amount(分), prod_id?"},
                {"name": "理财赎回", "method": "POST", "path": "/api/unlock",
                 "params": "amount(分), prod_id?"},
                {"name": "订阅列表", "method": "GET", "path": "/api/subscriptions", "params": "account?"},
                # ★第436章 动态银行
                {"name": "银行动态事件", "method": "GET", "path": "/api/bank-events",
                 "params": "limit?"},
                {"name": "实时行情", "method": "GET", "path": "/api/quote", "params": "-"},
                {"name": "定期存款清单", "method": "GET", "path": "/api/deposits",
                 "params": "account?"},
                {"name": "银行时钟", "method": "GET", "path": "/api/sim", "params": "-"},
                {"name": "调时钟节奏", "method": "POST", "path": "/api/sim/speed",
                 "params": "seconds_per_day(0=真实时钟)"},
                # ★第437章 社会级生态
                {"name": "社会服务统计", "method": "GET", "path": "/api/social", "params": "-"},
                {"name": "对公机构主体", "method": "GET", "path": "/api/corp-accounts",
                 "params": "-"},
                # ★第438章 AI Banking 六场景
                {"name": "收款人检索", "method": "GET", "path": "/api/accounts/find",
                 "params": "q(人名/手机号/账号)"},
                {"name": "定时转账预约", "method": "POST", "path": "/api/transfers/schedule",
                 "params": "to, amount(分), after_days, note?"},
                {"name": "定时转账清单", "method": "GET", "path": "/api/transfers/scheduled",
                 "params": "account?"},
                {"name": "拆分AA收款", "method": "POST", "path": "/api/transfer/aa",
                 "params": "members[], amount_each(分), note?"},
                {"name": "账单分类分析", "method": "GET", "path": "/api/bill/summary",
                 "params": "account?"},
                {"name": "异常交易识别", "method": "GET", "path": "/api/bill/anomalies",
                 "params": "account?"},
                {"name": "风险评估", "method": "POST", "path": "/api/risk-assess",
                 "params": "answers[](1-5 分)"},
                {"name": "产品推荐", "method": "GET", "path": "/api/products/recommend",
                 "params": "account?"},
                {"name": "卡片清单", "method": "GET", "path": "/api/cards", "params": "account?"},
                {"name": "卡片申请", "method": "POST", "path": "/api/cards/apply",
                 "params": "from?"},
                {"name": "卡片操作", "method": "POST", "path": "/api/cards/{no}",
                 "params": "action(limit/restrict/unrestrict/loss), value?"},
                {"name": "取消订阅", "method": "POST", "path": "/api/subscriptions/{id}/cancel",
                 "params": "-"},
                {"name": "商城商品", "method": "GET", "path": "/api/mall/items", "params": "-"},
                {"name": "商城下单", "method": "POST", "path": "/api/mall/order",
                 "params": "item_id, note?"},
                {"name": "生日档案", "method": "GET", "path": "/api/birthdays", "params": "-"},
            ]})
    # ---- 健康检查 ----
    if path == "/api/health" and method == "GET":
        return _ok(CORE.health())
    # ---- 账户 ----
    if path == "/api/accounts" and method == "GET":
        return _ok(CORE.accounts())
    # ★438 收款人检索——必须在 /api/accounts/{id} 通配之前（否则 "find" 被当账户名）
    if path == "/api/accounts/find" and method == "GET":
        return _ok(CORE.find_account(query.get("q", "")))
    if path.startswith("/api/accounts/") and method == "GET":
        # ★439 账户详情聚合（/api/accounts/{id}/detail）优先于单账户
        if path.endswith("/detail"):
            return _ok(CORE.account_detail(path.split("/")[-2]))
        return _ok(CORE.account(path.split("/")[-1]))
    # ---- 转账 ----
    if path == "/api/transfer" and method == "POST":
        for k in ("to", "amount"):
            if body.get(k) in (None, ""):
                return _bad(f"缺少必填字段: {k}")
        return _ok(CORE.transfer(body.get("from") or MAIN_ACCOUNT, str(body["to"]),
                                 int(body["amount"]), note=str(body.get("note", "")),
                                 idem_key=body.get("idem_key")))
    # ---- 冲正 ----
    if path == "/api/reverse" and method == "POST":
        if not body.get("tx_id"):
            return _bad("缺少必填字段: tx_id")
        return _ok(CORE.reverse(int(body["tx_id"]), str(body.get("reason", "用户发起"))))
    # ---- 流水/审计/风控 ----
    if path == "/api/transactions" and method == "GET":
        return _ok(CORE.transactions(query.get("account", ""), int(query.get("limit", 20))))
    if path == "/api/audit" and method == "GET":
        return _ok(CORE.audit_log(int(query.get("limit", 50))))
    if path == "/api/risk-events" and method == "GET":
        return _ok(CORE.risk_events(int(query.get("limit", 50))))
    # ---- 对账 ----
    if path == "/api/reconcile" and method == "POST":
        return _ok(CORE.reconcile())
    # ---- 复利 ----
    if path == "/api/compound" and method == "POST":
        return _ok(CORE.compound(float(body.get("principal", 0)),
                                 float(body.get("annual_rate", 0)),
                                 int(body.get("days", 0))))
    # ---- 理财 ----
    if path == "/api/products" and method == "GET":
        return _ok(CORE.products())
    if path == "/api/lock" and method == "POST":
        return _ok(CORE.lock_deposit(body.get("from") or MAIN_ACCOUNT,
                                     int(body.get("amount", 0)),
                                     str(body.get("prod_id", "P001"))))
    if path == "/api/unlock" and method == "POST":
        return _ok(CORE.unlock_deposit(body.get("from") or MAIN_ACCOUNT,
                                       int(body.get("amount", 0)),
                                       str(body.get("prod_id", "P001"))))
    if path == "/api/subscriptions" and method == "GET":
        return _ok(CORE.subscriptions(query.get("account", MAIN_ACCOUNT)))
    # ---- ★第436章 动态银行 ----
    if path == "/api/bank-events" and method == "GET":
        return _ok(CORE.bank_events(int(query.get("limit", 30))))
    if path == "/api/quote" and method == "GET":
        return _ok(CORE.stock_list())
    if path == "/api/deposits" and method == "GET":
        return _ok(CORE.deposits(query.get("account", "")))
    if path == "/api/sim" and method == "GET":
        return _ok(CORE.sim_info())
    if path == "/api/sim/speed" and method == "POST":
        return _ok(CORE.set_sim_speed(float(body.get("seconds_per_day", 0))))
    # ---- ★第437章 社会级生态 ----
    if path == "/api/social" and method == "GET":
        return _ok(CORE.social_summary())
    if path == "/api/corp-accounts" and method == "GET":
        return _ok(CORE.corp_accounts())
    # ---- ★第438章 AI Banking 六场景 ----
    if path == "/api/transfers/schedule" and method == "POST":
        return _ok(CORE.schedule_transfer(body.get("from") or MAIN_ACCOUNT,
                                          str(body.get("to", "")), int(body.get("amount", 0)),
                                          int(body.get("after_days", 1)),
                                          str(body.get("note", ""))))
    if path == "/api/transfers/scheduled" and method == "GET":
        return _ok(CORE.scheduled_list(query.get("account", "")))
    if path == "/api/transfer/aa" and method == "POST":
        return _ok(CORE.aa_collect(body.get("from") or MAIN_ACCOUNT,
                                   body.get("members") or [], int(body.get("amount_each", 0)),
                                   str(body.get("note", ""))))
    if path == "/api/bill/summary" and method == "GET":
        return _ok(CORE.bill_summary(query.get("account", MAIN_ACCOUNT),
                                     int(query.get("days", 30))))
    if path == "/api/bill/anomalies" and method == "GET":
        return _ok(CORE.bill_anomalies(query.get("account", MAIN_ACCOUNT)))
    if path == "/api/risk-assess" and method == "POST":
        return _ok(CORE.risk_assess(body.get("from") or MAIN_ACCOUNT,
                                    body.get("answers") or []))
    if path == "/api/products/recommend" and method == "GET":
        return _ok(CORE.product_recommend(query.get("account", MAIN_ACCOUNT)))
    if path == "/api/cards" and method == "GET":
        return _ok(CORE.card_list(query.get("account", MAIN_ACCOUNT)))
    if path == "/api/cards/apply" and method == "POST":
        return _ok(CORE.card_apply(body.get("from") or MAIN_ACCOUNT))
    if path.startswith("/api/cards/") and method == "POST":
        # ★v357: 卡号含空格（"6222 0000 0001"）→ URL 编码 %20 → 路径参数必须
        #   URL 解码，否则恒报"卡不存在"（S4 卡片管理空错误链根因之一）
        from urllib.parse import unquote as _uq
        no = _uq(path.split("/")[-1])
        return _ok(CORE.card_op(no, str(body.get("action", "")), body.get("value")))
    if path.startswith("/api/subscriptions/") and path.endswith("/cancel") and method == "POST":
        return _ok(CORE.subscription_cancel(int(path.split("/")[-2])))
    if path == "/api/mall/items" and method == "GET":
        return _ok(CORE.mall_items())
    if path == "/api/mall/order" and method == "POST":
        return _ok(CORE.mall_order(str(body.get("item_id", "")),
                                   body.get("from") or MAIN_ACCOUNT,
                                   str(body.get("note", ""))))
    if path == "/api/birthdays" and method == "GET":
        return _ok(CORE.birthdays())
    # ---- ★第440章 业务办事流程单 ----
    if path == "/api/service-orders" and method == "GET":
        return _ok(CORE.service_orders(query.get("account", "")))
    if path == "/api/service-orders" and method == "POST":
        return _ok(CORE.create_service_order(body.get("from") or MAIN_ACCOUNT,
                                             str(body.get("biz_type", "")),
                                             body.get("payload") or {}))
    # ---- ★第441章 现金存取 + 电子回执 ----
    if path == "/api/cash/deposit" and method == "POST":
        return _ok(CORE.deposit_cash(body.get("from") or MAIN_ACCOUNT,
                                     int(body.get("amount", 0)),
                                     str(body.get("note", "柜面存款"))))
    if path == "/api/cash/withdraw" and method == "POST":
        return _ok(CORE.withdraw_cash(body.get("from") or MAIN_ACCOUNT,
                                      int(body.get("amount", 0)),
                                      str(body.get("note", "柜面取款"))))
    if path == "/api/receipts" and method == "GET":
        return _ok(CORE.receipts(query.get("account", ""), int(query.get("limit", 20))))
    if path.startswith("/api/receipt/") and method == "GET":
        return _ok(CORE.receipt(int(path.split("/")[-1])))
    if path == "/api/calibrate" and method == "POST":
        return _ok(CORE.calibrate())
    # ---- ★第442章 注册开户 / 微信绑定 / 个人资料 / 订单 ----
    if path == "/api/account/open" and method == "POST":
        return _ok(CORE.open_account_flow(str(body.get("name", "")),
                                          str(body.get("phone", "")),
                                          str(body.get("birthday", ""))))
    if path == "/api/profile" and method == "POST":
        return _ok(CORE.update_profile(body.get("from") or MAIN_ACCOUNT,
                                       phone=body.get("phone"), birthday=body.get("birthday")))
    if path == "/api/wx/bind" and method == "POST":
        return _ok(CORE.bind_wx(body.get("from") or MAIN_ACCOUNT,
                                str(body.get("wxname", ""))))
    if path == "/api/mall/orders" and method == "GET":
        return _ok(CORE.mall_orders(query.get("account", "")))
    # ---- ★第421章 贷款融资 ----
    if path == "/api/loans" and method == "GET":
        return _ok(CORE.loans(query.get("account", "")))
    if path == "/api/loans/apply" and method == "POST":
        return _ok(CORE.apply_loan(body.get("from") or MAIN_ACCOUNT,
                                   float(body.get("amount", 0)),
                                   int(body.get("term_months", 12))))
    if path.startswith("/api/loans/") and path.endswith("/repay") and method == "POST":
        return _ok(CORE.repay_loan(int(path.split("/")[-2]), float(body.get("amount", 0))))
    # ---- ★第421章 基金 ----
    if path == "/api/funds" and method == "GET":
        return _ok(CORE.funds())
    if path.startswith("/api/funds/") and path.endswith("/nav") and method == "GET":
        return _ok(CORE.fund_nav(path.split("/")[-2], int(query.get("days", 90))))
    if path.startswith("/api/funds/") and path.endswith("/buy") and method == "POST":
        return _ok(CORE.fund_buy(body.get("from") or MAIN_ACCOUNT, path.split("/")[-2],
                                 float(body.get("amount", 0))))
    if path.startswith("/api/funds/") and path.endswith("/sell") and method == "POST":
        return _ok(CORE.fund_sell(body.get("from") or MAIN_ACCOUNT, path.split("/")[-2],
                                  float(body.get("shares", 0))))
    if path == "/api/holdings" and method == "GET":
        return _ok(CORE.holdings(query.get("account", MAIN_ACCOUNT)))
    # ---- ★第421章 股票 ----
    if path == "/api/stocks" and method == "GET":
        return _ok(CORE.stock_list())
    if path.startswith("/api/stocks/") and path.endswith("/kline") and method == "GET":
        return _ok(CORE.stock_kline(path.split("/")[-2], int(query.get("bars", 60))))
    if path.startswith("/api/stocks/") and path.endswith("/buy") and method == "POST":
        return _ok(CORE.stock_buy(body.get("from") or MAIN_ACCOUNT, path.split("/")[-2],
                                  int(body.get("shares", 0))))
    if path.startswith("/api/stocks/") and path.endswith("/sell") and method == "POST":
        return _ok(CORE.stock_sell(body.get("from") or MAIN_ACCOUNT, path.split("/")[-2],
                                   int(body.get("shares", 0))))
    # ---- ★第427章 服务端渲染界面快照（零 JS，供 Agent 抓取呈现） ----
    if path == "/api/console" and method == "GET":
        html = CORE.console_html().encode("utf-8")
        return ("html", html)
    # ---- ★v356 UI 状态总线：让操作台页面"跟随 Agent 业务跳动" ----
    #   POST: Agent/技能写入导航意图 {view, highlight, msg}
    #   GET : 页面内跟随精灵每 1.5s 拉取，自动切页/滚动/高亮
    if path == "/api/ui/state":
        global _UI_STATE
        if method == "POST":
            _UI_STATE = {
                "view": str(body.get("view") or "")[:24],
                "highlight": str(body.get("highlight") or "")[:40],
                "msg": str(body.get("msg") or "")[:120],
                "ts": __import__("time").time(),
            }
            return _ok({"success": True, "state": _UI_STATE})
        return _ok({"success": True, "state": _UI_STATE})
    return _bad(f"未知接口: {method} {path}", 404)


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Idempotency-Key")

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def _parse_qs(self, qs: str) -> dict:
        """★438: 换 urllib.parse.parse_qs——手写版未做 URL 解码，
        中文参数（如人名检索 ?q=李雷）到达时是 %XX 形态导致 LIKE 不命中。"""
        from urllib.parse import parse_qs
        return {k: v[0] for k, v in parse_qs(qs, keep_blank_values=True).items()}

    def do_GET(self):
        path, _, qs = self.path.partition("?")
        if path in ("/", "/index.html"):
            return self._serve_index()
        if not path.startswith("/api/"):
            return self._reply(404, {"success": False, "error": "not found"})
        try:
            code, obj = handle("GET", path, self._parse_qs(qs), {})
            if code == "html":  # ★第427章: 服务端渲染界面快照（text/html 直出）
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(obj)))
                self._cors()
                self.end_headers()
                self.wfile.write(obj)
                return
        except Exception as e:
            code, obj = 500, {"success": False, "error": f"服务器异常: {e}"}
        self._reply(code, obj)

    def do_POST(self):
        path, _, qs = self.path.partition("?")
        try:
            length = int(self.headers.get("Content-Length", 0))
            raw = self.rfile.read(length) if length else b"{}"
            body = json.loads(raw.decode("utf-8") or "{}")
        except Exception:
            return self._reply(400, {"success": False, "error": "请求体不是合法 JSON"})
        try:
            code, obj = handle("POST", path, self._parse_qs(qs), body)
        except (ValueError, TypeError) as e:
            code, obj = 400, {"success": False, "error": f"参数错误: {e}"}
        except Exception as e:
            code, obj = 500, {"success": False, "error": f"服务器异常: {e}"}
        self._reply(code, obj)

    def _serve_index(self):
        return self._serve_file("index.html")

    def _serve_file(self, fname: str):
        fp = os.path.join(HERE, fname)
        try:
            with open(fp, "rb") as f:
                content = f.read()
        except FileNotFoundError:
            return self._reply(404, {"success": False, "error": f"{fname} 缺失"})
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.wfile.write(content)

    def _reply(self, code: int, obj):
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self._cors()
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, fmt, *args):  # 静默默认访问日志（保持控制台干净）
        pass


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8090
    httpd = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    print("=" * 60)
    print("  数字银行沙箱 · Digital Bank Sandbox")
    print(f"  API 服务: http://127.0.0.1:{port}/api/health")
    print(f"  Web 操作台: http://127.0.0.1:{port}/")
    print("  Ctrl+C 停止")
    print("=" * 60)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n[数字银行] 已停止")


if __name__ == "__main__":
    main()
