# -*- coding: utf-8 -*-
"""★第437章 冒烟：社会级银行生态（对公/代发工资/税/社保/公积金/公共事业/收单/守恒）
═══════════════════════════════════════════════════════════════════════
1. 社会主体开户（2 企业 + 6 机构）
2. 代发工资四分流（每 5 银行日）：净额入个人户、个税入税务局、
   社保(个人10.5%+企业25%)入社保局、公积金(个人7%+企业7%)入公积金中心
3. 个税两档正确性（独立断言：8000 元月薪的税额）
4. 公共事业代收 + 房租（每 30 银行日）
5. 商户收单（市民每日 POS 消费）
6. 对公贷款（授信分档 + 放款/还款守恒闭环）
7. 全社会 14 户对账守恒（含日切利息/代扣全部扰动）
"""
import os
import sys
import tempfile
import time

os.environ["SIM_DAY_SECONDS"] = "2"
os.environ["MARKET_TICK_SECONDS"] = "1"

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  {'✅' if cond else '❌'} {name}" + (f" —— {detail}" if detail else ""))


print("=" * 70)
print("第437章冒烟：社会级银行生态（个人业务 + 社会服务）")
print("=" * 70)

print("\n[1] 社会主体开户")
import bank_core
db = os.path.join(tempfile.gettempdir(), "bank_437_smoke.db")
for suf in ("", "-wal", "-shm"):
    if os.path.exists(db + suf):
        os.remove(db + suf)
CORE = bank_core.BankCore(db_path=db)
corp = CORE.corp_accounts()
check("1.1 对公/机构 8 主体入网", corp["count"] == 8,
      "；".join(f"{x['owner']}({x['acc_type']})" for x in corp["items"]))
tech = next(x for x in corp["items"] if x["account_id"] == "ACC-C001")
check("1.2 企业注资 50 万", tech["balance_yuan"] == "500000.00")

print("\n[2] 个税两档正确性（独立断言）")
# 月薪 8000：社保个人 840.00，公积金 560.00 → 应税 = 8000-5000-840-560 = 1600 → 3% = 48
t = CORE._income_tax(8000_00 - 5000_00 - int(8000_00 * 0.105) - int(8000_00 * 0.07))
check("2.1 8000 元月薪个税=48.00 元（3% 档）", t == 4800, f"税 {t} 分")
# 月薪 30000：社保 3150，公积金 2100 → 应税 = 30000-5000-3150-2100=19750 → 3000*3%+16750*10%=1765
t2 = CORE._income_tax(30000_00 - 5000_00 - int(30000_00 * 0.105) - int(30000_00 * 0.07))
check("2.2 30000 元月薪个税=1765.00 元（跨档）", t2 == 176500, f"税 {t2} 分")
check("2.3 应税≤0 零税（未达起征）",
      CORE._income_tax(0) == 0 and CORE._income_tax(-500_00) == 0)

print("\n[3] 代发工资四分流（快进 5 银行日）")
time.sleep(11.5)  # 2s/日 → ≥5 银行日
soc = CORE.social_summary()
st = soc["stats"]
check("3.1 工资发放>0", st["工资发放"] > 0, f"{st['工资发放']/100:.2f} 元")
check("3.2 个税入库>0", st["个税入库"] > 0, f"{st['个税入库']/100:.2f} 元")
check("3.3 社保归集>0（个人+企业）", st["社保归集"] > 0, f"{st['社保归集']/100:.2f} 元")
check("3.4 公积金归集>0（个人+企业）", st["公积金归集"] > 0, f"{st['公积金归集']/100:.2f} 元")
ev = CORE.bank_events(50)
payroll_ev = [e for e in ev["items"] if e["kind"] == "代发工资"]
check("3.5 发薪事件留痕", len(payroll_ev) >= 1, payroll_ev[0]["detail"][:60] if payroll_ev else "")

print("\n[4] 商户收单 + 公共事业")
cons_ev = [e for e in ev["items"] if e["kind"] == "商户收单"]
check("4.1 市民 POS 消费（每日随机）", len(cons_ev) >= 1,
      cons_ev[0]["detail"][:50] if cons_ev else "")
# 快进到第 30 银行日
target = 30
while CORE.sim_info()["sim_day"] < target:
    time.sleep(1.0)
    if CORE.sim_info()["sim_day"] >= target:
        break
soc2 = CORE.social_summary()
check("4.2 公共事业代收（第30日批次）", soc2["stats"]["公共事业代收"] > 0,
      f"{soc2['stats']['公共事业代收']/100:.2f} 元")
check("4.3 房租入账", soc2["stats"]["房租"] > 0, f"{soc2['stats']['房租']/100:.2f} 元")

print("\n[5] 对公贷款（授信分档+守恒闭环）")
r = CORE.apply_loan("ACC-C001", 200000, 12)
check("5.1 对公授信放款", r.get("success"), (r.get("message") or r.get("reason", ""))[:50])
before = CORE.reconcile()
check("5.2 放款后守恒（seed_adj 动态基准）", before["balanced"],
      "；".join(f"{x['account_id']}不平" for x in before["accounts"] if not x["ok"]))
rp = CORE.repay_loan(r["loan_id"], 50000)
after = CORE.reconcile()
check("5.3 还款后守恒", after["balanced"] and rp.get("success"),
      "；".join(f"{x['account_id']}不平" for x in after["accounts"] if not x["ok"]))

print("\n[6] 全社会 14 户总对账（全部扰动后）")
final = CORE.reconcile()
pers = sum(1 for x in final["accounts"] if x["acc_type"] == "PERSONAL")
gov = sum(1 for x in final["accounts"] if x["acc_type"] == "GOV")
check("6.1 全账户账实相符", final["balanced"],
      f"{len(final['accounts'])} 户（个人{pers}/对公+机构{gov+2}）；".join("")
      + (final["message"][:60]))
check("6.2 覆盖个人+对公+机构三类主体",
      pers == 5 and gov == 6,
      f"个人 {pers} / 对公 2 / 机构 {gov}")

print("\n" + "=" * 70)
print(f"结果: {len(PASS)} PASS / {len(FAIL)} FAIL")
if FAIL:
    print("失败项:", FAIL)
    sys.exit(1)
print("第437章冒烟全绿 ✅ —— 一家有社会资金循环的虚拟银行")
