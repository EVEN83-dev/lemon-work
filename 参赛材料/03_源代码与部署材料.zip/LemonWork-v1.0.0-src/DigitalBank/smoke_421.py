# -*- coding: utf-8 -*-
"""第421章 冒烟：贷款/基金/股票/K线 新端点（直接 HTTP）。"""
import json
import urllib.request

B = 'http://127.0.0.1:8090'


def call(method, path, body=None):
    data = json.dumps(body or {}).encode()
    req = urllib.request.Request(B + path, data=data if method == 'POST' else None,
                                 method=method, headers={'Content-Type': 'application/json'})
    return json.loads(urllib.request.urlopen(req, timeout=5).read())


checks = []


def ck(name, ok, detail=''):
    checks.append((name, ok))
    print(('  [PASS] ' if ok else '  [FAIL] ') + name + ('  ' + str(detail)[:75] if detail else ''))


ln = call('POST', '/api/loans/apply', {'amount': 10000, 'term_months': 12})
ck('贷款授信+放款 1 万', ln.get('success'), ln.get('message'))
ln2 = call('POST', '/api/loans/apply', {'amount': 9999999})
ck('超额贷款被拒（授信评估）', ln2.get('rejected') == True, str(ln2.get('reason', ''))[:50])
rp = call('POST', f"/api/loans/{ln['loan_id']}/repay", {'amount': 10000})
ck('还款结清', rp.get('success') and rp.get('status') == '结清', rp.get('message'))

fs = call('GET', '/api/funds')
ck('基金超市 5 只', len(fs['items']) == 5)
fb = call('POST', '/api/funds/NF0003/buy', {'amount': 5000})
ck('基金申购', fb.get('success'), fb.get('message'))
nav = call('GET', '/api/funds/NF0003/nav?days=90')
ck('净值序列 90 日', nav['count'] == 90)

sl = call('GET', '/api/stocks')
ck('股票行情 6 只', len(sl['items']) == 6)
kl = call('GET', '/api/stocks/LM600001/kline?bars=60')
ok_ohlc = all(k['high'] >= max(k['open'], k['close']) >= min(k['open'], k['close']) >= k['low']
              for k in kl['items'])
ck('K线 43~60 根 OHLC 关系合法', 40 <= kl['count'] <= 60 and ok_ohlc, f"实际 {kl['count']} 根（周末跳市）")
sb = call('POST', '/api/stocks/LM600001/buy', {'shares': 300})
ck('股票买入 300 股', sb.get('success'), sb.get('message'))
sb2 = call('POST', '/api/stocks/LM600001/buy', {'shares': 150})
ck('非100整数倍委托拒绝', sb2.get('success') == False)
ss = call('POST', '/api/stocks/LM600001/sell', {'shares': 300})
ck('股票卖出回款', ss.get('success'), ss.get('message'))
hd = call('GET', '/api/holdings')
ck('持仓查询', hd.get('success'))

print()
p = sum(1 for _, ok in checks if ok)
print(f'421 冒烟汇总: {p}/{len(checks)} PASS')
