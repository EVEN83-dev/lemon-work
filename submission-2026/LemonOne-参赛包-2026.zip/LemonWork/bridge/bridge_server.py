# -*- coding: utf-8 -*-
"""lemonD-bridge: Lemon Bridge HTTP Server (:8765)。

对外暴露 bridge 引擎能力：
  GET  /health                      B1 健康检查
  GET  /api/skills                   B2 技能列表
  POST /api/skills/{name}/execute    B2 技能执行
  POST /api/agent/chat               B3 Agent 异步任务提交
  GET  /api/agent/task/{id}          B3 任务状态查询
  GET  /api/agent/task/{id}/events   B3 SSE 流式事件
  GET  /api/mcp/tools                B4 MCP 工具枚举
  WS   /ws                           A-02 网关（chat/ping/pong/stream_delta/tool_call 帧）

依赖策略：fastapi 可用 → FastAPI+uvicorn；不可用 → stdlib http.server 同构降级。
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import argparse
import json
import os
import signal
import sys
import threading
import time
from typing import Any, Dict, List, Optional, Tuple

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from bridge.protocol.cross_end_adapter import (  # A-03 单一适配层
    PROTOCOL_VERSION as _ADAPTER_PROTOCOL_VERSION,
    error_payload as _adapter_error,
    normalize_chat_payload as _adapter_chat,
    normalize_timestamp_ms as _adapter_ts,
    to_jsonrpc_envelope as _adapter_tools_rpc,
)
from bridge.api import require_auth  # A-05: 全端点鉴权单一入口
from bridge import host_config       # A-04: 部署配置唯一真源

_VERSION = "4.8.6-lemonD1"
_STARTED_AT = time.time()
_STATE: Dict[str, Any] = {
    "started_at": _STARTED_AT,
    "engine_manager": None,
    "skill_router": None,
    "version": _VERSION,
}

# ---- 依赖探测 ----
try:
    import fastapi as _fastapi  # noqa: F401
    import uvicorn as _uvicorn  # noqa: F401
    HAS_FASTAPI = True
except Exception:
    HAS_FASTAPI = False


def _build_runtime(engine_name: str = ""):
    """惰性构建 EngineManager + SkillRouter（失败不崩，标记 offline）。"""
    em = None
    router = None
    try:
        from shared.engines.manager import EngineManager  # ★ 收口项 7: import shared 实现
        em = EngineManager()
        # 尝试自动注册默认引擎
        try:
            _auto_register_engines(em, engine_name)
        except Exception:
            logger.debug("suppressed exception")
    except Exception:
        em = None
    try:
        from bridge.skills.router import SkillRouter
        router = SkillRouter()
        # 显式触发技能自动发现（registry 不会在构造时自动扫描）
        try:
            registry = getattr(router, "_registry", None)
            if registry is not None and hasattr(registry, "auto_discover"):
                registry.auto_discover()
        except Exception:
            logger.debug("suppressed exception")
    except Exception:
        router = None
    _STATE["engine_manager"] = em
    _STATE["skill_router"] = router

    # 注入各路由模块
    try:
        from bridge.api import routes_health, routes_skills, routes_agent, routes_mcp
        routes_health.configure(_STATE)
        routes_skills.configure(_STATE)
        routes_agent.configure(_STATE)
        routes_mcp.configure(_STATE)
    except Exception:
        logger.debug("suppressed exception")
    try:
        from bridge.api import routes_crawl
        routes_crawl.configure(_STATE)   # A-08: 爬虫能力端点
    except Exception:
        logger.debug("suppressed exception")
    try:
        from bridge.api import routes_quant
        routes_quant.configure(_STATE)   # A-09: 量化端点
    except Exception:
        logger.debug("suppressed exception")
    return em, router


def _auto_register_engines(em, preferred: str = "") -> None:
    """按 config.yaml / 环境变量探测可用引擎并注册；无可用则留空。"""
    from shared.engines.base import EngineConfig  # ★ 收口项 7: 基类单源
    candidates = []
    if preferred == "ollama":
        candidates.append("ollama")
    elif preferred == "deepseek":
        candidates.append("deepseek")
    else:
        candidates = ["ollama", "deepseek"]
    for etype in candidates:
        try:
            if etype == "ollama":
                # A-04: 基址由 host_config 统一解析（env OLLAMA_BASE_URL → config.yaml）
                base_url = host_config.ollama_base_url()
                # ★ W1: 模型选择统一走 model_policy.resolve_model()
                #   优先级：env OLLAMA_MODEL > 本机存在的 qwen3.5:9b > tags 第一个 > 兜底
                try:
                    from bridge.model_policy import resolve_model
                    model = resolve_model()
                except Exception as _e:
                    print(f"[bridge_server] resolve_model 失败: {_e}")
                    model = os.environ.get("OLLAMA_MODEL", "")
                    if not model:
                        try:
                            import urllib.request as _ur
                            _tags = json.loads(_ur.urlopen(base_url.rstrip("/") + "/api/tags", timeout=4).read())
                            _names = [m.get("name", "") for m in (_tags.get("models") or [])]
                            model = _names[0] if _names else ""
                        except Exception:
                            model = ""
                em.register_engine("ollama", EngineConfig(
                    engine_type="ollama", base_url=base_url, api_key="", model=model))
            elif etype == "deepseek":
                api_key = os.environ.get("DEEPSEEK_API_KEY", "")
                if api_key:
                    em.register_engine("deepseek", EngineConfig(
                        engine_type="deepseek", base_url="https://api.deepseek.com",
                        api_key=api_key, model="deepseek-chat"))
        except Exception:
            continue


def _banner(host: str, port: int, engine: str, skills_count: int) -> None:
    mode = "FastAPI" if HAS_FASTAPI else "stdlib(http.server)"
    print("=" * 56)
    print("  Lemon Bridge Server  ::  lemonD-bridge")
    print("=" * 56)
    print(f"  Endpoint : http://{host}:{port}")
    print(f"  Mode     : {mode}")
    print(f"  Engine   : {engine or 'auto (ollama/deepseek)'}")
    print(f"  Skills   : {skills_count}")
    print(f"  Version  : {_VERSION}")
    print("=" * 56)


# ============================================================================
# A-02: /ws 网关 —— BridgeMessage 帧的真实 WebSocket 服务（RFC6455）
#   帧：{"type":"ping"|"chat"|"tool_call"|...}，timestamp 容忍秒/毫秒并统一输出毫秒
#   （经 bridge/protocol/cross_end_adapter.py 单一适配层，不散落兼容分支）
#   chat 帧（content|prompt 双兼容）→ routes_agent.submit；task events 以
#   {"type":"task_event"} 推送（与 SSE 同源 routes_agent.iter_sse，各连接独立消费，
#   不做 SSE/WS 双写）；tool_call 帧 → routes_skills.execute_skill。
# ============================================================================
_WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"


def _ws_accept(key: str) -> str:
    import base64
    import hashlib
    return base64.b64encode(hashlib.sha1((key + _WS_GUID).encode("ascii")).digest()).decode("ascii")


def _ws_send_frame(wfile, payload: bytes, opcode: int = 0x1) -> None:
    import struct
    header = bytes([0x80 | opcode])
    n = len(payload)
    if n < 126:
        header += bytes([n])
    elif n < 65536:
        header += bytes([126]) + struct.pack(">H", n)
    else:
        header += bytes([127]) + struct.pack(">Q", n)
    wfile.write(header + payload)
    wfile.flush()


def _ws_read_frame(rfile) -> Optional[Tuple[int, bytes]]:
    """读一帧：返回 (opcode, payload)；连接关闭返回 None。客户端帧自动解掩码。"""
    import struct
    hdr = rfile.read(2)
    if not hdr or len(hdr) < 2:
        return None
    b1, b2 = hdr[0], hdr[1]
    opcode = b1 & 0x0F
    masked = b2 & 0x80
    length = b2 & 0x7F
    if length == 126:
        ext = rfile.read(2)
        if len(ext) < 2:
            return None
        length = struct.unpack(">H", ext)[0]
    elif length == 127:
        ext = rfile.read(8)
        if len(ext) < 8:
            return None
        length = struct.unpack(">Q", ext)[0]
    if length > 4 * 1024 * 1024:  # 4MB 上限，防恶意超长帧
        return None
    mask = rfile.read(4) if masked else None
    payload = rfile.read(length) if length else b""
    if len(payload) < length:
        return None
    if mask and payload:
        payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
    return opcode, payload


def _ws_dispatch(msg: Any, routes_agent, routes_skills) -> List[Dict[str, Any]]:
    """应用层帧分发：返回要回写的帧列表（chat 的 task_event 由 pump 线程另推）。"""
    if not isinstance(msg, dict):
        return [_adapter_error("invalid_params", "frame must be a JSON object")]
    mtype = msg.get("type")
    now_ms = _adapter_ts(None)
    if mtype == "ping":
        return [{"type": "pong", "timestamp": _adapter_ts(msg.get("timestamp")),
                 "protocol_version": _ADAPTER_PROTOCOL_VERSION}]
    if mtype == "chat":
        norm = _adapter_chat(msg)
        if not norm.get("prompt"):
            return [_adapter_error("invalid_params", "chat frame needs prompt/content")]
        sid = norm.get("session_id") or norm.get("sessionId")
        max_iter = int(norm.get("max_iterations") or norm.get("maxIterations") or 20)
        r = routes_agent.submit(norm["prompt"], sid, max_iter)
        return [{"type": "chat_accepted", "task_id": r.get("task_id"),
                 "sessionId": r.get("session_id"),
                 "timestamp": now_ms, "protocol_version": _ADAPTER_PROTOCOL_VERSION}]
    if mtype == "tool_call":
        name = str(msg.get("name") or "")
        if not name:
            return [_adapter_error("invalid_params", "tool_call frame needs name")]
        r = routes_skills.execute_skill(name, msg.get("arguments") or {})
        return [{"type": "tool_result", "name": name, "ok": bool(r.get("ok")),
                 "output": str(r.get("output") or "")[:2000],
                 "data": r.get("data"), "error": r.get("error"),
                 "timestamp": now_ms}]
    return [_adapter_error("invalid_params", f"unknown frame type: {mtype}")]


def _ws_pump_task_events(task_id: str, routes_agent, wfile, write_lock) -> None:
    """chat 任务事件泵：同一 iter_sse 源，逐帧推 task_event，终止推 task_done。"""
    try:
        for e in routes_agent.iter_sse(task_id):
            frame = json.dumps({"type": "task_event", "task_id": task_id, "event": e},
                               ensure_ascii=False, default=str).encode("utf-8")
            with write_lock:
                _ws_send_frame(wfile, frame)
        with write_lock:
            _ws_send_frame(wfile, json.dumps(
                {"type": "task_done", "task_id": task_id, "timestamp": _adapter_ts(None)}
            ).encode("utf-8"))
    except Exception:
        # 客户端断开属正常退出路径；异常不上抛炸连接线程
        pass


def _ws_handle(handler, routes_agent, routes_skills) -> None:
    """WebSocket upgrade + 帧循环（stdlib 降级模式）。"""
    key = handler.headers.get("Sec-WebSocket-Key", "")
    upgrade = (handler.headers.get("Upgrade") or "").lower()
    if not key or "websocket" not in upgrade:
        return handler._send(400, {"ok": False, "error": "not a websocket upgrade"})
    handler.send_response(101)
    handler.send_header("Upgrade", "websocket")
    handler.send_header("Connection", "Upgrade")
    handler.send_header("Sec-WebSocket-Accept", _ws_accept(key))
    handler.end_headers()
    handler.close_connection = True
    wfile, rfile = handler.wfile, handler.rfile
    write_lock = threading.Lock()

    def safe_send(payload: bytes, opcode: int = 0x1) -> bool:
        try:
            with write_lock:
                _ws_send_frame(wfile, payload, opcode=opcode)
            return True
        except Exception:
            return False

    pending = b""
    while True:
        try:
            frame = _ws_read_frame(rfile)
        except Exception:
            break
        if frame is None:
            break
        opcode, payload = frame
        if opcode == 0x8:  # close
            safe_send(payload[:2] if payload else b"\x03\xe8", opcode=0x8)
            break
        if opcode == 0x9:  # 心跳：协议层 ping → pong
            safe_send(payload, opcode=0xA)
            continue
        if opcode in (0xA, 0x2):  # pong / binary 忽略
            continue
        if opcode == 0x1:
            pending = payload
        elif opcode == 0x0:
            pending += payload  # 分片聚合
        else:
            break
        try:
            msg = json.loads(pending.decode("utf-8"))
        except Exception as exc:
            if not safe_send(json.dumps(_adapter_error(
                    "invalid_params", f"bad json frame: {exc}")).encode("utf-8")):
                break
            pending = b""
            continue
        pending = b""
        task_id = None
        for reply in _ws_dispatch(msg, routes_agent, routes_skills):
            if reply.get("type") == "chat_accepted":
                task_id = reply.get("task_id")
            try:
                data = json.dumps(reply, ensure_ascii=False, default=str).encode("utf-8")
            except Exception:
                data = json.dumps(_adapter_error("internal", "frame encode failed")).encode("utf-8")
            if not safe_send(data):
                return
        # chat 受理后异步泵任务事件（与 SSE 同源 iter_sse，各连接独立消费，不双写）
        if task_id:
            threading.Thread(target=_ws_pump_task_events,
                             args=(task_id, routes_agent, wfile, write_lock),
                             daemon=True).start()


# ============================================================================
# FastAPI 实现
# ============================================================================
def _run_fastapi(host: str, port: int, engine: str) -> int:
    from fastapi import FastAPI
    from fastapi.middleware.cors import CORSMiddleware

    app = FastAPI(title="Lemon Bridge Server", version=_VERSION)
    # A-05: CORS 由 "*" 收敛为显式白名单（host_config 唯一真源）
    app.add_middleware(
        CORSMiddleware, allow_origins=host_config.cors_origins(), allow_methods=["*"],
        allow_headers=["Content-Type", "X-Lemon-Bridge-Token", "Authorization"],
    )

    # 路由
    from bridge.api import routes_health, routes_skills, routes_agent, routes_mcp
    routes_health.register_fastapi(app)
    routes_skills.register_fastapi(app)
    routes_agent.register_fastapi(app)
    routes_mcp.register_fastapi(app)
    try:
        from bridge.api import routes_crawl
        routes_crawl.register_fastapi(app)   # A-08
    except Exception:
        logger.debug("suppressed exception")
    try:
        from bridge.api import routes_quant
        routes_quant.register_fastapi(app)   # A-09
    except Exception:
        logger.debug("suppressed exception")

    @app.get("/api")
    def api_index() -> Dict[str, Any]:
        return {
            "name": "Lemon Bridge Server",
            "version": _VERSION,
            "endpoints": [
                "GET  /health",
                "WS   /ws",
                "GET  /api/skills",
                "POST /api/skills/{name}/execute",
                "POST /api/agent/chat",
                "GET  /api/agent/task/{task_id}",
                "GET  /api/agent/task/{task_id}/events",
                "GET  /api/mcp/tools",
            ],
        }

    # A-02: FastAPI/uvicorn 模式下的 /ws 对等实现（与本文件 stdlib 版同帧协议）
    try:
        from fastapi import WebSocket

        @app.websocket("/ws")
        async def ws_endpoint(ws: WebSocket) -> None:
            import asyncio

            await ws.accept()
            loop = asyncio.get_running_loop()

            def _next_or_none(gen):
                try:
                    return next(gen)
                except StopIteration:
                    return None
                except Exception:
                    return None

            while True:
                raw = await ws.receive_text()
                try:
                    msg = json.loads(raw)
                except Exception as exc:
                    await ws.send_json(_adapter_error("invalid_params", f"bad json frame: {exc}"))
                    continue
                if isinstance(msg, dict) and msg.get("type") == "chat":
                    norm = _adapter_chat(msg)
                    if not norm.get("prompt"):
                        await ws.send_json(_adapter_error(
                            "invalid_params", "chat frame needs prompt/content"))
                        continue
                    sid = norm.get("session_id") or norm.get("sessionId")
                    r = await loop.run_in_executor(
                        None, routes_agent.submit, norm["prompt"], sid,
                        int(norm.get("max_iterations") or norm.get("maxIterations") or 20))
                    tid = r.get("task_id")
                    await ws.send_json({"type": "chat_accepted", "task_id": tid,
                                        "timestamp": _adapter_ts(None)})
                    gen = routes_agent.iter_sse(tid)
                    while True:
                        e = await loop.run_in_executor(None, _next_or_none, gen)
                        if e is None:
                            break
                        await ws.send_json({"type": "task_event", "task_id": tid, "event": e})
                    await ws.send_json({"type": "task_done", "task_id": tid,
                                        "timestamp": _adapter_ts(None)})
                    continue
                for reply in _ws_dispatch(msg, routes_agent, routes_skills):
                    await ws.send_json(reply)
    except Exception:
        pass  # fastapi 缺失时走 stdlib /ws

    import uvicorn
    config = uvicorn.Config(app, host=host, port=port, log_level="info")
    server = uvicorn.Server(config)

    def _sigint(signum, frame):
        print("\n[bridge] SIGINT received, shutting down…")
        try:
            server.should_exit = True
        except Exception:
            logger.debug("suppressed exception")

    try:
        signal.signal(signal.SIGINT, _sigint)
    except Exception:
        logger.debug("suppressed exception")
    server.run()
    return 0


# ============================================================================
# stdlib 降级实现（与 FastAPI 同构：路由/状态码/JSON 体一致）
# ============================================================================
def _run_stdlib(host: str, port: int, engine: str) -> int:
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
    from urllib.parse import urlparse, parse_qs

    from bridge.api import routes_health, routes_skills, routes_agent, routes_mcp
    try:
        from bridge.api import routes_crawl
    except Exception:
        routes_crawl = None
    try:
        from bridge.api import routes_quant
    except Exception:
        routes_quant = None

    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, fmt, *args):  # 静默默认日志
            pass

        # ---- A-05: CORS 白名单响应头（禁止 "*"）----
        def _cors_origin(self) -> str:
            origin = self.headers.get("Origin") or ""
            return origin if origin in host_config.cors_origins() else ""

        def _send(self, code: int, body: Dict[str, Any], content_type: str = "application/json"):
            data = json.dumps(body, ensure_ascii=False).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", content_type + "; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            origin = self._cors_origin()
            if origin:
                self.send_header("Access-Control-Allow-Origin", origin)
                self.send_header("Vary", "Origin")
            self.end_headers()
            self.wfile.write(data)

        def do_OPTIONS(self):  # A-05: 跨域预检 —— 仅白名单 Origin 通过
            origin = self._cors_origin()
            self.send_response(204 if origin else 403)
            if origin:
                self.send_header("Access-Control-Allow-Origin", origin)
                self.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
                self.send_header("Access-Control-Allow-Headers",
                                 "Content-Type, X-Lemon-Bridge-Token, Authorization")
                self.send_header("Access-Control-Max-Age", "600")
            self.send_header("Content-Length", "0")
            self.end_headers()

        # ---- A-05: 全端点鉴权（含 /health）----
        def _authed(self) -> bool:
            return require_auth.check_headers(self.headers)

        def do_GET(self):
            parsed = urlparse(self.path)
            path = parsed.path
            if not self._authed():
                return self._send(401, require_auth.unauthorized_payload())
            if path == "/ws":  # A-02: WebSocket 网关
                return _ws_handle(self, routes_agent, routes_skills)
            if path == "/health":
                return self._send(200, routes_health.health())
            if path == "/api":
                return self._send(200, {"name": "Lemon Bridge Server",
                                        "version": _VERSION, "mode": "stdlib"})
            if path == "/api/skills":
                return self._send(200, routes_skills.list_skills())
            if path == "/api/mcp/tools":
                # A-03: {ok,count,tools} 旧结构 / JSON-RPC 双形态，经适配层单一出口
                legacy = routes_mcp.list_tools()
                if "format=jsonrpc" in (parsed.query or ""):
                    return self._send(200, _adapter_tools_rpc(legacy, None))
                return self._send(200, legacy)
            if path == "/api/quant/status" and routes_quant is not None:   # A-09
                return self._send(200, routes_quant.status())
            qs = parse_qs(parsed.query or "")
            if path == "/api/crawl/status" and routes_crawl is not None:   # A-08
                return self._send(200, routes_crawl.status(qs.get("session_id", [""])[0]))
            if path == "/api/crawl/card" and routes_crawl is not None:
                return self._send(200, routes_crawl.card(qs.get("session_id", [""])[0]))
            if path == "/api/crawl/events" and routes_crawl is not None:
                return self._crawl_sse(routes_crawl, qs.get("session_id", [""])[0])
            if path.startswith("/api/agent/task/") and path.endswith("/events"):
                tid = path[len("/api/agent/task/"):-len("/events")]
                return self._sse(tid)
            if path.startswith("/api/agent/task/"):
                tid = path[len("/api/agent/task/"):]
                r = routes_agent.get_task(tid)
                return self._send(200 if r else 404, r or {"ok": False})
            return self._send(404, {"ok": False, "error": "not found"})

        def do_POST(self):
            if not self._authed():
                return self._send(401, require_auth.unauthorized_payload())
            parsed = urlparse(self.path)
            path = parsed.path
            length = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(length) if length else b"{}"
            try:
                body = json.loads(raw.decode("utf-8") or "{}")
            except Exception:
                body = {}

            if path == "/api/agent/chat":
                # A-03: content/prompt 双字段经单一适配层归一（B/C 端发 content）
                norm = _adapter_chat(body)
                r = routes_agent.submit(norm.get("prompt", ""),
                                        norm.get("session_id") or norm.get("sessionId"),
                                        int(norm.get("max_iterations") or norm.get("maxIterations") or 20))
                return self._send(200 if r.get("task_id") else 400, r)
            if path == "/api/quant/backtest" and routes_quant is not None:  # A-09
                r = routes_quant.backtest(body)
                return self._send(200 if r.get("ok") else 400, r)
            if routes_crawl is not None and path in ("/api/crawl/start", "/api/crawl/pause",
                                                     "/api/crawl/resume", "/api/crawl/stop"):
                op = path.rsplit("/", 1)[-1]
                fn = {"start": routes_crawl.start, "pause": routes_crawl.pause,
                      "resume": routes_crawl.resume, "stop": routes_crawl.stop}[op]
                r = fn(body)
                return self._send(200 if r.get("ok") else 400, r)
            if path.startswith("/api/skills/") and path.endswith("/execute"):
                name = path[len("/api/skills/"):-len("/execute")]
                r = routes_skills.execute_skill(name, body)
                return self._send(200 if r.get("ok") else 500, r)
            return self._send(404, {"ok": False, "error": "not found"})

        def _crawl_sse(self, routes_crawl, sid):
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-cache")
            origin = self._cors_origin()
            if origin:
                self.send_header("Access-Control-Allow-Origin", origin)
            self.end_headers()
            try:
                for frame in routes_crawl.iter_card_sse(sid):
                    data = ("data: " + json.dumps(frame, ensure_ascii=False, default=str)
                            + chr(10) + chr(10)).encode("utf-8")
                    self.wfile.write(data)
                    self.wfile.flush()
            except Exception:
                logger.debug("suppressed exception")

        def _sse(self, tid: str):
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-cache")
            origin = self._cors_origin()
            if origin:
                self.send_header("Access-Control-Allow-Origin", origin)
            self.end_headers()
            # A-13: 120ms 合并节流 + 400 事件上限（终态事件直通）
            from bridge.protocol.sse_throttle import SSEThrottle
            thr = SSEThrottle(min_interval_ms=120, max_buffer=400)
            try:
                for e in routes_agent.iter_sse(tid):
                    out = thr.feed(e)
                    if out is not None:
                        data = ("data: " + json.dumps(out, ensure_ascii=False) + "\n\n").encode("utf-8")
                        self.wfile.write(data)
                        self.wfile.flush()
                last = thr.close()
                if last is not None:
                    data = ("data: " + json.dumps(last, ensure_ascii=False) + "\n\n").encode("utf-8")
                    self.wfile.write(data)
                    self.wfile.flush()
            except Exception:
                logger.debug("suppressed exception")

    server = ThreadingHTTPServer((host, port), Handler)
    server.daemon_threads = True

    def _sigint(signum, frame):
        print("\n[bridge] SIGINT received, shutting down…")
        threading.Thread(target=server.shutdown, daemon=True).start()

    try:
        signal.signal(signal.SIGINT, _sigint)
    except Exception:
        logger.debug("suppressed exception")

    print(f"[bridge] stdlib server listening on {host}:{port}")
    server.serve_forever()
    return 0


# ============================================================================
# 入口
# ============================================================================
def main(argv: Optional[list] = None) -> int:
    # A-05: LEMON_BRIDGE_TOKEN 缺失即 fail-fast 拒绝启动（GLOBAL-8 鉴权铁律）
    require_auth.fail_fast_or_exit("lemonD-bridge")
    parser = argparse.ArgumentParser(description="Lemon Bridge Server")
    parser.add_argument("--port", type=int, default=host_config.resolve_port())
    parser.add_argument("--host", default=None,
                        help="监听地址；缺省按 A-04 解析链：LEMON_BRIDGE_HOST → config.yaml → 安全默认")
    parser.add_argument("--engine", default=os.environ.get("BRIDGE_ENGINE", ""),
                        choices=["", "ollama", "deepseek"])
    args = parser.parse_args(argv)
    host = args.host or host_config.resolve_host()
    port = args.port if args.port else host_config.resolve_port()

    if not host_config.is_loopback(host):
        print(f"[bridge] WARNING: 非回环监听 {host}:{port} —— 已强制鉴权，"
              "请确保 LEMON_BRIDGE_TOKEN 仅下发可信端")

    em, router = _build_runtime(args.engine)

    skills_count = 0
    try:
        if router is not None:
            registry = getattr(router, "_registry", None)
            if registry is not None:
                skills_count = len(getattr(registry, "_skills", {}) or {})
    except Exception:
        skills_count = 0

    _banner(host, port, args.engine, skills_count)

    # ★ A1 修复二: session_mesh 自启动接线（只增不改 —— 失败打日志不阻断主流程）。
    #   此前全仓无任何生产代码拉起 session_mesh，标准模式 UI 探测 8796-8800 永远 offline。
    try:
        from session_mesh import server as _mesh
        _mesh_port = _mesh.start()
        print(f"[bridge] session_mesh ready on 127.0.0.1:{_mesh_port}"
              if _mesh_port else "[bridge] session_mesh 未启动（8796-8800 端口全占用）")
    except Exception as e:
        print(f"[bridge] session_mesh 启动失败（不阻断主流程）: {e}")

    if HAS_FASTAPI:
        return _run_fastapi(host, port, args.engine)
    print("[bridge] fastapi unavailable → fallback to stdlib http.server")
    return _run_stdlib(host, port, args.engine)


if __name__ == "__main__":
    sys.exit(main())
