# -*- coding: utf-8 -*-
"""A-12: 反向移植 B 端的并发与资源治理（B core/CloudThrottle/RequestWatchdog/
ResourceGovernor）。

- FIFO 并发闸门：limit=3，release/cancel 幂等（禁止全局串行锁）
- per-reqId 看门狗：tick 5000ms / stale 60000ms，超时请求回收
- 大结果落盘：>32KB 落 data/bridge_spool/，图片类 LRU 50MB
- 前后台心跳降级常量：前台 10s / 后台 60s / 未知态 30s
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import json
import os
import threading
import time
import uuid
from collections import OrderedDict, deque
from typing import Any, Dict, List, Optional

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SPOOL_DIR = os.path.join(PROJECT_ROOT, "data", "bridge_spool")

# 心跳降级（B WsClient.ets:209-236 对齐）
HEARTBEAT_FOREGROUND_S = 10
HEARTBEAT_BACKGROUND_S = 60
HEARTBEAT_UNKNOWN_S = 30

SPOOL_THRESHOLD_BYTES = 32 * 1024


class AgentGate:
    """FIFO 并发闸门 + 看门狗 + 结果落盘（线程安全）。"""

    def __init__(self, limit: int = 3,
                 watchdog_tick_ms: int = 5000,
                 stale_ms: int = 60000,
                 spool_dir: str = SPOOL_DIR,
                 spool_threshold: int = SPOOL_THRESHOLD_BYTES,
                 image_lru_mb: float = 50.0):
        self.limit = max(1, int(limit))
        self.watchdog_tick_ms = int(watchdog_tick_ms)
        self.stale_ms = int(stale_ms)
        self.spool_dir = spool_dir
        self.spool_threshold = int(spool_threshold)
        self.image_lru_mb = float(image_lru_mb)
        self._lock = threading.Lock()
        self._active: "OrderedDict[str, float]" = OrderedDict()   # req_id → acquire ts
        self._queue: deque = deque()                             # FIFO 等待 req_id
        self._released: set = set()                              # 幂等 release/cancel 记录
        self._results: Dict[str, Dict[str, Any]] = {}

    # ---- 闸门 ----
    def acquire(self, req_id: str = "", timeout: Optional[float] = None) -> Optional[str]:
        """申请执行槽：FIFO 排队，拿不到则阻塞等待（timeout 秒）。返回 req_id 或 None。

        幂等性：已 release/cancel 的 req_id 再次 acquire 直接拒绝（None）。
        """
        req_id = req_id or ("req-" + uuid.uuid4().hex[:10])
        deadline = None if timeout is None else time.time() + timeout
        with self._lock:
            if req_id in self._released:
                return None
            if len(self._active) < self.limit:
                self._active[req_id] = time.time()
                return req_id
            self._queue.append(req_id)
        # FIFO 等待
        while True:
            if deadline is not None and time.time() > deadline:
                with self._lock:
                    try:
                        self._queue.remove(req_id)
                    except ValueError:
                        logger.debug("suppressed exception")
                return None
            time.sleep(0.02)
            with self._lock:
                if req_id in self._released:
                    try:
                        self._queue.remove(req_id)
                    except ValueError:
                        logger.debug("suppressed exception")
                    return None
                if len(self._active) < self.limit and self._queue and \
                        self._queue[0] == req_id:
                    self._queue.popleft()
                    self._active[req_id] = time.time()
                    return req_id

    def release(self, req_id: str) -> bool:
        """释放执行槽（幂等）；释放后唤醒队首。返回是否实际释放。"""
        with self._lock:
            self._released.add(req_id)
            if req_id in self._active:
                self._active.pop(req_id)
                return True
            try:
                self._queue.remove(req_id)
            except ValueError:
                logger.debug("suppressed exception")
            return False

    def cancel(self, req_id: str) -> bool:
        """取消排队/活动请求（幂等，等价 release 语义）。"""
        return self.release(req_id)

    def active_count(self) -> int:
        with self._lock:
            return len(self._active)

    def queued_count(self) -> int:
        with self._lock:
            return len(self._queue)

    # ---- 看门狗 ----
    def watchdog_sweep(self) -> List[Dict[str, Any]]:
        """回收超时请求：active 中滞留超过 stale_ms 的强制回收。返回回收清单。"""
        now = time.time()
        reclaimed = []
        with self._lock:
            stale = [(rid, ts) for rid, ts in self._active.items()
                     if (now - ts) * 1000 > self.stale_ms]
            for rid, ts in stale:
                self._active.pop(rid)
                self._released.add(rid)
                reclaimed.append({"req_id": rid, "stale_ms": int((now - ts) * 1000),
                                  "action": "reclaimed"})
        return reclaimed

    # ---- 结果治理（>32KB 落盘）----
    def store_result(self, req_id: str, payload: Any) -> Dict[str, Any]:
        """保存结果：<=32KB 内存驻留；>32KB 落盘 spool。返回引用描述。"""
        blob = json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8")
        if len(blob) <= self.spool_threshold:
            ref = {"req_id": req_id, "inline": True, "size": len(blob)}
            with self._lock:
                self._results[req_id] = {"inline": True, "payload": payload}
            return ref
        os.makedirs(self.spool_dir, exist_ok=True)
        path = os.path.join(self.spool_dir, f"{req_id}.json")
        with open(path, "w", encoding="utf-8") as f:
            f.write(blob.decode("utf-8"))
        ref = {"req_id": req_id, "inline": False, "size": len(blob), "path": path}
        with self._lock:
            self._results[req_id] = {"inline": False, "path": path}
        return ref

    def load_result(self, req_id: str) -> Optional[Any]:
        with self._lock:
            meta = self._results.get(req_id)
        if meta is None:
            return None
        if meta["inline"]:
            return meta["payload"]
        try:
            with open(meta["path"], "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return None
