"""B-002: LM Studio Engine Adapter — ★ 引擎收口（兼容 facade）。

实现已迁至 shared/engines/lmstudio_adapter.py（唯一真源）；
本文件仅 re-export，保留 `from bridge.engines.lmstudio_engine import ...`
兼容导入路径。新代码请 import shared.engines.lmstudio_adapter。
"""
from __future__ import annotations

try:
    from shared.engines.lmstudio_adapter import LMStudioAdapter
except ImportError:  # 兜底：bridge 作为顶层包直跑时补 repo 根
    import os
    import sys

    _ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    if _ROOT not in sys.path:
        sys.path.insert(0, _ROOT)
    from shared.engines.lmstudio_adapter import LMStudioAdapter

__all__ = ["LMStudioAdapter"]
