"""B-002: Engine Manager — ★ 引擎收口（兼容 facade）。

实现已迁至 shared/engines/manager.py（唯一真源；健康与 fallback 顺序委托
shared.engine_manager 单源）。本文件仅 re-export，保留
`from bridge.engines.engine_manager import EngineManager` 兼容导入路径。
新代码请 import shared.engines.manager（收口项 7）。
"""
from __future__ import annotations

try:
    from shared.engines.manager import (
        ENGINE_CLASS_MAP,
        EngineManager,
        EngineType,
    )
except ImportError:  # 兜底：bridge 作为顶层包直跑时补 repo 根
    import os
    import sys

    _ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    if _ROOT not in sys.path:
        sys.path.insert(0, _ROOT)
    from shared.engines.manager import (
        ENGINE_CLASS_MAP,
        EngineManager,
        EngineType,
    )

__all__ = ["EngineManager", "EngineType", "ENGINE_CLASS_MAP"]
