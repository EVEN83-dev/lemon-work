"""B-002: Base Engine Adapter — ★ 引擎收口（兼容 facade，无第二份定义）。

唯一真源已收口至 shared/engines/base.py（chat / generate_with_tools /
is_available / cleanup 四方法契约 + EngineStatus/EngineCapability/EngineConfig
富接口）。本文件仅 re-export，保留既有 `from bridge.engines.base import ...`
兼容导入路径；新代码请直接 import shared.engines.base。
"""
from __future__ import annotations

try:
    from shared.engines.base import (
        BaseEngineAdapter,
        EngineCapability,
        EngineConfig,
        EngineStatus,
    )
except ImportError:  # 兜底：bridge 作为顶层包直跑时补 repo 根
    import os
    import sys

    _ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    if _ROOT not in sys.path:
        sys.path.insert(0, _ROOT)
    from shared.engines.base import (
        BaseEngineAdapter,
        EngineCapability,
        EngineConfig,
        EngineStatus,
    )

__all__ = ["BaseEngineAdapter", "EngineCapability", "EngineConfig", "EngineStatus"]
