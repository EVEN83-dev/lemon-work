# -*- coding: utf-8 -*-
"""A-13: SSE 合并节流（对齐 C pages/chat/behaviors/chat-msg-behavior.js:1615-1645 的
120ms 纪律）。

- 120ms 最小发射间隔：间隔内的增量事件合并（只保留最新一条，中间态丢弃计数）
- 400 事件缓冲上限：超限立即强制发射，防止无界缓冲
- 终态事件（done/error/final_response/task_done）直通不节流（保证收尾语义）
"""
from __future__ import annotations

import time
from typing import Any, Dict, List, Optional

TERMINAL_TYPES = {"done", "error", "final_response", "task_done", "session_done"}


class SSEThrottle:
    """SSE 事件流节流器（线程不安全，单连接内使用）。"""

    def __init__(self, min_interval_ms: int = 120, max_buffer: int = 400):
        self.min_interval_ms = int(min_interval_ms)
        self.max_buffer = int(max_buffer)
        self._buf: List[Any] = []
        self._last_emit = time.time()   # 节流窗口自构造时起算（防首帧直通）
        self.dropped = 0          # 被合并丢弃的中间态计数
        self.emitted = 0

    def feed(self, event: Any) -> Optional[Any]:
        """喂入一条事件 → 返回应发射的事件（多数情况 None）。

        终态事件直通：先冲刷缓冲再原样放行。
        """
        if isinstance(event, dict) and event.get("type") in TERMINAL_TYPES:
            self.flush()
            self.emitted += 1
            return event
        self._buf.append(event)
        if len(self._buf) >= self.max_buffer:
            return self.flush()
        now = time.time()
        if (now - self._last_emit) * 1000 >= self.min_interval_ms:
            return self.flush()
        return None

    def flush(self) -> Optional[Any]:
        """冲刷缓冲：只发射最新一条（中间态丢弃计数）。"""
        if not self._buf:
            return None
        last = self._buf[-1]
        self.dropped += len(self._buf) - 1
        self._buf.clear()
        self._last_emit = time.time()
        self.emitted += 1
        return last

    def close(self) -> Optional[Any]:
        """连接收尾：强制冲刷。"""
        return self.flush()
