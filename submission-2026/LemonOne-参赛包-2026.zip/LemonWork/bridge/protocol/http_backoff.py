# -*- coding: utf-8 -*-
"""A-13: 统一 HTTP 退避（对齐 C utils/httpBackoff.js:19,25-34）。

纪律：仅对 429 / 5xx / 超时三类可重试错误退避；4xx 业务错误不重试。
退避序列 1000/2000/4000ms ×3（指数，封顶 4000）。
"""
from __future__ import annotations

import time
from typing import Optional

RETRYABLE_STATUS = {429, 500, 502, 503, 504}
RETRY_DELAYS_MS = [1000, 2000, 4000]
MAX_ATTEMPTS = 3


class Backoff:
    """退避决策器：attempt 从 1 计数。"""

    def __init__(self, delays_ms: Optional[list] = None,
                 retryable_status: Optional[set] = None):
        self.delays_ms = list(delays_ms or RETRY_DELAYS_MS)
        self.retryable = set(retryable_status if retryable_status is not None
                             else RETRYABLE_STATUS)

    def next_delay_ms(self, attempt: int, status: Optional[int] = None,
                      timed_out: bool = False) -> Optional[int]:
        """返回下一次退避毫秒数；不应重试返回 None。

        - timed_out=True（请求超时）→ 可重试
        - status 429/5xx → 可重试；其余 4xx → 不重试
        - attempt > MAX_ATTEMPTS → 不重试
        """
        if attempt > MAX_ATTEMPTS:
            return None
        retryable = timed_out or (status is not None and status in self.retryable)
        if not retryable:
            return None
        idx = min(attempt - 1, len(self.delays_ms) - 1)
        return self.delays_ms[idx]

    def wait(self, attempt: int, status: Optional[int] = None,
             timed_out: bool = False) -> bool:
        """按决策睡眠；返回是否执行了等待（即是否应重试）。"""
        ms = self.next_delay_ms(attempt, status=status, timed_out=timed_out)
        if ms is None:
            return False
        time.sleep(ms / 1000.0)
        return True
