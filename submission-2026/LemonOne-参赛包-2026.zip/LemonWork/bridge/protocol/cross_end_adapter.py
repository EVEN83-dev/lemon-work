# -*- coding: utf-8 -*-
"""A-03: 跨端协议单一适配层 —— content/prompt、秒/毫秒、旧结构/JSON-RPC 三类错配的
唯一归一口。三端（A 桥 / B HarmonyOS / C 小程序）所有入站字段兼容分支必须走本层，
禁止在各 routes_* / 网关里散落第二套兼容代码。

对齐：
  B WsClient.ets:116-137 发送 content + 秒级时间戳
  C utils/pcBridge.js:144-152 发送 content + 毫秒级时间戳
  A /api/agent/chat 认 prompt；/api/mcp/tools 旧结构 {ok,count,tools}
输出：归一后的 BridgeMessage 兼容载荷 + protocol_version。
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

PROTOCOL_VERSION = "1.0.0"

# 毫秒级时间戳合理下界（2001-09-09）：低于它视为秒级
_MS_FLOOR = 10 ** 12
# 秒级合理上界（2286 年）：高于它视为毫秒
_MS_CEIL = 10 ** 13


def normalize_chat_payload(payload: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """入站 chat 帧归一：content/prompt 双字段兼容（prompt 优先，content 兜底）。

    B 端发 {"content": "..."}，A 端 routes_agent.submit(prompt) —— 统一经此转换。
    """
    src = dict(payload or {})
    prompt = src.get("prompt")
    if not prompt:
        prompt = src.get("content")
    if not isinstance(prompt, str):
        prompt = "" if prompt is None else str(prompt)
    out: Dict[str, Any] = {"prompt": prompt}
    for k in ("session_id", "sessionId", "max_iterations", "maxIterations"):
        if k in src and src[k] is not None:
            out[k] = src[k]
    return out


def normalize_timestamp_ms(value: Any) -> int:
    """时间戳归一到毫秒：容忍秒/毫秒/ISO 字符串；非法输入回退当前毫秒。"""
    if isinstance(value, bool):
        return _now_ms()
    if isinstance(value, (int, float)):
        v = float(value)
        if v <= 0:
            return _now_ms()
        if v < _MS_FLOOR:      # 秒级（含 1e9~1e12 的秒）
            return int(v * 1000)
        if v < _MS_CEIL:       # 毫秒级
            return int(v)
        return int(v / 1000)   # 微秒级兜底
    if isinstance(value, str):
        s = value.strip()
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        try:
            from datetime import datetime
            dt = datetime.fromisoformat(s)
            return int(dt.timestamp() * 1000)
        except Exception:
            try:
                return normalize_timestamp_ms(float(s))
            except Exception:
                return _now_ms()
    return _now_ms()


def _now_ms() -> int:
    import time
    return int(time.time() * 1000)


def to_jsonrpc_envelope(payload: Any, req_id: Any = None) -> Dict[str, Any]:
    """旧结构 {ok,count,tools}（或裸 list）→ JSON-RPC 2.0 result 信封。"""
    if isinstance(payload, dict) and payload.get("jsonrpc") == "2.0":
        return payload  # 已是 JSON-RPC，不二次包装
    if isinstance(payload, dict) and "tools" in payload:
        tools: List[Any] = payload.get("tools") or []
    elif isinstance(payload, list):
        tools = payload
    else:
        tools = []
    return {"jsonrpc": "2.0", "result": {"tools": tools,
                                         "protocol_version": PROTOCOL_VERSION}, "id": req_id}


def from_jsonrpc_envelope(resp: Dict[str, Any]) -> Dict[str, Any]:
    """JSON-RPC result → 旧结构 {ok,count,tools}（供旧消费方兼容读取）。"""
    if not isinstance(resp, dict):
        return {"ok": False, "count": 0, "tools": [], "error": "invalid response"}
    if resp.get("error"):
        return {"ok": False, "count": 0, "tools": [], "error": resp["error"].get("message", "error")}
    result = resp.get("result") or {}
    tools = result.get("tools") or []
    return {"ok": True, "count": len(tools), "tools": tools}


# WS/HTTP 错误码映射（桥内统一错误码 ↔ 语义）
ERROR_CODE_MAP = {
    "unauthorized": 401,
    "not_found": 404,
    "method_not_allowed": 405,
    "invalid_params": 400,
    "internal": 500,
    "timeout": 504,
}


def error_payload(code_key: str, message: str, **extra: Any) -> Dict[str, Any]:
    """统一错误帧：{"error": {"code", "message", ...}}，code 为桥内语义码。"""
    err: Dict[str, Any] = {"code": code_key, "http_status": ERROR_CODE_MAP.get(code_key, 500),
                           "message": message}
    err.update(extra)
    return {"error": err, "protocol_version": PROTOCOL_VERSION}


__all__ = [
    "PROTOCOL_VERSION",
    "normalize_chat_payload",
    "normalize_timestamp_ms",
    "to_jsonrpc_envelope",
    "from_jsonrpc_envelope",
    "ERROR_CODE_MAP",
    "error_payload",
]
