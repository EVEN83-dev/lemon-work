# -*- coding: utf-8 -*-
"""
★ F4: 失败样本挖掘器（failure_miner）
====================================
读取一个或多个 e2e_report_*.json，按 (归因 label, 关键词, reply 形态) 聚类失败模式，
输出 {pattern, count, case_ids, evidence_examples, suggested_system_extra} 的 JSON。

识别三类核心失败模式：
  1. 输出截断（reply 尾部非句读且未命中关键词）
  2. 工具未调用（allowed_tools 非空但 tool_calls=0 且数值题）
  3. 工具执行失败（tool_calls 中有 success=false）

用法：
  python bridge/learning/failure_miner.py --reports data/evals/e2e_report_*.json
  python bridge/learning/failure_miner.py --reports report1.json report2.json --out data/evals/failure_patterns.json
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import glob
from collections import defaultdict
from typing import Any, Dict, List, Optional


# ── 截断检测（与 failure_attribution 同逻辑）──
_SENTENCE_END = tuple("。！？!?；;\n")
_MD_CLOSERS = ("```", "**", "*", "|", "</", "---")


def _is_truncated_reply(reply: str, expected: List[str]) -> bool:
    r = (reply or "").strip()
    if not r:
        return False
    exp = [k for k in (expected or []) if k]
    if exp and any(k in r for k in exp):
        return False
    tail = r[-1]
    if tail in _SENTENCE_END:
        return False
    for closer in _MD_CLOSERS:
        if r.endswith(closer):
            return False
    if re.search(r'[\u4e00-\u9fff\w]$', tail):
        return True
    return False


def _is_tool_not_called(case: Dict[str, Any]) -> bool:
    """allowed_tools 非空但 tool_calls=0 且数值题"""
    allowed = case.get("allowed_tools", []) or []
    tcs = case.get("tool_calls", []) or []
    if not allowed or tcs:
        return False
    # 数值题判定：expected_contains 含数字
    expected = case.get("expected_contains", []) or []
    return any(re.search(r'\d', k) for k in expected)


def _is_tool_exec_fail(case: Dict[str, Any]) -> bool:
    """tool_calls 中有 success=false"""
    tcs = case.get("tool_calls", []) or []
    return any(not t.get("success", True) for t in tcs)


def _get_reply_tail(reply: str, n: int = 60) -> str:
    r = (reply or "").strip()
    if len(r) <= n:
        return r
    return "..." + r[-n:]


def mine_reports(report_paths: List[str]) -> Dict[str, Any]:
    """读取多个报告，聚类失败模式。

    Returns:
        {
            patterns: [{pattern, count, case_ids, evidence_examples, suggested_system_extra}],
            total_failures: int,
            total_cases: int,
            report_files: List[str],
        }
    """
    all_failures: List[Dict[str, Any]] = []
    total_cases = 0
    report_files: List[str] = []

    for rp in report_paths:
        if not os.path.exists(rp):
            print(f"[warn] 报告不存在: {rp}")
            continue
        try:
            with open(rp, encoding="utf-8") as f:
                report = json.load(f)
        except Exception as e:
            print(f"[warn] 解析失败 {rp}: {e}")
            continue
        report_files.append(os.path.basename(rp))
        total_cases += report.get("summary", {}).get("total_cases", 0)
        for bc in report.get("bad_cases", []):
            all_failures.append(bc)

    # ── 聚类 ──
    patterns: Dict[str, List[Dict[str, Any]]] = defaultdict(list)

    for bc in all_failures:
        reply = bc.get("reply_preview", "")
        attribution = bc.get("attribution", {})
        label = attribution.get("label", "unknown")
        cid = bc.get("id", "?")

        # 1. 工具执行失败（最高优先级，因为截断检测可能误判）
        if _is_tool_exec_fail(bc):
            patterns["工具执行失败"].append(bc)
        # 2. 工具未调用
        elif _is_tool_not_called(bc):
            patterns["工具未调用"].append(bc)
        # 3. 输出截断
        elif _is_truncated_reply(reply, bc.get("expected_contains", [])):
            patterns["输出截断"].append(bc)
        # 4. 其他归因
        else:
            patterns[label].append(bc)

    # ── 生成输出 ──
    output_patterns = []
    for pattern_name, cases in sorted(patterns.items(), key=lambda x: -len(x[1])):
        case_ids = [c.get("id", "?") for c in cases]
        examples = [
            {
                "id": c.get("id", "?"),
                "reply_tail": _get_reply_tail(c.get("reply_preview", "")),
                "attribution_label": c.get("attribution", {}).get("label", "?"),
                "fix_hint": c.get("attribution", {}).get("fix_hint", ""),
            }
            for c in cases[:5]  # 最多 5 个示例
        ]
        suggested = _suggest_system_extra(pattern_name, cases)
        output_patterns.append({
            "pattern": pattern_name,
            "count": len(cases),
            "case_ids": case_ids,
            "evidence_examples": examples,
            "suggested_system_extra": suggested,
        })

    return {
        "patterns": output_patterns,
        "total_failures": len(all_failures),
        "total_cases": total_cases,
        "report_files": report_files,
    }


def _suggest_system_extra(pattern: str, cases: List[Dict[str, Any]]) -> str:
    """根据失败模式生成 system_extra 建议"""
    if pattern == "输出截断":
        return ("【输出纪律补充】长链推理题请分步作答并在最后一段收口；"
                "若推理步骤超过 5 步，先用一句话总结中间结论再继续，"
                "避免在推理中途耗尽输出预算。")
    elif pattern == "工具未调用":
        return ("【工具调用补充】当题目涉及数值计算且可用工具列表中包含 math_solver 时，"
                "必须先调用工具获取精确结果，再基于结果作答；禁止跳过工具直接心算。")
    elif pattern == "工具执行失败":
        return ("【工具容错补充】工具调用失败时，请先检查参数格式是否正确"
                "（如 operation 枚举值、expression 语法），修正后重试一次；"
                "若仍失败，明确告知用户工具不可用并给出手工推理结果。")
    elif pattern == "模型决策错":
        return ("【作答纪律补充】回答前先复述题目要求的关键约束（数值/格式/单位），"
                "确保不遗漏任何条件；最终答案必须严格匹配题目指定的格式。")
    elif pattern == "上下文不足":
        return ("【长题处理补充】对于多约束题目，请先将所有约束逐条列出编号，"
                "再逐条推导验证；若题目超过 3 个约束，先给出约束清单再开始推理。")
    else:
        return ""


# ══════════════════════════════════════════════════════════════════
# ★ F4: 内嵌自测（构造 3 个假报告断言聚类结果）
# ══════════════════════════════════════════════════════════════════
def _self_test():
    """内嵌自测：构造 3 个假报告验证聚类逻辑"""
    import tempfile
    tests = []

    # ── 假报告 1：输出截断 ──
    report1 = {
        "summary": {"total_cases": 2},
        "bad_cases": [
            {
                "id": "test_trunc_01",
                "reply_preview": "经过逐步推理我们得到了一个中间结果 1234.56 但是继续计算的话",
                "expected_contains": ["999.99"],
                "attribution": {"label": "输出截断", "confidence": "high",
                                "fix_hint": "提高 max_tokens"},
                "tool_calls": [],
                "allowed_tools": [],
            }
        ],
    }

    # ── 假报告 2：工具未调用 ──
    report2 = {
        "summary": {"total_cases": 2},
        "bad_cases": [
            {
                "id": "test_tool_01",
                "reply_preview": "答案是 42",
                "expected_contains": ["42"],
                "attribution": {"label": "模型决策错", "confidence": "medium",
                                "fix_hint": "补强工具调用要求"},
                "tool_calls": [],
                "allowed_tools": ["math_solver"],
            }
        ],
    }

    # ── 假报告 3：工具执行失败 ──
    report3 = {
        "summary": {"total_cases": 2},
        "bad_cases": [
            {
                "id": "test_fail_01",
                "reply_preview": "工具调用失败",
                "expected_contains": ["结果"],
                "attribution": {"label": "工具选错", "confidence": "high",
                                "fix_hint": "检查工具参数"},
                "tool_calls": [{"name": "math_solver", "success": False, "result": "error"}],
                "allowed_tools": ["math_solver"],
            }
        ],
    }

    with tempfile.TemporaryDirectory() as tmpdir:
        paths = []
        for i, rep in enumerate([report1, report2, report3], 1):
            p = os.path.join(tmpdir, f"report_{i}.json")
            with open(p, "w", encoding="utf-8") as f:
                json.dump(rep, f, ensure_ascii=False)
            paths.append(p)

        result = mine_reports(paths)

        # 断言
        pattern_names = [p["pattern"] for p in result["patterns"]]
        tests.append(("聚类: 输出截断被识别", "输出截断" in pattern_names))
        tests.append(("聚类: 工具未调用被识别", "工具未调用" in pattern_names))
        tests.append(("聚类: 工具执行失败被识别", "工具执行失败" in pattern_names))
        tests.append(("聚类: total_failures=3", result["total_failures"] == 3))
        tests.append(("聚类: total_cases=6", result["total_cases"] == 6))

        # 验证 suggested_system_extra 非空
        for p in result["patterns"]:
            if p["pattern"] in ("输出截断", "工具未调用", "工具执行失败"):
                tests.append((f"建议: {p['pattern']} 有 system_extra",
                              bool(p["suggested_system_extra"])))

    passed = sum(1 for _, ok in tests if ok)
    total = len(tests)
    for name, ok in tests:
        print(f"  {'✅' if ok else '❌'} {name}")
    print(f"\n  自测: {passed}/{total} {'PASS' if passed == total else 'FAIL'}")
    return passed == total


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="失败样本挖掘器")
    ap.add_argument("--reports", nargs="*", default=[],
                    help="e2e_report_*.json 路径列表（支持 glob）")
    ap.add_argument("--out", default="", help="输出 JSON 路径（缺省只打印）")
    ap.add_argument("--self-test", action="store_true", help="运行内嵌自测")
    args = ap.parse_args(argv)

    if args.self_test:
        return 0 if _self_test() else 1

    # 展开 glob
    report_paths: List[str] = []
    for rp in args.reports:
        if "*" in rp:
            report_paths.extend(sorted(glob.glob(rp)))
        else:
            report_paths.append(rp)

    if not report_paths:
        print("[FATAL] 无匹配报告")
        return 2

    result = mine_reports(report_paths)

    print("=" * 60)
    print("  失败样本挖掘报告")
    print("=" * 60)
    print(f"  报告文件: {len(result['report_files'])} 个")
    print(f"  总题数: {result['total_cases']}")
    print(f"  失败样本: {result['total_failures']}")
    print()
    for p in result["patterns"]:
        print(f"  【{p['pattern']}】× {p['count']}")
        print(f"    案例: {', '.join(p['case_ids'][:5])}")
        print(f"    建议: {p['suggested_system_extra'][:80]}...")
        print()

    if args.out:
        os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        print(f"  输出: {args.out}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
