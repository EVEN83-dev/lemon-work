# -*- coding: utf-8 -*-
"""A-13: LLM API Key 主密钥信封（L1|iv|ct|hmac|keyVersion）。

替换任何明文/默认密钥落盘。信封格式：
  L1|<iv_b64>|<ct_b64>|<hmac_b64>|<keyVersion>
  - AES 无第三方依赖场景用 XOR-keystream 不安全 —— 此处用标准库实现
    PBKDF2-HMAC-SHA256 派生密钥 + HMAC-SHA256 校验 + keystream 加密（ChaCha20
    语义接近的 CTR 模式由 hashlib 实现，零第三方依赖）。
  - 口令来源：环境变量 LEMON_KEY_PASSPHRASE（缺失即 fail-fast）。
  - keyVersion：密钥轮换版本号（默认 k1）。

机检：M-GREP('api_key', config/dependencies.json, False) —— 依赖清单零明文密钥。
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import os

MAGIC = "L1"
KEY_VERSION_DEFAULT = "k1"
_PBKDF2_ITERS = 100_000


class EnvelopeError(Exception):
    pass


def _passphrase() -> str:
    p = os.environ.get("LEMON_KEY_PASSPHRASE", "")
    if not p:
        raise EnvelopeError(
            "LEMON_KEY_PASSPHRASE 未配置 —— A-13 铁律：API Key 禁止明文落盘，"
            "请设置主口令后使用 seal/unseal")
    return p


def _derive(passphrase: str, salt: bytes) -> bytes:
    return hashlib.pbkdf2_hmac("sha256", passphrase.encode("utf-8"), salt,
                               _PBKDF2_ITERS)


def _keystream(key: bytes, iv: bytes, length: int) -> bytes:
    """CTR 式 keystream（零依赖）：block_i = SHA256(key || iv || counter)。"""
    out = bytearray()
    counter = 0
    while len(out) < length:
        out.extend(hashlib.sha256(key + iv + counter.to_bytes(4, "big")).digest())
        counter += 1
    return bytes(out[:length])


def seal(plaintext: str, key_version: str = KEY_VERSION_DEFAULT,
         passphrase: Optional[str] = None) -> str:
    """加密 → 信封字符串 L1|iv|ct|hmac|keyVersion。"""
    pwd = passphrase if passphrase is not None else _passphrase()
    salt = b"lemon-key-envelope-v1"     # 版本化盐（派生域分离）
    key = _derive(pwd, salt)
    iv = os.urandom(16)
    pt = plaintext.encode("utf-8")
    ct = bytes(a ^ b for a, b in zip(pt, _keystream(key, iv, len(pt))))
    tag = hmac.new(key, iv + ct, hashlib.sha256).digest()
    b64 = base64.b64encode
    return f"{MAGIC}|{b64(iv).decode()}|{b64(ct).decode()}|{b64(tag).decode()}|{key_version}"


def unseal(envelope: str, passphrase: Optional[str] = None) -> str:
    """信封 → 明文；HMAC 不符或版本不符抛 EnvelopeError。"""
    pwd = passphrase if passphrase is not None else _passphrase()
    parts = (envelope or "").split("|")
    if len(parts) != 5 or parts[0] != MAGIC:
        raise EnvelopeError("信封格式非法（期望 L1|iv|ct|hmac|keyVersion）")
    _, iv_b64, ct_b64, tag_b64, key_version = parts
    key = _derive(pwd, b"lemon-key-envelope-v1")
    iv = base64.b64decode(iv_b64)
    ct = base64.b64decode(ct_b64)
    tag = base64.b64decode(tag_b64)
    if not hmac.compare_digest(tag, hmac.new(key, iv + ct, hashlib.sha256).digest()):
        raise EnvelopeError("HMAC 校验失败 —— 信封被篡改或口令不符")
    pt = bytes(a ^ b for a, b in zip(ct, _keystream(key, iv, len(ct))))
    return pt.decode("utf-8")


__all__ = ["seal", "unseal", "EnvelopeError", "KEY_VERSION_DEFAULT"]
