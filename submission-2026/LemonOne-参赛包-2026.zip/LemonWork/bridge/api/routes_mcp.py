# -*- coding: utf-8 -*-
"""B4: MCP 路由 — GET /api/mcp/tools。

经 shared/mcp_gateway.py 或 bridge/mcp/mcp_client.py 枚举可用 MCP 工具；
不可用时返回 {ok:false, reason:"mcp gateway offline"}，不崩。
"""
from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

from bridge.api import require_auth  # A-05: 全端点鉴权单一入口

from typing import Any, Dict, List

_STATE: Dict[str, Any] = {}


def configure(state: Dict[str, Any]) -> None:
    _STATE.update(state)


def _to_dict(tool: Any) -> Dict[str, Any]:
    try:
        if hasattr(tool, "to_dict"):
            return tool.to_dict()
        if hasattr(tool, "model_dump"):
            return tool.model_dump()
        if isinstance(tool, dict):
            return tool
        # MCPToolSchema 常见字段
        return {
            "name": getattr(tool, "name", ""),
            "description": getattr(tool, "description", ""),
            "inputSchema": getattr(tool, "input_schema", {}) or getattr(tool, "inputSchema", {}),
        }
    except Exception:
        return {"name": str(tool)}


def list_tools() -> Dict[str, Any]:
    # 1) 优先 shared/mcp_gateway.py（只读探测）
    try:
        from shared import mcp_gateway  # type: ignore
        fn = getattr(mcp_gateway, "list_tools", None) or getattr(mcp_gateway, "get_tools", None)
        if callable(fn):
            tools = fn()
            if tools:
                return {"ok": True, "source": "shared.mcp_gateway",
                        "count": len(tools), "tools": [_to_dict(t) for t in tools]}
    except Exception as _exc:
        logger.debug("[A-15] routes_mcp.py:48 list_tools 异常已结构化记录: %s", _exc)

    # 2) 其次 bridge/mcp/mcp_client.MCPServerManager
    try:
        from bridge.mcp.mcp_client import MCPServerManager  # type: ignore
        mgr = MCPServerManager()
        # 尝试加载默认配置
        try:
            mgr.load_config()
        except Exception as _exc:
            logger.debug("[A-15] routes_mcp.py:58 list_tools 异常已结构化记录: %s", _exc)
        pairs: List = mgr.list_all_tools()
        if pairs:
            return {
                "ok": True,
                "source": "bridge.mcp.MCPServerManager",
                "count": len(pairs),
                "tools": [
                    {"server": srv, **_to_dict(tool)} for srv, tool in pairs
                ],
            }
    except Exception as _exc:
        logger.debug("[A-15] routes_mcp.py:70 list_tools 异常已结构化记录: %s", _exc)

    return {"ok": False, "reason": "mcp gateway offline", "tools": []}


# ---- FastAPI 适配 ----
def register_fastapi(app) -> None:
    from fastapi import APIRouter

    router = APIRouter(tags=["mcp"], dependencies=[require_auth.fastapi_dependency()])

    @router.get("/api/mcp/tools")
    def get_mcp_tools() -> Dict[str, Any]:
        return list_tools()

    app.include_router(router)


# ---- stdlib 降级适配 ----
ROUTES = [
    ("GET", "/api/mcp/tools", lambda body=None: list_tools(), None),
]
