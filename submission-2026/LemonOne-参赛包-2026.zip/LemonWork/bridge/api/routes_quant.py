# -*- coding: utf-8 -*-
"""A-09: 量化结果端点化 + synthetic 强制标注。

  POST /api/quant/backtest  {data_path?, ts_code?, factor_id?, factor_params?,
                             rebal_freq?, init_cash?, emit?}
      → {ok, run_id, metrics, card, factor_eval, lookahead, meta,
         data_source, disclaimer, token_set, skip_reason}
  GET  /api/quant/status    → data/evals/quant_live_smoke.json 的 SKIP 状态
                              + data/quant/meta/provenance.json + 运行时源环境

铁律（GLOBAL-3）：禁止把 synthetic 数据当作真实行情 —— data_source 强制标注
（live 需 provenance.json synthetic=false 且有 source 落款；否则一律 synthetic）；
任何 IC/夏普输出都带 disclaimer。pipeline.ingest 的
"无 TUSHARE_TOKEN → SKIP-ENV，不生成任何假数据" 铁律不得放宽。
"""
from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

import glob
import json
import os
from typing import Any, Dict, Optional

from bridge.api import require_auth  # A-05: 全端点鉴权单一入口

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
SMOKE_PATH = os.path.join(PROJECT_ROOT, "data", "evals", "quant_live_smoke.json")
PROVENANCE_PATH = os.path.join(PROJECT_ROOT, "data", "quant", "meta", "provenance.json")

DISCLAIMER_SYNTHETIC = (
    "合成数据（synthetic）：仅验证算法正确性，不得作为真实市场结论或对外展示依据。"
    "接入真实数据只需替换 shared/quant/sources/ 适配器。")
DISCLAIMER_LIVE_TMPL = (
    "真实行情数据（source={source}，fetched_at={fetched_at}）：结果仅供研究参考，"
    "非投资建议；历史回测不代表未来收益。")


def _provenance() -> Dict[str, Any]:
    try:
        with open(PROVENANCE_PATH, "r", encoding="utf-8") as f:
            return json.load(f) or {}
    except Exception:
        return {}


def _runtime_env() -> Dict[str, Any]:
    env = {"tushare_token_set": bool(os.environ.get("TUSHARE_TOKEN")),
           "tushare_lib": False, "akshare_lib": False, "baostock_lib": False}
    for lib in ("tushare", "akshare", "baostock"):
        try:
            __import__(lib)
            env[lib + "_lib"] = True
        except Exception as _exc:
            logger.debug("[A-15] routes_quant.py:52 _runtime_env 异常已结构化记录: %s", _exc)
    return env


def classify_data_source(data_path: str = "") -> Dict[str, Any]:
    """判定 data_source：live 仅当 provenance 声明非合成；其余一律 synthetic（保守）。"""
    prov = _provenance()
    if prov and prov.get("synthetic") is False and prov.get("source"):
        return {"data_source": "live", "source_detail": str(prov.get("source")),
                "fetched_at": prov.get("fetched_at", ""),
                "skip_reason": None}
    return {"data_source": "synthetic", "source_detail": "builtin-synthetic",
            "fetched_at": "", "skip_reason": "provenance 缺失或声明 synthetic"}


def _default_data_path() -> str:
    """默认取 data/quant/clean/daily 最新 dt= 分区。"""
    root = os.path.join(PROJECT_ROOT, "data", "quant", "clean", "daily")
    parts = sorted(glob.glob(os.path.join(root, "dt=*")))
    if not parts:
        return ""
    files = sorted(glob.glob(os.path.join(parts[-1], "*.parquet")))
    return files[-1] if files else parts[-1]


# ── POST /api/quant/backtest ──
def backtest(body: Dict[str, Any]) -> Dict[str, Any]:
    from shared.backtest.skills import run_backtest
    data_path = str(body.get("data_path") or "") or _default_data_path()
    if not data_path or not os.path.exists(data_path):
        return {"ok": False,
                "error": "无可用数据：请传入 data_path 或先执行 quant 数据接入（pipeline.ingest）",
                "data_source": "synthetic", "disclaimer": DISCLAIMER_SYNTHETIC,
                "token_set": bool(os.environ.get("TUSHARE_TOKEN")),
                "skip_reason": "no_data"}
    try:
        r = run_backtest(data_path,
                         ts_code=str(body.get("ts_code") or ""),
                         factor_id=str(body.get("factor_id") or "mom"),
                         factor_params=body.get("factor_params") or {"window": 20},
                         rebal_freq=str(body.get("rebal_freq") or "weekly"),
                         init_cash=float(body.get("init_cash") or 1_000_000.0),
                         emit=bool(body.get("emit", True)))
    except Exception as exc:
        # A-09: 结构化错误返回（不炸 HTTP 连接），仍带来源标注（禁止假数据兜底）
        cls = classify_data_source(data_path)
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}",
                "data_source": cls["data_source"],
                "disclaimer": DISCLAIMER_SYNTHETIC if cls["data_source"] != "live"
                else DISCLAIMER_LIVE_TMPL.format(source=cls["source_detail"],
                                                 fetched_at=cls["fetched_at"]),
                "token_set": _runtime_env()["tushare_token_set"],
                "skip_reason": cls["skip_reason"]}
    if not r.get("ok"):
        r.setdefault("data_source", classify_data_source(data_path)["data_source"])
        r.setdefault("disclaimer", DISCLAIMER_SYNTHETIC)
        r.setdefault("token_set", bool(os.environ.get("TUSHARE_TOKEN")))
        return r
    cls = classify_data_source(data_path)
    r["data_source"] = cls["data_source"]
    r["source_detail"] = cls["source_detail"]
    r["disclaimer"] = (DISCLAIMER_LIVE_TMPL.format(source=cls["source_detail"],
                                                   fetched_at=cls["fetched_at"])
                       if cls["data_source"] == "live" else DISCLAIMER_SYNTHETIC)
    r["token_set"] = _runtime_env()["tushare_token_set"]
    r["skip_reason"] = cls["skip_reason"]
    return r


# ── GET /api/quant/status ──
def status() -> Dict[str, Any]:
    smoke = {}
    try:
        with open(SMOKE_PATH, "r", encoding="utf-8") as f:
            smoke = json.load(f) or {}
    except Exception as e:
        smoke = {"status": "unknown", "reason": f"smoke file unavailable: {e}"}
    out = {"ok": True,
           "live_smoke": smoke,
           "provenance": _provenance(),
           "runtime_env": _runtime_env(),
           "ingest_rule": "无 TUSHARE_TOKEN / 无可用源 → SKIP-ENV，不生成任何假数据"}
    return out


# ═══════════════ FastAPI 适配 ═══════════════
def register_fastapi(app) -> None:
    from fastapi import APIRouter, Body

    router = APIRouter(tags=["quant"],
                       dependencies=[require_auth.fastapi_dependency()])

    @router.post("/api/quant/backtest")
    def post_backtest(body: Dict[str, Any] = Body(default={})) -> Dict[str, Any]:
        return backtest(body)

    @router.get("/api/quant/status")
    def get_status() -> Dict[str, Any]:
        return status()

    app.include_router(router)
