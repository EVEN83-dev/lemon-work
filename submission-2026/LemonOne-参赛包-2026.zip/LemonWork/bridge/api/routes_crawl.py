# -*- coding: utf-8 -*-
"""A-08: 爬虫能力端点化 —— 供 B/C 端消费 crawl_live_card。

  POST /api/crawl/start    {urls|seeds, name?, max_pages?, max_depth?} → {session_id}
  POST /api/crawl/pause    {session_id} → 真实线程级暂停（A-07 控制面）
  POST /api/crawl/resume   {session_id} → 恢复
  POST /api/crawl/stop     {session_id} → 排空收尾
  GET  /api/crawl/status   ?session_id= → 引擎/会话真实状态（或最近会话列表）
  GET  /api/crawl/card     ?session_id= → live_bridge 卡片（overview/queue/recent/
                                          series/annotations 五字段）
  GET  /api/crawl/events   ?session_id= → SSE 卡片推流（600ms 节流，200 条上限）
  GET  /api/stats          ?session_id= → ★ 窗口2 build_stats 只读聚合
                                          （counters/by_domain/直方图/timeline/
                                            words/arcs/edges/tags，1s 缓存）

铁律：全部走真实技能链路（crawler_skills/_crawl_start_w3：配额检查 + 合规
domain_policy 闸门 + robots），禁止端点层构造假 recent/overview。
"""
from __future__ import annotations

import json
import logging
import threading
import time
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

from bridge.api import require_auth  # A-05: 全端点鉴权单一入口

_STATE: Dict[str, Any] = {}


def configure(state: Dict[str, Any]) -> None:
    _STATE.update(state)


def _skills():
    from shared.skills_builtin import crawler_skills as cs
    return cs


def _live_bridge():
    from shared.crawler.live_bridge import get_live_bridge
    return get_live_bridge()


def _result_payload(r, extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """SkillResult → JSON（统一 ok/output/data/error）。

    注：crawler_skills 的 SkillResult.to_dict 可能不含 data（多套结果类并存），
    data 一律优先取实例属性。
    """
    data = getattr(r, "data", None)
    try:
        d = r.to_dict()
    except Exception:
        d = {"success": getattr(r, "success", False),
             "output": getattr(r, "output", ""),
             "error": getattr(r, "error", "")}
    if data is None:
        data = d.get("data")
    ok = bool(d.get("success", getattr(r, "success", False)))
    out = {"ok": ok, "output": d.get("output", getattr(r, "output", "")),
           "error": d.get("error") if not ok else None,
           "data": data}
    if extra:
        out.update(extra)
    return out


# ── POST /api/crawl/start ──
def start(body: Dict[str, Any]) -> Dict[str, Any]:
    cs = _skills()
    seeds = body.get("urls") or body.get("seeds") or []
    if isinstance(seeds, str):
        seeds = [seeds]
    # ★ D3-06: 端点默认对齐技能层（30），不再只得 5 页；clamp 仍在 [1,500]/[0,3]
    kw = {"seeds": seeds,
          "name": body.get("name"),
          "max_pages": body.get("max_pages", 30),
          "max_depth": body.get("max_depth", 1),
          "delay_ms": body.get("delay_ms", 0)}
    r = cs._crawl_start_w3(**kw)
    data = getattr(r, "data", None) or {}
    sid = data.get("session_id")
    if not sid:
        # 兜底：从 output 文本提取 cs_xxx（防结果类字段丢失）
        import re as _re
        m = _re.search(r"cs_\d{8}_\d{6}_\d{4}", str(getattr(r, "output", "")))
        sid = m.group(0) if m else None
    return _result_payload(r, {"session_id": sid,
                               "state": "running" if sid else None})


# ── POST /api/crawl/{pause,resume,stop} ──
# ★ 本窗口（项34/35）: 控制面统一返回 session_id + 当前 state；错误带 code 与
#   可读 reason（禁止静默吞异常）。
def pause(body: Dict[str, Any]) -> Dict[str, Any]:
    from shared.crawler.engine import pause_session
    sid = str(body.get("session_id") or "")
    if not sid:
        return {"ok": False, "code": "SESSION_REQUIRED",
                "error": "session_id required（缺会话号）", "session_id": "",
                "state": None}
    r = pause_session(sid)
    r.setdefault("session_id", sid)
    r.setdefault("state", r.get("state") or "paused")
    if not r.get("ok", True):
        r.setdefault("code", "PAUSE_FAILED")
    if not r.get("live", True):   # ★ D3-07: 非本进程 → 已落库，显式告知来源
        r["source"] = "db"
    return r


def resume(body: Dict[str, Any]) -> Dict[str, Any]:
    from shared.crawler.engine import resume_session
    sid = str(body.get("session_id") or "")
    if not sid:
        return {"ok": False, "code": "SESSION_REQUIRED",
                "error": "session_id required（缺会话号）", "session_id": "",
                "state": None}
    r = resume_session(sid)
    r.setdefault("session_id", sid)
    r.setdefault("state", r.get("state") or "running")
    if not r.get("ok", True):
        r.setdefault("code", "RESUME_FAILED")
    if not r.get("live", True):
        r["source"] = "db"
    return r


def stop(body: Dict[str, Any]) -> Dict[str, Any]:
    sid = str(body.get("session_id") or "")
    if not sid:
        return {"ok": False, "code": "SESSION_REQUIRED",
                "error": "session_id required（缺会话号）", "session_id": "",
                "state": None}
    from shared.crawler.engine import _LIVE_ENGINES
    eng = _LIVE_ENGINES.get(sid)
    if eng is not None:
        threading.Thread(target=eng.stop, daemon=True).start()
        return {"ok": True, "session_id": sid, "state": "stopping", "live": True}
    from shared.crawler import session as crawl_session
    r = crawl_session.transition(sid, "stopping")
    if not r.get("success"):
        return {"ok": False, "code": "STOP_FAILED", "session_id": sid,
                "state": None, "error": r.get("error") or "transition refused"}
    return {"ok": True, "session_id": sid, "state": "stopping",
            "live": False, "source": "db"}   # ★ D3-07: 已落库，显式告知来源


# ── GET /api/crawl/status ──
def status(session_id: str = "") -> Dict[str, Any]:
    from shared.crawler.engine import status_session
    if session_id:
        return status_session(session_id)
    from shared.crawler import session as crawl_session
    rows = crawl_session.list_sessions(10)
    return {"ok": True, "recent_sessions": rows}


# ── GET /api/stats（★ 窗口2·真实统计层；require_auth 由 router 统一挂）──
def stats(session_id: str = "") -> Dict[str, Any]:
    """build_stats 只读聚合（1s 缓存；sid 缺省回退最近会话，与 /api/board 同口径）"""
    from shared.crawler.stats import build_stats
    from shared.crawler.board_data import latest_session
    sid = session_id or (latest_session() or "")
    return build_stats(sid)


# ── GET /api/crawl/card ──
def _card_from_db(sid: str) -> Optional[Dict[str, Any]]:
    """★ D3-07: 跨进程兜底——桥无卡时从 crawl_session / crawl_page 真实行构造同形状卡。

    零伪造：overview 全部来自 store 聚合；不可用字段显式给 0/空。
    """
    from shared.crawler import session as crawl_session, store
    s = crawl_session.get(sid)
    if not s.get("session"):
        return None
    sess = s["session"]
    try:
        # 注：store.conn() 返回线程级缓存连接，禁止 close（会断掉同线程后续调用）
        c = store.conn()
        agg = c.execute(
            "SELECT COUNT(*) n, "
            "SUM(CASE WHEN status IN ('ok','not_modified') THEN 1 ELSE 0 END) ok, "
            "SUM(CASE WHEN status='skipped' THEN 1 ELSE 0 END) skipped, "
            "SUM(CASE WHEN status='dup' THEN 1 ELSE 0 END) dedup, "
            "SUM(CASE WHEN status NOT IN ('ok','not_modified','skipped','dup') "
            "THEN 1 ELSE 0 END) fail, "
            "SUM(IFNULL(size_bytes,0)) bytes, "
            "AVG(CASE WHEN IFNULL(elapsed_ms,0)>0 THEN elapsed_ms END) avg_ms "
            "FROM crawl_page WHERE session_id=?", (sid,)).fetchone()
        recent = c.execute(
            "SELECT id, url, domain, status, mode, title, text_len, quality, "
            "size_bytes, elapsed_ms, fetched_at FROM crawl_page "
            "WHERE session_id=? ORDER BY id DESC LIMIT 12", (sid,)).fetchall()
    except Exception:
        return None

    total = int(agg["n"] or 0)
    ok = int(agg["ok"] or 0)
    fail = int(agg["fail"] or 0)
    skipped = int(agg["skipped"] or 0)
    dedup = int(agg["dedup"] or 0)
    bytes_ = int(agg["bytes"] or 0)
    avg_ms = int(round(agg["avg_ms"] or 0))
    # rate_per_min：会话时长（秒）→ 分钟；无法解析时给 0（不伪造）
    rate = 0.0
    try:
        import datetime as _dt
        end = sess.get("ended_at") or sess.get("started_at")
        start = sess.get("started_at") or sess.get("created_at")
        if start:
            f = "%Y-%m-%d %H:%M:%S"
            t0 = _dt.datetime.strptime(str(start)[:19], f)
            t1 = (_dt.datetime.strptime(str(end)[:19], f) if end
                  else _dt.datetime.now())
            mins = max((t1 - t0).total_seconds() / 60.0, 0.1)
            rate = round(total / mins, 1)
    except Exception:
        rate = 0.0

    rows = []
    for r in recent:
        d = dict(r)
        rows.append({
            "page_id": d["id"], "ts": (d.get("fetched_at") or "")[11:19],
            "title": (d.get("title") or d.get("url") or "")[:60],
            "domain": d.get("domain", ""), "status": d.get("status", ""),
            "mode": d.get("mode", ""), "text_len": int(d.get("text_len") or 0),
            "elapsed_ms": int(d.get("elapsed_ms") or 0),
            "dup": d.get("status") == "dup",
            "quality": round(float(d.get("quality") or 0), 2),
        })
    return {
        "type": "crawl_live_card",
        "card_id": "cl_" + sid,
        "session_id": sid,
        "title": sess.get("name") or ("爬取 " + sid[:20]),
        "state": sess.get("state") or "",
        "source": "db_fallback",
        "overview": {"total": total, "ok": ok, "fail": fail, "skipped": skipped,
                     "dedup_hit": dedup, "size_bytes": bytes_, "avg_ms": avg_ms,
                     "rate_per_min": rate},
        "queue": {"pending": s.get("queue_pending", 0), "inflight": 0},
        "recent": rows,
        "series": [],
        "annotations": [],
        "tools": [
            {"action": "crawl.pause", "label": "暂停"},
            {"action": "crawl.resume", "label": "继续"},
            {"action": "crawl.stop", "label": "停止"},
            {"action": "crawl.export", "label": "导出"},
        ],
        "notes": [],
    }


def card(session_id: str = "", spark: int = 0) -> Dict[str, Any]:
    lb = _live_bridge()
    sid = session_id
    cards = getattr(lb, "_cards", {}) or {}
    if not sid and cards:
        sid = next(iter(cards))
    c = cards.get(sid)
    source = "live"
    if not c:
        # ★ D3-07: 跨进程兜底——daemon/另一进程的会话在库中可见
        c = _card_from_db(sid)
        source = "db_fallback"
    if not c:
        return {"ok": False, "error": f"no live card for session {sid or '<latest>'}",
                "sessions_with_cards": list(cards.keys())}
    # 五字段契约（overview/queue/recent/series/annotations）+ 事件/状态常量
    out = {k: c.get(k) for k in ("type", "card_id", "session_id", "title", "state",
                                 "overview", "queue", "recent", "series",
                                 "annotations", "tools", "notes")}
    out["source"] = c.get("source") or source   # ★ 契约追加键（只增不改）
    # ★ D3-09: 追加 war（A-08 契约，只增不改；异常时省略键，不用 null 冒充）
    try:
        from shared.crawler.war_room_data import war_room as _war_room
        w = _war_room(sid)
        if w:
            out["war"] = {
                "domain_health": w.get("domain_health"),
                "queue": w.get("queue"),
                "rate_429": w.get("rate_429"),
                "circuit": w.get("circuit"),
                "plan": w.get("plan"),
                "fetching_window_s": 20,
                "log": w.get("log"),
            }
    except Exception as _exc:
        logger.debug("[A-15] routes_crawl.py:264 war 附加块异常已结构化记录: %s", _exc)
    from shared.crawler import (EV_PAGE_DONE, EV_PAGE_FAIL, EV_SESSION_DONE,
                                EV_CONTROL)
    # ★ D3-08: 契约追加 control（三端六类同名同值）
    out["event_names"] = {"page_done": EV_PAGE_DONE, "page_fail": EV_PAGE_FAIL,
                          "session_done": EV_SESSION_DONE,
                          "control": EV_CONTROL}
    from shared.crawler import ST_RUNNING, ST_PAUSED, ST_COMPLETED
    out["state_names"] = {"running": ST_RUNNING, "paused": ST_PAUSED,
                          "completed": ST_COMPLETED}
    out["ok"] = True
    # ★ D5-02: spark=N → 追加 LTTB 降采样序列（缺省 0 时响应与旧形状一致）
    if spark and int(spark) > 0:
        n = max(10, min(int(spark), 60))
        try:
            out["spark"] = build_spark(sid, n)
        except Exception as _exc:
            logger.debug("[A-15] routes_crawl.py:281 build_spark 异常已结构化记录: %s", _exc)
    return out


def build_spark(sid: str, n: int, db_path=None) -> Dict[str, Any]:
    """从 crawl_page 真实行构建四条趋势序列并 LTTB 降采样（REQ-005）。

    pages  累计页数 / bytes 累计字节 / avg_ms 单页耗时 / rate 页每分钟
    """
    import datetime as _dt
    from shared.crawler.downsample import lttb
    from shared.crawler import store
    c = store.conn(db_path)
    rows = c.execute(
        "SELECT id, IFNULL(size_bytes,0) b, IFNULL(elapsed_ms,0) m, "
        "fetched_at FROM crawl_page WHERE session_id=? ORDER BY id",
        (sid,)).fetchall()
    if not rows:
        return {"pages": [], "bytes": [], "avg_ms": [], "rate": []}
    pages, bytes_, avg, rate = [], [], [], []
    cum_b = 0
    t0 = None
    for i, r in enumerate(rows):
        cum_b += int(r["b"] or 0)
        ft = str(r["fetched_at"] or "")
        if t0 is None and ft:
            try:
                t0 = _dt.datetime.strptime(ft[:19], "%Y-%m-%d %H:%M:%S")
            except Exception:
                t0 = None
        mins = 1.0 / 60.0   # 无时间戳时按 1 秒计（防除零）
        if t0 is not None and ft:
            try:
                t1 = _dt.datetime.strptime(ft[:19], "%Y-%m-%d %H:%M:%S")
                mins = max((t1 - t0).total_seconds() / 60.0, 1.0 / 60.0)
            except Exception:
                mins = 1.0 / 60.0
        pages.append({"t": i, "v": i + 1})
        bytes_.append({"t": i, "v": cum_b})
        avg.append({"t": i, "v": int(r["m"] or 0)})
        rate.append({"t": i, "v": round((i + 1) / mins, 3)})
    return {"pages": lttb(pages, n), "bytes": lttb(bytes_, n),
            "avg_ms": lttb(avg, n), "rate": lttb(rate, n)}


# ── GET /api/crawl/events （SSE，600ms 节流与 live_bridge 对齐） ──
# ★ D5-01: 断线重放——seq 单调号 + 每会话环形缓冲（≤200 帧）+ since 缺口重放。
from collections import deque as _deque
from itertools import count as _count

_PATCH_WAIT = 0.6  # 与 live_bridge._PATCH_MS 对齐
_SSE_SEQ: dict = {}        # session_id -> itertools.count（每会话独立）
_SSE_BUF: dict = {}        # session_id -> deque[(seq, json_str)]（环形 200）
_SSE_SNAP: dict = {}       # session_id -> 最近全量卡 json（snapshot 用）


def _sse_counter(sid: str):
    c = _SSE_SEQ.get(sid)
    if c is None:
        c = _count(1)
        _SSE_SEQ[sid] = c
    return c


def _sse_record(sid: str, card: dict) -> int:
    """记录一帧到环形缓冲，返回其 seq。"""
    seq = next(_sse_counter(sid))
    js = json.dumps(card, ensure_ascii=False, default=str)
    buf = _SSE_BUF.get(sid)
    if buf is None:
        buf = _deque(maxlen=200)
        _SSE_BUF[sid] = buf
    buf.append((seq, js))
    return seq


_SSE_LAST_SEQ: dict = {}   # ★ 集群A: sid → 上帧 stats_seq（stats 附带去重）


def _with_board(sid: str, frame: dict) -> dict:
    """★ D5-04: 给帧附加 board/war_room（UI 真实形状，与 /api/board 同源）。

    ★ 窗口2: 帧附带 stats_seq（build_stats 内容变更序列号，客户端据此拉
    /api/stats 全量；内容不变 seq 不动，缓存 1s 不产生额外查询压力）。
    ★ 集群A(项8): SSE 帧带 stats —— seq 相对上帧变化（含首帧）时附带全量
    stats；未变化只带 stats_seq（客户端沿用缓存）。旧键只增不改。"""
    try:
        from shared.crawler.stage_server import _board_payload
        p = _board_payload(sid)
        frame["board"] = p.get("board")
        frame["war_room"] = p.get("war_room")
        seq = int(p.get("stats_seq") or 0)
        frame["stats_seq"] = seq
        if seq and _SSE_LAST_SEQ.get(sid) != seq:
            st = p.get("stats")
            if st:
                frame["stats"] = st
            _SSE_LAST_SEQ[sid] = seq
    except Exception as _exc:
        logger.debug("[A-15] routes_crawl.py:365 SSE frame board 异常已结构化记录: %s", _exc)
    return frame


def _resolve_since(since, last_event_id) -> int:
    """since 优先级：query 参数 > Last-Event-ID 头。"""
    try:
        if since is not None and int(since) > 0:
            return int(since)
    except (TypeError, ValueError) as _exc:
        logger.debug("[A-15] routes_crawl.py:375 since 解析回退 Last-Event-ID: %s", _exc)
    if last_event_id:
        try:
            return int(str(last_event_id).strip())
        except (TypeError, ValueError):
            return 0
    return 0


def iter_card_sse(session_id: str, since=0, last_event_id=None):
    """生成器：推卡片帧（含 seq）；会话终态或客户端断开即止。上限 200 帧/连接。

    帧信封：{"seq": N, "card": {...}}；
    缺口超出环形缓冲时首帧改发 {"type":"snapshot","seq":N,"card":{...},
    "reloaded":true}，客户端以此全量重置。
    """
    lb = _live_bridge()
    since = _resolve_since(since, last_event_id)
    buf = _SSE_BUF.get(session_id)

    # ── 断线重放：先补 (since, current] 的缓存帧 ──
    if since > 0 and buf:
        oldest = buf[0][0]
        if oldest > since + 1:
            # 缺口超出 200 帧缓冲 → 发全量 snapshot（不冒充补齐）
            c0 = (getattr(lb, "_cards", {}) or {}).get(session_id)
            if c0 is None:
                yield {"type": "error", "error": f"no card for {session_id}"}
                return
            snap = dict(c0)
            snap["type"] = "snapshot"
            snap["reloaded"] = True
            seq = _sse_record(session_id, snap)
            _SSE_SNAP[session_id] = json.dumps(snap, ensure_ascii=False, default=str)
            yield _with_board(session_id, {"type": "snapshot", "seq": seq,
                                         "card": snap, "reloaded": True})
        else:
            for seq, js in list(buf):
                if seq > since:
                    card_j = json.loads(js)
                    if card_j.get("type") == "snapshot":
                        fr = {"type": "snapshot", "seq": seq,
                              "card": card_j, "reloaded": True}
                    else:
                        fr = {"seq": seq, "card": card_j}
                    yield _with_board(session_id, fr)

    # ── 实时流 ──
    sent = 0
    last_json = ""
    while sent < 200:
        c = (getattr(lb, "_cards", {}) or {}).get(session_id)
        if not c:
            yield {"type": "error", "error": f"no card for {session_id}"}
            return
        frame = json.dumps(c, ensure_ascii=False, default=str)
        if frame != last_json:  # 内容变化才推（配合 live_bridge 600ms patch 节流）
            _SSE_SNAP[session_id] = frame
            seq = _sse_record(session_id, dict(c))
            yield _with_board(session_id, {"seq": seq, "card": dict(c)})
            last_json = frame
            sent += 1
        if c.get("state") in ("completed", "failed", "cancelled"):
            return
        time.sleep(_PATCH_WAIT)


# ═══════════════ FastAPI 适配 ═══════════════
def register_fastapi(app) -> None:
    from fastapi import APIRouter, Body, Header
    from fastapi.responses import StreamingResponse

    router = APIRouter(tags=["crawl"],
                       dependencies=[require_auth.fastapi_dependency()])

    @router.post("/api/crawl/start")
    def post_start(body: Dict[str, Any] = Body(default={})) -> Dict[str, Any]:
        return start(body)

    @router.post("/api/crawl/pause")
    def post_pause(body: Dict[str, Any] = Body(default={})) -> Dict[str, Any]:
        return pause(body)

    @router.post("/api/crawl/resume")
    def post_resume(body: Dict[str, Any] = Body(default={})) -> Dict[str, Any]:
        return resume(body)

    @router.post("/api/crawl/stop")
    def post_stop(body: Dict[str, Any] = Body(default={})) -> Dict[str, Any]:
        return stop(body)

    @router.get("/api/crawl/status")
    def get_status(session_id: str = "") -> Dict[str, Any]:
        return status(session_id)

    @router.get("/api/stats")
    def get_stats(session_id: str = "") -> Dict[str, Any]:
        # ★ 窗口2·真实统计层（require_auth 由 router dependencies 统一收口）
        return stats(session_id)

    @router.get("/api/crawl/card")
    def get_card(session_id: str = "", spark: int = 0) -> Dict[str, Any]:
        return card(session_id, spark=spark)

    @router.get("/api/crawl/events")
    def get_events(session_id: str = "", since: int = 0,
                   last_event_id: str = Header(default=None, alias="Last-Event-ID")):
        # ★ D5-01: since 缺口重放；Last-Event-ID 由浏览器 EventSource 自动带回
        def gen():
            for frame in iter_card_sse(session_id, since=since,
                                       last_event_id=last_event_id):
                seq = frame.get("seq")
                data = json.dumps(frame, ensure_ascii=False, default=str)
                if seq is not None:
                    yield f"id: {seq}\ndata: {data}\n\n"
                else:
                    yield f"data: {data}\n\n"
        return StreamingResponse(gen(), media_type="text/event-stream")

    app.include_router(router)
