# -*- coding: utf-8 -*-
"""B3: Agent 路由 — POST /api/agent/chat + GET task/{id} + GET task/{id}/events(SSE)。

- POST /api/agent/chat：body {prompt, session_id?, max_iterations?}
  异步提交到 AgentLoop，HTTP 立即返回 {task_id, status:"running"}
- GET /api/agent/task/{task_id}：状态与结果（running/done/failed + 回复 + 工具调用列表）
- GET /api/agent/task/{task_id}/events：SSE 流式输出（支持回调则逐 token，否则降级轮询）

任务注册表：内存 dict + 上限 100 条 FIFO。
"""
from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

from bridge.api import require_auth  # A-05: 全端点鉴权单一入口

import asyncio
import json
import os
import queue
import threading
import time
import uuid
from collections import OrderedDict
from typing import Any, Dict, Optional

_STATE: Dict[str, Any] = {"engine_manager": None}

# ★ v6.4: 会话记忆共享池 —— 此前每个任务新建 AgentLoop（各自全新 SessionMemory/
#   ContextManager），跨请求零记忆。现在同进程共享同一持久实例，按 session_id
#   累积历史，AgentLoop 每任务新建（callback 干净）但传入共享存储。
_shared_memory = None
_shared_context = None
_shared_lock = threading.Lock()


def _get_shared_stores():
    global _shared_memory, _shared_context
    with _shared_lock:
        if _shared_memory is None:
            from bridge.core.session_memory import SessionMemory
            from bridge.core.context_manager import ContextManager
            _shared_memory = SessionMemory()
            _shared_context = ContextManager()
        return _shared_memory, _shared_context



MAX_TASKS = 100
_tasks: "OrderedDict[str, Dict[str, Any]]" = OrderedDict()
_lock = threading.Lock()


def configure(state: Dict[str, Any]) -> None:
    _STATE.update(state)


def _make_task(prompt: str, session_id: str, max_iterations: int) -> Dict[str, Any]:
    tid = "t-" + uuid.uuid4().hex[:12]
    return {
        "task_id": tid,
        "status": "running",
        "prompt": prompt,
        "session_id": session_id,
        "max_iterations": max_iterations,
        "created_at": time.time(),
        "updated_at": time.time(),
        "reply": "",
        "tool_calls": [],
        "error": None,
        "events": [],           # 累积事件（降级轮询用）
        "_queue": queue.Queue(),  # SSE 实时队列
        "_done_event": threading.Event(),
    }


def submit(prompt: str, session_id: Optional[str] = None,
           max_iterations: int = 20) -> Dict[str, Any]:
    with _lock:
        while len(_tasks) >= MAX_TASKS:
            _tasks.popitem(last=False)
        sid = session_id or ("sess-" + uuid.uuid4().hex[:8])
        task = _make_task(prompt, sid, max_iterations)
        _tasks[task["task_id"]] = task

    # 后台线程跑 asyncio.run(AgentLoop.run(...))
    t = threading.Thread(target=_run_agent, args=(task["task_id"],), daemon=True)
    t.start()
    return {"task_id": task["task_id"], "status": "running", "session_id": sid}


def _emit(task: Dict[str, Any], kind: str, payload: Dict[str, Any]) -> None:
    evt = {"type": kind, "ts": round(time.time() - task["created_at"], 3), **payload}
    task["events"].append(evt)
    try:
        task["_queue"].put_nowait(evt)
    except Exception as _exc:
        logger.debug("[A-15] routes_agent.py:95 _emit 异常已结构化记录: %s", _exc)


def _run_agent(task_id: str) -> None:
    task = _tasks.get(task_id)
    if not task:
        return
    try:
        from bridge.agent_loop import AgentLoop
        em = _STATE.get("engine_manager")
        mem, ctx = _get_shared_stores()
        loop = AgentLoop(engine_manager=em, session_memory=mem, context_manager=ctx)
        loop.set_message_callback(lambda msg: _on_msg(task, msg))
        # A-14: trajectory_recorder 接生产链路（此前 set_trajectory_recorder 无调用方）
        try:
            from bridge.trajectory.trajectory_recorder import TrajectoryRecorder
            rec = _STATE.get("_trajectory_recorder")
            if rec is None:
                rec_dir = os.path.join(os.path.dirname(os.path.dirname(
                    os.path.dirname(os.path.abspath(__file__)))),
                    "data", "trajectories")
                os.makedirs(rec_dir, exist_ok=True)
                rec = TrajectoryRecorder(storage_path=os.path.join(
                    rec_dir, f"traj_{task['task_id']}.jsonl"))
                _STATE["_trajectory_recorder"] = rec
            loop.set_trajectory_recorder(rec)
        except Exception as exc:
            print(f"[routes_agent] trajectory_recorder 挂载失败（不阻断任务）: {exc}")

        async def _go():
            return await loop.run(
                session_id=task["session_id"],
                user_message=task["prompt"],
                skill_hint="",
            )

        reply = asyncio.run(_go())
        task["reply"] = reply or ""
        task["status"] = "done"
        _emit(task, "done", {"reply": task["reply"]})
    except Exception as exc:
        task["status"] = "failed"
        task["error"] = f"{type(exc).__name__}: {exc}"
        _emit(task, "error", {"error": task["error"]})
    finally:
        task["updated_at"] = time.time()
        task["_done_event"].set()


def _on_msg(task: Dict[str, Any], msg: Any) -> None:
    try:
        # BridgeMessage → dict
        d = msg.to_dict() if hasattr(msg, "to_dict") else {
            "role": getattr(msg, "role", ""), "content": getattr(msg, "content", "")}
        mtype = d.get("type") or d.get("role") or "message"
        if mtype in ("tool_call", "function_call"):
            task["tool_calls"].append({
                "name": d.get("name") or d.get("tool_name") or "",
                "arguments": d.get("arguments") or d.get("args") or {},
            })
            _emit(task, "tool_call", d)
        elif mtype in ("assistant", "token", "delta"):
            piece = d.get("content") or d.get("token") or ""
            task["reply"] += piece
            _emit(task, "token", {"content": piece})
        elif mtype == "thinking":
            _emit(task, "thinking", d)
        else:
            _emit(task, mtype, d)
    except Exception as _exc:
        logger.debug("[A-15] routes_agent.py:165 _on_msg 异常已结构化记录: %s", _exc)


def get_task(task_id: str) -> Optional[Dict[str, Any]]:
    with _lock:
        task = _tasks.get(task_id)
        if not task:
            return None
        return {
            "task_id": task["task_id"],
            "status": task["status"],
            "session_id": task["session_id"],
            "prompt": task["prompt"],
            "reply": task["reply"],
            "tool_calls": list(task["tool_calls"]),
            "error": task["error"],
            "elapsed_ms": int((time.time() - task["created_at"]) * 1000),
        }


def list_events(task_id: str, after_ts: float = 0.0) -> list:
    with _lock:
        task = _tasks.get(task_id)
        if not task:
            return []
        return [e for e in task["events"] if e.get("ts", 0) >= after_ts]


def iter_sse(task_id: str):
    """生成器：实时从队列取事件；若任务已结束则补发历史后关闭。"""
    with _lock:
        task = _tasks.get(task_id)
    if not task:
        yield {"type": "error", "error": "task not found"}
        return
    q = task["_queue"]
    # 先补历史
    for e in list(task["events"]):
        yield e
    while True:
        if task["_done_event"].is_set() and q.empty():
            break
        try:
            e = q.get(timeout=1.0)
            yield e
        except queue.Empty:
            continue


# ---- FastAPI 适配 ----
def register_fastapi(app) -> None:
    from fastapi import APIRouter
    from fastapi.responses import StreamingResponse

    router = APIRouter(tags=["agent"], dependencies=[require_auth.fastapi_dependency()])

    @router.post("/api/agent/chat")
    def post_chat(body: Dict[str, Any]) -> Dict[str, Any]:
        # A-03: content/prompt 双字段经单一适配层归一（B/C 端发 content）
        from bridge.protocol.cross_end_adapter import normalize_chat_payload
        norm = normalize_chat_payload(body)
        prompt = norm.get("prompt", "")
        if not prompt:
            return {"ok": False, "error": "prompt required"}
        return submit(prompt, norm.get("session_id") or norm.get("sessionId"),
                      int(norm.get("max_iterations") or norm.get("maxIterations") or 20))

    @router.get("/api/agent/task/{task_id}")
    def get_task_route(task_id: str):
        r = get_task(task_id)
        if r is None:
            return {"ok": False, "error": "task not found"}
        return r

    @router.get("/api/agent/task/{task_id}/events")
    def get_events(task_id: str):
        def gen():
            for e in iter_sse(task_id):
                yield f"data: {json.dumps(e, ensure_ascii=False)}\n\n"
        return StreamingResponse(gen(), media_type="text/event-stream")

    app.include_router(router)


# ---- stdlib 降级适配 ----
ROUTES = [
    ("POST", "/api/agent/chat", lambda body=None: submit((body or {}).get("prompt", ""),
                                                        (body or {}).get("session_id"),
                                                        int((body or {}).get("max_iterations", 20))), None),
    ("GET", "/api/agent/task/{task_id}", lambda body=None, task_id=None: get_task(task_id) or {"ok": False}, None),
]
