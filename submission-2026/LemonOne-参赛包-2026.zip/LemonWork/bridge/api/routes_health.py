# -*- coding: utf-8 -*-
"""B1: 健康检查路由 — GET /health。

返回 {status, uptime_sec, engine_ready, skills_count, version}。
uptime 由 server 启动时间戳计算；engine_ready 探测 AgentLoop/EngineManager 可实例化。
"""
from __future__ import annotations

from bridge.api import require_auth  # A-05: 全端点鉴权单一入口

import time
from typing import Any, Dict

# 由 bridge_server 在启动时注入，避免路由层直接依赖 server 全局状态
_STATE: Dict[str, Any] = {
    "started_at": None,
    "engine_manager": None,
    "skill_router": None,
    "version": "4.8.6-lemonD1",
}


def configure(state: Dict[str, Any]) -> None:
    _STATE.update(state)


def health() -> Dict[str, Any]:
    started = _STATE.get("started_at") or time.time()
    uptime = max(0.0, round(time.time() - started, 2))

    engine_manager = _STATE.get("engine_manager")
    skill_router = _STATE.get("skill_router")

    engine_ready = False
    engine_detail = {"available": [], "primary": ""}
    try:
        if engine_manager is not None:
            avail = engine_manager.list_available_engines()
            engine_detail["available"] = list(avail or [])
            engine_detail["primary"] = engine_manager.get_primary_name() or ""
            engine_ready = len(avail) > 0 or engine_manager.get_primary_name() != ""
    except Exception as exc:  # 探测失败不崩
        engine_detail["error"] = str(exc)

    skills_count = 0
    try:
        if skill_router is not None:
            registry = getattr(skill_router, "_registry", None)
            if registry is not None:
                skills_count = len(getattr(registry, "_skills", {}) or {})
    except Exception:
        skills_count = 0

    return {
        "status": "ok",
        "uptime_sec": uptime,
        "engine_ready": engine_ready,
        "engine": engine_detail,
        "skills_count": skills_count,
        "version": _STATE.get("version", "unknown"),
    }


# ---- FastAPI 适配 ----
def engine_health() -> Dict[str, Any]:
    """★ 收口项 13：引擎健康单源快照（UP/DOWN/延迟/失败计数）。

    数据只读 shared.engine_manager.engine_health_summary()（唯一真源），
    附加 bridge 侧注册表的主引擎与可用列表。任何异常降级为空快照。"""
    out: Dict[str, Any] = {"status": "ok", "engines": {},
                           "source": "shared.engine_manager"}
    try:
        from shared.engine_manager import engine_health_summary
        out["engines"] = engine_health_summary()
    except Exception as exc:
        out["engines"] = {}
        out["error"] = str(exc)[:200]
    em = _STATE.get("engine_manager")
    try:
        if em is not None:
            out["primary"] = em.get_primary_name() or ""
            out["available"] = list(em.list_available_engines() or [])
    except Exception:
        import logging
        logging.getLogger(__name__).debug("[A-15] routes_health:83 engine_health 附加块降级", exc_info=True)
    return out

def register_fastapi(app) -> None:
    from fastapi import APIRouter

    router = APIRouter(tags=["health"], dependencies=[require_auth.fastapi_dependency()])

    @router.get("/health")
    def get_health() -> Dict[str, Any]:
        return health()

    @router.get("/api/engine/health")
    def get_engine_health() -> Dict[str, Any]:
        return engine_health()

    app.include_router(router)


# ---- stdlib 降级适配（与 FastAPI 同构的 (method, path, handler, body_schema)） ----
ROUTES = [
    ("GET", "/health", health, None),
    ("GET", "/api/engine/health", engine_health, None),
]

import logging
logger = logging.getLogger(__name__)