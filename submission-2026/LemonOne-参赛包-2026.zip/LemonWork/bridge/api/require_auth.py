# -*- coding: utf-8 -*-
"""A-05: 全端点鉴权 —— X-Lemon-Bridge-Token 单一校验入口。

铁律（GLOBAL-8）：桥一旦对外必须同步具备鉴权；环境变量 LEMON_BRIDGE_TOKEN
缺失即 fail-fast 拒绝启动（bridge_server.main 调 fail_fast_or_exit）。

- stdlib 降级模式：Handler 的 do_GET/do_POST 入口调用 check_headers()（单一收口）
- FastAPI 模式：各 routes_*.register_fastapi(app) 经 fastapi_dependency 挂载
- 令牌：请求头 X-Lemon-Bridge-Token 或 Authorization: Bearer <token>
"""
from __future__ import annotations

import hmac
import os
from typing import Any, Dict

MISSING_TOKEN_MSG = (
    "LEMON_BRIDGE_TOKEN 未配置 —— A-05 铁律：桥服务必须显式配置访问令牌。\n"
    "  PowerShell:  $env:LEMON_BRIDGE_TOKEN='<随机长串>'; python bridge/bridge_server.py\n"
    "  bash:        LEMON_BRIDGE_TOKEN='<随机长串>' python bridge/bridge_server.py\n"
    "  桌面启动器 bridge/start.py 会自动生成并持久化令牌（data/config/bridge_token.json）。"
)


def auth_token() -> str:
    return os.environ.get("LEMON_BRIDGE_TOKEN", "").strip()


def fail_fast_or_exit(service: str = "lemonD-bridge") -> None:
    """LEMON_BRIDGE_TOKEN 缺失即拒绝启动（fail-fast）。"""
    if not auth_token():
        raise SystemExit(f"[{service}] FAIL-FAST: {MISSING_TOKEN_MSG}")


def check_headers(headers: Any) -> bool:
    """校验请求头令牌；未配置令牌时仅允许显式豁免（LEMON_BRIDGE_INSECURE=1）。"""
    token = auth_token()
    if not token:
        # 仅当运行方显式声明不安全模式才放行（本仓机检/桌面启动器不会使用）
        return os.environ.get("LEMON_BRIDGE_INSECURE", "") == "1"
    supplied = ""
    try:
        supplied = headers.get("X-Lemon-Bridge-Token", "") or ""
    except Exception:
        supplied = ""
    if not supplied:
        try:
            authz = headers.get("Authorization", "") or ""
        except Exception:
            authz = ""
        if authz.startswith("Bearer "):
            supplied = authz[len("Bearer "):]
    return bool(supplied) and hmac.compare_digest(supplied, token)


def unauthorized_payload() -> Dict[str, Any]:
    return {"ok": False, "error": "unauthorized: missing/invalid X-Lemon-Bridge-Token"}


def fastapi_dependency():
    """FastAPI 依赖：校验失败抛 401（供 APIRouter(dependencies=[...]) 挂载）。"""
    try:
        from fastapi import Header, HTTPException
    except Exception:
        def _missing(*_args, **_kw):
            raise RuntimeError("fastapi unavailable; use check_headers for stdlib mode")
        return _missing

    async def _dep(
        x_lemon_bridge_token: str = Header(default=""),
        authorization: str = Header(default=""),
    ):
        class _H:
            @staticmethod
            def get(key: str, default: str = ""):
                k = key.lower()
                if k == "x-lemon-bridge-token":
                    return x_lemon_bridge_token
                if k == "authorization":
                    return authorization
                return default

        if not check_headers(_H()):
            raise HTTPException(status_code=401, detail="unauthorized")

    return _dep
