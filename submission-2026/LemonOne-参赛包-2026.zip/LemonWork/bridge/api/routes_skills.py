# -*- coding: utf-8 -*-
"""B2: 技能路由 — GET /api/skills + POST /api/skills/{name}/execute。

- GET /api/skills：列出 SkillRouter 注册的全部技能（名称/描述/参数 schema）
- POST /api/skills/{name}/execute：JSON body 传 args，调 SkillRouter 执行，
  返回 {ok, output, data, elapsed_ms}；30s 超时 + 异常捕获（500 + {ok:false, error}）
"""
from __future__ import annotations

from bridge.api import require_auth  # A-05: 全端点鉴权单一入口

import time
from typing import Any, Dict, Optional

_STATE: Dict[str, Any] = {"skill_router": None}


def configure(state: Dict[str, Any]) -> None:
    _STATE.update(state)


def _router():
    return _STATE.get("skill_router")


def list_skills() -> Dict[str, Any]:
    router = _router()
    if router is None:
        return {"ok": False, "error": "skill router offline", "skills": []}
    skills = []
    try:
        registry = getattr(router, "_registry", None)
        if registry is not None:
            items = getattr(registry, "_skills", {}) or {}
            for name, skill in items.items():
                try:
                    info = skill.to_api_dict()
                except Exception:
                    info = {"name": name, "description": getattr(skill, "description", "")}
                # 精简：只保留前端需要的字段，避免 schema 过大
                skills.append({
                    "name": info.get("name", name),
                    "description": info.get("description", ""),
                    "category": info.get("category", ""),
                    "riskLevel": info.get("riskLevel", ""),
                    "parameters": info.get("parameters", {}),
                    "inputSchema": info.get("inputSchema", {}),
                    "timeout": info.get("timeout", 30),
                })
        return {"ok": True, "count": len(skills), "skills": skills}
    except Exception as exc:
        return {"ok": False, "error": str(exc), "skills": []}


def execute_skill(name: str, args: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    router = _router()
    if router is None:
        return {"ok": False, "error": "skill router offline"}
    args = args or {}
    start = time.time()
    try:
        # SkillRouter.invoke 是同步接口；用 30s 超时保护
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as ex:
            future = ex.submit(router.invoke, name, args)
            try:
                result = future.result(timeout=30)
            except concurrent.futures.TimeoutError:
                future.cancel()
                return {"ok": False, "error": "skill execution timeout (30s)",
                        "elapsed_ms": int((time.time() - start) * 1000)}
        elapsed = int((time.time() - start) * 1000)
        try:
            d = result.to_dict()
        except Exception:
            d = {"success": getattr(result, "success", False),
                 "output": getattr(result, "output", ""),
                 "error": getattr(result, "error", ""),
                 "data": getattr(result, "data", None)}
        ok = bool(d.get("success"))
        return {
            "ok": ok,
            "output": d.get("output", ""),
            "data": d.get("data"),
            "error": d.get("error") if not ok else None,
            "elapsed_ms": elapsed,
        }
    except Exception as exc:
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}",
                "elapsed_ms": int((time.time() - start) * 1000)}


# ---- FastAPI 适配 ----
def register_fastapi(app) -> None:
    from fastapi import APIRouter, Body

    router = APIRouter(tags=["skills"], dependencies=[require_auth.fastapi_dependency()])

    @router.get("/api/skills")
    def get_skills() -> Dict[str, Any]:
        return list_skills()

    @router.post("/api/skills/{name}/execute")
    def post_execute(name: str, body: Dict[str, Any] = Body(default={})) -> Dict[str, Any]:
        result = execute_skill(name, body)
        # FastAPI 默认 200；执行失败时按任务要求返回 500 + {ok:false, error}
        return result

    app.include_router(router)


# ---- stdlib 降级适配 ----
ROUTES = [
    ("GET", "/api/skills", lambda body=None: list_skills(), None),
    ("POST", "/api/skills/{name}/execute", lambda body=None, name=None: execute_skill(name, body or {}), None),
]
