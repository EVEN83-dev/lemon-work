"""
B-007: Auth - JWT-based user authentication and multi-tenant support.

Uses python-jose for JWT, passlib for password hashing.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
import sqlite3
import threading
import time
import uuid
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# A-05: 密钥强制环境变量，零默认值（缺失时签名/验签操作 fail-fast）
JWT_SECRET_KEY = os.environ.get("LEMON_JWT_SECRET", "")


def _require_jwt_secret() -> str:
    secret = JWT_SECRET_KEY
    if not secret:
        raise RuntimeError(
            "LEMON_JWT_SECRET 未配置 —— A-05 铁律：禁止默认密钥。"
            "请设置环境变量后重启（PowerShell: $env:LEMON_JWT_SECRET='<随机长串>'）"
        )
    return secret
JWT_ALGORITHM = "HS256"
JWT_EXPIRE_HOURS = 72


class User:
    def __init__(self, user_id: str = "", username: str = "", email: str = "",
                 password_hash: str = "", api_key: str = "",
                 created_at: float = 0.0):
        self.user_id = user_id or uuid.uuid4().hex[:16]
        self.username = username
        self.email = email
        self.password_hash = password_hash
        self.api_key = api_key or uuid.uuid4().hex[:24]
        self.created_at = created_at or time.time()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "userId": self.user_id,
            "username": self.username,
            "email": self.email,
            "apiKey": self.api_key,
            "createdAt": self.created_at,
        }


class AuthManager:
    def __init__(self, db_path: str = ""):
        if not db_path:
            config_dir = os.path.join(os.path.expanduser("~"), ".lemon_bridge")
            os.makedirs(config_dir, exist_ok=True)
            db_path = os.path.join(config_dir, "auth.db")
        self._db_path = db_path
        self._lock = threading.Lock()
        self._init_db()

    def _init_db(self) -> None:
        with self._lock:
            conn = sqlite3.connect(self._db_path)
            c = conn.cursor()
            c.execute("""CREATE TABLE IF NOT EXISTS users (
                user_id TEXT PRIMARY KEY,
                username TEXT UNIQUE NOT NULL,
                email TEXT UNIQUE,
                password_hash TEXT NOT NULL,
                api_key TEXT UNIQUE,
                created_at REAL,
                salt TEXT
            )""")
            try:
                c.execute("ALTER TABLE users ADD COLUMN salt TEXT")
            except sqlite3.OperationalError:
                pass  # 列已存在
            conn.commit()
            conn.close()

    # A-05: 仅供存量库（无 salt 列）校验迁移使用；新密码一律 per-user 随机盐
    _LEGACY_SALT = b"lemon_salt_legacy_row_migration_only"

    def _hash_password(self, password: str, salt: str = "") -> str:
        if not salt:
            salt = os.urandom(16).hex()
        return hashlib.sha256(password.encode("utf-8") + salt.encode("utf-8")).hexdigest()

    def _verify_password(self, password: str, password_hash: str, salt: str = "") -> bool:
        if salt:
            return hmac.compare_digest(self._hash_password(password, salt), password_hash)
        # 存量行（固定盐时代）→ 校验后由 login() 触发升级
        legacy = hashlib.sha256(password.encode("utf-8") + self._LEGACY_SALT).hexdigest()
        return hmac.compare_digest(legacy, password_hash)

    def register(self, username: str, password: str, email: str = "") -> Tuple[Optional[User], str]:
        if not username or len(username) < 3:
            return None, "Username must be at least 3 characters"
        if not password or len(password) < 6:
            return None, "Password must be at least 6 characters"
        salt = os.urandom(16).hex()
        password_hash = self._hash_password(password, salt)
        user = User(username=username, email=email, password_hash=password_hash)
        user._pw_salt = salt
        with self._lock:
            try:
                conn = sqlite3.connect(self._db_path)
                c = conn.cursor()
                c.execute(
                    "INSERT INTO users (user_id, username, email, password_hash, api_key, created_at, salt) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (user.user_id, user.username, user.email, user.password_hash,
                     user.api_key, user.created_at, getattr(user, "_pw_salt", "")),
                )
                conn.commit()
                conn.close()
                return user, ""
            except sqlite3.IntegrityError:
                return None, "Username or email already exists"

    def login(self, username: str, password: str) -> Tuple[Optional[User], str]:
        with self._lock:
            conn = sqlite3.connect(self._db_path)
            c = conn.cursor()
            c.execute(
                "SELECT user_id, username, email, password_hash, api_key, created_at, salt FROM users WHERE username=?",
                (username,),
            )
            row = c.fetchone()
            conn.close()
        if row is None:
            return None, "User not found"
        salt = row[6] or ""
        if not self._verify_password(password, row[3], salt):
            return None, "Invalid password"
        if not salt:
            # 存量固定盐行 → 校验通过即升级为 per-user 随机盐
            new_salt = os.urandom(16).hex()
            new_hash = self._hash_password(password, new_salt)
            with self._lock:
                conn = sqlite3.connect(self._db_path)
                c = conn.cursor()
                c.execute("UPDATE users SET password_hash=?, salt=? WHERE user_id=?",
                          (new_hash, new_salt, row[0]))
                conn.commit()
                conn.close()
        user = User(
            user_id=row[0], username=row[1], email=row[2],
            password_hash=row[3], api_key=row[4], created_at=row[5],
        )
        return user, ""

    def create_token(self, user: User) -> str:
        jwt_secret = _require_jwt_secret()  # A-05: 零默认密钥，缺失即抛
        try:
            from jose import jwt
            payload = {
                "sub": user.user_id,
                "username": user.username,
                "exp": int(time.time()) + JWT_EXPIRE_HOURS * 3600,
                "iat": int(time.time()),
            }
            return jwt.encode(payload, jwt_secret, algorithm=JWT_ALGORITHM)
        except ImportError:
            payload = json.dumps({
                "sub": user.user_id,
                "username": user.username,
                "exp": int(time.time()) + JWT_EXPIRE_HOURS * 3600,
            })
            sig = hmac.new(jwt_secret.encode(), payload.encode(), hashlib.sha256).hexdigest()[:24]
            return f"{payload}|{sig}"

    def verify_token(self, token: str) -> Optional[Dict[str, Any]]:
        jwt_secret = _require_jwt_secret()  # A-05: 零默认密钥，缺失即抛
        try:
            from jose import jwt, JWTError
            payload = jwt.decode(token, jwt_secret, algorithms=[JWT_ALGORITHM])
            return payload
        except ImportError:
            logger.debug("suppressed exception")
        except Exception:
            return None
        try:
            parts = token.rsplit("|", 1)
            if len(parts) != 2:
                return None
            payload_str, sig = parts
            expected_sig = hmac.new(jwt_secret.encode(), payload_str.encode(),
                                    hashlib.sha256).hexdigest()[:24]
            if sig != expected_sig:
                return None
            payload = json.loads(payload_str)
            if payload.get("exp", 0) < time.time():
                return None
            return payload
        except (json.JSONDecodeError, ValueError):
            return None

    def authenticate_api_key(self, api_key: str) -> Optional[User]:
        with self._lock:
            conn = sqlite3.connect(self._db_path)
            c = conn.cursor()
            c.execute(
                "SELECT user_id, username, email, api_key, created_at FROM users WHERE api_key=?",
                (api_key,),
            )
            row = c.fetchone()
            conn.close()
        if row is None:
            return None
        return User(user_id=row[0], username=row[1], email=row[2],
                    api_key=row[3], created_at=row[4])

    def get_user(self, user_id: str) -> Optional[User]:
        with self._lock:
            conn = sqlite3.connect(self._db_path)
            c = conn.cursor()
            c.execute(
                "SELECT user_id, username, email, api_key, created_at FROM users WHERE user_id=?",
                (user_id,),
            )
            row = c.fetchone()
            conn.close()
        if row is None:
            return None
        return User(user_id=row[0], username=row[1], email=row[2],
                    api_key=row[3], created_at=row[4])
