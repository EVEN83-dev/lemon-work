# -*- coding: utf-8 -*-
"""bridge/autoloop/guardrails.py — 闭环护栏 V1.6-WPD

职责：
    1. 白名单写入检查（任何写路径必须在 data/autoloop 下）
    2. 轮数/超时/子进程退出码检查
    3. 报告 json schema 校验（缺字段即中止）
    4. 候选条款长度 ≤500 字且不含代码/HTML 校验
    5. dry-run 零写入断言（除 data/autoloop/dryrun.log）

违规一律抛 GuardrailViolation，由 orchestrator 捕获后写 summary 并安全退出（exit=2）。
"""
from __future__ import annotations

import json
import os
import re
from typing import Any, Dict, List

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
AUTOLOOP_DIR = os.path.join(PROJECT_ROOT, "data", "autoloop")
DRYRUN_LOG = os.path.join(AUTOLOOP_DIR, "dryrun.log")

# 报告 schema 必需字段（与 bridge/eval/real_e2e_bench.py 输出一致）
REQUIRED_META_FIELDS = {"generated_at", "engine", "model", "repeat"}
REQUIRED_SUMMARY_FIELDS = {
    "total_cases", "passed", "pass_rate", "avg_duration_ms",
    "avg_tokens", "tool_accuracy",
}


class GuardrailViolation(Exception):
    """护栏违规异常"""
    pass


def check_write_path(path: str) -> None:
    """校验写路径必须在 data/autoloop 下"""
    abspath = os.path.abspath(path)
    if not abspath.startswith(os.path.abspath(AUTOLOOP_DIR)):
        raise GuardrailViolation(
            f"白名单违规：写路径 {abspath} 不在 data/autoloop 下")


def check_rounds(max_rounds: int, current_round: int) -> None:
    """校验轮数上限"""
    if current_round > max_rounds:
        raise GuardrailViolation(
            f"轮数超限：当前第 {current_round} 轮，上限 {max_rounds}")


def check_timeout(elapsed_sec: float, timeout_sec: int = 900) -> None:
    """校验单轮超时"""
    if elapsed_sec > timeout_sec:
        raise GuardrailViolation(
            f"单轮超时：{elapsed_sec:.1f}s > {timeout_sec}s")


def check_returncode(returncode: int) -> None:
    """校验子进程退出码"""
    if returncode != 0:
        raise GuardrailViolation(
            f"子进程退出码非 0：returncode={returncode}")


def validate_report_schema(report: Dict[str, Any]) -> None:
    """校验报告 json schema（缺字段即中止）"""
    if not isinstance(report, dict):
        raise GuardrailViolation("报告不是 dict")
    meta = report.get("meta")
    if not isinstance(meta, dict):
        raise GuardrailViolation("报告缺 meta 字段")
    missing_meta = REQUIRED_META_FIELDS - set(meta.keys())
    if missing_meta:
        raise GuardrailViolation(f"meta 缺字段: {missing_meta}")
    summary = report.get("summary")
    if not isinstance(summary, dict):
        raise GuardrailViolation("报告缺 summary 字段")
    missing_sum = REQUIRED_SUMMARY_FIELDS - set(summary.keys())
    if missing_sum:
        raise GuardrailViolation(f"summary 缺字段: {missing_sum}")
    if not isinstance(report.get("per_case"), list):
        raise GuardrailViolation("报告缺 per_case 字段")
    if not isinstance(report.get("bad_cases"), list):
        raise GuardrailViolation("报告缺 bad_cases 字段")


def validate_clause(clause: str) -> None:
    """校验候选条款：长度 ≤500 字且不含代码/HTML"""
    if len(clause) > 500:
        raise GuardrailViolation(f"条款超长：{len(clause)} > 500")
    # 禁止含代码片段特征
    code_patterns = [
        r"<[^>]+>",           # HTML 标签
        r"\b(def|class|import|function|return|var|let|const)\b",  # 代码关键字
        r"[{};]\s*[{};]",      # 连续代码符号
        r"```",               # markdown 代码块
    ]
    for pat in code_patterns:
        if re.search(pat, clause):
            raise GuardrailViolation(f"条款含代码/HTML 特征: 匹配 {pat}")


def assert_dryrun_zero_write(exclude_log: bool = True) -> None:
    """dry-run 零写入断言：检查 data/autoloop 下除 dryrun.log 外无新增文件"""
    allowed = {os.path.basename(DRYRUN_LOG)} if exclude_log else set()
    violations = []
    for root, dirs, files in os.walk(AUTOLOOP_DIR):
        for f in files:
            if f not in allowed:
                violations.append(os.path.join(root, f))
    if violations:
        raise GuardrailViolation(f"dry-run 违规写入: {violations}")


def safe_write(path: str, content: str, dry_run: bool = False) -> None:
    """带白名单校验的安全写入"""
    check_write_path(path)
    if dry_run:
        # dry-run 只允许写 dryrun.log
        if os.path.abspath(path) != os.path.abspath(DRYRUN_LOG):
            raise GuardrailViolation(f"dry-run 禁止写: {path}")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)


def safe_write_json(path: str, obj: Any, dry_run: bool = False) -> None:
    """带白名单校验的安全 JSON 写入"""
    safe_write(path, json.dumps(obj, ensure_ascii=False, indent=2), dry_run)
