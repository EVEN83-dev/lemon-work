# -*- coding: utf-8 -*-
"""bridge/autoloop — 自主改进闭环 V1.6-WPD

把"评估 → 归因 → 生成候选条款 → 回归 → 保留/回滚"从人驱动变成无人闭环。
只通过 CLI 参数注入候选推理条款（--system-extra），绝不改产品代码。

模块：
    orchestrator.py —— 闭环编排器（CLI 入口）
    guardrails.py   —— 护栏（白名单/超时/schema/条款/ dry-run）
"""
