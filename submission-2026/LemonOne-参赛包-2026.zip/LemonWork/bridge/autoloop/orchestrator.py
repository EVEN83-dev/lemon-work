# -*- coding: utf-8 -*-
"""bridge/autoloop/orchestrator.py — 自主改进闭环编排器 V1.6-WPD

CLI:
    python -m bridge.autoloop.orchestrator --cases <paths> --max-rounds 3 --repeat 2 --dry-run

每轮流程：
    ① subprocess 调跑批器（超时 900s，UTF-8 环境）读报告 json
    ② 筛 bad_cases 并按归因 label 聚合
    ③ 候选补丁生成器据失败模式产出下轮 --system-extra 条款（规则表）
    ④ 写 data/autoloop/round_N/{report_before.json, patch.json, system_extra.txt, command.txt}
    ⑤ 下轮带新条款重跑
    ⑥ 决策：pass_rate 提升且回归不退化（退化阈值 5pt）→ 保留（kept.json）；否则回滚（rolled_back.json）

最终产出 data/autoloop/summary.md
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
from typing import Any, Dict, List, Optional, Tuple

# 允许直接以脚本方式运行
if __package__ in (None, ""):
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from bridge.autoloop.guardrails import (
        GuardrailViolation, check_rounds, check_returncode, check_timeout,
        check_write_path, safe_write, safe_write_json, validate_clause,
        validate_report_schema, AUTOLOOP_DIR, DRYRUN_LOG,
    )
else:
    from .guardrails import (
        GuardrailViolation, check_rounds, check_returncode, check_timeout,
        check_write_path, safe_write, safe_write_json, validate_clause,
        validate_report_schema, AUTOLOOP_DIR, DRYRUN_LOG,
    )

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
BENCH_MODULE = "bridge.eval.real_e2e_bench"

# ── 规则表：失败模式 → 候选条款 ──────────────────────────────────────
RULE_TABLE: Dict[str, str] = {
    "输出截断": "收口前先给出最终答案行，再展开解释；若内容过长，先输出结论再分段补充。",
    # ★ J3 新增：针对 4b 模型输出预算不足的截断，强调先结论 + 分步 + 收口
    "输出截断_v2": "作答先给结论行，推理分步且每步不超过2句；若总步数超过5步，先收口给出答案再补充。",
    "工具未调用": "数值计算或数据查询必须先调用可用的计算/检索工具，禁止凭空估算。",
    # ★ J3 新增：数值题强制先调工具并回报结果
    "工具未调用_v2": "遇到数值题必须先调用计算工具（如 math_solver）并回报工具结果，禁止直接估算。",
    "工具失败": "工具报错时重述约束并换参重试一次；若仍失败，说明原因并降级给出部分答案。",
    "关键词未命中": "作答前对照题目要求的格式自查，确保关键术语与数值完整出现。",
    "模型决策错": "作答前复述题目关键约束，逐条自查是否覆盖；避免答非所问。",
    "工具选错": "选择工具前核对参数与适用场景，优先调用题目允许的工具白名单。",
    "上下文不足": "长任务先分块复述关键约束，再逐块作答，避免遗漏后半段要求。",
}

# 归因 label → 规则表 key 的映射（报告 label 可能比规则表更细）
LABEL_TO_RULE: Dict[str, str] = {
    "模型决策错": "模型决策错",
    "工具选错": "工具选错",
    "上下文不足": "上下文不足",
    "输出截断": "输出截断_v2",
    "工具未调用": "工具未调用_v2",
    "工具失败": "工具失败",
    "关键词未命中": "关键词未命中",
}

DEGRADE_THRESHOLD_PT = 5.0  # 退化阈值 5 个百分点
MAX_ROUNDS_DEFAULT = 3
REPEAT_DEFAULT = 2
ROUND_TIMEOUT_SEC = 900


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def _sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _run_bench(cases: str, repeat: int, outdir: str, model: str,
               system_extra: Optional[str], timeout: int,
               dry_run: bool, limit: int = 0) -> Tuple[Optional[Dict[str, Any]], str]:
    """调用跑批器，返回 (报告 dict 或 None, command 字符串)"""
    cmd_parts = [
        sys.executable, "-m", BENCH_MODULE,
        "--cases", cases,
        "--repeat", str(repeat),
        "--outdir", outdir,
        "--model", model,
    ]
    if limit > 0:
        cmd_parts += ["--limit", str(limit)]
    if system_extra:
        cmd_parts += ["--system-extra", system_extra]
    cmd_str = " ".join(cmd_parts)

    if dry_run:
        return None, cmd_str

    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONUTF8"] = "1"
    t0 = time.time()
    try:
        proc = subprocess.run(
            cmd_parts, capture_output=True, text=True,
            timeout=timeout, env=env, encoding="utf-8", errors="replace")
    except subprocess.TimeoutExpired:
        raise GuardrailViolation(f"跑批超时（{timeout}s）")
    elapsed = time.time() - t0
    check_timeout(elapsed, timeout)
    check_returncode(proc.returncode)

    # 读最新报告
    report_path = _find_latest_report(outdir)
    if not report_path:
        raise GuardrailViolation("跑批完成但未找到报告 json")
    with open(report_path, "r", encoding="utf-8") as f:
        report = json.load(f)
    validate_report_schema(report)
    return report, cmd_str


def _find_latest_report(outdir: str) -> Optional[str]:
    """找 outdir 下最新的 report json"""
    if not os.path.isdir(outdir):
        return None
    cands = [os.path.join(outdir, f) for f in os.listdir(outdir)
             if f.endswith(".json") and "report" in f.lower()]
    if not cands:
        # 退而求其次：任意 json
        cands = [os.path.join(outdir, f) for f in os.listdir(outdir) if f.endswith(".json")]
    if not cands:
        return None
    cands.sort(key=lambda p: os.path.getmtime(p), reverse=True)
    return cands[0]


def _aggregate_bad_cases(report: Dict[str, Any]) -> Dict[str, List[Dict[str, Any]]]:
    """按归因 label 聚合 bad_cases"""
    agg: Dict[str, List[Dict[str, Any]]] = {}
    for bc in report.get("bad_cases", []):
        label = (bc.get("attribution") or {}).get("label", "模型决策错")
        agg.setdefault(label, []).append(bc)
    return agg


def _generate_clause(bad_agg: Dict[str, List[Dict[str, Any]]],
                     prev_clause: str) -> str:
    """据失败模式产出下轮 --system-extra 条款"""
    if not bad_agg:
        return prev_clause  # 无失败则沿用
    # 按失败数排序，取最多的 label
    sorted_labels = sorted(bad_agg.items(), key=lambda kv: len(kv[1]), reverse=True)
    top_label = sorted_labels[0][0]
    rule_key = LABEL_TO_RULE.get(top_label, top_label)
    new_clause = RULE_TABLE.get(rule_key, "")
    if not new_clause:
        return prev_clause
    # 拼接：若已存在同条款则不重复
    if new_clause in prev_clause:
        return prev_clause
    parts = [p for p in prev_clause.split("\n") if p.strip()]
    parts.append(new_clause)
    return "\n".join(parts)


def _pass_rate(report: Dict[str, Any]) -> float:
    return float(report.get("summary", {}).get("pass_rate", 0.0)) * 100.0


def _make_round_dir(n: int) -> str:
    return os.path.join(AUTOLOOP_DIR, f"round_{n}")


def run(cases: str, max_rounds: int = MAX_ROUNDS_DEFAULT,
        repeat: int = REPEAT_DEFAULT, model: str = "qwen3.5:4b",
        outdir: Optional[str] = None, dry_run: bool = False,
        limit: int = 0) -> int:
    """闭环主流程"""
    t_start = time.time()
    outdir = outdir or os.path.join(AUTOLOOP_DIR, "evals")
    os.makedirs(outdir, exist_ok=True)

    if dry_run:
        # dry-run：零写入（除 dryrun.log）
        log_lines = [f"[DRY-RUN] {_now_iso()} 开始 dry-run（零写入模式）"]
        log_lines.append(f"  cases={cases} max_rounds={max_rounds} repeat={repeat} model={model}")
        log_lines.append("  dry-run 跳过真实跑批，仅验证 CLI 与护栏")
        # 模拟一个假报告走一遍决策
        fake_report = _load_fixture("all_pass.json") if _fixture_exists("all_pass.json") else {
            "meta": {"generated_at": _now_iso(), "engine": "mock", "model": model, "repeat": repeat},
            "summary": {"total_cases": 5, "passed": 5, "pass_rate": 1.0,
                        "avg_duration_ms": 100.0, "avg_tokens": 100, "tool_accuracy": 1.0},
            "per_case": [], "bad_cases": [],
        }
        validate_report_schema(fake_report)
        log_lines.append(f"  [DRY-RUN] 模拟报告校验通过 pass_rate={_pass_rate(fake_report):.1f}%")
        log_lines.append(f"[DRY-RUN] {_now_iso()} 结束 dry-run")
        safe_write(DRYRUN_LOG, "\n".join(log_lines) + "\n", dry_run=True)
        print("[DRY-RUN] 完成，详见 data/autoloop/dryrun.log")
        return 0

    prev_clause = ""
    prev_pass_rate = 0.0
    history: List[Dict[str, Any]] = []
    decision = "pending"

    for rnd in range(1, max_rounds + 1):
        check_rounds(max_rounds, rnd)
        round_dir = _make_round_dir(rnd)
        os.makedirs(round_dir, exist_ok=True)

        # ① 跑批
        report, cmd_str = _run_bench(cases, repeat, outdir, model, prev_clause or None,
                                     ROUND_TIMEOUT_SEC, dry_run=False, limit=limit)
        assert report is not None
        # ④ 写快照
        safe_write_json(os.path.join(round_dir, "report_before.json"), report)
        safe_write(os.path.join(round_dir, "command.txt"), cmd_str + "\n")

        pr = _pass_rate(report)
        bad_agg = _aggregate_bad_cases(report)
        history.append({
            "round": rnd, "pass_rate": pr, "bad_agg": {k: len(v) for k, v in bad_agg.items()},
            "system_extra": prev_clause,
        })

        # ③ 生成候选条款
        new_clause = _generate_clause(bad_agg, prev_clause)
        validate_clause(new_clause)
        safe_write(os.path.join(round_dir, "system_extra.txt"), new_clause + "\n")
        safe_write_json(os.path.join(round_dir, "patch.json"), {
            "prev_clause": prev_clause, "new_clause": new_clause,
            "bad_agg": {k: len(v) for k, v in bad_agg.items()},
            "rule_applied": list(bad_agg.keys()),
        })

        # ⑥ 决策
        if rnd == 1:
            # 首轮无对比基准，记录 baseline
            prev_pass_rate = pr
            prev_clause = new_clause
            if not bad_agg:
                decision = "kept_no_improvement_needed"
                safe_write_json(os.path.join(round_dir, "kept.json"), {
                    "reason": "首轮全通过，无需改进", "pass_rate": pr})
                break
            continue

        # 退化检测
        degrade = prev_pass_rate - pr
        if degrade > DEGRADE_THRESHOLD_PT:
            decision = "rolled_back"
            safe_write_json(os.path.join(round_dir, "rolled_back.json"), {
                "reason": f"退化 {degrade:.1f}pt > 阈值 {DEGRADE_THRESHOLD_PT}pt",
                "prev_pass_rate": prev_pass_rate, "cur_pass_rate": pr,
            })
            # 回滚到上一轮条款：把上一轮 clause 写回 round_dir
            safe_write(os.path.join(round_dir, "system_extra_rolled_back.txt"),
                       prev_clause + "\n")
            break
        elif pr > prev_pass_rate:
            decision = "kept"
            safe_write_json(os.path.join(round_dir, "kept.json"), {
                "reason": f"通过率 {prev_pass_rate:.1f}% → {pr:.1f}%（+{pr - prev_pass_rate:.1f}pt）",
                "prev_pass_rate": prev_pass_rate, "cur_pass_rate": pr,
            })
            prev_pass_rate = pr
            prev_clause = new_clause
        else:
            # 无提升但无退化 → 沿用当前条款
            prev_clause = new_clause
            if not bad_agg:
                decision = "kept_all_pass"
                safe_write_json(os.path.join(round_dir, "kept.json"), {
                    "reason": f"第 {rnd} 轮全通过", "pass_rate": pr})
                break

    # ★ v6.6 收口修复：多轮候选条款均未提升 → 明确回滚到基线，
    #   杜绝 summary 以 "pending" 收尾却同时打印"最终保留条款"的自相矛盾
    if decision == "pending":
        decision = "rolled_back_no_gain"
        baseline_clause = history[0].get("system_extra", "") if history else ""
        prev_clause = baseline_clause
        last_dir = os.path.join(AUTOLOOP_DIR, f"round_{len(history)}")
        os.makedirs(last_dir, exist_ok=True)
        safe_write_json(os.path.join(last_dir, "rolled_back.json"), {
            "reason": "多轮候选条款均未提升通过率，按规格回滚到基线条款",
            "final_pass_rate": history[-1]["pass_rate"] if history else 0.0,
            "rolled_back_to": baseline_clause,
        })

    # 汇总
    total_elapsed = time.time() - t_start
    summary = _render_summary(history, decision, prev_clause, total_elapsed)
    safe_write(os.path.join(AUTOLOOP_DIR, "summary.md"), summary)
    print(summary)
    return 0


def _render_summary(history: List[Dict[str, Any]], decision: str,
                    final_clause: str, elapsed: float) -> str:
    lines = ["# LemonWork 自主改进闭环 · 汇总报告", ""]
    lines.append(f"> 生成时间：{_now_iso()}  ")
    lines.append(f"> 总耗时：{elapsed:.1f}s  ")
    lines.append(f"> 最终决策：**{decision}**  ")
    lines.append("")
    lines.append("## 一、每轮通过率曲线")
    lines.append("")
    lines.append("| 轮次 | 通过率 | 失败归因分布 | 条款数 |")
    lines.append("|---|---|---|---|")
    for h in history:
        agg = ", ".join(f"{k}:{v}" for k, v in h["bad_agg"].items()) or "无失败"
        lines.append(f"| {h['round']} | {h['pass_rate']:.1f}% | {agg} | {len(h['system_extra'].splitlines())} |")
    lines.append("")
    lines.append("## 二、条款演进")
    lines.append("")
    for h in history:
        lines.append(f"### 第 {h['round']} 轮")
        lines.append("```")
        lines.append(h["system_extra"] or "（无条款）")
        lines.append("```")
        lines.append("")
    lines.append("## 三、保留/回滚决策")
    lines.append("")
    lines.append(f"- **最终决策**：{decision}")
    lines.append(f"- **最终条款**（kept=保留 / rolled_back=回滚至基线）：")
    lines.append("```")
    lines.append(final_clause or "（无）")
    lines.append("```")
    lines.append("")
    lines.append("## 四、护栏与边界")
    lines.append("")
    lines.append("- 本闭环仅通过 CLI 参数注入候选推理条款（--system-extra），**未改任何产品代码**")
    lines.append("- 每轮有快照（round_N/report_before.json）与可回滚路径")
    lines.append(f"- 退化阈值 {DEGRADE_THRESHOLD_PT}pt；单轮超时 {ROUND_TIMEOUT_SEC}s")
    lines.append("- 这是自动化提示词搜索，不是权重更新/在线学习/自主学习")
    lines.append("")
    return "\n".join(lines)


def _fixture_exists(name: str) -> bool:
    return os.path.exists(os.path.join(AUTOLOOP_DIR, "fixtures", name))


def _load_fixture(name: str) -> Dict[str, Any]:
    with open(os.path.join(AUTOLOOP_DIR, "fixtures", name), "r", encoding="utf-8") as f:
        return json.load(f)


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="LemonWork 自主改进闭环编排器")
    ap.add_argument("--cases", required=True, help="题集路径（逗号分隔多个）")
    ap.add_argument("--max-rounds", type=int, default=MAX_ROUNDS_DEFAULT)
    ap.add_argument("--repeat", type=int, default=REPEAT_DEFAULT)
    ap.add_argument("--model", default=os.environ.get("EVAL_MODEL", "qwen3.5:4b"))
    ap.add_argument("--outdir", default=None)
    ap.add_argument("--limit", type=int, default=0, help="只跑前 N 题（0=全部），用于控制时长")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args(argv)

    try:
        return run(args.cases, args.max_rounds, args.repeat, args.model,
                   args.outdir, args.dry_run, args.limit)
    except GuardrailViolation as e:
        # 写 summary 后安全退出（exit=2）
        err_summary = f"# AUTOLOOP 护栏违规\n\n> {_now_iso()}\n\n**违规**：{e}\n"
        try:
            safe_write(os.path.join(AUTOLOOP_DIR, "summary.md"), err_summary)
        except Exception:
            logger.debug("suppressed exception")
        print(f"[GUARDRAIL] {e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
