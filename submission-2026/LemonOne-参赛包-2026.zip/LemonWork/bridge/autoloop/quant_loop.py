# -*- coding: utf-8 -*-
"""★ 2026-11-11 · 量化研究闭环（最小 RD-Agent(Q) 形态）

把 autoloop 的"假设 → 实验 → 反馈 → 保留/拒绝"从 prompt 条款层扩展到因子研究层：

    因子假设 → 语义前视检查 → 计算因子值 → Rank IC/ICIR/增量 IC 评估
             → keep/reject → 研究日志落盘（可跨轮积累）

护栏：
- 纯函数式，**不改任何产品代码、不写 data/autoloop 以外文件**（日志除外）
- 不自动改因子实现；"生成新假设"由调用方提供，本模块只做评估与决策
- 不调用 Ollama、不联网；离线合成数据即可跑通全部自测
"""
from __future__ import annotations

import json
import os
import time
from typing import Any, Callable, Dict, List, Optional

import numpy as np
import pandas as pd

from shared.backtest.factor_eval import evaluate_factor
from shared.backtest.parametric_leak import semantic_scan

LOG_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__)))), "data", "autoloop", "quant")


def run_quant_research(hypotheses: List[Dict[str, Any]],
                       forward_return: pd.Series,
                       *, close: Optional[pd.Series] = None,
                       controls: Optional[pd.DataFrame] = None,
                       write_log: bool = True,
                       ic_threshold: float = 0.10) -> Dict[str, Any]:
    """评估一批因子假设。hypothesis = {id, description?, expression?, fn}。

    fn: (n) -> 因子值序列（可调用对象）；缺省时用 expression 里的常量序列。
    """
    os.makedirs(LOG_DIR, exist_ok=True)
    records = []
    for h in hypotheses:
        hid = str(h.get("id", "h"))
        desc = str(h.get("description", "") or "")
        expr = str(h.get("expression", "") or "")
        rec: Dict[str, Any] = {"id": hid, "description": desc}

        # ① 语义前视检查（未来字段直接拒绝，不进入评估）
        sem = semantic_scan(expr, desc)
        rec["semantic"] = sem["signals"]
        if sem["severity"] == "high":
            rec["decision"] = "blocked"
            rec["reason"] = "表达式含未来字段，参数化前视风险"
            records.append(rec)
            continue

        # ② 计算因子值
        try:
            fn: Optional[Callable] = h.get("fn")
            if fn is not None:
                f = pd.Series(fn(len(forward_return)), dtype=float)
            else:
                f = pd.Series(np.linspace(0, 1, len(forward_return)), dtype=float)
        except Exception as e:
            rec["decision"] = "rejected"
            rec["reason"] = "因子计算失败: " + str(e)[:100]
            records.append(rec)
            continue

        # ③ 有效性评估
        ev = evaluate_factor(f, forward_return, controls=controls,
                             ic_threshold=ic_threshold)
        rec["factor_eval"] = ev
        # 研究闭环比单题评测更严：除 IC 达标外还要求 ICIR 稳定、增量 IC 同号，
        # 防止随机因子靠一次碰巧的高 IC 混入研究库。
        keep = bool(ev["keep"]
                    and abs(float(ev.get("icir", 0.0))) >= 0.5
                    and np.sign(ev["incremental_ic"]) == np.sign(ev["rank_ic"]))
        rec["decision"] = "kept" if keep else "rejected"
        rec["reason"] = ev["reason"] if keep else ("稳定性/增量信息不足：" + ev["reason"])
        records.append(rec)

    summary = {
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "n": len(records),
        "kept": sum(1 for r in records if r["decision"] == "kept"),
        "rejected": sum(1 for r in records if r["decision"] == "rejected"),
        "blocked": sum(1 for r in records if r["decision"] == "blocked"),
        "records": records,
    }
    if write_log:
        path = os.path.join(LOG_DIR, "research_log.jsonl")
        with open(path, "a", encoding="utf-8") as fp:
            fp.write(json.dumps(summary, ensure_ascii=False) + "\n")
        summary["log_path"] = path
    return summary


# ── 离线自测 ───────────────────────────────────────────────────────
if __name__ == "__main__":
    n = 120
    r = pd.Series(np.arange(n, dtype=float) * 0.01)
    rng = np.random.RandomState(3)
    hs = [
        {"id": "h_good", "description": "趋势动量因子",
         "expression": "close.pct_change(5)",
         "fn": lambda k: np.arange(k, dtype=float)},
        {"id": "h_noise", "description": "随机噪声因子",
         "expression": "random()",
         "fn": lambda k: rng.randn(k)},
        {"id": "h_future", "description": "使用次日收盘价",
         "expression": "df['next_close'] / df['close'] - 1",
         "fn": lambda k: np.arange(k, dtype=float)},
    ]
    out = run_quant_research(hs, r, write_log=False)
    tests = [
        ("三假设全部有决策", len(out["records"]) == 3),
        ("真因子 kept", any(x["id"] == "h_good" and x["decision"] == "kept"
                           for x in out["records"])),
        ("噪声因子 rejected", any(x["id"] == "h_noise" and x["decision"] == "rejected"
                                for x in out["records"])),
        ("未来字段 blocked", any(x["id"] == "h_future" and x["decision"] == "blocked"
                               for x in out["records"])),
        ("统计守恒", out["kept"] + out["rejected"] + out["blocked"] == 3),
    ]
    for name, ok in tests:
        print(("PASS" if ok else "FAIL"), name)
    print("ALL_PASS" if all(o for _, o in tests) else "HAS_FAIL")
