# -*- coding: utf-8 -*-
"""A-04: 部署配置唯一真源。

环境变量 LEMON_BRIDGE_HOST 是监听地址的唯一真源；未设置时回退 config.yaml
（bridge.host，安全默认 127.0.0.1），再回退硬编码安全默认。
禁止在 bridge_server.py 里硬编码任何监听地址/内网 URL 字面量。

GLOBAL-8：桥一旦对外必须同步具备鉴权 —— 非回环监听必须配置 LEMON_BRIDGE_TOKEN。
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import os
from typing import List

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_PATH = os.path.join(PROJECT_ROOT, "bridge", "config.yaml")

LOOPBACK_HOSTS = {"127.0.0.1", "localhost", "::1"}
SAFE_DEFAULT_HOST = "127.0.0.1"

# CORS 显式白名单（禁止 "*"）：本机桥自身 + 常见本地开发端口
DEFAULT_CORS_ORIGINS = [
    "http://127.0.0.1:8765",
    "http://localhost:8765",
    "http://127.0.0.1:8899",
    "http://localhost:8899",
    "http://127.0.0.1:5500",
    "http://localhost:5500",
]


def _load_yaml_bridge_section() -> dict:
    try:
        import yaml
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        return (data.get("bridge") or {}) if isinstance(data, dict) else {}
    except Exception:
        return {}


def _load_yaml_engine_section(name: str) -> dict:
    try:
        import yaml
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        return (data.get("engines") or {}).get(name) or {} if isinstance(data, dict) else {}
    except Exception:
        return {}


def resolve_host() -> str:
    """监听地址：环境变量 LEMON_BRIDGE_HOST → config.yaml bridge.host → 安全默认。"""
    env = os.environ.get("LEMON_BRIDGE_HOST", "").strip()
    if env:
        return env
    cfg = str(_load_yaml_bridge_section().get("host") or "").strip()
    if cfg:
        return cfg
    return SAFE_DEFAULT_HOST


def resolve_port(default: int = 8765) -> int:
    env = os.environ.get("LEMON_BRIDGE_PORT", "").strip() or os.environ.get("BRIDGE_PORT", "").strip()
    if env:
        try:
            return int(env)
        except ValueError:
            logger.debug("suppressed exception")
    cfg = _load_yaml_bridge_section().get("port")
    try:
        return int(cfg) if cfg else default
    except (TypeError, ValueError):
        return default


def is_loopback(host: str) -> bool:
    return host in LOOPBACK_HOSTS


def bridge_token() -> str:
    return os.environ.get("LEMON_BRIDGE_TOKEN", "").strip()


def cors_origins() -> List[str]:
    env = os.environ.get("LEMON_CORS_ORIGINS", "").strip()
    if env:
        return [o.strip() for o in env.split(",") if o.strip()]
    cfg = _load_yaml_bridge_section().get("cors_origins")
    if isinstance(cfg, list) and cfg:
        out = [str(o).strip() for o in cfg if str(o).strip() and str(o).strip() != "*"]
        if out:
            return out
    return list(DEFAULT_CORS_ORIGINS)


def ollama_base_url() -> str:
    """ollama 基址：env OLLAMA_BASE_URL → config.yaml engines.ollama.host/port。

    （宿主地址字面量只允许出现在本模块与 config.yaml，禁止散落调用方。）
    """
    env = os.environ.get("OLLAMA_BASE_URL", "").strip()
    if env:
        return env.rstrip("/")
    eng = _load_yaml_engine_section("ollama")
    host = str(eng.get("host") or SAFE_DEFAULT_HOST)
    port = eng.get("port") or 11434
    return f"http://{host}:{port}"
