# -*- coding: utf-8 -*-
"""
★ I1: 模型策略唯一真源（model_policy）
======================================
resolve_model(preferred=None, available=None) -> str

优先级（从高到低）：
  1. 显式 preferred 参数
  2. 环境变量 OLLAMA_MODEL
  3. 本机 /api/tags 里存在的 PREFERRED_MODEL（★ A5 决策后为 qwen3.5:4b）
  4. tags 第一个可用模型
  5. 兜底字符串 DEFAULT_FALLBACK（必须再验证存在性，不存在则抛明确错误）

禁止硬编码任何"必然存在"的假设——所有默认值都必须经过存在性验证。

用法：
  from bridge.model_policy import resolve_model
  model = resolve_model()  # 自动探测
  model = resolve_model(preferred="qwen3.5:4b")  # 显式指定
  model = resolve_model(available=["qwen3.5:9b", "qwen3.5:4b"])  # 离线测试

  python bridge/model_policy.py --self-test  # 离线自测
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.request
from typing import List, Optional

# ── 常量 ──
DEFAULT_FALLBACK = "qwen3.5:9b"
# ★ A5 (P03) 超级收口集群 2026-11-06 决策：保持 qwen3.5:4b 为默认。
#   依据 data/evals/model_rematch_20261106.md（8K context 全 GPU 公平重横评）：
#   4b-ctx8k 90.9%(20/22) / 7.9s，9b-ctx8k 86.4%(19/22) / 9.5s；
#   9b 未达切换条件②（总通过率 ≥ 4b）。9b 仅作难任务按需加载：
#   OLLAMA_MODEL=qwen3.5:9b（或 9b-ctx8k）一键临时切换，详见 model_switch_decision.md 第七节。
PREFERRED_MODEL = "qwen3.5:4b"
OLLAMA_BASE_URL = os.environ.get("OLLAMA_BASE_URL", "http://127.0.0.1:11434")
ENV_VAR = "OLLAMA_MODEL"


def _fetch_available(base_url: str = None, timeout: int = 4) -> List[str]:
    """从 Ollama /api/tags 获取可用模型名列表"""
    base = (base_url or OLLAMA_BASE_URL).rstrip("/")
    try:
        raw = urllib.request.urlopen(base + "/api/tags", timeout=timeout).read()
        tags = json.loads(raw)
        return [m.get("name", "") for m in (tags.get("models") or []) if m.get("name")]
    except Exception:
        return []


def _exists(model: str, available: List[str]) -> bool:
    """检查模型是否在可用列表中（支持精确匹配和别名匹配）"""
    if not model or not available:
        return False
    if model in available:
        return True
    # 别名匹配：qwen3.5:9b 匹配 qwen3.5:9b-instruct-Q4_K_M 等
    # 规则：available 中的名字以 model 开头（允许 model:tag 或 model-suffix）
    for name in available:
        if name == model or name.startswith(model + ":") or name.startswith(model + "-"):
            return True
    return False


def resolve_model(preferred: Optional[str] = None,
                  available: Optional[List[str]] = None) -> str:
    """解析最终使用的模型名。

    Args:
        preferred: 显式指定的模型名（最高优先级）
        available: 可用模型列表（None 时自动从 /api/tags 获取）

    Returns:
        最终模型名

    Raises:
        RuntimeError: 兜底模型也不存在时抛出明确错误
    """
    # 1. 显式 preferred
    if preferred:
        # 验证存在性（如果 available 已知）
        if available is not None and not _exists(preferred, available):
            raise RuntimeError(
                f"显式指定的模型 '{preferred}' 不在可用列表中: {available}")
        return preferred

    # 2. 环境变量 OLLAMA_MODEL
    env_model = os.environ.get(ENV_VAR, "").strip()
    if env_model:
        if available is not None and not _exists(env_model, available):
            raise RuntimeError(
                f"环境变量 {ENV_VAR} 指定的模型 '{env_model}' 不在可用列表中: {available}")
        return env_model

    # 3. 自动探测可用列表
    tags = available if available is not None else _fetch_available()
    if not tags:
        # 无 tags 信息时，兜底并尝试验证
        fallback = DEFAULT_FALLBACK
        # 再验证一次（如果 available 为 None，尝试获取）
        if available is None:
            tags = _fetch_available()
            if tags and _exists(fallback, tags):
                return fallback
        raise RuntimeError(
            f"无法获取可用模型列表（Ollama 可能未启动），"
            f"且兜底模型 '{DEFAULT_FALLBACK}' 无法验证存在性。"
            f"请设置环境变量 {ENV_VAR} 或检查 Ollama 服务。")

    # 4. 优先选择 PREFERRED_MODEL（如果存在）
    if _exists(PREFERRED_MODEL, tags):
        return PREFERRED_MODEL

    # 5. tags 第一个可用模型
    return tags[0]


# ══════════════════════════════════════════════════════════════════
# 离线自测
# ══════════════════════════════════════════════════════════════════
def _self_test() -> bool:
    """离线自测：传入伪造 tags 列表断言优先级"""
    tests = []

    # T1: 显式 preferred 优先
    r = resolve_model(preferred="qwen3.5:4b", available=["qwen3.5:9b", "qwen3.5:4b"])
    tests.append(("T1: preferred 优先", r == "qwen3.5:4b"))

    # T2: env OLLAMA_MODEL 次之
    os.environ[ENV_VAR] = "qwen3.5:4b"
    r = resolve_model(available=["qwen3.5:9b", "qwen3.5:4b"])
    tests.append(("T2: env 次之", r == "qwen3.5:4b"))
    del os.environ[ENV_VAR]

    # T3: PREFERRED_MODEL 存在时优先（★ A5 决策后 PREFERRED_MODEL=qwen3.5:4b）
    r = resolve_model(available=["qwen3.5:4b", "qwen3.5:9b"])
    tests.append(("T3: PREFERRED 优先（当前=%s）" % PREFERRED_MODEL,
                  r == PREFERRED_MODEL))

    # T4: PREFERRED 不存在时选第一个（动态构造不含 PREFERRED_MODEL 的列表）
    avail_t4 = [m for m in ["qwen3.5:4b", "qwen3.5:9b", "qwen3:4b"] if m != PREFERRED_MODEL]
    r = resolve_model(available=avail_t4)
    tests.append(("T4: 无 PREFERRED 选第一个（got=%s expected=%s）" % (r, avail_t4[0]),
                  r == avail_t4[0]))

    # T5: 空列表 → 抛异常
    try:
        resolve_model(available=[])
        tests.append(("T5: 空列表抛异常", False))
    except RuntimeError:
        tests.append(("T5: 空列表抛异常", True))

    # T6: preferred 不存在 → 抛异常
    try:
        resolve_model(preferred="nonexistent", available=["qwen3.5:4b"])
        tests.append(("T6: preferred 不存在抛异常", False))
    except RuntimeError:
        tests.append(("T6: preferred 不存在抛异常", True))

    # T7: 别名匹配（PREFERRED_MODEL 匹配其 -instruct-Q4_K_M 变体）
    r = resolve_model(available=[PREFERRED_MODEL + "-instruct-Q4_K_M"])
    tests.append(("T7: 别名匹配（%s → 变体）" % PREFERRED_MODEL, r == PREFERRED_MODEL))

    # T8: env 不存在 → 抛异常
    os.environ[ENV_VAR] = "nonexistent"
    try:
        resolve_model(available=["qwen3.5:4b"])
        tests.append(("T8: env 不存在抛异常", False))
    except RuntimeError:
        tests.append(("T8: env 不存在抛异常", True))
    del os.environ[ENV_VAR]

    passed = sum(1 for _, ok in tests if ok)
    total = len(tests)
    for name, ok in tests:
        print(f"  {'✅' if ok else '❌'} {name}")
    print(f"\n  自测: {passed}/{total} {'PASS' if passed == total else 'FAIL'}")
    return passed == total


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="模型策略唯一真源")
    ap.add_argument("--self-test", action="store_true", help="离线自测")
    ap.add_argument("--resolve", action="store_true", help="解析并打印默认模型")
    args = ap.parse_args()

    if args.self_test:
        sys.exit(0 if _self_test() else 1)
    elif args.resolve:
        try:
            print(resolve_model())
        except RuntimeError as e:
            print(f"ERROR: {e}")
            sys.exit(1)
    else:
        ap.print_help()
