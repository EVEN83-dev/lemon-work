"""
lemonD-bridge: Lemon Bridge Startup Script.

初始化 EngineManager/SkillRouter 并启动 HTTP 服务（:8765）。
依赖策略：fastapi 可用 → FastAPI；不可用 → stdlib http.server 同构降级。

A-05: LEMON_BRIDGE_TOKEN 缺失时自动生成并持久化到 data/config/bridge_token.json，
再注入环境变量 —— 桌面启动链路无感；直接运行 bridge_server.py 仍 fail-fast。
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import json
import os
import secrets
import sys
import time

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

_TOKEN_FILE = os.path.join(PROJECT_ROOT, "data", "config", "bridge_token.json")


def _ensure_bridge_token() -> str:
    """A-05: 桌面启动链路的令牌自举 —— env 优先，缺失则生成并持久化。"""
    env = os.environ.get("LEMON_BRIDGE_TOKEN", "").strip()
    if env:
        return env
    token = ""
    try:
        with open(_TOKEN_FILE, "r", encoding="utf-8") as f:
            token = (json.load(f) or {}).get("token", "")
    except Exception:
        token = ""
    if not token:
        token = "lbk_" + secrets.token_urlsafe(32)
        os.makedirs(os.path.dirname(_TOKEN_FILE), exist_ok=True)
        with open(_TOKEN_FILE, "w", encoding="utf-8") as f:
            json.dump({"token": token, "created": int(time.time())},
                      f, ensure_ascii=False, indent=2)
        try:
            os.chmod(_TOKEN_FILE, 0o600)
        except Exception:
            logger.debug("suppressed exception")
        print(f"[start] 已生成桥访问令牌 → {_TOKEN_FILE}（B/C 端联调请取用此值）")
    os.environ["LEMON_BRIDGE_TOKEN"] = token
    return token


def _probe_fastapi() -> bool:
    try:
        import fastapi  # noqa: F401
        import uvicorn  # noqa: F401
        return True
    except Exception:
        return False


def main():
    from bridge.core.settings_manager import SettingsManager
    from bridge.core.i18n import set_language

    settings = SettingsManager.instance()
    settings.load()
    set_language(settings.get("general.language", "zh"))

    # ★ 收口项 30：单实例保护（双进程抢端口直接退出）
    from shared.runtime_preflight import acquire_app_lock, release_app_lock
    lock_path = acquire_app_lock("bridge")
    if lock_path is None:
        return 2

    # ★ 收口项 29：启动前端口探测（默认只报告；清理用 scripts/preflight_ports.py --kill）
    from shared.runtime_preflight import print_port_report
    print_port_report()

    token = _ensure_bridge_token()  # A-05: 必须先于 bridge_server.main 的 fail-fast

    # A-04: 监听地址唯一真源 LEMON_BRIDGE_HOST → settings → host_config 安全默认
    host = (os.environ.get("LEMON_BRIDGE_HOST", "").strip()
            or settings.get("bridge.host", "127.0.0.1"))
    port = int(os.environ.get("LEMON_BRIDGE_PORT", "").strip()
               or os.environ.get("BRIDGE_PORT", "")
               or settings.get("bridge.port", 8765))
    engine = os.environ.get("BRIDGE_ENGINE", "")

    # ★ 收口项 28：打印源码版本与打包版本，不一致告警
    from shared.runtime_preflight import check_source_vs_package
    vinfo = check_source_vs_package()
    ver_note = ("源码=%s 打包=%s ✓ 一致" % (vinfo["source"], vinfo["package"])
                if vinfo["match"] else
                "⚠ 源码=%s 打包=%s 不一致 —— 打包目录是旧代码，请运行 "
                "scripts/make_release.py --internal-only 重建" % (
                    vinfo["source"], vinfo["package"]))

    # 启动横幅
    mode = "FastAPI" if _probe_fastapi() else "stdlib(http.server) fallback"
    print("=" * 56)
    print("  Lemon Bridge Server")
    print("=" * 56)
    print(f"  Host    : {host}")
    print(f"  Port    : {port}")
    print(f"  Engine  : {engine or 'auto'}")
    print(f"  Mode    : {mode}")
    print(f"  Auth    : LEMON_BRIDGE_TOKEN 已配置（长度 {len(token)}）")
    print(f"  Version : {ver_note}")
    print(f"  Lock    : {lock_path}")
    print("=" * 56)

    try:
        from bridge.bridge_server import main as serve
        return serve(["--host", str(host), "--port", str(port), "--engine", str(engine)])
    finally:
        release_app_lock("bridge")


if __name__ == "__main__":
    sys.exit(main())
