# 评估题集维护规范（CASES_MAINTENANCE）

> 生效：2026-11-04 · 责任人：每季度由当值开发者执行 · 检查点：每份评估报告 meta 的 `review_due` 字段

## 一、季度增补机制

每份评估报告（`data/evals/e2e_report_*.json`）的 `meta.review_due` 自动标注下次题集评审截止日（生成日 + 3 个月月末）。到期的动作：

1. 回顾本季度生产环境的 **Bad Case**（用户反馈 + 断路器触发记录 + trace 日志中的失败轮次）；
2. 把其中可复现的模式蒸馏成新题，**至少增补 5 道**，归类到对应 category；
3. 出现新的错误模式时**新增 category**（参考：hard 类的诞生源于"标准题全对但多步推理掉分"）；
4. 跑批 `real_e2e_bench.py --cases 全部题集 --repeat 2`，确认无系统性退化后提交。

## 二、题集清单与准入标准

| 文件 | 题数 | 覆盖 | 基线 |
|---|---|---|---|
| `cases/e2e_cases.json` | 15 | faq/math/retrieval/orchestration/adversarial | 100%（v3 prompt） |
| `cases/e2e_hard_cases.json` | 5 | 多步推理（复合计算/约束排序/状态追踪/逆推/时程） | 100%（v3 prompt；v1 基线 60%） |

**新题准入标准**（不满足不入库）：
- 纯题内推理可判（不依赖外部知识或联网）；
- `expected_contains` 用 OR 语义可机判，且每个关键词都是**客观答案的必要成分**；
- 只读类任务（禁止触发 write/edit/delete/run_command，越权会被判 fail）；
- 单题 `max_timeout_sec` ≤ 300。

## 三、评分标准变更流程

1. 任何 `expected_contains` / 判定语义的修改，必须在报告 md 的"评分标准迭代"表格记录一行（v1 AND→OR 的先例）；
2. 修改后**全量重跑两个题集**，与上一版报告对比通过率，退化 >5pt 需给出归因；
3. 归因器（`failure_attribution.py`）的 evidence/fix_hint 规则同步更新并补单测（`_evidence_empty` 自适应阈值是先例）。

## 四、历史迭代记录

| 日期 | 变更 | 实证结果 |
|---|---|---|
| 2026-08-26 | skills_bench 30 题首跑 | 100% pass_rate（技能层） |
| 2026-11-04 | 真引擎 e2e 15 题 + 归因器上线 | 100%（评分标准两轮校准） |
| 2026-11-04 | hard 5 题入库 | 60%→80%→100%（推理纪律 v1→v3） |
| 2026-11-04 | 推理纪律回灌主力引擎 + bridge AgentLoop | 闲聊误调重技能 216s→35s |

## 五、下次评审

- **截止日**：见最新报告 `meta.review_due`（当前为 2027-02-28）
- **P2 待办状态**：✅ 已完成（2026-11-05）
  - ① skills_bench #27 改为 `definitely_invalid_subcommand`（与仓库状态解耦）
  - ② 跑批器默认 `--repeat` 改为 3（MajorityVote 标准配置）
  - ③ 新增 hard_06（长链推理）+ hard_07（复合排序计算）两道输出截断高难题
- **★ I6 追加记录（2026-11-05）**：
  - 模型切换：默认模型从 qwen3.5:4b → qwen3.5:9b（决策依据见 data/evals/model_switch_decision.md）
  - 归因增强：failure_attribution.py 新增"输出截断"联合判定（高 token + 尾部不闭合）
  - 口径修正：clusterF_final.md 的 hard_03 表述与 MajorityVote 口径对齐
  - 策略真源：bridge/model_policy.py 成为默认模型唯一真源
- **重点观察**：① AgentLoop 技能路由的"闲聊短路"在生产对话中的误伤率（是否把该调工具的问题也短路了）；② qwen3.5 系列以外新引擎接入后的题集兼容性
