# -*- coding: utf-8 -*-
"""★ A3 (P06): --num-predict 冻结契约扩展单测（纯 mock，不依赖 Ollama）。

契约要点（supercluster 集群铁律 3）：
  1. 既有 CLI 参数 --cases/--repeat/--outdir/--model/--system-extra/--limit 一个不少；
  2. 新增可选参数 --num-predict 默认 0；
  3. 不传（默认 0）时 chat payload 与旧版逐字段一致（options 恒存在：
     temperature + num_predict=2048，无任何新键注入）→ 旧调用零行为变化；
  4. 传 4096 时 payload.options.num_predict == 4096（temperature 保持）；
  5. meta 记录 num_predict 值。

运行：
    D:/xiaomi_temp/lemon_agent/_py312/python.exe bridge/eval/test_num_predict.py
"""
from __future__ import annotations

import json
import sys
import types
import os
from argparse import Namespace
from typing import Any, Dict, List

PROJ_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if PROJ_ROOT not in sys.path:
    sys.path.insert(0, PROJ_ROOT)

from bridge.eval.real_e2e_bench import OllamaClient, _build_report, CaseResult, main  # noqa: E402

RESULTS = []


def report(name: str, ok: bool, detail: str = "") -> None:
    RESULTS.append((name, ok))
    print(f"  [{'PASS' if ok else 'FAIL'}] {name} {detail}", flush=True)


class _FakeResp:
    def raise_for_status(self) -> None:
        pass

    def json(self) -> Dict[str, Any]:
        return {"message": {"content": "ok"}, "prompt_eval_count": 1, "eval_count": 1}


_CAPTURED: List[Dict[str, Any]] = []


def _install_fake_requests() -> None:
    fake = types.ModuleType("requests")

    def _post(url: str, json: Dict[str, Any] = None, timeout: int = 0):
        _CAPTURED.append(json)
        return _FakeResp()

    def _get(url: str, timeout: int = 0):
        class _R:
            status_code = 200
        return _R()

    fake.post = _post
    fake.get = _get
    sys.modules["requests"] = fake


def main() -> int:
    _install_fake_requests()

    # ── 契约 1: 既有 CLI 参数逐字存在，新增 --num-predict 默认 0 ──
    import argparse
    ap = argparse.ArgumentParser()
    # 从 main 的 parser 复刻检测：直接用 python -m 跑 --help 太重，改查源码
    import inspect
    src = inspect.getsource(sys.modules["bridge.eval.real_e2e_bench"])
    for legacy in ("--cases", "--repeat", "--outdir", "--model", "--system-extra", "--limit"):
        report(f"契约_旧参数存在 {legacy}", f'"{legacy}"' in src or f"'{legacy}'" in src)
    report("契约_新参数--num-predict存在", '"--num-predict"' in src)
    report("契约_num-predict默认0", 'type=int, default=0' in src)

    # ── 契约 3: 默认不传 → payload 与旧版逐字段一致 ──
    _CAPTURED.clear()
    c_old = OllamaClient(model="qwen3.5:4b")
    c_old.chat([{"role": "user", "content": "hi"}])
    p_old = _CAPTURED[-1]
    report("A3_默认payload与旧版一致",
           p_old["options"] == {"temperature": 0.3, "num_predict": 2048},
           f"options={p_old['options']}")
    report("A3_默认无新增覆盖键", set(p_old["options"].keys()) == {"temperature", "num_predict"},
           f"keys={sorted(p_old['options'].keys())}")
    report("A3_默认think=false保持", p_old.get("think") is False)

    # ── 契约 4: 传 4096 → 覆盖注入 ──
    _CAPTURED.clear()
    c_new = OllamaClient(model="qwen3.5:9b-ctx8k", num_predict=4096)
    c_new.chat([{"role": "user", "content": "hi"}])
    p_new = _CAPTURED[-1]
    report("A3_传4096覆盖num_predict", p_new["options"].get("num_predict") == 4096,
           f"options={p_new['options']}")
    report("A3_传4096温度保持", p_new["options"].get("temperature") == 0.3)
    report("A3_传4096think保持", p_new.get("think") is False)

    # ── 契约 5: meta 记录 num_predict ──
    cr = CaseResult(id="t", category="faq", prompt="p", passed=True)
    args = Namespace(engine="ollama", model="m", repeat=1, cases="cases.json", num_predict=4096)
    rep = _build_report([cr], args, [], "traj.json", "", [])
    report("A3_meta记录num_predict=4096", rep["meta"].get("num_predict") == 4096,
           f"meta.num_predict={rep['meta'].get('num_predict')}")
    args0 = Namespace(engine="ollama", model="m", repeat=1, cases="cases.json", num_predict=0)
    rep0 = _build_report([cr], args0, [], "traj.json", "", [])
    report("A3_meta默认num_predict=0", rep0["meta"].get("num_predict") == 0)
    # 旧调用方若不传该属性（getattr 兜底）也不崩
    args_none = Namespace(engine="ollama", model="m", repeat=1, cases="cases.json")
    repn = _build_report([cr], args_none, [], "traj.json", "", [])
    report("A3_旧args缺属性时meta兜底0", repn["meta"].get("num_predict") == 0)
    # 报告结构冻结契约：{meta,summary,categories,per_case,bad_cases}
    report("A3_报告结构冻结不变", set(rep.keys()) == {"meta", "summary", "categories", "per_case", "bad_cases"},
           f"keys={sorted(rep.keys())}")

    passed = sum(1 for _, ok in RESULTS if ok)
    total = len(RESULTS)
    print("\n" + "=" * 60)
    print(f"A3 num-predict 契约单测: {passed}/{total} {'PASS' if passed == total else 'FAIL'}")
    print("=" * 60, flush=True)
    return 0 if passed == total else 1


if __name__ == "__main__":
    sys.exit(main())
