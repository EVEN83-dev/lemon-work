# -*- coding: utf-8 -*-
"""lemonE-eval: 失败归因器（四分类，图1 面试标准 + 输出截断）。

① 模型决策错：空回复 / 答非所问 / 重复同一工具≥3次 / LoopDetector 触发
② 工具选错：调用了不相关工具 / 参数非法被 _validate 拒绝 / 工具 success=false
③ 上下文不足：历史截断后丢失关键信息 / 长 prompt 后半段被无视
              （用"重跑一次带显式提示复述"作二次探针）
④ ★ F5: 输出截断：reply 非空但尾部不闭合（非 。！？!?；;\n 且未命中 Markdown 闭合），
              且期望关键词未命中 → 高置信度归因
"""
from __future__ import annotations

import re
from typing import Any, Dict, List

# ── 输出截断检测常量 ──
_SENTENCE_END = tuple("。！？!?；;\n")
_MD_CLOSERS = ("```", "**", "*", "|", "</", "---")


def _is_truncated(reply: str, expected: List[str],
                  total_tokens: int = 0) -> bool:
    """★ F5+I5: 判断 reply 是否为输出截断。

    条件（满足任一即判定为截断）：
      A) 尾部是中文/字母/数字（句子不完整）
      B) ★ I5: total_tokens > 5000 或 reply 字符数 > 6000

    前置条件（两者共用）：
      - reply 非空
      - 尾部不是句读（。！？!?；;\n）
      - 尾部不是 Markdown 闭合
      - 期望关键词未命中

    Returns:
        True = 疑似输出截断
    """
    r = (reply or "").strip()
    if not r:
        return False
    exp = [k for k in (expected or []) if k]
    if exp and any(k in r for k in exp):
        return False
    tail = r[-1]
    if tail in _SENTENCE_END:
        return False
    for closer in _MD_CLOSERS:
        if r.endswith(closer):
            return False
    if re.search(r'[\u4e00-\u9fff\w]$', tail):
        return True
    # ★ I5: 尾部是省略号 → 截断信号
    if r.endswith("...") or r.endswith("…"):
        return True
    if total_tokens > 5000 or len(r) > 6000:
        return True
    return False


def _evidence_empty(reply: str, expected: Optional[List[str]] = None) -> bool:
    """空回复 = 硬信号；'过短' = 回复比最长期望关键词还短。
    ★ v6.3 修复：原实现 len<5 绝对阈值，会把"丙甲丁乙"这类 4 字标准答案误报为过短。"""
    r = (reply or "").strip()
    if not r:
        return True
    exp = [k for k in (expected or []) if k]
    if exp and len(r) < max(len(k) for k in exp):
        return True
    return False


def _evidence_repeat_tools(tool_calls: List[Dict[str, Any]]) -> List[str]:
    counts: Dict[str, int] = {}
    for t in tool_calls:
        counts[t.get("name", "?")] = counts.get(t.get("name", "?"), 0) + 1
    return [f"工具 {n} 被调用 {c} 次（≥3）" for n, c in counts.items() if c >= 3]


def _evidence_tool_fail(tool_calls: List[Dict[str, Any]]) -> List[str]:
    out = []
    for t in tool_calls:
        if not t.get("success"):
            out.append(f"工具 {t.get('name')} 执行失败: {str(t.get('result',''))[:80]}")
    return out


def _evidence_offtopic(reply: str, prompt: str, keywords: List[str]) -> List[str]:
    hit = [k for k in keywords if k in reply]
    miss = [k for k in keywords if k not in reply]
    ev = []
    if miss:
        ev.append(f"期望关键词未命中: {miss}")
    if hit:
        ev.append(f"命中关键词: {hit}（部分命中）")
    return ev


def attribute(result) -> Dict[str, Any]:
    """对单个 CaseResult（fail）归因。返回 {label, confidence, evidence, fix_hint}。"""
    reply = (result.reply or "")
    tcs = result.tool_calls or []
    prompt = result.prompt or ""
    expected = getattr(result, "keywords_hit", []) or []
    case_expected = getattr(result, "_expected", []) or expected

    # 重新取期望关键词：从 result 上无法直接拿，用 keywords_hit 反推不全；
    # 这里以 result 携带的字段为准；跑批器会在调用前注入 _expected
    expected = getattr(result, "_expected", None) or expected

    evidence: List[str] = []
    label = "模型决策错"
    confidence = "medium"
    fix_hint = ""

    # 预计算 off_topic（截断检测需要）
    off_topic = _evidence_offtopic(reply, prompt, expected)

    # ── ④ ★ F5+I5: 输出截断检测（最高优先级，仅 fail 时进入）──
    # 保留原三分类优先级：截断 > 模型决策错 > 工具选错 > 上下文不足
    # ★ I5: 传入 total_tokens 做联合判定
    _usage = getattr(result, "usage", None) or {}
    _total_tokens = 0
    if isinstance(_usage, dict):
        _total_tokens = _usage.get("total_tokens", 0) or 0
        if not _total_tokens:
            _total_tokens = (_usage.get("prompt_tokens", 0) or 0) + (_usage.get("completion_tokens", 0) or 0)
    truncated = _is_truncated(reply, case_expected, total_tokens=_total_tokens)
    if truncated:
        label = "输出截断"
        confidence = "high"
        tail_preview = reply[-50:] if len(reply) > 50 else reply
        evidence.append(f"回复尾部不闭合（tail=...{tail_preview}）")
        if off_topic:
            evidence.extend(off_topic[:2])
        fix_hint = "提高 max_tokens 或要求模型分步收口；检查是否触发引擎输出上限。"
        return {
            "label": label,
            "confidence": confidence,
            "evidence": evidence,
            "fix_hint": fix_hint,
            "tool_calls_total": len(tcs),
            "tool_success_rate": result.tool_success_rate,
        }

    # ── ③ 上下文不足探针：先检测长 prompt / 截断信号 ──
    long_prompt = len(prompt) > 800
    # ② 工具选错检测
    tool_fail = _evidence_tool_fail(tcs)
    repeat = _evidence_repeat_tools(tcs)
    off_topic = _evidence_offtopic(reply, prompt, expected)

    # ── ① 模型决策错 ──
    if _evidence_empty(reply, case_expected):
        label = "模型决策错"
        confidence = "high"
        evidence.append(f"回复为空或过短（len={len(reply.strip())}）")
        if repeat:
            evidence.extend(repeat)
        fix_hint = "检查引擎是否返回内容；确认提示词是否触发安全过滤导致空回复。"
    elif repeat:
        label = "模型决策错"
        confidence = "high"
        evidence.extend(repeat)
        fix_hint = "工具循环陷入重复调用；建议降低 max_iterations 或加强 LoopDetector 提前熔断。"
    elif result.breaker_triggered:
        label = "模型决策错"
        confidence = "medium"
        evidence.append("断路器触发（同一工具≥3 次）")
        fix_hint = "增强 AgentLoop 的反思提示，避免重复同参调用。"

    # ── ② 工具选错 ──
    elif tool_fail:
        label = "工具选错"
        confidence = "high"
        evidence.extend(tool_fail[:3])
        if off_topic:
            evidence.extend(off_topic[:2])
        fix_hint = "工具参数或选择不匹配；建议在 skill 描述中强化适用场景与参数约束。"

    # ── ③ 上下文不足 ──
    elif long_prompt and off_topic:
        label = "上下文不足"
        confidence = "medium"
        evidence.append(f"prompt 长度 {len(prompt)} 字符（>800）")
        evidence.extend(off_topic[:3])
        fix_hint = "长 prompt 后半段可能被截断；建议分块注入或要求模型先复述关键约束。"
    elif off_topic:
        label = "模型决策错"
        confidence = "medium"
        evidence.extend(off_topic[:3])
        fix_hint = "回复未覆盖期望要点；建议补强 system prompt 的作答要求。"
    else:
        # ★ A7 (P07): 兜底分支治理 —— "无明确证据且未命中关键词"不再误标"模型决策错"，
        #   改为显式"待人工复核"并附结构化证据，消除 unknown 字样。
        label = "待人工复核"
        confidence = "low"
        _usage2 = getattr(result, "usage", None) or {}
        _tk = _usage2.get("total_tokens") if isinstance(_usage2, dict) else None
        evidence.append(f"回复长度={len((reply or '').strip())} 字符")
        evidence.append(f"期望关键词={list(case_expected) if case_expected else '（题目未给）'}")
        evidence.append(f"工具调用数={len(tcs)}（成功 {sum(1 for t in tcs if t.get('success'))}）")
        if _tk:
            evidence.append(f"总 tokens={_tk}")
        evidence.append("未命中期望关键词，且无明确工具失败信号")
        fix_hint = "人工复核：可能是评分标准与模型表述差异；对照结构化证据逐条核对。"

    if not evidence:
        evidence.append("无显著证据（归因置信度低）")

    return {
        "label": label,
        "confidence": confidence,
        "evidence": evidence,
        "fix_hint": fix_hint,
        "tool_calls_total": len(tcs),
        "tool_success_rate": result.tool_success_rate,
    }


# ══════════════════════════════════════════════════════════════════
# ★ F5: 单元测试（≥8 项，含既有 _evidence_empty 4 个用例不回归）
# ══════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    import json as _json

    class _FakeResult:
        def __init__(self, reply="", tool_calls=None, prompt="", expected=None,
                     passed=False, breaker_triggered=False, tool_success_rate=0.0):
            self.reply = reply
            self.tool_calls = tool_calls or []
            self.prompt = prompt
            self.keywords_hit = []
            self._expected = expected or []
            self.passed = passed
            self.breaker_triggered = breaker_triggered
            self.tool_success_rate = tool_success_rate

    tests = []

    # ── _evidence_empty 既有 4 用例（不回归）──
    tests.append(("evidence_empty: 空字符串", _evidence_empty("") == True))
    tests.append(("evidence_empty: 空白字符串", _evidence_empty("   ") == True))
    tests.append(("evidence_empty: 过短（< 最长期望关键词）",
                  _evidence_empty("丙甲", ["丙丁甲乙"]) == True))
    tests.append(("evidence_empty: 正常回复", _evidence_empty("丙丁甲乙", ["丙丁甲乙"]) == False))

    # ── _is_truncated 新增 4 用例 ──
    tests.append(("truncated: 尾部非句读且中文结尾",
                  _is_truncated("答案是 354.04 元因为计算过程比较复杂所以我需要", ["354.04"]) == False))  # 命中关键词 → 不是截断
    tests.append(("truncated: 尾部非句读且未命中关键词",
                  _is_truncated("经过逐步推理我们得到了一个中间结果 1234.56 但是继续计算的话", ["999.99"]) == True))
    tests.append(("truncated: 尾部是句读 → 不是截断",
                  _is_truncated("答案是 354.04 元。", ["999.99"]) == False))
    tests.append(("truncated: 尾部是 Markdown 闭合 → 不是截断",
                  _is_truncated("```\n结果\n```", ["999.99"]) == False))

    # ── attribute 集成 2 用例 ──
    r1 = _FakeResult(reply="答案是 354.04 元因为计算过程比较复杂所以我需要",
                     expected=["999.99"])
    a1 = attribute(r1)
    tests.append(("attribute: 截断归因高置信", a1["label"] == "输出截断" and a1["confidence"] == "high"))

    r2 = _FakeResult(reply="", expected=["答案"])
    a2 = attribute(r2)
    tests.append(("attribute: 空回复仍为模型决策错", a2["label"] == "模型决策错"))

    # ── ★ I5: 联合截断检测新增 4 用例 ──
    # T1: 高 token + 尾部不闭合 → 截断
    tests.append(("I5: 高 token(8000) + 尾部不闭合 → 截断",
                  _is_truncated("经过长链推理得到中间结果 1234.56", ["999.99"], total_tokens=8000) == True))
    # T2: 高 token 但尾部句读 → 不是截断
    tests.append(("I5: 高 token(8000) + 尾部句读 → 不是截断",
                  _is_truncated("经过长链推理得到结果。", ["999.99"], total_tokens=8000) == False))
    # T3: 低 token + 尾部不闭合 → 条件 A 仍生效
    tests.append(("I5: 低 token(2000) + 尾部不闭合 → 截断",
                  _is_truncated("推理中途 1234.56 但", ["999.99"], total_tokens=2000) == True))
    # T4: 长 reply(>6000 字符) + 尾部不闭合 → 截断
    long_reply = "A" * 6001 + "但是"
    tests.append(("I5: 长 reply(6001 字符) + 尾部不闭合 → 截断",
                  _is_truncated(long_reply, ["999.99"], total_tokens=0) == True))
    # T5: attribute 集成 — 高 token 场景
    r3 = _FakeResult(reply="推理过程..." + "X" * 100, expected=["答案"])
    r3.usage = {"total_tokens": 8000}
    a3 = attribute(r3)
    tests.append(("I5: attribute 高 token 归因为输出截断", a3["label"] == "输出截断"))
    # T6: attribute 集成 — 正常 token 场景不受影响
    r4 = _FakeResult(reply="答案是 354.04 元。", expected=["999.99"])
    r4.usage = {"total_tokens": 200}
    a4 = attribute(r4)
    tests.append(("I5: attribute 正常 token 不误判", a4["label"] != "输出截断"))

    # ── ★ A7 (P07): 兜底分支"待人工复核"新增 3 用例 ──
    # 兜底分支真实触发条件：题目未定义期望关键词（expected=[]）、回复完整闭合、
    # 无工具失败/重复/断路器 → 无任何明确证据（若"给了关键词且未命中"会走
    # off_topic 分支归"模型决策错"，不属于无明确证据场景）。
    # A7-1: 有回复、题目未给期望关键词、无工具 → 待人工复核（不再误标模型决策错）
    r5 = _FakeResult(reply="这个问题比较复杂，需要结合具体情况判断。", expected=[])
    a5 = attribute(r5)
    tests.append(("A7: 无明确证据兜底 → 待人工复核", a5["label"] == "待人工复核" and a5["confidence"] == "low"))
    # A7-2: 结构化证据包含 回复长度/期望关键词/工具调用数
    ev = a5.get("evidence", [])
    has_len = any("回复长度" in e for e in ev)
    has_kw = any("期望关键词" in e for e in ev)
    has_tc = any("工具调用数" in e for e in ev)
    tests.append(("A7: 结构化证据三要素齐备", has_len and has_kw and has_tc))
    tests.append(("A7: 证据中不含 unknown 字样", "unknown" not in _json.dumps(a5, ensure_ascii=False)))
    # A7-3: 有工具失败证据时不受影响（仍归工具选错；回复以句读收尾避免误入截断分支）
    r6 = _FakeResult(reply="尝试检索但失败了。", expected=["丙丁甲乙"],
                     tool_calls=[{"name": "web_researcher", "success": False, "result": "err"}])
    a6 = attribute(r6)
    tests.append(("A7: 有工具失败仍归工具选错", a6["label"] == "工具选错"))

    passed = sum(1 for _, ok in tests if ok)
    total = len(tests)
    for name, ok in tests:
        print(f"  {'✅' if ok else '❌'} {name}")
    print(f"\n  {passed}/{total} {'PASS' if passed == total else 'FAIL'}")
    exit(0 if passed == total else 1)
