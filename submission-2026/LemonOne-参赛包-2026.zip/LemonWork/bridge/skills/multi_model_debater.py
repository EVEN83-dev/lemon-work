"""Multi-perspective debate via real model calls.

v2.0 (fake-implementation removal): v1 produced the whole "debate" by string
templates out of a canned ``_ROLE_DATA`` table (no model was ever consulted) and
still returned ``success=True`` with a formatted report. The report now comes
from real engine calls; when no engine is reachable the skill fails loudly
instead of emitting fabricated argumentation.
"""

import json
import re
from typing import Any, Dict, List, Optional

from .models import SkillResult, SkillDef

METADATA = {
    "name": "multi_model_debater",
    "version": "2.0.0",
    "category": "reasoning",
    "description": "Multi-perspective debate driven by real model calls (2-4 roles + judge scoring).",
}

_ROLES: Dict[str, str] = {
    "Proponent": ("You argue IN FAVOUR of the topic. Give concrete, checkable reasons "
                  "(data, mechanism, precedent). Do not hedge. 3-5 sentences."),
    "Opponent": ("You argue AGAINST the topic. Name the 2-3 most damaging flaws "
                 "(cost, risk, failure conditions, counterexamples). Be specific. 3-5 sentences."),
    "Neutral Analyst": ("You take no side. State which arguments from either side are "
                        "supported by evidence and which lack it, and how to test them. 3-5 sentences."),
    "Devil's Advocate": ("You challenge the shared assumptions behind both sides, then state "
                         "what would have to be true for your challenge to be wrong. 3-5 sentences."),
}

_JUDGE_SYSTEM = (
    "You are the debate judge. Output ONLY one JSON object, no prose, no code fence. "
    'Shape: {"scores": {"<Role>": <0-100 integer>, ...}, "winner": "<Role>", '
    '"reason": "<=60 words"}. Score on specificity, checkability, and how well each '
    "side answered the other's strongest point."
)


def _engine_manager():
    from shared.engine_manager import get_engine_manager
    return get_engine_manager()


def _engines_for(em, n: int) -> List[str]:
    names: List[str] = []
    try:
        names = [str(x) for x in (em.get_available_engines() or []) if x]
    except Exception:
        names = []
    if not names:
        names = [str(getattr(em, "_active_engine", "") or "")]
    names = [x for x in names if x] or [""]
    return [names[i % len(names)] for i in range(n)]


def _call(em, prompt: str, system: str, engine: str) -> Dict[str, Any]:
    kwargs: Dict[str, Any] = {"system_prompt": system, "use_cache": False}
    if engine:
        kwargs["engine"] = engine
    try:
        resp = em.chat(prompt, **kwargs)
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {str(e)[:180]}", "engine": engine}
    content = str(getattr(resp, "content", "") or "").strip()
    if not content:
        return {"ok": False, "error": "engine returned empty content", "engine": engine}
    return {"ok": True, "content": content, "engine": engine,
            "model": str(getattr(resp, "model", "") or ""),
            "tokens": int(getattr(resp, "token_count", 0) or 0)}


def _parse_json(text: str) -> Optional[Dict[str, Any]]:
    if not text:
        return None
    cleaned = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.MULTILINE).strip()
    m = re.search(r"\{.*\}", cleaned, re.DOTALL)
    if not m:
        return None
    try:
        obj = json.loads(m.group(0))
        return obj if isinstance(obj, dict) else None
    except Exception:
        return None


def execute(topic: str, perspectives: int = 3, **kwargs) -> SkillResult:
    if not str(topic or "").strip():
        return SkillResult.fail(error="topic is required")

    perspectives = max(2, min(4, int(perspectives or 3)))
    rounds = max(1, min(3, int(kwargs.get("rounds") or 1)))
    context = str(kwargs.get("context") or "")
    roles = list(_ROLES.keys())[:perspectives]

    try:
        em = _engine_manager()
    except Exception as e:
        return SkillResult.fail(
            error=f"no model engine available ({type(e).__name__}: {str(e)[:150]}); "
                  f"this skill refuses to fabricate debate text")

    engines = _engines_for(em, len(roles))
    entries: List[Dict[str, Any]] = []
    errors: List[str] = []
    total_tokens = 0

    for round_num in range(1, rounds + 1):
        prior = "\n".join(
            f"[round {e['round']}·{e['role']} ({e['engine']})] {e['argument']}"
            for e in entries)
        for idx, role in enumerate(roles):
            if round_num == 1:
                prompt = (f"Topic: {topic}\n"
                          + (f"Context: {context}\n" if context else "")
                          + "Deliver your opening argument.")
            else:
                prompt = (f"Topic: {topic}\n"
                          + (f"Context: {context}\n" if context else "")
                          + f"Previous statements:\n{prior}\n"
                            "Cross-examine the strongest opposing point and revise your position.")
            r = _call(em, prompt, _ROLES[role], engines[idx])
            if not r["ok"]:
                errors.append(f"round {round_num} {role}: {r['error']}")
                continue
            total_tokens += r["tokens"]
            entries.append({"round": round_num, "role": role, "engine": r["engine"],
                            "model": r["model"], "tokens": r["tokens"],
                            "argument": r["content"]})

    if not entries:
        return SkillResult.fail(
            error="every stance call failed, no real debate to report: "
                  + " | ".join(errors[:3]))

    transcript = "\n".join(
        f"[{e['round']}·{e['role']} ({e['engine']})] {e['argument']}" for e in entries)
    judge = _call(em,
                  f"Topic: {topic}\nRoles: {json.dumps(roles, ensure_ascii=False)}\n"
                  f"Statements:\n{transcript}\n"
                  f"scores keys must be exactly {roles}.",
                  _JUDGE_SYSTEM, engines[0])
    if not judge["ok"]:
        return SkillResult.fail(
            error=f"judge model unavailable ({judge['error']}); scores are not fabricated")
    total_tokens += judge["tokens"]
    verdict = _parse_json(judge["content"])
    if not verdict or not isinstance(verdict.get("scores"), dict):
        return SkillResult.fail(
            error="judge did not return the agreed JSON; raw: " + judge["content"][:160])

    scores: Dict[str, float] = {}
    for role in roles:
        try:
            val = float((verdict.get("scores") or {}).get(role))
        except (TypeError, ValueError):
            return SkillResult.fail(
                error=f"judge omitted a usable score for {role!r}; refusing to invent one")
        scores[role] = round(max(0.0, min(100.0, val)) / 100.0, 3)

    winner = str(verdict.get("winner") or "")
    if winner not in scores:
        winner = max(scores, key=lambda r: scores[r])

    lines = ["=" * 64, "MULTI-PERSPECTIVE DEBATE (real model calls)", "=" * 64, "",
             f"Topic: {topic}", f"Roles: {', '.join(roles)}",
             f"Engine map: " + "; ".join(f"{r}<-{e}" for r, e in zip(roles, engines)),
             f"Judge engine: {judge['engine']}"
             + (f" ({judge['model']})" if judge.get("model") else ""), ""]
    for rnd in sorted({e["round"] for e in entries}):
        lines.append(f"## Round {rnd}")
        for e in entries:
            if e["round"] != rnd:
                continue
            lines.append(f"**{e['role']}** [{e['engine']}]: {e['argument']}")
            lines.append("")
    lines.append("## Judge scores")
    for role in roles:
        lines.append(f"- {role}: {round(scores[role] * 100, 1)}%")
    lines.append("")
    lines.append(f"Winner: **{winner}**")
    if verdict.get("reason"):
        lines.append(f"Reason: {str(verdict['reason'])[:200]}")
    if errors:
        lines += ["", "## Degraded during this run"] + [f"- {x}" for x in errors]
    lines += ["", f"Total tokens consumed by real calls: {total_tokens}"]

    return SkillResult.ok(
        output="\n".join(lines),
        data={"needs_llm": True, "llm_used": True, "topic": topic,
              "roles": roles, "entries": entries, "scores": scores,
              "winner": winner, "judge_reason": str(verdict.get("reason") or ""),
              "tokens_total": total_tokens, "errors": errors},
    )


def register(registry) -> None:
    registry.register(SkillDef(
        name="multi_model_debater",
        description="Multi-perspective debate with real model calls and judge scoring (2-4 perspectives).",
        category="reasoning",
        parameters={
            "type": "object",
            "properties": {
                "topic": {
                    "type": "string",
                    "description": "Debate topic",
                },
                "perspectives": {
                    "type": "integer",
                    "description": "Number of debate perspectives (2-4)",
                    "minimum": 2,
                    "maximum": 4,
                },
                "rounds": {
                    "type": "integer",
                    "description": "Debate rounds (1-3); round >1 adds cross-examination",
                    "minimum": 1,
                    "maximum": 3,
                },
                "context": {
                    "type": "string",
                    "description": "Background material given to all roles",
                },
            },
            "required": ["topic"],
        },
        handler=execute,
        # real multi-role + judge calls: 45s would always be cut
        timeout=300,
    ))
