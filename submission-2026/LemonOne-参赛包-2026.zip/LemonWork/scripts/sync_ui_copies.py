# -*- coding: utf-8 -*-
"""lemonG #6: UI 副本同步器（源 standard_mode/ui → bin/_internal 与 dist/_internal）。

- 运行时文件：html / js / css（含新增 lw_*）
- 幂等：内容一致则跳过
- UTF-8，跳过 .bak_* / __pycache__ / .pyc
- --check：只报差异不写
- --bump：按内容 hash 更新 mimo_page.html 子资源版本串（三份副本同步）
"""
from __future__ import annotations

import argparse
import hashlib
import os
import re
import shutil
import sys
from typing import Dict, List, Tuple

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC_UI = os.path.join(ROOT, "standard_mode", "ui")
TARGETS = [
    os.path.join(ROOT, "bin", "_internal", "standard_mode", "ui"),
    os.path.join(ROOT, "dist", "lemon_agent", "_internal", "standard_mode", "ui"),
]
EXTS = (".html", ".js", ".css")
SKIP_PREFIX = ".bak_"
VERSION_RE = re.compile(r"(v=\d+\.\d+-\d{8})")


def _files(root: str) -> Dict[str, str]:
    """返回 {相对路径: 绝对路径}，仅运行时文件，跳过 .bak_*。"""
    out: Dict[str, str] = {}
    if not os.path.isdir(root):
        return out
    for name in sorted(os.listdir(root)):
        if name.startswith(SKIP_PREFIX):
            continue
        if not name.lower().endswith(EXTS):
            continue
        full = os.path.join(root, name)
        if os.path.isfile(full):
            out[name] = full
    return out


def _hash(path: str) -> str:
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def _collect_diffs() -> List[Tuple[str, str, str]]:
    """返回 [(目标目录, 文件名, 状态)]，状态 in same/dkip/missing/differ。"""
    src = _files(SRC_UI)
    diffs: List[Tuple[str, str, str]] = []
    for tgt in TARGETS:
        dst = _files(tgt)
        for name, spath in src.items():
            dpath = os.path.join(tgt, name)
            if not os.path.exists(dpath):
                diffs.append((tgt, name, "missing"))
            elif _hash(spath) == _hash(dpath):
                diffs.append((tgt, name, "same"))
            else:
                diffs.append((tgt, name, "differ"))
        # 目标有但源没有（冗余副本）
        for name in dst:
            if name not in src:
                diffs.append((tgt, name, "extra"))
    return diffs


def _bump_version() -> str:
    """按 mimo_app.js + mimo_style.css 内容 hash 生成版本串，写入三份 html。"""
    base = os.path.join(ROOT, "standard_mode", "ui", "mimo_page.html")
    h = hashlib.sha256()
    for fn in ("mimo_app.js", "mimo_style.css", "mimo_page.html"):
        p = os.path.join(ROOT, "standard_mode", "ui", fn)
        if os.path.isfile(p):
            h.update(_hash(p).encode("ascii"))
    new_ver = "v6.5-" + h.hexdigest()[:8]
    return new_ver


def _apply_bump(new_ver: str) -> List[str]:
    """把 mimo_page.html 的子资源版本串统一替换，返回改动的文件路径列表。"""
    changed: List[str] = []
    for root in [SRC_UI] + TARGETS:
        hp = os.path.join(root, "mimo_page.html")
        if not os.path.isfile(hp):
            continue
        with open(hp, encoding="utf-8") as f:
            s = f.read()
        s2 = VERSION_RE.sub(new_ver, s)
        if s2 != s:
            with open(hp, "w", encoding="utf-8", newline="") as f:
                f.write(s2)
            changed.append(hp)
    return changed


def main(argv: List[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Sync UI copies")
    ap.add_argument("--check", action="store_true", help="只报差异不写")
    ap.add_argument("--bump", action="store_true", help="按内容 hash 更新版本串")
    args = ap.parse_args(argv)

    if not os.path.isdir(SRC_UI):
        print(f"[FATAL] 源目录不存在: {SRC_UI}")
        return 2

    print("=" * 60)
    print("  lemonG #6 UI 副本同步器")
    print("=" * 60)
    print(f"  SRC    : {SRC_UI}")
    for t in TARGETS:
        print(f"  TARGET : {t}  ({'exists' if os.path.isdir(t) else 'MISSING'})")

    if args.bump:
        new_ver = _bump_version()
        changed = _apply_bump(new_ver)
        print(f"  [bump] 版本串 → {new_ver}（{len(changed)} 个 html 已更新）")

    diffs = _collect_diffs()
    missing = [d for d in diffs if d[2] == "missing"]
    differ = [d for d in diffs if d[2] == "differ"]
    extra = [d for d in diffs if d[2] == "extra"]
    same = [d for d in diffs if d[2] == "same"]

    print("-" * 60)
    print(f"  same={len(same)}  differ={len(differ)}  missing={len(missing)}  extra={len(extra)}")

    if args.check:
        for tgt, name, st in differ + missing + extra:
            print(f"  [{st.upper():7s}] {os.path.relpath(tgt, ROOT)}/{name}")
        if not (differ or missing or extra):
            print("  [OK] 三份副本零差异")
            return 0
        print("  [CHECK] 存在差异（干跑，未写入）")
        return 1

    # 同步
    src = _files(SRC_UI)
    written = 0
    for tgt in TARGETS:
        os.makedirs(tgt, exist_ok=True)
        for name, spath in src.items():
            dpath = os.path.join(tgt, name)
            if (not os.path.exists(dpath)) or _hash(spath) != _hash(dpath):
                shutil.copy2(spath, dpath)
                written += 1
                print(f"  [COPY] {os.path.relpath(dpath, ROOT)}")
    print("-" * 60)
    print(f"  同步完成：写入 {written} 个文件")

    # 复核
    diffs2 = _collect_diffs()
    bad = [d for d in diffs2 if d[2] in ("missing", "differ", "extra")]
    if bad:
        print(f"  [WARN] 同步后仍有 {len(bad)} 处差异")
        return 1
    print("  [OK] 同步后零差异")
    return 0


if __name__ == "__main__":
    sys.exit(main())
