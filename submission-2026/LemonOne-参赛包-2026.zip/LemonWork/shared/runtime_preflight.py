# -*- coding: utf-8 -*-
"""★ 收口项 28/29/30 启动侧三合一：版本比对 / 端口探测 / 单实例锁。

- check_source_vs_package()  源码版本 vs 打包版本（data/config/package_version.json），
                              不一致打印告警（打包目录跑旧代码的最后一道闸）
- probe_service_ports()      8791-8795(stage)/8796-8800(mesh)/8801-8805(company)/8765(bridge)
                              占用探测，返回监听者清单（默认只报告不清理）
- acquire_app_lock(name)     单实例锁（data/run/<name>.lock，PID 存活检测 + 陈旧锁回收）
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import json
import os
import re
import socket
import time
from typing import Any, Dict, List, Optional

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# 服务端口段（收口项 29）：各服务占用顺延，探测覆盖完整段
SERVICE_PORT_RANGES = {
    "crawl_stage": (8791, 8795),     # 爬虫作战室 stage_server
    "session_mesh": (8796, 8800),    # 会话网格
    "company": (8801, 8805),         # 公司模式
    "bridge": (8765, 8765),          # bridge 主服务
}


def source_version() -> str:
    """源码版本唯一真源 = bridge/api/routes_health.py 的 version 常量。"""
    p = os.path.join(_ROOT, "bridge", "api", "routes_health.py")
    try:
        with open(p, encoding="utf-8") as f:
            m = re.search(r'"version":\s*"([^"]+)"', f.read())
        return m.group(1) if m else "unknown"
    except Exception:
        return "unknown"


def check_source_vs_package() -> Dict[str, Any]:
    """★ 收口项 28：源码版本 vs 打包版本；不一致返回 match=False。"""
    src = source_version()
    pkg_path = os.path.join(_ROOT, "bin", "_internal", "data", "config",
                            "package_version.json")
    pkg = "unknown"
    try:
        with open(pkg_path, encoding="utf-8") as f:
            pkg = str(json.load(f).get("version") or "unknown")
    except Exception:
        logger.debug("suppressed exception")
    return {"source": src, "package": pkg, "match": src == pkg}


def _listener(pid: int) -> Dict[str, Any]:
    """读进程名（失败不阻塞探测）。"""
    name = ""
    try:
        import psutil
        name = psutil.Process(pid).name()
    except Exception:
        try:
            out = os.popen(f'tasklist /FI "PID eq {pid}" /FO CSV /NH').read()
            name = out.split(",")[0].strip('"') if "," in out else ""
        except Exception:
            logger.debug("suppressed exception")
    return {"pid": pid, "process": name}


def probe_service_ports() -> List[Dict[str, Any]]:
    """★ 收口项 29：端口段占用探测（连接测试，不杀进程）。"""
    import subprocess
    listeners: List[Dict[str, Any]] = []
    seen: Dict[int, Dict[str, Any]] = {}
    try:
        out = subprocess.run(["netstat", "-ano", "-p", "TCP"], capture_output=True,
                             text=True, encoding="utf-8", errors="ignore",
                             timeout=15).stdout or ""
        for line in out.splitlines():
            parts = line.split()
            if len(parts) >= 5 and parts[3] == "LISTENING":
                try:
                    port = int(parts[1].rsplit(":", 1)[1])
                    pid = int(parts[4])
                except ValueError:
                    continue
                seen[port] = pid
    except Exception:
        logger.debug("suppressed exception")
    for svc, (lo, hi) in SERVICE_PORT_RANGES.items():
        for port in range(lo, hi + 1):
            pid = seen.get(port)
            if pid:
                info = _listener(pid)
                listeners.append({"service": svc, "port": port,
                                  "pid": pid, "process": info["process"]})
    return listeners


def print_port_report() -> None:
    """启动前端口探测报告（收口项 29：启动前做端口探测）。"""
    try:
        ls = probe_service_ports()
    except Exception:
        return
    if not ls:
        print("[preflight] 服务端口 8791-8805 / 8765 全部空闲")
        return
    print(f"[preflight] 检测到 {len(ls)} 个服务端口占用（残留进程用 "
          "scripts/preflight_ports.py --kill 清理）：")
    for x in ls:
        print(f"  - {x['service']}:{x['port']}  PID={x['pid']}  {x['process']}")


# ═══════════════════════════ 单实例锁（收口项 30）═══════════════════════════

def _pid_alive(pid: int) -> bool:
    try:
        import psutil
        return psutil.pid_exists(pid)
    except Exception:
        try:
            out = os.popen(f'tasklist /FI "PID eq {pid}" /FO CSV /NH').read()
            return str(pid) in out
        except Exception:
            return True   # 探测失败宁可保守（不误抢锁）


def acquire_app_lock(name: str = "bridge") -> Optional[str]:
    """★ 收口项 30：应用级单实例锁。

    data/run/<name>.lock 写入 PID；持锁进程死亡 → 陈旧锁自动回收。
    获得锁返回锁文件路径；已被活进程持锁返回 None（调用方退出）。
    """
    run_dir = os.path.join(_ROOT, "data", "run")
    os.makedirs(run_dir, exist_ok=True)
    lock_path = os.path.join(run_dir, f"{name}.lock")
    me = os.getpid()
    for _ in range(2):
        try:
            with open(lock_path, "x", encoding="utf-8") as f:
                f.write(str(me))
            return lock_path
        except FileExistsError:
            try:
                with open(lock_path, encoding="utf-8") as f:
                    holder = int((f.read() or "0").strip() or 0)
            except Exception:
                holder = 0
            if holder == me:
                return lock_path            # 同进程重复获取（幂等）
            if holder and _pid_alive(holder):
                print(f"[single-instance] {name} 已由 PID {holder} 运行，"
                      "本次启动退出（避免双进程抢端口）")
                return None
            # 陈旧锁：持锁进程已死 → 回收重试
            try:
                os.remove(lock_path)
            except OSError:
                return None
            time.sleep(0.05)
    return None


def release_app_lock(name: str = "bridge") -> None:
    try:
        lock_path = os.path.join(_ROOT, "data", "run", f"{name}.lock")
        with open(lock_path, encoding="utf-8") as f:
            holder = int((f.read() or "0").strip() or 0)
        if holder == os.getpid():
            os.remove(lock_path)
    except Exception:
        logger.debug("suppressed exception")
