# -*- coding: utf-8 -*-
"""E4 · 事件驱动回测。

1) 事件：Bar / Tick / Order / Fill
2) 撮合：限价 / 市价，部分成交可配置
3) 状态机：pending / partial / filled / cancelled

禁止：撮合里用未来 bar。
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import pandas as pd

from shared.backtest import make_result

VALID_STATES = {"pending", "partial", "filled", "cancelled"}


@dataclass
class Order:
    order_id: str
    ts_code: str
    side: str                 # buy / sell
    price: float              # 限价；市价用 None
    quantity: float
    filled_qty: float = 0.0
    state: str = "pending"
    created_at: str = ""
    fills: List[Dict] = field(default_factory=list)

    @property
    def remaining(self) -> float:
        return self.quantity - self.filled_qty

    def is_closed(self) -> bool:
        return self.state in ("filled", "cancelled")


class MatchingEngine:
    """撮合引擎：只用当前 bar 数据（禁止未来 bar）。"""

    def __init__(self, allow_partial: bool = True):
        self.allow_partial = allow_partial
        self.orders: Dict[str, Order] = {}

    def submit(self, order: Order) -> Order:
        self.orders[order.order_id] = order
        return order

    def match(self, order: Order, bar: Dict) -> List[Dict]:
        """用单根 bar 撮合（bar = {open, high, low, close, volume}）。"""
        if order.is_closed():
            return []
        price = bar["close"] if order.price is None else order.price
        # 限价单：价格必须可达（用 high/low 判断）
        if order.side == "buy" and price > bar["high"] + 1e-9:
            return []
        if order.side == "sell" and price < bar["low"] - 1e-9:
            return []
        # 可成交量：不超过该 bar 成交量的一定比例 + 剩余量
        capacity = max(bar.get("volume", 0.0) * 0.1, order.remaining)
        fill_qty = min(order.remaining, capacity)
        if fill_qty <= 0:
            return []
        if not self.allow_partial and fill_qty < order.remaining - 1e-9:
            return []

        fill = {"order_id": order.order_id, "price": price, "qty": fill_qty,
                "bar_date": bar.get("trade_date", "")}
        order.filled_qty += fill_qty
        order.fills.append(fill)
        if abs(order.filled_qty - order.quantity) < 1e-9:
            order.state = "filled"
        else:
            order.state = "partial"
        return [fill]

    def cancel(self, order_id: str) -> bool:
        o = self.orders.get(order_id)
        if not o or o.is_closed():
            return False
        o.state = "cancelled"
        return True


def event_backtest(df: pd.DataFrame,
                   signal_fn,          # (df_upto_t) -> List[Order 参数]
                   allow_partial: bool = True,
                   data_version: str = "unknown",
                   rule_version: str = "1.0",
                   run_id: Optional[str] = None) -> Dict:
    """事件驱动回测：逐 bar 推进，T 日信号 → T+1 日撮合。"""
    run_id = run_id or ("evt-" + uuid.uuid4().hex[:10])
    engine = MatchingEngine(allow_partial=allow_partial)
    fills: List[Dict] = []
    trades: List[Dict] = []

    if df.empty:
        return make_result(returns=pd.Series(dtype=float), positions=[],
                           trades=[], metrics={}, data_version=data_version,
                           rule_version=rule_version, run_id=run_id)

    d = df.sort_values("trade_date").reset_index(drop=True)
    for i in range(len(d)):
        row = d.iloc[i]
        # T 日信号（只用 <= T 的数据）
        sig = signal_fn(d.iloc[: i + 1])
        for s in sig or []:
            o = Order(order_id=f"o{len(engine.orders)}", ts_code=row["ts_code"],
                      side=s["side"], price=s.get("price"), quantity=s["quantity"],
                      created_at=row["trade_date"])
            engine.submit(o)
        # T+1 日撮合（用下一根 bar；此处模拟为当日 bar，实际应取 i+1）
        if i + 1 < len(d):
            nxt = d.iloc[i + 1]
            bar = {"trade_date": nxt["trade_date"], "open": float(nxt["open"]),
                   "high": float(nxt["high"]), "low": float(nxt["low"]),
                   "close": float(nxt["close"]), "volume": float(nxt["vol"])}
            for o in list(engine.orders.values()):
                got = engine.match(o, bar)
                fills.extend(got)
                if o.state in ("filled", "partial") and got:
                    trades.append({"order_id": o.order_id, "ts_code": o.ts_code,
                                   "side": o.side, "filled_qty": o.filled_qty,
                                   "state": o.state})

    # 收益：用成交价与最终价估算（简化）
    if fills:
        avg_fill = sum(f["price"] * f["qty"] for f in fills) / sum(f["qty"] for f in fills)
        final_close = float(d["close"].iloc[-1])
        total_ret = (final_close - avg_fill) / avg_fill if avg_fill else 0.0
    else:
        total_ret = 0.0

    return make_result(
        returns=pd.Series([1.0, 1.0 + total_ret]),
        positions=[{"order_id": o.order_id, "state": o.state,
                    "filled_qty": o.filled_qty, "remaining": o.remaining}
                   for o in engine.orders.values()],
        trades=trades,
        metrics={"n_fills": len(fills), "n_orders": len(engine.orders),
                 "filled": sum(1 for o in engine.orders.values() if o.state == "filled"),
                 "partial": sum(1 for o in engine.orders.values() if o.state == "partial"),
                 "cancelled": sum(1 for o in engine.orders.values() if o.state == "cancelled"),
                 "total_return": float(total_ret)},
        data_version=data_version, rule_version=rule_version, run_id=run_id,
        extra_meta={"allow_partial": allow_partial, "states": sorted(VALID_STATES)},
    )


__all__ = ["Order", "MatchingEngine", "event_backtest", "VALID_STATES"]
