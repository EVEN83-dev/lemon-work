# -*- coding: utf-8 -*-
"""E3 · 向量化回测。

1) 信号 shift(1) 后执行（T 日信号 → T+1 日成交）
2) 支持等权 / 市值加权 / 自定义权重
3) 调仓频率 daily / weekly / monthly

禁止：同日信号同日成交。
"""
from __future__ import annotations

import uuid
from typing import Callable, Dict, List, Optional

import numpy as np
import pandas as pd

from shared.backtest import make_result, ensure_dirs


def _resample_mask(dates: pd.DatetimeIndex, freq: str) -> np.ndarray:
    """生成调仓掩码：freq=daily 全部；weekly 每周首个交易日；monthly 每月首个。"""
    if freq == "daily":
        return np.ones(len(dates), dtype=bool)
    if freq == "weekly":
        key = dates.to_period("W")
    elif freq == "monthly":
        key = dates.to_period("M")
    else:
        raise ValueError(f"不支持的调仓频率: {freq}")
    return np.array(~key.duplicated())


def vector_backtest(
    df: pd.DataFrame,
    signal_fn: Callable[[pd.DataFrame], pd.Series],
    weight: str = "equal",
    rebal_freq: str = "daily",
    init_cash: float = 1_000_000.0,
    cost_fn: Optional[Callable[[float, float], float]] = None,
    data_version: str = "unknown",
    rule_version: str = "1.0",
    run_id: Optional[str] = None,
) -> Dict:
    """向量化回测主入口。

    signal_fn(df) -> 信号序列（正=买入，负=卖出，0=不动）
    信号 T 日产生 → T+1 日执行（shift(1)）。
    """
    run_id = run_id or ("vbt-" + uuid.uuid4().hex[:10])
    if df.empty:
        return make_result(returns=pd.Series(dtype=float), positions=[], trades=[],
                           metrics={}, data_version=data_version,
                           rule_version=rule_version, run_id=run_id)

    d = df.sort_values("trade_date").reset_index(drop=True).copy()
    raw_signal = signal_fn(d)
    # ★ 核心防未来函数：信号 shift(1) 后执行
    signal = raw_signal.shift(1).fillna(0.0)
    d["signal"] = signal.values

    # 权重
    if weight == "equal":
        w = signal.abs()
        w = w / w.replace(0, np.nan).max() if w.abs().max() > 0 else w
    elif weight == "custom" and "custom_weight" in d.columns:
        w = d["custom_weight"].abs() * signal.abs()
    else:
        raise ValueError(f"不支持的权重类型: {weight}")

    # 调仓频率
    dates = pd.DatetimeIndex(pd.to_datetime(d["trade_date"].astype(str)))
    mask = _resample_mask(dates, rebal_freq)
    w = w.where(mask, 0.0)
    d["weight"] = w.values

    # 组合收益 = 权重 × 次日收益
    ret = d["close"].pct_change().shift(-1).fillna(0.0)
    port_ret = (d["weight"].fillna(0.0) * ret).fillna(0.0)

    # 成本
    turnover = d["weight"].diff().abs().fillna(d["weight"].abs())
    if cost_fn is not None:
        cost = turnover.apply(lambda t: cost_fn(t, init_cash))
        port_ret = port_ret - cost
    else:
        cost = pd.Series(0.0, index=d.index)

    nav = (1.0 + port_ret).cumprod()
    positions = d.loc[d["weight"] > 0, ["trade_date", "ts_code", "weight"]].to_dict("records")
    trades = d.loc[turnover > 0, ["trade_date", "weight"]].to_dict("records")

    return make_result(
        returns=nav, positions=positions, trades=trades,
        metrics={"final_nav": float(nav.iloc[-1]) if len(nav) else 1.0,
                 "total_return": float(nav.iloc[-1] - 1.0) if len(nav) else 0.0,
                 "n_rebalance": int(mask.sum())},
        data_version=data_version, rule_version=rule_version, run_id=run_id,
        extra_meta={"weight": weight, "rebal_freq": rebal_freq,
                    "shift_applied": True},
    )


__all__ = ["vector_backtest"]
