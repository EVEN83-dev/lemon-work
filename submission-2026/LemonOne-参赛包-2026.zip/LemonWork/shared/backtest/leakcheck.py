# -*- coding: utf-8 -*-
"""E7 · 防未来函数检查器。

1) 扫描因子/信号是否引用 t 之后的数据
2) 检查财报是否按公告日
3) 检查 shift 是否存在

禁止：只给警告不阻断（返回结构含 blocked 标志，由调用方阻断）。
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

import pandas as pd


def check_shift_applied(signal_fn_src: str) -> Dict[str, Any]:
    """检查源码里是否出现 shift(1)。"""
    ok = bool(re.search(r"\.shift\(\s*1\s*\)", signal_fn_src))
    return {"check": "shift_applied", "ok": ok,
            "detail": {"has_shift": ok}}


def check_factor_lookahead(factor_fn_src: str) -> Dict[str, Any]:
    """检查因子源码是否有未来引用（负 shift / 未来切片）。"""
    bad = []
    if re.search(r"\.shift\(\s*-\d+", factor_fn_src):
        bad.append("负 shift（引用未来）")
    if re.search(r"\.iloc\[.*\+.*\]", factor_fn_src) and "shift" not in factor_fn_src:
        bad.append("疑似正偏移切片")
    return {"check": "factor_lookahead", "ok": not bad, "detail": {"bad": bad}}


def check_finance_pit(finance: pd.DataFrame, as_of: Optional[str]) -> Dict[str, Any]:
    """检查财报是否按公告日（available_at / ann_date）。"""
    if "available_at" not in finance.columns and "ann_date" not in finance.columns:
        return {"check": "finance_pit", "ok": False,
                "detail": {"reason": "缺 ann_date/available_at"}}
    col = "available_at" if "available_at" in finance.columns else "ann_date"
    if as_of:
        a = str(as_of).replace("-", "")[:8]
        leak = int((finance[col].astype(str).str.replace(r"[-/]", "", regex=True)
                    .str[:8] > a).sum())
        return {"check": "finance_pit", "ok": leak == 0,
                "detail": {"leak_rows": leak, "as_of": a}}
    return {"check": "finance_pit", "ok": True,
            "detail": {"note": "未提供 as_of，跳过泄露检查"}}


def check_signal_forward(signal: pd.Series, close: pd.Series,
                         future_close: Optional[pd.Series] = None) -> Dict[str, Any]:
    """实证检查：信号是否与未来收益异常相关（疑似泄露）。"""
    if future_close is None or len(signal) < 3:
        return {"check": "signal_forward", "ok": True,
                "detail": {"note": "无未来价，跳过"}}
    fut_ret = future_close.shift(-1) / close - 1.0
    corr = pd.Series(signal.values).corr(pd.Series(fut_ret.values))
    # 高度相关（>0.5）视为疑似泄露
    ok = not (corr is not None and abs(float(corr)) > 0.5)
    return {"check": "signal_forward", "ok": ok,
            "detail": {"corr_with_future": None if corr is None else float(corr)}}


def run_all(signal_fn_src: str = "", factor_fn_src: str = "",
            finance: Optional[pd.DataFrame] = None,
            as_of: Optional[str] = None,
            signal: Optional[pd.Series] = None,
            close: Optional[pd.Series] = None,
            future_close: Optional[pd.Series] = None) -> Dict[str, Any]:
    """跑全部泄露检查，返回 {blocked, results}。"""
    results = []
    if signal_fn_src:
        results.append(check_shift_applied(signal_fn_src))
    if factor_fn_src:
        results.append(check_factor_lookahead(factor_fn_src))
    if finance is not None:
        results.append(check_finance_pit(finance, as_of))
    if signal is not None and close is not None:
        results.append(check_signal_forward(signal, close, future_close))
    blocked = any(not r["ok"] for r in results)
    return {"blocked": blocked, "results": results,
            "violations": [r["check"] for r in results if not r["ok"]]}


__all__ = ["check_shift_applied", "check_factor_lookahead",
           "check_finance_pit", "check_signal_forward", "run_all"]
