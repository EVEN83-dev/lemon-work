# -*- coding: utf-8 -*-
"""★ 2026-11-11 升级 B2 · 参数化前视偏差（Parametric Look-Ahead Bias）联合检测

背景（arXiv 2026.5，Edinburgh）：LLM 在训练时"见过"历史行情，用它生成的因子/策略
可能只是把记忆中的走势背出来；这种泄漏**存在于模型参数里**，传统数据管道审计
（PIT / ann_date / shift 检查）完全查不出来。

本模块提出并实现一个三层联合检测（这是本轮的算法创新点之一）：

  L1 语义层  —— 扫描因子表达式/描述里的"未来字段"与"历史记忆常量"信号
                 （next_close / 次日 / 具体日期 / 点位常量），命中高危即阻断
  L2 双期层  —— 以"模型知识截止日"为界把样本切成前后两段分别算 Rank IC；
                 若截止日之前的 IC 显著高于之后，说明因子拟合的是模型记忆而非规律
  L3 对照层  —— 打乱前瞻收益作为对照组；真 IC 应显著高于打乱 IC，
                 否则该 IC 只是噪声/过拟合，不构成"有效因子"证据

并与既有 shared/backtest/leakcheck.py（代码级 shift/PIT）串联：
  leakcheck 查"代码有没有偷看"，本模块查"模型有没有背过"。

零第三方依赖；所有函数为纯函数、可离线自测、不抛异常中断回测。
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

try:
    from shared.backtest.factor_eval import rank_ic
except ImportError:  # 允许以脚本方式直接运行
    from factor_eval import rank_ic

# ── L1 语义信号 ─────────────────────────────────────────────────────
FUTURE_TOKENS = (
    r"next_close|next_ret|future_|fwd_|forward_ret|tomorrow|t\+1_close",
    r"次日|明日|未来|收盘后|事后|公布后|已知|事后收益|下期|下一日|提前知道",
)
MEMORY_TOKENS = (
    r"\b20\d{2}[-/]?\d{2}[-/]?\d{2}\b",      # 具体历史日期
    r"20\d{2}\s*年",                          # 中文年份
    r"(?:\d{4,5})\s*(?:点|点位)",              # 指数点位常量
    r"\b(?:19|20)\d{2}\b",                    # 裸年份常量
)
MARKET_WORDS = ("指数", "股价", "收盘", "行情", "涨停", "大盘", "price", "close", "index")


def semantic_scan(expression: str, description: str = "") -> Dict[str, Any]:
    """L1：语义级信号扫描。返回 {suspicious, signals, severity}。"""
    text = (str(expression or "") + "\n" + str(description or ""))
    signals: List[str] = []
    for pat in FUTURE_TOKENS:
        if re.search(pat, text, re.I):
            signals.append("future_field:" + pat)
    mem_hits = []
    for pat in MEMORY_TOKENS:
        mem_hits.extend(m.group(0) for m in re.finditer(pat, text, re.I))
    if mem_hits:
        has_market = any(w in text.lower() for w in MARKET_WORDS)
        signals.append("memory_constant:" + ",".join(mem_hits[:5])
                       + ("|with_market" if has_market else ""))
    severity = "high" if any(s.startswith("future_field") for s in signals) else (
        "medium" if signals else "none")
    return {"suspicious": bool(signals), "signals": signals, "severity": severity}


def _ic_on(factor: pd.Series, forward: pd.Series, dates: pd.Series,
           split: str, before: bool) -> float:
    d = pd.Series(dates).astype(str).reset_index(drop=True)
    f = pd.Series(factor).astype(float).reset_index(drop=True)
    r = pd.Series(forward).astype(float).reset_index(drop=True)
    s = str(split).replace("-", "")
    mask = d.str.replace(r"[-/]", "", regex=True).str[:8] < s if before else \
        d.str.replace(r"[-/]", "", regex=True).str[:8] >= s
    seg_f, seg_r = f[mask], r[mask]
    if len(seg_f) < 5:
        return float("nan")
    return rank_ic(seg_f, seg_r)


def two_period_ic_gap(factor: pd.Series, forward_return: pd.Series,
                      dates: pd.Series, knowledge_cutoff: str = "2024-01-01",
                      gap_threshold: float = 0.30) -> Dict[str, Any]:
    """L2：知识截止日前后 IC 落差。前段远高于后段 = 疑似记忆泄漏。"""
    ic_before = _ic_on(factor, forward_return, dates, knowledge_cutoff, True)
    ic_after = _ic_on(factor, forward_return, dates, knowledge_cutoff, False)
    if np.isnan(ic_before) or np.isnan(ic_after):
        return {"suspicious": False, "ic_before": None, "ic_after": None,
                "gap": None, "detail": "样本不足，跳过双期检验"}
    gap = float(ic_before - ic_after)
    suspicious = bool(gap > gap_threshold and abs(ic_before) > 0.15)
    return {"suspicious": suspicious, "ic_before": round(float(ic_before), 4),
            "ic_after": round(float(ic_after), 4), "gap": round(gap, 4),
            "detail": "截止日前 IC 显著更高，疑似复述训练记忆" if suspicious
                      else "双期 IC 无异常落差"}


def shuffled_control(factor: pd.Series, forward_return: pd.Series,
                     seed: int = 7, edge_threshold: float = 0.03) -> Dict[str, Any]:
    """L3：打乱前瞻收益对照组。真 IC 未显著高于打乱 IC → 因子没有真实预测力。"""
    f = pd.Series(factor).astype(float).replace([np.inf, -np.inf], np.nan).dropna()
    r = pd.Series(forward_return).astype(float).reindex(f.index).replace(
        [np.inf, -np.inf], np.nan).dropna()
    common = f.index.intersection(r.index)
    f, r = f.loc[common], r.loc[common]
    if len(f) < 5:
        return {"suspicious": False, "true_ic": 0.0, "shuffled_ic": 0.0,
                "detail": "样本不足，跳过对照"}
    true_ic = rank_ic(f, r)
    rng = np.random.RandomState(seed)
    shuffled_ic = float(np.mean([
        rank_ic(f, pd.Series(rng.permutation(r.values), index=r.index))
        for _ in range(5)]))
    edge = float(true_ic - shuffled_ic)
    return {"suspicious": bool(edge < edge_threshold),
            "true_ic": round(true_ic, 4), "shuffled_ic": round(shuffled_ic, 4),
            "edge": round(edge, 4),
            "detail": "真 IC 未显著优于打乱对照，因子预测力存疑"
                      if edge < edge_threshold else "对照检验通过"}


def run_all(*, expression: str = "", description: str = "",
            factor: Optional[pd.Series] = None,
            forward_return: Optional[pd.Series] = None,
            dates: Optional[pd.Series] = None,
            knowledge_cutoff: str = "2024-01-01") -> Dict[str, Any]:
    """三层联合判定。blocked=True 时调用方应拒绝把该因子投入回测/实盘。"""
    checks: Dict[str, Any] = {"L1_semantic": semantic_scan(expression, description)}
    if factor is not None and forward_return is not None:
        checks["L3_control"] = shuffled_control(factor, forward_return)
        if dates is not None:
            checks["L2_two_period"] = two_period_ic_gap(
                factor, forward_return, dates, knowledge_cutoff)
    high_risk = checks["L1_semantic"]["severity"] == "high"
    period_risk = checks.get("L2_two_period", {}).get("suspicious", False)
    return {
        "blocked": bool(high_risk or period_risk),
        "checks": checks,
        "violations": (["L1_future_field"] if high_risk else [])
                     + (["L2_memory_gap"] if period_risk else []),
        "note": "与 leakcheck.run_all（代码级）串联使用；本模块查参数化/语义级泄漏",
    }


# ── 离线自测 ───────────────────────────────────────────────────────
if __name__ == "__main__":
    n = 120
    f = pd.Series(np.arange(n, dtype=float))
    r = pd.Series(np.arange(n, dtype=float) * 0.01)
    rng = np.random.RandomState(1)
    dates = pd.Series(pd.date_range("2023-01-01", periods=n).strftime("%Y-%m-%d"))
    # 记忆型因子：截止日前完美单调，之后纯噪声
    f_mem = pd.Series(np.where(np.arange(n) < 60,
                               np.arange(n, dtype=float), rng.randn(n)))
    r_mem = pd.Series(np.where(np.arange(n) < 60,
                               np.arange(n, dtype=float) * 0.01, rng.randn(n) * 0.01))
    tests = [
        ("未来字段高危拦截", semantic_scan("return df['next_close']", "")["severity"] == "high"),
        ("中文未来词拦截", semantic_scan("", "使用次日收盘价计算")["severity"] == "high"),
        ("历史日期常量标记", semantic_scan("if date == 20200506 close", "大盘")["suspicious"]),
        ("干净表达式通过", not semantic_scan("df['close'].pct_change(5)", "动量因子")["suspicious"]),
        ("双期落差检出记忆因子", two_period_ic_gap(f_mem, r_mem, dates, "2023-03-01")["suspicious"]),
        ("干净因子双期不误报", not two_period_ic_gap(f, r, dates, "2023-03-01")["suspicious"]),
        ("打乱对照：真因子有预测力", not shuffled_control(f, r)["suspicious"]),
        ("打乱对照：随机因子 edge 更低",
         shuffled_control(pd.Series(rng.randn(n)), r)["edge"]
         < shuffled_control(f, r)["edge"]),
        ("联合判定 blocked", run_all(expression="df['future_ret']",
                                     factor=f, forward_return=r, dates=dates,
                                     knowledge_cutoff="2023-03-01")["blocked"]),
        ("联合判定干净通过", not run_all(expression="df['close'].pct_change(5)",
                                    factor=f, forward_return=r, dates=dates,
                                    knowledge_cutoff="2023-03-01")["blocked"]),
    ]
    for name, ok in tests:
        print(("PASS" if ok else "FAIL"), name)
    print("ALL_PASS" if all(o for _, o in tests) else "HAS_FAIL")
