# -*- coding: utf-8 -*-
"""E9 · 报告卡。

1) 卡型 backtest_card：净值曲线、回撤、指标表、分年收益
2) 导出 HTML（断网可读）

禁止：报告里省略成本与数据版本。
"""
from __future__ import annotations

import html
import json
import os
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from shared.backtest import ensure_dirs


def build_card(result: Dict[str, Any]) -> Dict[str, Any]:
    """从统一结果结构构造 backtest_card。"""
    meta = result.get("meta", {})
    metrics = result.get("metrics", {})
    nav = result.get("returns")
    if nav is None:
        nav = pd.Series(dtype=float)

    drawdown = pd.Series(dtype=float)
    if len(nav):
        roll_max = nav.cummax()
        drawdown = (nav - roll_max) / roll_max

    return {
        "kind": "backtest_card",
        "title": "回测报告",
        "nav": [None if pd.isna(v) else float(v) for v in nav.tolist()],
        "dates": ([str(d) for d in nav.index.tolist()] if hasattr(nav, "index") else []),
        "drawdown": [None if pd.isna(v) else float(v) for v in drawdown.tolist()],
        "metrics": {k: v for k, v in metrics.items()
                    if isinstance(v, (int, float, str))},
        "yearly": metrics.get("yearly", []),
        "cost": metrics.get("cost", {}),
        "data_version": meta.get("data_version", "unknown"),
        "rule_version": meta.get("rule_version", "1.0"),
        "code_commit": meta.get("code_commit", "unknown"),
        "run_id": meta.get("run_id", "unknown"),
    }


def export_html(card: Dict[str, Any], out_path: Optional[str] = None) -> str:
    """导出单文件 HTML（内联样式与数据，断网可读）。"""
    esc = lambda s: html.escape(str(s if s is not None else ""))
    nav = card.get("nav", [])
    dd = card.get("drawdown", [])
    metrics = card.get("metrics", {})
    yearly = card.get("yearly", [])

    # 净值 sparkline（纯 CSS 柱）
    bars = ""
    if nav:
        valid = [v for v in nav if v is not None]
        lo, hi = (min(valid), max(valid)) if valid else (0, 1)
        span = (hi - lo) or 1.0
        for v in nav:
            if v is None:
                continue
            h = int((v - lo) / span * 100)
            bars += f'<span style="display:inline-block;width:2px;height:{max(h,1)}px;' \
                     f'background:#ff6900;margin-right:1px;vertical-align:bottom;"></span>'

    metric_rows = "".join(
        f"<tr><td>{esc(k)}</td><td>{esc(v)}</td></tr>"
        for k, v in metrics.items() if isinstance(v, (int, float, str)))

    yearly_rows = "".join(
        f"<tr><td>{esc(r.get('year'))}</td><td>{esc(round(float(r.get('return', 0)) * 100, 2))}%</td></tr>"
        for r in yearly)

    doc = f"""<!DOCTYPE html>
<html lang="zh"><head><meta charset="utf-8"><title>回测报告 {esc(card.get('run_id'))}</title>
<style>body{{font-family:-apple-system,Consolas,monospace;max-width:820px;margin:24px auto;
padding:0 16px;color:#e8e8ee;background:#14151c}}h1{{font-size:18px}}table{{border-collapse:collapse;
width:100%;margin:12px 0;font-size:13px}}th,td{{border:1px solid rgba(255,255,255,.12);
padding:6px 8px;text-align:left}}th{{background:rgba(255,255,255,.06)}}
.meta{{font-size:12px;opacity:.75;margin:8px 0}}.nav{{height:120px;display:flex;align-items:flex-end;
border-bottom:1px solid rgba(255,255,255,.12);padding:8px 0}}</style></head>
<body>
<h1>回测报告 · {esc(card.get('run_id'))}</h1>
<div class="meta">
  数据版本：{esc(card.get('data_version'))} ·
  规则版本：{esc(card.get('rule_version'))} ·
  代码 commit：{esc(card.get('code_commit'))}
</div>
<h2>净值曲线</h2>
<div class="nav">{bars}</div>
<h2>指标</h2>
<table><thead><tr><th>指标</th><th>值</th></tr></thead><tbody>{metric_rows}</tbody></table>
<h2>分年度收益</h2>
<table><thead><tr><th>年份</th><th>收益</th></tr></thead><tbody>{yearly_rows}</tbody></table>
<h2>成本</h2>
<div class="meta">{esc(json.dumps(card.get('cost', {}), ensure_ascii=False))}</div>
</body></html>"""

    if out_path:
        os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(doc)
    return doc


__all__ = ["build_card", "export_html"]
