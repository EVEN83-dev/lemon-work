# -*- coding: utf-8 -*-
"""★ 2026-11-11 升级 B · 因子有效性评估闭环

对标 Qlib / RD-Agent(Q) / 开源金工 Eval Agent 的"因子回测评价"层：
因子算完不等于有效，必须经过 Rank IC、ICIR、多空收益、换手率，
以及**剔除行业/市值/动量等控制变量后的增量 IC** 才能决定保留与否。

本模块补齐 shared/backtest/metrics.py（只评策略净值）缺失的这一层。

依赖：仅 numpy/pandas（仓内已有，factor.py 已用）。零第三方新增。
所有函数对 NaN / 样本不足 / 常数序列返回 0.0 而不抛异常（评估层不许打断回测）。
"""
from __future__ import annotations

from typing import Dict, Optional, Sequence

import numpy as np
import pandas as pd


def _clean(factor: pd.Series, forward: pd.Series) -> pd.DataFrame:
    df = pd.DataFrame({"f": pd.Series(factor).astype(float),
                       "r": pd.Series(forward).astype(float)}).replace(
                           [np.inf, -np.inf], np.nan).dropna()
    return df


def rank_ic(factor: pd.Series, forward_return: pd.Series) -> float:
    """Spearman 秩相关（对因子值与前瞻收益）。样本<3 或常数序列返回 0。"""
    df = _clean(factor, forward_return)
    if len(df) < 3 or df["f"].nunique() < 2 or df["r"].nunique() < 2:
        return 0.0
    return float(df["f"].rank().corr(df["r"].rank()))


def ic_series(factor: pd.Series, forward_return: pd.Series,
              dates: Optional[pd.Series] = None) -> pd.Series:
    """按日期分组的横截面 IC 序列（无 dates 时按 20 期滚动窗口）。"""
    df = _clean(factor, forward_return)
    if len(df) < 3:
        return pd.Series(dtype=float)
    if dates is not None:
        d = pd.Series(dates).reindex(df.index).astype(str)
        out = {}
        for key, grp in df.groupby(d.values):
            if len(grp) >= 3 and grp["f"].nunique() >= 2 and grp["r"].nunique() >= 2:
                out[key] = float(grp["f"].rank().corr(grp["r"].rank()))
        return pd.Series(out, dtype=float)
    w = 20
    vals = [rank_ic(df["f"].iloc[max(0, i - w):i],
                    df["r"].iloc[max(0, i - w):i])
            for i in range(w, len(df) + 1)]
    return pd.Series(vals, dtype=float).replace([np.inf, -np.inf], np.nan).dropna()


def icir(factor: pd.Series, forward_return: pd.Series,
         dates: Optional[pd.Series] = None) -> float:
    """IC 信息比率 = IC 均值 / IC 标准差（衡量稳定性）。

    ★ 2026-11-11 修复：IC 序列完全恒定（最稳定）时 std=0，
      旧实现返回 0 会把完美因子误判为"不稳定"。此时按符号返回
      饱和值 ±10.0 表示极稳定；均值≈0 仍返回 0。
    """
    s = ic_series(factor, forward_return, dates)
    if len(s) < 2:
        return 0.0
    sd = float(s.std(ddof=1))
    mean = float(s.mean())
    if sd < 1e-9:
        return 10.0 if abs(mean) > 1e-9 else 0.0
    return float(mean / sd)


def long_short_return(factor: pd.Series, forward_return: pd.Series,
                      q: int = 5) -> float:
    """分 q 组，多头(最高组) - 空头(最低组) 的平均前瞻收益。"""
    df = _clean(factor, forward_return)
    if len(df) < q * 2:
        return 0.0
    try:
        grp = pd.qcut(df["f"].rank(method="first"), q, labels=False, duplicates="drop")
    except ValueError:
        return 0.0
    means = df.groupby(grp)["r"].mean()
    if len(means) < 2:
        return 0.0
    return float(means.iloc[-1] - means.iloc[0])


def incremental_ic(factor: pd.Series, forward_return: pd.Series,
                   controls: Optional[pd.DataFrame] = None) -> float:
    """★ 增量 IC：把因子对控制变量（行业/市值/动量/波动...）做 OLS 残差化，
    再与前瞻收益算 Rank IC。

    对标"剔除五因子影响后仍稳定 Rank IC"的检验：若因子只是复刻已知风格，
    残差化后 IC 会显著下降。这是判断"真增量信息"而非"旧因子换皮"的关键。
    """
    base = rank_ic(factor, forward_return)
    if controls is None or len(controls) == 0:
        return base
    df = _clean(factor, forward_return)
    X = pd.DataFrame(controls).astype(float).reindex(df.index)
    X = X.replace([np.inf, -np.inf], np.nan).fillna(0.0)
    if X.empty or len(X.columns) == 0:
        return base
    # 常数项 + 控制变量；最小二乘残差
    A = np.column_stack([np.ones(len(X)), X.values])
    y = df["f"].values
    try:
        coef, *_ = np.linalg.lstsq(A, y, rcond=None)
        resid = pd.Series(y - A @ coef, index=df.index)
    except np.linalg.LinAlgError:
        return base
    return rank_ic(resid, df["r"])


def factor_turnover(factor: pd.Series, dates: Optional[pd.Series] = None,
                    q: int = 5) -> float:
    """分组换手：相邻截面因子分位组变化的比例（0-1）。"""
    df = pd.DataFrame({"f": pd.Series(factor).astype(float)}).replace(
        [np.inf, -np.inf], np.nan).dropna()
    if len(df) < q * 2:
        return 0.0
    try:
        grp = pd.qcut(df["f"].rank(method="first"), q, labels=False, duplicates="drop")
    except ValueError:
        return 0.0
    return float((pd.Series(grp).diff().abs() > 0).mean())


def evaluate_factor(factor: pd.Series, forward_return: pd.Series,
                    *, controls: Optional[pd.DataFrame] = None,
                    dates: Optional[pd.Series] = None,
                    q: int = 5, ic_threshold: float = 0.02) -> Dict:
    """因子评估总入口 → RD-Agent(Q) 式"保留/拒绝"决策所需字段。"""
    ic = rank_ic(factor, forward_return)
    inc = incremental_ic(factor, forward_return, controls)
    out = {
        "rank_ic": round(ic, 4),
        "icir": round(icir(factor, forward_return, dates), 4),
        "ls_return": round(long_short_return(factor, forward_return, q), 6),
        "incremental_ic": round(inc, 4),
        "turnover": round(factor_turnover(factor, dates, q), 4),
        "n_obs": int(len(_clean(factor, forward_return))),
        "ic_threshold": ic_threshold,
    }
    # 保留判据：IC 达标 + 剔除风格后仍有增量 + 多空方向一致
    out["keep"] = bool(abs(ic) >= ic_threshold
                       and abs(inc) >= ic_threshold * 0.5
                       and np.sign(out["ls_return"]) == np.sign(ic))
    out["reason"] = ("保留：IC 达标且具备增量信息" if out["keep"]
                     else "拒绝：IC 不足 / 增量信息缺失 / 多空方向不一致")
    return out


# ── 离线自测 ───────────────────────────────────────────────────────
if __name__ == "__main__":
    n = 200
    idx = pd.RangeIndex(n)
    f_perfect = pd.Series(np.arange(n, dtype=float), index=idx)
    r_perfect = pd.Series(np.arange(n, dtype=float) * 0.01, index=idx)
    rng = np.random.RandomState(42)
    f_rand = pd.Series(rng.randn(n), index=idx)
    r_rand = pd.Series(rng.randn(n), index=idx)
    # 伪因子 = 控制变量的线性组合 + 少量噪声（残差化后 IC 应塌掉）
    ctrl = pd.DataFrame({"style": np.arange(n, dtype=float)}, index=idx)
    f_style = pd.Series(np.arange(n, dtype=float) * 0.5 + rng.randn(n) * 0.01, index=idx)
    tests = [
        ("完美单调 Rank IC≈1", abs(rank_ic(f_perfect, r_perfect) - 1.0) < 1e-6),
        ("随机因子 Rank IC≈0", abs(rank_ic(f_rand, r_rand)) < 0.2),
        ("多空收益方向正确", long_short_return(f_perfect, r_perfect) > 0),
        ("增量 IC 剔风格后下降", abs(incremental_ic(f_style, r_perfect, ctrl))
         < abs(rank_ic(f_style, r_perfect))),
        ("评估决策 keep=True", evaluate_factor(f_perfect, r_perfect)["keep"] is True),
        ("评估决策随机因子 keep=False", evaluate_factor(f_rand, r_rand,
                                                  ic_threshold=0.3)["keep"] is False),
        ("样本不足不抛异常", rank_ic(pd.Series([1.0]), pd.Series([2.0])) == 0.0),
        ("NaN 安全", np.isfinite(rank_ic(pd.Series([1.0, np.nan, 3.0]),
                                        pd.Series([1.0, 2.0, np.nan])))),
    ]
    for name, ok in tests:
        print(("PASS" if ok else "FAIL"), name)
    print("ALL_PASS" if all(o for _, o in tests) else "HAS_FAIL")
