# -*- coding: utf-8 -*-
"""★ W8: 回测技能（backtest_run）

- 读取：shared.backtest.data.read_parquet_range
- 单标的：按 ts_code 过滤；多标的：先等权合成一条净值序列
- 信号：shared.backtest.factor.compute
- 回测：shared.backtest.vector.vector_backtest
- 指标：shared.backtest.metrics.compute_all
- 报告：shared.backtest.report.build_card → emit backtest_card
- meta 必须含 data_version/rule_version/code_commit/run_id
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import json
import os
import subprocess
import uuid
from typing import Any, Dict, Optional

import pandas as pd

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _read(data_path: str, ts_code: str = "", start: str = "", end: str = "") -> pd.DataFrame:
    try:
        from shared.backtest.data import read_parquet_range
    except ImportError:
        import sys
        sys.path.insert(0, _ROOT)
        from shared.backtest.data import read_parquet_range
    syms = [ts_code] if ts_code else None
    return read_parquet_range(data_path, start=start, end=end, symbols=syms)


def _code_commit() -> str:
    try:
        r = subprocess.run(["git", "rev-parse", "--short", "HEAD"],
                           cwd=_ROOT, capture_output=True, text=True, timeout=5)
        return r.stdout.strip() or "unknown"
    except Exception:
        return "unknown"


def run_backtest(data_path: str, ts_code: str = "", factor_id: str = "mom",
                 factor_params: Optional[Dict] = None,
                 rebal_freq: str = "weekly", init_cash: float = 1_000_000.0,
                 emit: bool = True) -> Dict[str, Any]:
    """执行回测并 emit backtest_card"""
    factor_params = factor_params or {"window": 20}
    run_id = "bt-" + uuid.uuid4().hex[:10]
    data_version = "v1"
    rule_version = "1.0"
    commit = _code_commit()

    df = _read(data_path, ts_code=ts_code)
    if df is None or len(df) == 0:
        return {"ok": False, "error": f"无数据: {data_path}（ts_code={ts_code or '全部'}）"}

    # 信号
    try:
        from shared.backtest.factor import compute as factor_compute
    except ImportError:
        import sys
        sys.path.insert(0, _ROOT)
        from shared.backtest.factor import compute as factor_compute

    # 多标的等权合成：先算各标的信号再等权
    if "ts_code" in df.columns and df["ts_code"].nunique() > 1:
        codes = sorted(df["ts_code"].unique())
        sigs = []
        for c in codes:
            sub = df[df["ts_code"] == c].copy()
            if len(sub) < 10:
                continue
            s = factor_compute(sub, factor_id, factor_params)
            if s is not None and len(s):
                sigs.append(s.rename(c))
        if not sigs:
            return {"ok": False, "error": f"因子 {factor_id} 无有效信号"}
        sig_df = pd.concat(sigs, axis=1).fillna(0)
        signal = sig_df.mean(axis=1)
        # 合成价格：等权收盘价
        px = df.pivot_table(index="trade_date", columns="ts_code",
                            values="close", aggfunc="last").ffill()
        nav_df = pd.DataFrame({"close": px.mean(axis=1), "signal": signal})
        nav_df.index.name = "trade_date"
    else:
        signal = factor_compute(df, factor_id, factor_params)
        if signal is None or len(signal) == 0:
            return {"ok": False, "error": f"因子 {factor_id} 无有效信号"}
        nav_df = df.copy()
        nav_df["signal"] = signal

    # 回测
    try:
        from shared.backtest.vector import vector_backtest
    except ImportError:
        import sys
        sys.path.insert(0, _ROOT)
        from shared.backtest.vector import vector_backtest

    result = vector_backtest(
        nav_df,
        signal_fn=lambda d: d["signal"],
        weight="equal",
        rebal_freq=rebal_freq,
        init_cash=float(init_cash),
        data_version=data_version,
        rule_version=rule_version,
        run_id=run_id,
    )
    # meta 补 commit
    if isinstance(result, dict):
        meta = result.setdefault("meta", {})
        meta["data_version"] = data_version
        meta["rule_version"] = rule_version
        meta["code_commit"] = commit
        meta["run_id"] = run_id

    # 报告卡
    card = None
    try:
        from shared.backtest.report import build_card
        card = build_card(result)
        if emit:
            try:
                from shared.action_cards import get_action_card_registry
                get_action_card_registry().emit_card(card)
            except Exception as e:
                print(f"[backtest_skills] emit 失败: {e}")
    except Exception as e:
        print(f"[backtest_skills] build_card 失败: {e}")

    # 指标摘要
    metrics = result.get("metrics", {}) if isinstance(result, dict) else {}
    summary = {k: v for k, v in metrics.items()
               if isinstance(v, (int, float)) and not pd.isna(v)}

    # ★ 2026-11-11 接线基建：回测结果同时给出因子有效性评估
    #   （Rank IC / ICIR / 多空收益 / 增量 IC / keep 决策）。
    #   前瞻收益仅用于评估，不参与回测信号与仓位决策；异常不打断回测。
    factor_eval = None
    try:
        from shared.backtest.factor_eval import evaluate_factor
        if "close" in nav_df.columns and len(nav_df) > 10:
            fwd = nav_df["close"].astype(float).pct_change().shift(-1)
            factor_eval = evaluate_factor(pd.Series(signal).astype(float), fwd)
            factor_eval["note"] = "评估用前瞻收益，不参与回测信号/仓位决策"
    except Exception as e:
        factor_eval = {"ok": False, "error": str(e)[:120]}

    # ★ 2026-11-11 主链路接线：回测结果附带前视风险标记。
    #   代码级（leakcheck：负 shift / 未来切片）+ 语义级（parametric_leak：
    #   未来字段 / 历史记忆常量）双层检查；只标记、不改回测行为，异常降级。
    lookahead = None
    try:
        import inspect
        from shared.backtest.factor import REGISTRY as _FACTOR_REGISTRY
        from shared.backtest.leakcheck import run_all as _leak_code
        from shared.backtest.parametric_leak import semantic_scan
        _fn = (_FACTOR_REGISTRY.get(factor_id) or {}).get("fn")
        _src = inspect.getsource(_fn) if _fn else ""
        _sem = semantic_scan(_src, factor_id)
        _code = _leak_code(factor_fn_src=_src)
        lookahead = {
            "blocked": bool(_sem["severity"] == "high" or _code["blocked"]),
            "semantic": _sem["signals"],
            "code_level": _code["violations"],
            "note": "仅作风险标记，不阻断已执行的回测；blocked=true 时该因子禁止投入实盘",
        }
    except Exception as e:
        lookahead = {"ok": False, "error": str(e)[:120]}

    return {
        "ok": True,
        "run_id": run_id,
        "metrics": summary,
        "card": card,
        "factor_eval": factor_eval,
        "lookahead": lookahead,
        "meta": result.get("meta") if isinstance(result, dict) else {},
    }


def register(registry=None) -> dict:
    """注册 backtest_run 技能"""
    try:
        from standard_mode.core.skills_registry import SkillDef, get_skills_registry
    except ImportError:
        try:
            from core.skills_registry import SkillDef, get_skills_registry
        except ImportError:
            return {"success": False, "error": "skills_registry 不可用"}
    reg = registry or get_skills_registry()

    def _run(**kw):
        data_path = kw.get("data_path") or ""
        if not data_path:
            return json.dumps({"ok": False, "error": "缺少 data_path"})
        if not os.path.exists(data_path):
            return json.dumps({"ok": False, "error": f"data_path 不存在: {data_path}"})
        r = run_backtest(
            data_path=data_path,
            ts_code=str(kw.get("ts_code", "") or ""),
            factor_id=str(kw.get("factor_id", "mom") or "mom"),
            factor_params=kw.get("factor_params") or {"window": 20},
            rebal_freq=str(kw.get("rebal_freq", "weekly") or "weekly"),
            init_cash=float(kw.get("init_cash", 1_000_000) or 1_000_000),
            emit=bool(kw.get("emit", True)),
        )
        return json.dumps(r, ensure_ascii=False, default=str)

    reg.register(SkillDef(
        name="backtest_run",
        description="向量化回测（shift(1) 执行，含成本，emit backtest_card）",
        category="backtest", requires_confirm=False,
        parameters={"type": "object", "properties": {
            "data_path": {"type": "string"},
            "ts_code": {"type": "string"},
            "factor_id": {"type": "string"},
            "factor_params": {"type": "object"},
            "rebal_freq": {"type": "string"},
            "init_cash": {"type": "number"},
            "emit": {"type": "boolean"},
        }, "required": ["data_path"]},
        handler=_run, timeout=120))

    # ★ W22-7: 横截面 top-N 回测
    reg.register(SkillDef(
        name="backtest_cross_section",
        description="横截面 top-N 回测（T 日因子 → T+1 收益，equal/market_cap 加权）",
        category="backtest", requires_confirm=False,
        parameters={"type": "object", "properties": {
            "data_path": {"type": "string"},
            "factor_col": {"type": "string"},
            "top_n": {"type": "integer"},
            "weight": {"type": "string"},
            "rebal_freq": {"type": "string"},
            "init_cash": {"type": "number"},
            "emit": {"type": "boolean"},
        }, "required": ["data_path"]},
        handler=_cross_section_run, timeout=120))

    names = set()
    try:
        for d in reg.get_tool_definitions():
            names.add((d.get("function") or {}).get("name") or d.get("name") or "")
    except Exception:
        logger.debug("suppressed exception")
    found = "backtest_run" in names and "backtest_cross_section" in names
    return {"success": found, "found": [n for n in ("backtest_run", "backtest_cross_section") if n in names],
            "total": 2}


if __name__ == "__main__":
    print(register())


# ══════════════════════════════════════════════════════════════════
# ★ W22-7: 横截面 top-N 回测技能
# ══════════════════════════════════════════════════════════════════

def _cross_section_run(**kw):
    """横截面 top-N 回测（T 日因子 → T+1 收益）"""
    try:
        from shared.backtest.cross import cross_section_backtest
    except ImportError:
        import sys
        sys.path.insert(0, _ROOT)
        from shared.backtest.cross import cross_section_backtest
    data_path = kw.get("data_path") or ""
    if not data_path:
        import json as _json
        return _json.dumps({"ok": False, "error": "缺少 data_path"}, ensure_ascii=False)
    if not os.path.exists(data_path):
        import json as _json
        return _json.dumps({"ok": False, "error": f"data_path 不存在: {data_path}"}, ensure_ascii=False)
    try:
        import pandas as _pd
        panel = _pd.read_parquet(data_path)
    except Exception as e:
        import json as _json
        return _json.dumps({"ok": False, "error": f"读取失败: {str(e)[:120]}"}, ensure_ascii=False)
    r = cross_section_backtest(
        panel,
        factor_col=str(kw.get("factor_col", "factor") or "factor"),
        top_n=max(1, min(int(kw.get("top_n", 20) or 20), 500)),
        weight=str(kw.get("weight", "equal") or "equal"),
        rebal_freq=str(kw.get("rebal_freq", "weekly") or "weekly"),
        init_cash=float(kw.get("init_cash", 1_000_000) or 1_000_000),
    )
    if not r.get("ok"):
        import json as _json
        return _json.dumps(r, ensure_ascii=False)
    # emit backtest_card
    emit = bool(kw.get("emit", True))
    if emit:
        try:
            from shared.action_cards import get_action_card_registry
            get_action_card_registry().emit_card({
                "type": "backtest_card",
                "card_id": f"bt_cross_{int(__import__('time').time())}",
                "title": f"横截面回测 top{r.get('holdings_per_day')} · {data_path[-30:]}",
                "nav": r.get("nav", []),
                "drawdown": [],
                "metrics": r.get("metrics", {}),
                "yearly": r.get("yearly", {}),
                "data_version": "v1",
                "rule_version": "1.0",
                "code_commit": "",
                "run_id": "",
                "cost_total": 0,
            })
        except Exception as _ee:
            print(f"[backtest_cross_section] emit 失败: {_ee}")
    import json as _json
    return _json.dumps(r, ensure_ascii=False, default=str)
