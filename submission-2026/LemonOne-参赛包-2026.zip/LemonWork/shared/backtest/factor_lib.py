# -*- coding: utf-8 -*-
"""★ W24-5: 因子库（momentum/reversal/value/quality/volatility）

5 个因子可计算，IC/RankIC/分组收益，walk-forward 无未来函数。
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Any, Dict, List, Optional


# ═══════════════════════════════════════════════════════════════
# 5 个因子
# ═══════════════════════════════════════════════════════════════
def factor_momentum(df: pd.DataFrame, window: int = 20) -> pd.Series:
    """动量因子：过去 window 日收益率"""
    if "close" not in df.columns:
        return pd.Series(np.nan, index=df.index)
    return df["close"].pct_change(window)


def factor_reversal(df: pd.DataFrame, window: int = 5) -> pd.Series:
    """反转因子：过去 window 日负收益（短期反转）"""
    if "close" not in df.columns:
        return pd.Series(np.nan, index=df.index)
    return -df["close"].pct_change(window)


def factor_value(df: pd.DataFrame, pe: Optional[pd.Series] = None) -> pd.Series:
    """价值因子：PE 倒数（EP），PE 越低越高"""
    if pe is None:
        # 无 PE 数据时用 price/book 近似（book 用 close 近似）
        if "close" not in df.columns:
            return pd.Series(np.nan, index=df.index)
        return 1.0 / df["close"].replace(0, np.nan)
    return 1.0 / pe.replace(0, np.nan)


def factor_quality(df: pd.DataFrame, roe: Optional[pd.Series] = None) -> pd.Series:
    """质量因子：ROE，越高越好"""
    if roe is None:
        # 无 ROE 时用盈利增长率近似
        if "close" not in df.columns:
            return pd.Series(np.nan, index=df.index)
        return df["close"].pct_change(60)  # 60 日盈利增长代理
    return roe


def factor_volatility(df: pd.DataFrame, window: int = 20) -> pd.Series:
    """波动率因子：过去 window 日收益波动率，越低越好（负号）"""
    if "close" not in df.columns:
        return pd.Series(np.nan, index=df.index)
    ret = df["close"].pct_change()
    vol = ret.rolling(window).std()
    return -vol  # 低波动为正


FACTOR_MAP = {
    "momentum": factor_momentum,
    "reversal": factor_reversal,
    "value": factor_value,
    "quality": factor_quality,
    "volatility": factor_volatility,
}


def compute_factor(df: pd.DataFrame, factor_id: str,
                   params: Optional[Dict] = None) -> pd.Series:
    """计算单个因子"""
    if factor_id not in FACTOR_MAP:
        raise ValueError(f"未知因子: {factor_id}")
    params = params or {}
    return FACTOR_MAP[factor_id](df, **params)


# ═══════════════════════════════════════════════════════════════
# IC / RankIC
# ═══════════════════════════════════════════════════════════════
def compute_ic(factor: pd.Series, forward_ret: pd.Series) -> Dict[str, float]:
    """IC（Pearson 相关）+ RankIC（Spearman 相关，用 rank+pearson 实现，免 scipy）"""
    # 对齐
    idx = factor.dropna().index.intersection(forward_ret.dropna().index)
    if len(idx) < 10:
        return {"ic": np.nan, "rank_ic": np.nan, "n": len(idx)}
    f = factor.loc[idx]
    r = forward_ret.loc[idx]
    ic = f.corr(r, method="pearson")
    # Spearman = Pearson on ranks（避免 scipy 依赖）
    rank_ic = f.rank().corr(r.rank(), method="pearson")
    return {"ic": round(ic, 4), "rank_ic": round(rank_ic, 4), "n": len(idx)}


def compute_group_returns(factor: pd.Series, forward_ret: pd.Series,
                          n_groups: int = 5) -> pd.DataFrame:
    """分组收益（按因子值分 n_groups 组）"""
    idx = factor.dropna().index.intersection(forward_ret.dropna().index)
    if len(idx) < n_groups * 5:
        return pd.DataFrame()
    f = factor.loc[idx]
    r = forward_ret.loc[idx]
    # 分位分组
    try:
        groups = pd.qcut(f, n_groups, labels=False, duplicates="drop")
    except Exception:
        return pd.DataFrame()
    result = []
    for g in sorted(groups.dropna().unique()):
        mask = groups == g
        result.append({
            "group": int(g),
            "n": int(mask.sum()),
            "mean_ret": round(r[mask].mean(), 6),
            "std_ret": round(r[mask].std(), 6),
        })
    return pd.DataFrame(result)


# ═══════════════════════════════════════════════════════════════
# Walk-Forward（滚动训练/测试，禁止未来函数）
# ═══════════════════════════════════════════════════════════════
def walk_forward(factor: pd.Series, forward_ret: pd.Series,
                 train_window: int = 60, test_window: int = 20) -> List[Dict]:
    """Walk-forward 回测：滚动训练/测试

    每步用 train_window 训练，test_window 测试，窗口滚动前进。
    禁止未来函数：测试期只用训练期数据。
    """
    idx = factor.dropna().index.intersection(forward_ret.dropna().index)
    if len(idx) < train_window + test_window:
        return []
    results = []
    for start in range(0, len(idx) - train_window - test_window, test_window):
        train_end = start + train_window
        test_end = train_end + test_window
        train_idx = idx[start:train_end]
        test_idx = idx[train_end:test_end]
        # 训练期：计算因子 IC
        train_ic = compute_ic(factor.loc[train_idx], forward_ret.loc[train_idx])
        # 测试期：用训练期选定的因子方向
        test_ic = compute_ic(factor.loc[test_idx], forward_ret.loc[test_idx])
        results.append({
            "train_start": str(train_idx[0])[:10],
            "train_end": str(train_idx[-1])[:10],
            "test_start": str(test_idx[0])[:10],
            "test_end": str(test_idx[-1])[:10],
            "train_ic": train_ic.get("ic"),
            "test_ic": test_ic.get("ic"),
            "train_n": train_ic.get("n"),
            "test_n": test_ic.get("n"),
        })
    return results


if __name__ == "__main__":
    # 测试
    dates = pd.bdate_range("2024-01-01", periods=200)
    df = pd.DataFrame({
        "close": 10 + np.random.randn(200).cumsum() * 0.1,
    }, index=dates)
    f = compute_factor(df, "momentum")
    fwd = df["close"].pct_change(5).shift(-5)
    ic = compute_ic(f, fwd)
    print("IC:", ic)
    grp = compute_group_returns(f, fwd)
    print("分组:\n", grp)
    wf = walk_forward(f, fwd)
    print("Walk-forward:", len(wf), "步")
