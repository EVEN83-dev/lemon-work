# -*- coding: utf-8 -*-
"""E5 · 成本模型。

1) 佣金（万2.5 可配，最低 5 元）
2) 印花税（卖出千分之一，可配）
3) 过户费（沪市）
4) 滑点（固定/百分比/成交量比例）
5) 涨跌停不可成交

禁止：默认零成本。
"""
from __future__ import annotations

from typing import Dict, Optional

import pandas as pd

# 默认参数（可配）
DEFAULT = {
    "commission_rate": 0.00025,     # 万2.5
    "commission_min": 5.0,           # 最低 5 元
    "stamp_tax_rate": 0.001,         # 卖出千分之一
    "transfer_fee_rate": 0.00002,    # 过户费（沪市）
    "slippage_fixed": 0.0,           # 固定滑点（元）
    "slippage_pct": 0.0005,          # 百分比滑点
    "slippage_volume_ratio": 0.0,    # 按成交量比例
    "stamp_tax_side": "sell",        # 印花税方向
}

# 涨跌停幅度（A股主板 10%，ST 5%，创业板/科创板 20%）
LIMIT_UP_PCT = 0.10
LIMIT_DOWN_PCT = -0.10


def commission(amount: float, rate: float = DEFAULT["commission_rate"],
               minimum: float = DEFAULT["commission_min"]) -> float:
    """佣金：万2.5，最低 5 元。"""
    return max(abs(amount) * rate, minimum)


def stamp_tax(amount: float, side: str,
              rate: float = DEFAULT["stamp_tax_rate"]) -> float:
    """印花税：仅卖出收取。"""
    if side != DEFAULT["stamp_tax_side"]:
        return 0.0
    return abs(amount) * rate


def transfer_fee(amount: float, is_sh: bool,
                 rate: float = DEFAULT["transfer_fee_rate"]) -> float:
    """过户费：仅沪市。"""
    return abs(amount) * rate if is_sh else 0.0


def slippage(price: float, volume: float, side: str,
             params: Optional[Dict] = None) -> float:
    """滑点成本（价格恶化量，正数表示不利）。"""
    p = {**DEFAULT, **(params or {})}
    s = p["slippage_fixed"]
    s += price * p["slippage_pct"]
    s += price * p["slippage_volume_ratio"] * min(volume / 1e6, 1.0)
    return s if side == "buy" else -s   # 买入推高、卖出压低


def trade_cost(amount: float, side: str, is_sh: bool,
               params: Optional[Dict] = None) -> float:
    """单笔交易总成本（佣金 + 印花税 + 过户费）。"""
    p = {**DEFAULT, **(params or {})}
    return (commission(amount, p["commission_rate"], p["commission_min"])
            + stamp_tax(amount, side, p["stamp_tax_rate"])
            + transfer_fee(amount, is_sh, p["transfer_fee_rate"]))


def turnover_to_cost(turnover_ratio: float, cash: float,
                     side: str = "buy", is_sh: bool = True,
                     params: Optional[Dict] = None) -> float:
    """把换手率转成成本金额（供向量化回测使用）。"""
    amount = abs(turnover_ratio) * cash
    return trade_cost(amount, side, is_sh, params)


def is_limit_move(prev_close: float, close: float,
                  limit_pct: float = LIMIT_UP_PCT) -> bool:
    """是否涨跌停（默认主板 10%）。"""
    if prev_close <= 0:
        return False
    chg = (close - prev_close) / prev_close
    return chg >= limit_pct - 1e-9 or chg <= -(limit_pct - 1e-9)


def can_trade(prev_close: float, close: float, side: str,
              limit_pct: float = LIMIT_UP_PCT) -> bool:
    """涨跌停不可成交：涨停不可买、跌停不可卖。"""
    if prev_close <= 0:
        return True
    chg = (close - prev_close) / prev_close
    if side == "buy" and chg >= limit_pct - 1e-9:
        return False
    if side == "sell" and chg <= -(limit_pct - 1e-9):
        return False
    return True


__all__ = ["DEFAULT", "LIMIT_UP_PCT", "LIMIT_DOWN_PCT",
           "commission", "stamp_tax", "transfer_fee", "slippage",
           "trade_cost", "turnover_to_cost", "is_limit_move", "can_trade"]
