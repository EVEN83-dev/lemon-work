# -*- coding: utf-8 -*-
"""E8 · 实验追踪。

1) 每次回测写 data/backtest/runs/{run_id}/
2) 记录参数、指标、数据版本、代码 commit、耗时
3) 支持 runs 列表与对比

禁止：只存最终收益不存参数。
"""
from __future__ import annotations

import json
import os
import time
import uuid
from typing import Any, Dict, List, Optional

import pandas as pd

from shared.backtest import RUNS_DIR, ensure_dirs


def _commit() -> str:
    import subprocess
    try:
        root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        return subprocess.check_output(["git", "rev-parse", "--short", "HEAD"],
                                       cwd=root, stderr=subprocess.DEVNULL).decode().strip()
    except Exception:
        return "unknown"


def start_run(params: Dict[str, Any], data_version: str = "unknown",
              rule_version: str = "1.0") -> Dict[str, Any]:
    """开一个 run（写 run_id/params.json），返回 run 句柄。"""
    paths = ensure_dirs()
    run_id = "run-" + time.strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:6]
    rdir = os.path.join(paths["runs"], run_id)
    os.makedirs(rdir, exist_ok=True)
    rec = {
        "run_id": run_id,
        "params": params,
        "data_version": data_version,
        "rule_version": rule_version,
        "code_commit": _commit(),
        "started_at": pd.Timestamp.now().isoformat(timespec="seconds"),
        "status": "running",
    }
    with open(os.path.join(rdir, "params.json"), "w", encoding="utf-8") as f:
        json.dump(rec, f, ensure_ascii=False, indent=1)
    return rec


def finish_run(run_id: str, metrics: Dict[str, Any],
               extra: Optional[Dict[str, Any]] = None,
               base_dir: Optional[str] = None) -> str:
    """收尾：写 metrics.json + summary.json。"""
    root = (base_dir or RUNS_DIR)
    rdir = os.path.join(root, run_id)
    os.makedirs(rdir, exist_ok=True)
    elapsed = None
    p_path = os.path.join(rdir, "params.json")
    rec: Dict[str, Any] = {}
    if os.path.isfile(p_path):
        with open(p_path, encoding="utf-8") as f:
            rec = json.load(f)
    t0 = pd.Timestamp(rec.get("started_at", pd.Timestamp.now().isoformat()))
    elapsed = float((pd.Timestamp.now() - t0).total_seconds())

    rec.update({
        "status": "done",
        "finished_at": pd.Timestamp.now().isoformat(timespec="seconds"),
        "elapsed_sec": round(elapsed, 2),
        "metrics": metrics,
    })
    if extra:
        rec.update(extra)
    with open(os.path.join(rdir, "metrics.json"), "w", encoding="utf-8") as f:
        json.dump(metrics, f, ensure_ascii=False, indent=1)
    with open(os.path.join(rdir, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(rec, f, ensure_ascii=False, indent=1)
    return rdir


def list_runs(base_dir: Optional[str] = None) -> List[Dict[str, Any]]:
    """列出全部 run（按时间升序）。"""
    root = base_dir or RUNS_DIR
    if not os.path.isdir(root):
        return []
    out = []
    for rid in sorted(os.listdir(root)):
        sp = os.path.join(root, rid, "summary.json")
        if os.path.isfile(sp):
            with open(sp, encoding="utf-8") as f:
                out.append(json.load(f))
    return out


def compare_runs(run_ids: List[str],
                 base_dir: Optional[str] = None) -> pd.DataFrame:
    """对比多个 run 的指标。"""
    root = base_dir or RUNS_DIR
    rows = []
    for rid in run_ids:
        mp = os.path.join(root, rid, "metrics.json")
        if os.path.isfile(mp):
            with open(mp, encoding="utf-8") as f:
                m = json.load(f)
            flat = {k: v for k, v in m.items()
                    if isinstance(v, (int, float, str))}
            flat["run_id"] = rid
            rows.append(flat)
    return pd.DataFrame(rows)


def get_run(run_id: str, base_dir: Optional[str] = None) -> Optional[Dict[str, Any]]:
    root = base_dir or RUNS_DIR
    sp = os.path.join(root, run_id, "summary.json")
    if not os.path.isfile(sp):
        return None
    with open(sp, encoding="utf-8") as f:
        return json.load(f)


__all__ = ["start_run", "finish_run", "list_runs", "compare_runs", "get_run"]
