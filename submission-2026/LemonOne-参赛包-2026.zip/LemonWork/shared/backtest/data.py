# -*- coding: utf-8 -*-
"""E1 · 读取层。

1) DuckDB 直读 Parquet（按 trade_date 分区裁剪）；不可用时降级 pandas/pyarrow
2) 只读连接；PIT as_of 参数必填
3) 缺失标的返回空而非报错

禁止：全表加载进 pandas 再过滤。
"""
from __future__ import annotations

import os
from typing import List, Optional

import pandas as pd


def has_duckdb() -> bool:
    try:
        import duckdb  # noqa: F401
        return True
    except Exception:
        return False


def _normalize_date(d: str) -> str:
    return str(d).replace("-", "").replace("/", "")[:8]


def read_parquet_range(path: str, start: Optional[str] = None,
                       end: Optional[str] = None,
                       symbols: Optional[List[str]] = None,
                       columns: Optional[List[str]] = None) -> pd.DataFrame:
    """读 Parquet（或目录），按 trade_date 区间裁剪。

    - duckdb 可用：走 read_parquet + WHERE（分区裁剪）
    - 否则：pyarrow.dataset 过滤（仍避免全表加载）
    """
    if not os.path.exists(path):
        return pd.DataFrame()

    start_n = _normalize_date(start) if start else None
    end_n = _normalize_date(end) if end else None

    if has_duckdb():
        import duckdb
        # ★ duckdb 2.0.0 兼容：enable_external_access 必须在连接时配置，
        #   不能在运行时 SET（否则报 InvalidInputException）
        try:
            con = duckdb.connect(config={"enable_external_access": True})
        except Exception:
            con = duckdb.connect()
        try:
            where = []
            args: list = []
            target = (f"'{path}'" if os.path.isfile(path)
                      else f"'{os.path.join(path, '**', '*.parquet')}'")
            if start_n:
                where.append("trade_date >= ?")
                args.append(start_n)
            if end_n:
                where.append("trade_date <= ?")
                args.append(end_n)
            if symbols:
                where.append("ts_code IN (" + ",".join(["?"] * len(symbols)) + ")")
                args.extend(list(symbols))
            sql = f"SELECT * FROM read_parquet({target})"
            if where:
                sql += " WHERE " + " AND ".join(where)
            df = con.execute(sql, args).fetchdf()
            if columns:
                keep = [c for c in columns if c in df.columns]
                df = df[keep]
            return df
        finally:
            con.close()

    # 降级路径：pyarrow.dataset 过滤（Expression，仍避免全表加载）
    import pyarrow.dataset as ds
    import pyarrow.compute as pc
    dataset = ds.dataset(path, format="parquet", partitioning="hive")
    exprs = []
    if start_n:
        exprs.append(pc.field("trade_date") >= start_n)
    if end_n:
        exprs.append(pc.field("trade_date") <= end_n)
    if symbols:
        exprs.append(pc.field("ts_code").isin(list(symbols)))
    flt = None
    for e in exprs:
        flt = e if flt is None else (flt & e)
    tbl = dataset.to_table(columns=columns, filter=flt)
    return tbl.to_pandas()


def read_daily(symbols: List[str], as_of: str,
               start: Optional[str] = None, end: Optional[str] = None,
               data_dir: Optional[str] = None) -> pd.DataFrame:
    """读日线（PIT 视图）：as_of 必填，按 available_at <= as_of 过滤。

    缺失标的返回空 DataFrame（不报错）。
    """
    if not as_of:
        raise ValueError("as_of 必填（回测读取不允许默认取最新）")
    from shared.quant import DATA_ROOT
    data_dir = data_dir or os.path.join(DATA_ROOT, "clean", "daily")
    if not os.path.isdir(data_dir):
        return pd.DataFrame(columns=["ts_code", "trade_date", "open", "high",
                                     "low", "close", "vol", "amount", "available_at"])

    df = read_parquet_range(data_dir, start=start, end=end, symbols=symbols)
    if df.empty:
        return df
    if "available_at" in df.columns:
        a = _normalize_date(as_of)
        df = df[df["available_at"].astype(str).str.replace(
            r"[-/]", "", regex=True).str[:8] <= a].copy()
    return df


def read_available_asof(as_of: str) -> bool:
    """探测 as_of 视图是否可用（供测试）。"""
    return bool(as_of)


__all__ = ["has_duckdb", "read_parquet_range", "read_daily", "read_available_asof"]
