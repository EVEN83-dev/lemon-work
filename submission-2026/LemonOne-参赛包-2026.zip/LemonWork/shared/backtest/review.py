# -*- coding: utf-8 -*-
"""★ 2026-11-11 · 投资复盘报告生成（TRAE 效率工具赛道扣题功能）

用户说一句"帮我把这个月的流水整理成复盘报告，标出异常支出"，
Agent 调 `investment_review` 技能 → 本模块算指标 + 生成 Markdown 报告
→ 走现有文件卡/报告通道给用户（可另存 docx，复用 office_generator）。

纪律：纯函数、无第三方依赖（仅 pandas）、不碰真实账户、只读传入流水。
"""
from __future__ import annotations

import json
from typing import Any, Dict, Optional

import numpy as np
import pandas as pd

REQUIRED = ("date", "symbol", "side", "amount", "price")


def _normalize(trades: Any) -> pd.DataFrame:
    if isinstance(trades, str):
        trades = json.loads(trades)
    df = pd.DataFrame(trades)
    for c in REQUIRED:
        if c not in df.columns:
            raise ValueError(f"流水缺列: {c}")
    if "fee" not in df.columns:
        df["fee"] = 0.0
    df["amount"] = pd.to_numeric(df["amount"], errors="coerce").fillna(0.0)
    df["price"] = pd.to_numeric(df["price"], errors="coerce").fillna(0.0)
    df["fee"] = pd.to_numeric(df["fee"], errors="coerce").fillna(0.0)
    df["side"] = df["side"].astype(str).str.lower()
    df["date"] = df["date"].astype(str)
    return df


def build_review(trades: Any, *, title: str = "投资复盘报告",
                 anomaly_sigma: float = 3.0) -> Dict:
    """生成结构化复盘指标 + Markdown 报告。"""
    df = _normalize(trades)
    buys = df[df["side"].isin(("buy", "买入", "b"))]
    sells = df[df["side"].isin(("sell", "卖出", "s"))]
    gross_buy = float((buys["amount"] * buys["price"] + buys["fee"]).sum())
    gross_sell = float((sells["amount"] * sells["price"] - sells["fee"]).sum())
    total_fee = float(df["fee"].sum())
    fee_ratio = total_fee / max(1.0, gross_buy + gross_sell)

    # 按标的配对：平均买价 vs 平均卖价 × 卖出数量
    realized = 0.0
    per_symbol = []
    for sym, g in df.groupby("symbol"):
        b, s = g[g["side"].isin(("buy", "买入", "b"))], g[g["side"].isin(("sell", "卖出", "s"))]
        bp = float(b["price"].mean()) if len(b) else 0.0
        sp = float(s["price"].mean()) if len(s) else 0.0
        qty = float(s["amount"].sum())
        pnl = (sp - bp) * qty if bp > 0 else 0.0
        realized += pnl
        per_symbol.append({"symbol": str(sym), "buy_count": int(len(b)),
                           "sell_count": int(len(s)), "avg_buy_price": round(bp, 4),
                           "avg_sell_price": round(sp, 4), "realized_pnl": round(pnl, 2)})

    # 异常支出：单笔金额 > 均值 + k*标准差
    amt = df["amount"]
    mu, sd = float(amt.mean()), float(amt.std(ddof=0) or 0.0)
    thr = mu + anomaly_sigma * sd
    anomalies = df[amt > thr][["date", "symbol", "side", "amount", "price"]].to_dict("records")

    monthly = (df.assign(month=df["date"].str[:7])
               .groupby("month")["amount"].sum().round(2).to_dict())

    result = {
        "title": title,
        "n_trades": int(len(df)),
        "n_buy": int(len(buys)), "n_sell": int(len(sells)),
        "gross_buy": round(gross_buy, 2), "gross_sell": round(gross_sell, 2),
        "net_flow": round(gross_sell - gross_buy, 2),
        "realized_pnl": round(realized, 2),
        "total_fee": round(total_fee, 2), "fee_ratio": round(fee_ratio, 6),
        "symbols": per_symbol, "monthly_amount": monthly,
        "anomaly_threshold": round(thr, 2), "anomalies": anomalies,
        "note": "本报告基于传入流水计算，不构成投资建议；买入/卖出按均价配对估算已实现盈亏",
    }

    lines = [f"# {title}", "",
             f"- 交易笔数：{result['n_trades']}（买 {result['n_buy']} / 卖 {result['n_sell']}）",
             f"- 买入总额：{result['gross_buy']:.2f}｜卖出总额：{result['gross_sell']:.2f}",
             f"- 净现金流：{result['net_flow']:.2f}｜已实现盈亏（均价配对估算）：{result['realized_pnl']:.2f}",
             f"- 手续费合计：{result['total_fee']:.2f}（占比 {result['fee_ratio'] * 100:.3f}%）", "",
             "## 分标的", ""]
    for s in per_symbol:
        lines.append(f"- **{s['symbol']}**：买 {s['buy_count']} / 卖 {s['sell_count']}，"
                     f"均价 {s['avg_buy_price']} → {s['avg_sell_price']}，盈亏 {s['realized_pnl']}")
    lines += ["", "## 异常支出", ""]
    if anomalies:
        for a in anomalies[:10]:
            lines.append(f"- {a['date']} {a['symbol']} {a['side']} 数量 {a['amount']} "
                         f"@ {a['price']}（超过阈值 {result['anomaly_threshold']}）")
    else:
        lines.append("- 未检出超过 3σ 的异常支出")
    lines += ["", "## 月度数量", ""]
    for m, v in sorted(monthly.items()):
        lines.append(f"- {m}: {v}")
    lines += ["", "> 数据来源：用户提供的交易流水；本报告不构成投资建议。"]
    result["markdown"] = "\n".join(lines)
    return result


def make_skill_handler():
    """返回符合 SkillDef.handler(**kw)->str 约定的处理函数。"""
    def _handler(**kw):
        try:
            payload = kw.get("trades") or kw.get("data") or kw.get("path")
            if isinstance(payload, str) and payload.endswith((".json", ".csv")):
                import os
                if not os.path.exists(payload):
                    return json.dumps({"ok": False, "error": f"文件不存在: {payload}"},
                                      ensure_ascii=False)
                payload = (pd.read_csv(payload) if payload.endswith(".csv")
                           else json.load(open(payload, encoding="utf-8")))
            rep = build_review(payload, title=str(kw.get("title") or "投资复盘报告"))
            return json.dumps({"ok": True, "report": rep["markdown"],
                               "metrics": {k: v for k, v in rep.items()
                                           if k not in ("markdown", "symbols", "anomalies")}},
                              ensure_ascii=False)
        except Exception as e:
            return json.dumps({"ok": False, "error": str(e)[:200]}, ensure_ascii=False)
    return _handler


def register(registry=None) -> dict:
    """把 investment_review 注册进技能注册表（幂等，失败不影响启动）。"""
    try:
        from standard_mode.core.skills_registry import SkillDef, get_skills_registry
    except ImportError:
        try:
            from core.skills_registry import SkillDef, get_skills_registry
        except ImportError:
            return {"success": False, "error": "skills_registry 不可用"}
    reg = registry or get_skills_registry()
    reg.register(SkillDef(
        name="investment_review",
        description="根据交易流水生成投资复盘报告：净现金流、已实现盈亏、分标的、月度汇总、异常支出（3σ）",
        parameters={"type": "object", "properties": {
            "trades": {"type": "array", "description": "流水数组，每条含 date/symbol/side/amount/price/fee"},
            "title": {"type": "string", "description": "报告标题"}},
            "required": ["trades"]},
        handler=make_skill_handler(), category="finance", timeout=30))
    return {"success": True, "name": "investment_review"}


# ── 离线自测 ───────────────────────────────────────────────────────
if __name__ == "__main__":
    rows = []
    for i in range(10):
        rows.append({"date": f"2026-10-{i + 1:02d}", "symbol": "000001.SZ",
                     "side": "buy", "amount": 100, "price": 10.0 + i * 0.1, "fee": 1.0})
    rows.append({"date": "2026-10-20", "symbol": "000001.SZ",
                 "side": "sell", "amount": 500, "price": 12.0, "fee": 1.0})
    rows.append({"date": "2026-10-21", "symbol": "600000.SH",
                 "side": "buy", "amount": 100000, "price": 8.0, "fee": 50.0})  # 异常
    rep = build_review(rows)
    h = make_skill_handler()
    got = json.loads(h(trades=rows))
    tests = [
        ("笔数正确", rep["n_trades"] == 12),
        ("买/卖计数", rep["n_buy"] == 11 and rep["n_sell"] == 1),
        ("异常支出命中", len(rep["anomalies"]) == 1
         and rep["anomalies"][0]["symbol"] == "600000.SH"),
        ("手续费占比为正", rep["fee_ratio"] > 0),
        ("分标的两条", len(rep["symbols"]) == 2),
        ("已实现盈亏数值", isinstance(rep["realized_pnl"], float)),
        ("Markdown 含关键段", all(k in rep["markdown"] for k in
                                ("投资复盘报告", "异常支出", "月度数量", "不构成投资建议"))),
        ("技能 handler 返回 ok", got["ok"] is True and "报告" in got["report"]),
        ("handler 错误不抛异常", json.loads(h(trades=[]))["ok"] is False
         or json.loads(h(trades=[])).get("ok") is True),
        ("缺列给明确错误", "缺列" in json.loads(h(trades=[{"x": 1}]))["error"]),
    ]
    for name, ok in tests:
        print(("PASS" if ok else "FAIL"), name)
    print("ALL_PASS" if all(o for _, o in tests) else "HAS_FAIL")
