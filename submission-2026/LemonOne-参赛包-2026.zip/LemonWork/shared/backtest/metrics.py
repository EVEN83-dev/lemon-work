# -*- coding: utf-8 -*-
"""E6 · 绩效指标。

1) 年化收益 / 波动 / 夏普 / 最大回撤 / 卡玛 / 胜率 / 换手 / 盈亏比
2) 分年度 / 分月度收益表

禁止：用简单收益率冒充对数收益率而不标注。
"""
from __future__ import annotations

from typing import Dict, Optional

import numpy as np
import pandas as pd

TRADING_DAYS = 242          # A 股年化交易日近似
RISK_FREE = 0.02            # 无风险利率（年化）


def _to_returns(nav: pd.Series) -> pd.Series:
    """净值 → 简单收益率（本函数一律使用简单收益率，不混用对数）。"""
    return nav.pct_change().fillna(0.0)


def annualized_return(nav: pd.Series, periods: int = TRADING_DAYS) -> float:
    """年化收益（几何）。"""
    if len(nav) < 2 or nav.iloc[0] <= 0:
        return 0.0
    total = float(nav.iloc[-1] / nav.iloc[0])
    n = len(nav) - 1
    return float(total ** (periods / max(n, 1)) - 1.0)


def annualized_volatility(returns: pd.Series, periods: int = TRADING_DAYS) -> float:
    """年化波动（简单收益率标准差 × sqrt(periods)）。"""
    if len(returns) < 2:
        return 0.0
    return float(returns.std(ddof=1) * np.sqrt(periods))


def sharpe(returns: pd.Series, periods: int = TRADING_DAYS,
           rf: float = RISK_FREE) -> float:
    """夏普比率（基于简单收益率）。"""
    if len(returns) < 2:
        return 0.0
    excess = returns.mean() * periods - rf
    std = returns.std(ddof=1) * np.sqrt(periods)
    return float(excess / std) if std > 0 else 0.0


def max_drawdown(nav: pd.Series) -> float:
    """最大回撤（正数）。"""
    if len(nav) < 2:
        return 0.0
    roll_max = nav.cummax()
    dd = (nav - roll_max) / roll_max
    return float(-dd.min())


def calmar(nav: pd.Series, periods: int = TRADING_DAYS) -> float:
    """卡玛比率 = 年化收益 / 最大回撤。"""
    mdd = max_drawdown(nav)
    return float(annualized_return(nav, periods) / mdd) if mdd > 0 else 0.0


def win_rate(returns: pd.Series) -> float:
    """胜率（正收益占比）。"""
    if len(returns) == 0:
        return 0.0
    return float((returns > 0).sum() / len(returns))


def turnover_ratio(weights: pd.Series) -> float:
    """换手率（平均绝对变动）。"""
    if len(weights) < 2:
        return 0.0
    return float(weights.diff().abs().mean())


def profit_loss_ratio(trades: pd.Series) -> float:
    """盈亏比 = 平均盈利 / 平均亏损（绝对值）。"""
    if len(trades) == 0:
        return 0.0
    wins = trades[trades > 0]
    losses = trades[trades < 0]
    if wins.empty or losses.empty:
        return 0.0
    return float(wins.mean() / abs(losses.mean()))


def yearly_returns(nav: pd.Series, dates: Optional[pd.Series] = None) -> pd.DataFrame:
    """分年度收益表。"""
    if len(nav) == 0:
        return pd.DataFrame(columns=["year", "return"])
    s = nav.copy()
    idx = pd.to_datetime(dates.astype(str)) if dates is not None else pd.to_datetime(s.index)
    s.index = idx
    g = s.resample("YE").last()
    out = g.pct_change().dropna()
    return pd.DataFrame({"year": out.index.year.astype(str), "return": out.values})


def monthly_returns(nav: pd.Series, dates: Optional[pd.Series] = None) -> pd.DataFrame:
    """分月度收益表。"""
    if len(nav) == 0:
        return pd.DataFrame(columns=["month", "return"])
    s = nav.copy()
    idx = pd.to_datetime(dates.astype(str)) if dates is not None else pd.to_datetime(s.index)
    s.index = idx
    g = s.resample("ME").last()
    out = g.pct_change().dropna()
    return pd.DataFrame({"month": out.index.strftime("%Y-%m"), "return": out.values})


def compute_all(nav: pd.Series, returns: Optional[pd.Series] = None,
                trades: Optional[pd.Series] = None,
                weights: Optional[pd.Series] = None,
                dates: Optional[pd.Series] = None,
                periods: int = TRADING_DAYS) -> Dict:
    """全部指标（无交易返回零值不报错）。"""
    returns = _to_returns(nav) if returns is None else returns
    out = {
        "annual_return": annualized_return(nav, periods),
        "annual_volatility": annualized_volatility(returns, periods),
        "sharpe": sharpe(returns, periods),
        "max_drawdown": max_drawdown(nav),
        "calmar": calmar(nav, periods),
        "win_rate": win_rate(returns),
        "total_return": float(nav.iloc[-1] / nav.iloc[0] - 1.0) if len(nav) else 0.0,
        "return_type": "simple",   # 明确标注：不使用对数收益率
        "n_periods": int(len(nav)),
    }
    if weights is not None:
        out["turnover"] = turnover_ratio(weights)
    if trades is not None:
        out["profit_loss_ratio"] = profit_loss_ratio(trades)
    out["yearly"] = yearly_returns(nav, dates).to_dict("records")
    out["monthly"] = monthly_returns(nav, dates).to_dict("records")
    return out


__all__ = ["TRADING_DAYS", "RISK_FREE", "compute_all", "annualized_return",
           "annualized_volatility", "sharpe", "max_drawdown", "calmar",
           "win_rate", "turnover_ratio", "profit_loss_ratio",
           "yearly_returns", "monthly_returns"]
