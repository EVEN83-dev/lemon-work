# -*- coding: utf-8 -*-
"""E2 · 因子接口。

1) factor(df, params) -> Series/DataFrame
2) 注册表 factor_id -> {fn, params_schema, version}
3) 因子值落 feature 层，带 version

禁止：因子函数里读未来数据。
"""
from __future__ import annotations

import hashlib
import json
import os
from typing import Any, Callable, Dict, Optional

import numpy as np
import pandas as pd

from shared.quant import ensure_dirs

REGISTRY: Dict[str, Dict[str, Any]] = {}


def register(factor_id: str, version: str = "1.0",
             params_schema: Optional[dict] = None,
             fn: Optional[Callable] = None):
    """注册因子（装饰器或显式调用）。"""
    def deco(f):
        REGISTRY[factor_id] = {
            "fn": f, "version": version,
            "params_schema": params_schema or {"type": "object", "properties": {}},
        }
        return f
    return deco(fn) if fn is not None else deco


def get_factor(factor_id: str) -> Dict[str, Any]:
    if factor_id not in REGISTRY:
        raise KeyError(f"未注册因子: {factor_id}")
    return REGISTRY[factor_id]


def compute(df: pd.DataFrame, factor_id: str,
            params: Optional[dict] = None) -> pd.Series:
    """计算因子值（同一因子两次计算结果一致）。"""
    spec = get_factor(factor_id)
    params = params or {}
    _validate_params(spec["params_schema"], params)
    return spec["fn"](df, params)


def _validate_params(schema: dict, params: dict) -> None:
    props = (schema or {}).get("properties", {})
    required = (schema or {}).get("required", [])
    for r in required:
        if r not in params:
            raise ValueError(f"因子缺参数: {r}")
    for k, v in params.items():
        if k in props and "type" in props[k]:
            t = props[k]["type"]
            if t == "integer" and not isinstance(v, int):
                raise TypeError(f"参数 {k} 应为 integer")
            if t == "number" and not isinstance(v, (int, float)):
                raise TypeError(f"参数 {k} 应为 number")


# ── 内置因子（均只用历史数据） ────────────────────────────────────
@register("mom", version="1.0",
          params_schema={"type": "object",
                         "properties": {"window": {"type": "integer"}},
                         "required": ["window"]})
def _mom(df: pd.DataFrame, params: dict) -> pd.Series:
    """动量：过去 window 日收益率。"""
    w = int(params["window"])
    return df["close"].pct_change(w)


@register("ma", version="1.0",
          params_schema={"type": "object",
                         "properties": {"window": {"type": "integer"}},
                         "required": ["window"]})
def _ma(df: pd.DataFrame, params: dict) -> pd.Series:
    """均线。"""
    w = int(params["window"])
    return df["close"].rolling(w, min_periods=w).mean()


@register("vol", version="1.0",
          params_schema={"type": "object",
                         "properties": {"window": {"type": "integer"}},
                         "required": ["window"]})
def _vol(df: pd.DataFrame, params: dict) -> pd.Series:
    """波动率：window 日收益标准差。"""
    w = int(params["window"])
    return df["close"].pct_change().rolling(w, min_periods=w).std()


def persist(df: pd.DataFrame, factor_id: str, series: pd.Series,
            version: str, out_dir: Optional[str] = None) -> str:
    """因子值落 feature 层（带 version），返回路径。"""
    paths = ensure_dirs()
    vdir = os.path.join(paths["feature"], f"{factor_id}_{version}")
    os.makedirs(vdir, exist_ok=True)
    out = os.path.join(vdir, "data.parquet")
    payload = df[[c for c in ("ts_code", "trade_date") if c in df.columns]].copy()
    payload["value"] = series.values
    payload.to_parquet(out, index=False)
    with open(os.path.join(vdir, "meta.json"), "w", encoding="utf-8") as f:
        json.dump({"factor_id": factor_id, "version": version,
                   "rows": int(len(payload)),
                   "schema_hash": hashlib.sha256(
                       json.dumps(list(payload.dtypes.astype(str)), sort_keys=True).encode()
                   ).hexdigest()[:16]}, f, ensure_ascii=False)
    return out


__all__ = ["REGISTRY", "register", "get_factor", "compute", "persist"]
