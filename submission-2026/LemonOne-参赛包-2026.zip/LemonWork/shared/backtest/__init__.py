# -*- coding: utf-8 -*-
"""LemonWork 回测引擎（E 集群）。

统一结果结构：{returns, positions, trades, metrics, meta}
meta 必含 data_version / rule_version / code_commit / run_id。

依赖策略：DuckDB 可用则用 DuckDB 直读 Parquet；否则降级 pandas/pyarrow，
接口签名一致（见 data.py）。不装依赖。
"""
from __future__ import annotations

import os

BACKTEST_ROOT = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
    "data", "backtest")

RESULT_FIELDS = ("returns", "positions", "trades", "metrics", "meta")
META_REQUIRED = ("data_version", "rule_version", "code_commit", "run_id")

RUNS_DIR = os.path.join(BACKTEST_ROOT, "runs")

BACKTEST_VERSION = "1.0"


def ensure_dirs(root: str = BACKTEST_ROOT) -> dict:
    paths = {"root": root, "runs": os.path.join(root, "runs")}
    for p in paths.values():
        os.makedirs(p, exist_ok=True)
    return paths


def make_result(returns, positions=None, trades=None, metrics=None,
                data_version="unknown", rule_version="1.0",
                code_commit="unknown", run_id="unknown",
                extra_meta: dict | None = None) -> dict:
    """构造统一结果结构（所有回测入口必须返回此结构）。"""
    meta = {
        "data_version": data_version,
        "rule_version": rule_version,
        "code_commit": code_commit,
        "run_id": run_id,
        "backtest_version": BACKTEST_VERSION,
    }
    if extra_meta:
        meta.update(extra_meta)
    return {
        "returns": returns,
        "positions": positions if positions is not None else [],
        "trades": trades if trades is not None else [],
        "metrics": metrics if metrics is not None else {},
        "meta": meta,
    }


def validate_result(result: dict) -> tuple:
    """校验结果结构完整（缺字段返回 False + 原因）。"""
    for f in RESULT_FIELDS:
        if f not in result:
            return False, f"缺字段 {f}"
    for m in META_REQUIRED:
        if m not in result.get("meta", {}):
            return False, f"meta 缺 {m}"
    return True, ""


__all__ = ["BACKTEST_ROOT", "RESULT_FIELDS", "META_REQUIRED", "RUNS_DIR",
           "BACKTEST_VERSION", "ensure_dirs", "make_result", "validate_result"]
