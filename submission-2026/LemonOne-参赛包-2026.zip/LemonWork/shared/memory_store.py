# -*- coding: utf-8 -*-
"""
F1 · 跨会话记忆层 (shared/memory_store.py) V1.6-WPD
====================================================
三层记忆 + 写入/读取/遗忘 + 来源可追溯 + 删除生效。

三层：
  episodic   会话摘要（每轮结束落一条，带 session_id / 时间）
  semantic   事实（从文本抽实体/偏好，带 source）
  procedural 技能偏好（工具调用频次/成功率统计）

铁律：
  - 禁止把整段对话原样塞进记忆（只存摘要/抽取结果）
  - 注入必须带来源与时间
  - 全部函数 try/except 自包，任何异常不影响主流程
  - 无来源注入禁止
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import json
import os
import re
import threading
import time
from typing import Any, Dict, List, Optional

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_MEMORY_DIR = os.path.join(_ROOT, "data", "memory_store")
_EPISODIC_FILE = os.path.join(_MEMORY_DIR, "episodic.jsonl")
_SEMANTIC_FILE = os.path.join(_MEMORY_DIR, "semantic.jsonl")
_PROCEDURAL_FILE = os.path.join(_MEMORY_DIR, "procedural.jsonl")
_INDEX_FILE = os.path.join(_MEMORY_DIR, "index.json")

_lock = threading.RLock()
_MAX_EPISODIC = 500
_MAX_SEMANTIC = 1000
_TTL_DAYS = {"episodic": 90, "semantic": 180, "procedural": 365}
_IMPORTANCE_DECAY = 0.995  # 每日衰减系数


def _ensure_dir() -> None:
    os.makedirs(_MEMORY_DIR, exist_ok=True)


def _read_jsonl(path: str) -> List[Dict[str, Any]]:
    _ensure_dir()
    if not os.path.exists(path):
        return []
    items = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                items.append(json.loads(line))
            except Exception:
                continue
    return items


def _append_jsonl(path: str, item: Dict[str, Any], max_items: int) -> None:
    _ensure_dir()
    items = _read_jsonl(path)
    items.append(item)
    if len(items) > max_items:
        items = items[-max_items:]
    with open(path, "w", encoding="utf-8") as f:
        for it in items:
            f.write(json.dumps(it, ensure_ascii=False) + "\n")


def _decay(ts: float, now: float) -> float:
    age_days = max(0.0, (now - ts) / 86400.0)
    return _IMPORTANCE_DECAY ** age_days


def _tokenize(text: str) -> set:
    if not text:
        return set()
    tokens = set()
    buf = ""
    for ch in text.lower():
        if ch.isalnum():
            buf += ch
        else:
            if len(buf) >= 2:
                tokens.add(buf)
            buf = ""
    if len(buf) >= 2:
        tokens.add(buf)
    cjk = [ch for ch in text if "\u4e00" <= ch <= "\u9fff"]
    for i in range(len(cjk) - 1):
        tokens.add(cjk[i] + cjk[i + 1])
    return tokens


def _similarity(a: set, b: set) -> float:
    if not a or not b:
        return 0.0
    inter = len(a & b)
    union = len(a | b)
    return inter / union if union else 0.0


# ════════════════════════════════════════════════════════════════
# 实体/偏好抽取（正则，不依赖 LLM）
# ════════════════════════════════════════════════════════════════
_PATTERNS = [
    (re.compile(r"(?:我喜欢?|偏好|倾向|prefer|I like|I prefer)\s*(.{2,30})", re.I), "preference"),
    (re.compile(r"(?:我不喜欢?|讨厌|avoid|I hate|I dislike)\s*(.{2,30})", re.I), "aversion"),
    (re.compile(r"(?:我的名字是?|叫?我|I am|my name is)\s*(.{2,20})", re.I), "identity"),
    (re.compile(r"(?:我在?|工作在?|位于|I work at|I live in)\s*(.{2,30})", re.I), "location"),
    (re.compile(r"(?:用的是?|using|with)\s*(\S{2,20})", re.I), "tool_preference"),
]


def _extract_entities(text: str) -> List[Dict[str, Any]]:
    """从文本抽取实体/偏好，返回 [{value, kind, source_text}]"""
    out = []
    for pat, kind in _PATTERNS:
        for m in pat.finditer(text):
            val = (m.group(1) or "").strip().rstrip("。，,. ")
            if 2 <= len(val) <= 60:
                out.append({"value": val, "kind": kind,
                            "source_text": text[max(0, m.start() - 10):m.end() + 10]})
    return out


# ════════════════════════════════════════════════════════════════
# 写入 API
# ════════════════════════════════════════════════════════════════
def write_episodic(session_id: str, summary: str, entities: Optional[List[str]] = None,
                   importance: float = 1.0, source: str = "") -> Dict[str, Any]:
    """每轮结束写会话摘要。

    Args:
        session_id: 会话 ID
        summary: 摘要文本（禁止传整段对话原文，建议 ≤200 字）
        entities: 关键实体列表
        importance: 重要度 0-1
        source: 来源（如 "session:xxx"）
    """
    try:
        _ensure_dir()
        if len(summary) > 2000:
            summary = summary[:2000] + "…"
        item = {
            "id": f"epi_{int(time.time() * 1000)}_{session_id[:8]}",
            "session_id": session_id,
            "summary": summary,
            "entities": entities or [],
            "importance": max(0.0, min(1.0, float(importance))),
            "source": source or f"session:{session_id}",
            "created_at": time.time(),
        }
        _append_jsonl(_EPISODIC_FILE, item, _MAX_EPISODIC)
        return item
    except Exception:
        return {}


def write_semantic(text: str, source: str, importance: float = 1.0) -> List[Dict[str, Any]]:
    """从文本抽取事实/偏好并落盘。

    Args:
        text: 对话文本
        source: 来源标识（如 "turn:123"），无来源禁止写入
        importance: 重要度
    Returns:
        写入的条目列表
    """
    try:
        if not source:
            return []  # 无来源禁止
        _ensure_dir()
        ents = _extract_entities(text)
        written = []
        for e in ents:
            item = {
                "id": f"sem_{int(time.time() * 1000)}_{len(e['value'])}",
                "value": e["value"],
                "kind": e["kind"],
                "source_text": e["source_text"],
                "source": source,
                "importance": max(0.0, min(1.0, float(importance))),
                "created_at": time.time(),
            }
            _append_jsonl(_SEMANTIC_FILE, item, _MAX_SEMANTIC)
            written.append(item)
        return written
    except Exception:
        return []


def write_procedural(tool_name: str, success: bool, source: str = "") -> Dict[str, Any]:
    """记录技能调用频次/成功率。"""
    try:
        _ensure_dir()
        items = _read_jsonl(_PROCEDURAL_FILE)
        rec = next((x for x in items if x.get("tool_name") == tool_name), None)
        now = time.time()
        if rec is None:
            rec = {"tool_name": tool_name, "calls": 0, "successes": 0,
                   "last_used": now, "created_at": now, "source": source}
            items.append(rec)
        rec["calls"] = int(rec.get("calls", 0)) + 1
        if success:
            rec["successes"] = int(rec.get("successes", 0)) + 1
        rec["last_used"] = now
        with open(_PROCEDURAL_FILE, "w", encoding="utf-8") as f:
            for it in items:
                f.write(json.dumps(it, ensure_ascii=False) + "\n")
        return rec
    except Exception:
        return {}


# ════════════════════════════════════════════════════════════════
# 读取 API（按相关性 TopK 注入，带来源与时间）
# ════════════════════════════════════════════════════════════════
def recall_episodic(query: str, top_k: int = 5,
                    session_id: Optional[str] = None) -> List[Dict[str, Any]]:
    """按相关性召回会话摘要，带来源与时间。"""
    try:
        items = _read_jsonl(_EPISODIC_FILE)
        now = time.time()
        q_tokens = _tokenize(query)
        scored = []
        for it in items:
            age_days = (now - it.get("created_at", now)) / 86400.0
            if age_days > _TTL_DAYS["episodic"]:
                continue
            if session_id and it.get("session_id") != session_id:
                continue
            sim = _similarity(q_tokens, _tokenize(it.get("summary", "") + " " + " ".join(it.get("entities", []))))
            score = sim * it.get("importance", 1.0) * _decay(it.get("created_at", now), now)
            if score > 0:
                scored.append((score, it))
        scored.sort(key=lambda x: -x[0])
        out = []
        for score, it in scored[:top_k]:
            out.append({
                "id": it.get("id"), "summary": it.get("summary"),
                "entities": it.get("entities", []),
                "source": it.get("source", ""), "created_at": it.get("created_at"),
                "score": round(score, 4),
            })
        return out
    except Exception:
        return []


def recall_semantic(query: str, top_k: int = 5) -> List[Dict[str, Any]]:
    """按相关性召回事实/偏好，带来源与时间。"""
    try:
        items = _read_jsonl(_SEMANTIC_FILE)
        now = time.time()
        q_tokens = _tokenize(query)
        scored = []
        for it in items:
            age_days = (now - it.get("created_at", now)) / 86400.0
            if age_days > _TTL_DAYS["semantic"]:
                continue
            sim = _similarity(q_tokens, _tokenize(it.get("value", "") + " " + it.get("source_text", "")))
            score = sim * it.get("importance", 1.0) * _decay(it.get("created_at", now), now)
            if score > 0:
                scored.append((score, it))
        scored.sort(key=lambda x: -x[0])
        return [{
            "id": it.get("id"), "value": it.get("value"), "kind": it.get("kind"),
            "source": it.get("source", ""), "source_text": it.get("source_text", ""),
            "created_at": it.get("created_at"), "score": round(score, 4),
        } for score, it in scored[:top_k]]
    except Exception:
        return []


def recall_procedural(tool_name: Optional[str] = None) -> List[Dict[str, Any]]:
    """读取技能偏好统计。"""
    try:
        items = _read_jsonl(_PROCEDURAL_FILE)
        if tool_name:
            items = [x for x in items if x.get("tool_name") == tool_name]
        return [{
            "tool_name": x.get("tool_name"), "calls": x.get("calls", 0),
            "successes": x.get("successes", 0),
            "success_rate": round(x.get("successes", 0) / max(1, x.get("calls", 1)), 4),
            "last_used": x.get("last_used"),
        } for x in items]
    except Exception:
        return []


def inject_into_prompt(query: str, max_chars: int = 400) -> str:
    """把相关记忆注入到 prompt，带来源与时间。无来源不注入。"""
    try:
        epi = recall_episodic(query, top_k=3)
        sem = recall_semantic(query, top_k=3)
        lines = []
        if epi:
            lines.append("【相关会话记忆】")
            for e in epi:
                if e.get("source"):
                    lines.append(f"- {e['summary']}（来源: {e['source']}）")
        if sem:
            lines.append("【相关事实/偏好】")
            for s in sem:
                if s.get("source"):
                    lines.append(f"- {s['value']}（来源: {s['source']}）")
        text = "\n".join(lines)
        return text[:max_chars] if text else ""
    except Exception:
        return ""


# ════════════════════════════════════════════════════════════════
# 遗忘 API
# ════════════════════════════════════════════════════════════════
def forget_by_id(memory_id: str) -> bool:
    """按 ID 删除单条记忆，可生效。"""
    try:
        _ensure_dir()
        for path in (_EPISODIC_FILE, _SEMANTIC_FILE):
            items = _read_jsonl(path)
            kept = [x for x in items if x.get("id") != memory_id]
            if len(kept) != len(items):
                with open(path, "w", encoding="utf-8") as f:
                    for it in kept:
                        f.write(json.dumps(it, ensure_ascii=False) + "\n")
                return True
        return False
    except Exception:
        return False


def forget_by_source(source: str) -> int:
        """按来源删除（如删除某会话全部记忆）。"""
        try:
            _ensure_dir()
            removed = 0
            for path in (_EPISODIC_FILE, _SEMANTIC_FILE):
                items = _read_jsonl(path)
                kept = [x for x in items if x.get("source") != source]
                removed += len(items) - len(kept)
                with open(path, "w", encoding="utf-8") as f:
                    for it in kept:
                        f.write(json.dumps(it, ensure_ascii=False) + "\n")
            return removed
        except Exception:
            return 0


def prune_expired() -> int:
    """TTL 清理，返回清理条数。"""
    try:
        _ensure_dir()
        now = time.time()
        removed = 0
        for path, ttl_key in ((_EPISODIC_FILE, "episodic"), (_SEMANTIC_FILE, "semantic")):
            items = _read_jsonl(path)
            kept = [x for x in items
                    if (now - x.get("created_at", now)) / 86400.0 <= _TTL_DAYS[ttl_key]]
            removed += len(items) - len(kept)
            with open(path, "w", encoding="utf-8") as f:
                for it in kept:
                    f.write(json.dumps(it, ensure_ascii=False) + "\n")
        return removed
    except Exception:
        return 0


# ════════════════════════════════════════════════════════════════
# 迁移：从既有 user_memory.jsonl 导入
# ════════════════════════════════════════════════════════════════
def migrate_from_user_memory(path: Optional[str] = None) -> Dict[str, int]:
    """从既有 user_memory.jsonl 迁移事实到 semantic 层。"""
    src = path or os.path.join(_ROOT, "data", "user_memory.jsonl")
    if not os.path.exists(src):
        return {"migrated": 0, "skipped": 0}
    migrated = 0
    skipped = 0
    try:
        _ensure_dir()
        with open(src, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                except Exception:
                    skipped += 1
                    continue
                text = rec.get("text") or rec.get("content") or ""
                source = rec.get("source") or "migrated:user_memory"
                if not text or not source:
                    skipped += 1
                    continue
                write_semantic(text, source=source,
                               importance=float(rec.get("importance", 0.8)))
                migrated += 1
    except Exception:
        logger.debug("suppressed exception")
    return {"migrated": migrated, "skipped": skipped}


def get_stats() -> Dict[str, int]:
    """返回各层条数。"""
    return {
        "episodic": len(_read_jsonl(_EPISODIC_FILE)),
        "semantic": len(_read_jsonl(_SEMANTIC_FILE)),
        "procedural": len(_read_jsonl(_PROCEDURAL_FILE)),
    }
