# -*- coding: utf-8 -*-
"""★ D6-07: 沙箱默认化（默认安全，渐进开关）。

① 危险命令黑名单拦截（8 类）→ {blocked, reason}
② execute_code 默认受限模式（禁网络 / 禁写仓外 / 30s 超时）
   —— 开关 sandbox_default（默认 true；关闭需写审计）
③ 文件写并发锁（同名写排队）
④ web_fetch 统一重试（3 次指数退避）
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import os
import re
import subprocess
import sys
import threading
import time
from typing import Callable, Dict, Optional, Tuple

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# ── ① 危险命令黑名单（8 类）──
DANGER_RULES = [
    ("磁盘格式化", re.compile(r"\b(format\s+[a-z]:|mkfs(\.\w+)?\b)", re.I)),
    ("递归删除", re.compile(r"(rm\s+-[a-zA-Z]*r[a-zA-Z]*f|rmdir\s+/s|rd\s+/s|"
                            r"Remove-Item\s+-Recurse\s+-Force|"
                            r"del\s+/s\s+/q|shutil\.rmtree)", re.I)),
    ("注册表改写", re.compile(r"\b(reg\s+(add|delete|import|restore|copy|export)\b|regedit)", re.I)),
    ("计划任务", re.compile(r"\b(schtasks\s+/Create|Register-ScheduledTask|"
                            r"New-ScheduledTaskAction)", re.I)),
    ("账户/权限", re.compile(r"\b(net\s+(user|localgroup\s+\w*\s*administrators)|"
                             r"Add-LocalGroupMember)", re.I)),
    ("安全策略", re.compile(r"(netsh\s+advfirewall\s+set\s+\w+\s+state\s+off|"
                            r"Set-MpPreference\s+-DisableRealtimeMonitoring\s*\$true)", re.I)),
    ("引导配置", re.compile(r"\b(bcdedit|bootrec\b)", re.I)),
    ("批量杀进程", re.compile(r"(taskkill\s+/f\s+/im\s+\*|kill\s+-9\s+-1|"
                              r"pkill\s+-9\s+-f\s+/|Stop-Process\s+-Name\s+\*)", re.I)),
]


def is_dangerous(cmd: str) -> Tuple[bool, str]:
    """返回 (是否拦截, 类别/原因)。"""
    s = str(cmd or "")
    for label, pat in DANGER_RULES:
        if pat.search(s):
            return True, f"{label}（黑名单命中）"
    return False, ""


# ── ② 受限模式 ──
SANDBOX_DEFAULT = os.environ.get("LW_SANDBOX_DEFAULT", "1").strip().lower() \
    not in ("0", "false", "no", "off")

# 受限模式下禁止的 Python 模块
_RESTRICTED_MODULES = ("socket", "http", "urllib.request", "requests",
                       "httpx", "ftplib", "smtplib", "telnetlib", "subprocess")
_EXEC_LOCK = threading.Lock()


def _audit(msg: str) -> None:
    try:
        d = os.path.join(_ROOT, "data", "audit")
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, "sandbox_audit.log"), "a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {msg}\n")
    except Exception:
        logger.debug("suppressed exception")


def sandbox_enabled() -> bool:
    return bool(SANDBOX_DEFAULT)


def run_command(cmd: str, timeout: int = 30,
                env: Optional[Dict[str, str]] = None) -> Dict:
    """执行 shell 命令；危险命令直接拦截（{blocked, reason}）。"""
    bad, reason = is_dangerous(cmd)
    if bad:
        return {"blocked": True, "reason": reason, "ok": False,
                "stdout": "", "stderr": "", "exit_code": None}
    try:
        r = subprocess.run(str(cmd), shell=True, cwd=_ROOT, env=env,
                           capture_output=True, text=True,
                           timeout=max(1, int(timeout)))
        return {"blocked": False, "ok": r.returncode == 0,
                "exit_code": r.returncode,
                "stdout": (r.stdout or "")[-4000:],
                "stderr": (r.stderr or "")[-2000:]}
    except subprocess.TimeoutExpired:
        return {"blocked": False, "ok": False, "exit_code": None,
                "stdout": "", "stderr": "timeout"}
    except Exception as e:  # noqa: BLE001
        return {"blocked": False, "ok": False, "exit_code": None,
                "stdout": "", "stderr": str(e)[:200]}


# 受限模式包装器：拦截网络模块导入 + 仓库外文件写
_RESTRICT_WRAPPER = r'''
import sys, os, builtins
_R = os.environ.get("LW_SANDBOX_RESTRICTED") == "1"
_ROOT = os.environ.get("LW_SANDBOX_ROOT", "")
_BLK = ("socket","http","urllib","requests","httpx","ftplib","smtplib",
        "telnetlib","subprocess","asyncio")
class _Block:
    def find_spec(self, name, path=None, target=None):
        if _R and name.split(".")[0] in _BLK:
            raise ImportError("restricted module: " + name)
        return None
sys.meta_path.insert(0, _Block())
if _R and _ROOT:
    _open = builtins.open
    def _safe_open(file, mode="r", *a, **k):
        if any(str(mode).startswith(m) for m in ("w","a","x","+")):
            ap = os.path.abspath(str(file))
            if not ap.startswith(_ROOT):
                raise PermissionError("restricted write outside repo: " + ap)
        return _open(file, mode, *a, **k)
    builtins.open = _safe_open
'''


def execute_code(code: str, restricted: Optional[bool] = None,
                 timeout: int = 30) -> Dict:
    """在受限模式下执行 Python 代码片段。

    受限模式（默认开）：禁网络模块 / 禁写仓库外 / 30s 超时。
    关闭受限模式 → 写审计。
    """
    restricted = SANDBOX_DEFAULT if restricted is None else bool(restricted)
    if not restricted:
        _audit("[sandbox] 受限模式关闭（已审计）")
    program = (_RESTRICT_WRAPPER + "\n" + str(code)) if restricted else str(code)
    try:
        with _EXEC_LOCK:
            r = subprocess.run(
                [sys.executable, "-c", program],
                cwd=_ROOT, capture_output=True, text=True,
                timeout=max(1, int(timeout)),
                env={**os.environ,
                     "LW_SANDBOX_RESTRICTED": "1" if restricted else "0",
                     "LW_SANDBOX_ROOT": _ROOT},
            )
        return {"blocked": False, "ok": r.returncode == 0,
                "exit_code": r.returncode,
                "stdout": (r.stdout or "")[-4000:],
                "stderr": (r.stderr or "")[-2000:],
                "restricted": restricted}
    except subprocess.TimeoutExpired:
        return {"blocked": False, "ok": False, "exit_code": None,
                "stdout": "", "stderr": "timeout", "restricted": restricted}
    except Exception as e:  # noqa: BLE001
        return {"blocked": False, "ok": False, "exit_code": None,
                "stdout": "", "stderr": str(e)[:200], "restricted": restricted}


# ── ③ 文件写并发锁 ──
_WRITE_LOCKS: Dict[str, threading.Lock] = {}
_WRITE_META_LOCK = threading.Lock()


def _write_lock(path: str) -> threading.Lock:
    key = os.path.abspath(path)
    with _WRITE_META_LOCK:
        if key not in _WRITE_LOCKS:
            _WRITE_LOCKS[key] = threading.Lock()
        return _WRITE_LOCKS[key]


def write_file(path: str, content: str, mode: str = "w") -> Dict:
    """带并发锁的文件写：同名写排队，避免交叉覆盖。"""
    p = os.path.abspath(path)
    with _write_lock(p):
        try:
            d = os.path.dirname(p)
            if d:
                os.makedirs(d, exist_ok=True)
            with open(p, mode, encoding="utf-8" if "b" not in mode else None) as f:
                f.write(content)
            return {"ok": True, "path": p}
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": str(e)[:200]}


# ── ④ web_fetch 统一重试 ──
def web_fetch(url: str, retries: int = 3, base_delay: float = 0.5,
              timeout: int = 15) -> Dict:
    """GET 抓取，指数退避重试（base * 2^i）。"""
    try:
        import requests
    except ImportError:
        return {"ok": False, "error": "requests 未安装"}
    last = None
    for i in range(max(1, int(retries))):
        try:
            r = requests.get(url, timeout=timeout)
            if 200 <= r.status_code < 300:
                return {"ok": True, "status": r.status_code,
                        "text": r.text, "attempts": i + 1}
            last = f"HTTP {r.status_code}"
        except Exception as e:  # noqa: BLE001
            last = str(e)[:120]
        if i < retries - 1:
            time.sleep(base_delay * (2 ** i))
    return {"ok": False, "error": last, "attempts": max(1, int(retries))}


__all__ = ["is_dangerous", "run_command", "execute_code", "write_file",
           "web_fetch", "sandbox_enabled", "DANGER_RULES", "SANDBOX_DEFAULT"]
