# -*- coding: utf-8 -*-
"""
Skill: weather_query
描述: 查询城市当前天气与未来数日预报（Open-Meteo，免密钥）
"""

import os, json, traceback
from typing import Any, Dict, List, Optional

import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from skills_registry import SkillDef, SkillResult

_GEOCODE_URL = "https://geocoding-api.open-meteo.com/v1/search"
_FORECAST_URL = "https://api.open-meteo.com/v1/forecast"
_UA = {"User-Agent": "Mozilla/5.0 (LemonAgent/2.0)"}

# WMO 天气代码 → 中文描述（Open-Meteo 文档口径）
_WMO = {
    0: "晴", 1: "基本晴", 2: "局部多云", 3: "阴",
    45: "雾", 48: "雾凇雾",
    51: "毛毛雨(弱)", 53: "毛毛雨(中)", 55: "毛毛雨(强)",
    61: "小雨", 63: "中雨", 65: "大雨", 66: "冻雨", 67: "强冻雨",
    71: "小雪", 73: "中雪", 75: "大雪", 77: "米雪",
    80: "阵雨(弱)", 81: "阵雨(中)", 82: "阵雨(强)",
    85: "阵雪(弱)", 86: "阵雪(强)",
    95: "雷暴", 96: "雷暴伴冰雹(弱)", 99: "雷暴伴冰雹(强)",
}


def _http_get(url: str, params: Dict[str, Any]) -> Dict[str, Any]:
    import requests
    r = requests.get(url, params=params, timeout=15, headers=_UA)
    r.raise_for_status()
    return r.json()


def _geocode(city: str) -> List[Dict[str, Any]]:
    data = _http_get(_GEOCODE_URL, {"name": city, "count": 5, "language": "zh",
                                    "format": "json"})
    out = []
    for it in (data.get("results") or []):
        out.append({"name": it.get("name") or "",
                    "admin": it.get("admin1") or "",
                    "country": it.get("country") or "",
                    "lat": it.get("latitude"), "lon": it.get("longitude"),
                    "timezone": it.get("timezone") or "auto"})
    return out


def _handle_weather_query(city: str = "", days: int = 1) -> SkillResult:
    """查询城市天气。

    Args:
        city: 城市名（中文或英文，如 "杭州" / "Hangzhou"）
        days: 预报天数（1-7，1 表示仅当前）
    """
    city = str(city or "").strip()
    if not city:
        return SkillResult(success=False, error="city 参数为空")
    days = max(1, min(7, int(days or 1)))

    try:
        candidates = _geocode(city)
        if not candidates:
            return SkillResult(success=False,
                               error=f"未在城市库中找到「{city}」，请换用标准城市名")
        loc = candidates[0]
        params = {
            "latitude": loc["lat"], "longitude": loc["lon"],
            "current": "temperature_2m,relative_humidity_2m,apparent_temperature,"
                       "weather_code,wind_speed_10m,precipitation",
            "daily": "weather_code,temperature_2m_max,temperature_2m_min,"
                     "precipitation_probability_max",
            "forecast_days": days,
            "timezone": loc["timezone"] or "auto",
        }
        data = _http_get(_FORECAST_URL, params)
    except Exception as e:
        # 真实失败必须如实上报：此前这里是 TODO + success=True
        return SkillResult(success=False,
                           error=f"天气查询失败（{type(e).__name__}: {str(e)[:180]}）",
                           output=traceback.format_exc())

    cur = data.get("current") or {}
    if not cur:
        return SkillResult(success=False, error="接口未返回当前天气字段")
    code = int(cur.get("weather_code") or 0)
    where = " / ".join([x for x in (loc["country"], loc["admin"], loc["name"]) if x])
    lines = [
        f"📍 {where}（{loc['lat']:.2f}, {loc['lon']:.2f}）",
        f"现在: {_WMO.get(code, f'天气代码{code}')}，"
        f"{cur.get('temperature_2m')}°C（体感 {cur.get('apparent_temperature')}°C），"
        f"湿度 {cur.get('relative_humidity_2m')}%，"
        f"风速 {cur.get('wind_speed_10m')} km/h，"
        f"降水 {cur.get('precipitation')} mm",
    ]
    daily = data.get("daily") or {}
    dates = daily.get("time") or []
    for i, d in enumerate(dates):
        dcode = (daily.get("weather_code") or [0] * len(dates))[i]
        tmax = (daily.get("temperature_2m_max") or [None] * len(dates))[i]
        tmin = (daily.get("temperature_2m_min") or [None] * len(dates))[i]
        pop = (daily.get("precipitation_probability_max") or [None] * len(dates))[i]
        lines.append(f"{d}: {_WMO.get(int(dcode or 0), str(dcode))}，"
                     f"{tmin}~{tmax}°C" + (f"，降水概率 {pop}%" if pop is not None else ""))
    if len(candidates) > 1:
        lines.append("（同名候选: " + "、".join(
            f"{c['name']}[{c['admin'] or c['country']}]" for c in candidates[1:4]) + "）")

    return SkillResult(
        success=True,
        output="\n".join(lines),
        data={"location": loc, "current": cur, "daily": daily,
              "candidates": candidates[1:4], "source": "open-meteo"},
    )


WEATHER_QUERY_SKILL = SkillDef(
    name="weather_query",
    description="查询城市当前天气与未来数日预报（Open-Meteo 实时数据，免密钥）",
    parameters={
        "type": "object",
        "properties": {
            "city": {"type": "string", "description": "城市名称（中文或英文）"},
            "days": {"type": "integer", "description": "预报天数 1-7，1=仅当前",
                      "default": 1, "minimum": 1, "maximum": 7},
        },
        "required": ["city"],
    },
    handler=_handle_weather_query,
    category="system",
    timeout=30,
)
