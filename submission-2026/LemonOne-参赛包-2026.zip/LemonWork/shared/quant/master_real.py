# -*- coding: utf-8 -*-
"""★ W23-5: 真实主数据生成器

铁律：
  - 只接受真实数据源（baostock/akshare/tushare）
  - 无源 → 返回 {"skip": True, "reason": "no_source"}，禁止回退 synthetic
  - 写入 provenance.json: {"synthetic": false, "source": ..., "fetched_at": ...}
  - build_all_real(out_dir=data/quant/meta)
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import json
import os
import time
from typing import Any, Dict, Optional

import pandas as pd

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
META_DIR = os.path.join(_ROOT, "data", "quant", "meta")


def _provenance(source: str, out_dir: str, extra: Optional[dict] = None):
    os.makedirs(out_dir, exist_ok=True)
    p = {"synthetic": False, "source": source,
         "fetched_at": time.strftime("%Y-%m-%d %H:%M:%S")}
    if extra:
        p.update(extra)
    with open(os.path.join(out_dir, "provenance.json"), "w", encoding="utf-8") as f:
        json.dump(p, f, ensure_ascii=False, indent=2)
    return p


def _no_source(reason: str) -> Dict[str, Any]:
    return {"skip": True, "reason": reason or "no_source"}


def _fmt_date(d: str) -> str:
    d = str(d or "")
    if len(d) == 8 and d.isdigit():
        return f"{d[:4]}-{d[4:6]}-{d[6:]}"
    return d


def build_trade_cal_real(source: str = "baostock",
                         start: str = "20100101", end: str = "20261231",
                         out_dir: Optional[str] = None) -> Dict[str, Any]:
    """真实交易日历（baostock.query_trade_dates）"""
    out_dir = out_dir or META_DIR
    try:
        import baostock as bs
    except ImportError:
        return _no_source("baostock not installed")
    try:
        lg = bs.login()
        if lg.error_code != "0":
            return _no_source(f"baostock login failed: {lg.error_code}")
        rs = bs.query_trade_dates(start_date=_fmt_date(start), end_date=_fmt_date(end))
        rows = []
        while rs.error_code == "0" and rs.next():
            rows.append(rs.get_row_data())
        bs.logout()
        if not rows:
            return _no_source("baostock returned empty trade dates")
        df = pd.DataFrame(rows, columns=rs.fields)
        os.makedirs(out_dir, exist_ok=True)
        df.to_csv(os.path.join(out_dir, "trade_cal.csv"), index=False)
        _provenance(source, out_dir, {"rows": len(df), "kind": "trade_cal"})
        return {"ok": True, "rows": len(df), "kind": "trade_cal"}
    except Exception as e:
        return _no_source(f"baostock error: {str(e)[:120]}")


def build_securities_real(source: str = "baostock",
                          include_delisted: bool = True,
                          out_dir: Optional[str] = None) -> Dict[str, Any]:
    """真实证券代码表（baostock.query_stock_basic / query_all_stock）"""
    out_dir = out_dir or META_DIR
    try:
        import baostock as bs
    except ImportError:
        return _no_source("baostock not installed")
    try:
        lg = bs.login()
        if lg.error_code != "0":
            return _no_source(f"baostock login failed: {lg.error_code}")
        rs = bs.query_stock_basic()
        rows = []
        while rs.error_code == "0" and rs.next():
            rows.append(rs.get_row_data())
        bs.logout()
        if not rows:
            return _no_source("baostock returned empty stock basic")
        df = pd.DataFrame(rows, columns=rs.fields)
        # 标记退市
        if include_delisted and "status" in df.columns:
            df["status"] = df["status"].apply(lambda x: "delisted" if x == "0" else "listed")
        os.makedirs(out_dir, exist_ok=True)
        df.to_csv(os.path.join(out_dir, "securities.csv"), index=False)
        _provenance(source, out_dir, {"rows": len(df), "kind": "securities",
                                      "include_delisted": include_delisted})
        return {"ok": True, "rows": len(df), "kind": "securities"}
    except Exception as e:
        return _no_source(f"baostock error: {str(e)[:120]}")


def build_adj_factor_real(source: str = "baostock", codes: Optional[list] = None,
                          start: str = "20100101", end: str = "20261231",
                          out_dir: Optional[str] = None) -> Dict[str, Any]:
    """真实复权因子（baostock.query_adjust_factor 需要逐 code 查询）"""
    out_dir = out_dir or META_DIR
    if not codes:
        # ★ W25-H2: 缺省自动加载全市场 codes（来自 securities.csv）
        sec_path = os.path.join(out_dir, "securities.csv")
        if os.path.exists(sec_path):
            try:
                sec = pd.read_csv(sec_path)
                # type=1 为股票（2=指数/3=其它），复权因子仅对股票有意义
                if "type" in sec.columns:
                    sec = sec[sec["type"] == 1]
                codes = sec["code"].dropna().tolist()
            except Exception:
                codes = []
        if not codes:
            return _no_source("codes_required and no securities.csv")
    try:
        import baostock as bs
    except ImportError:
        return _no_source("baostock not installed")
    try:
        lg = bs.login()
        if lg.error_code != "0":
            return _no_source(f"baostock login failed: {lg.error_code}")
        frames = []
        for code in codes:
            rs = bs.query_adjust_factor(code=code,
                                        start_date=_fmt_date(start),
                                        end_date=_fmt_date(end))
            rows = []
            while rs.error_code == "0" and rs.next():
                rows.append(rs.get_row_data())
            if rows:
                frames.append(pd.DataFrame(rows, columns=rs.fields))
        bs.logout()
        if not frames:
            return _no_source("baostock returned empty adjust factor")
        df = pd.concat(frames, ignore_index=True)
        os.makedirs(out_dir, exist_ok=True)
        df.to_csv(os.path.join(out_dir, "adj_factor.csv"), index=False)
        _provenance(source, out_dir, {"rows": len(df), "kind": "adj_factor"})
        return {"ok": True, "rows": len(df), "kind": "adj_factor"}
    except Exception as e:
        return _no_source(f"baostock error: {str(e)[:120]}")


def build_all_real(source: str = "baostock", out_dir: Optional[str] = None,
                   codes: Optional[list] = None,
                   start: str = "20100101", end: str = "20261231") -> Dict[str, Any]:
    """构建真实主数据三件套（无源 → skip）"""
    out_dir = out_dir or META_DIR
    results = {}
    results["trade_cal"] = build_trade_cal_real(source, start=start, end=end,
                                                 out_dir=out_dir)
    results["securities"] = build_securities_real(source, out_dir=out_dir)
    results["adj_factor"] = build_adj_factor_real(source, codes=codes,
                                                   start=start, end=end,
                                                   out_dir=out_dir)
    all_skip = all(v.get("skip") for v in results.values())
    if all_skip:
        return {"skip": True, "reason": "no_source_available", "details": results}
    # ★ W25-H: 统一 provenance，避免最后一个成功的 kind 覆盖全部
    try:
        _provenance(source, out_dir, {
            "kinds": results,
            "synthetic": False,
            "fetched_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        })
    except Exception:
        logger.debug("suppressed exception")
    return {"ok": True, "details": results, "out_dir": out_dir}


if __name__ == "__main__":
    import sys
    src = sys.argv[1] if len(sys.argv) > 1 else "baostock"
    r = build_all_real(src)
    print(json.dumps(r, ensure_ascii=False, indent=2, default=str))
