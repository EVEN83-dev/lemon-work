# -*- coding: utf-8 -*-
"""D5 · PIT（Point-in-Time）快照。

1) 财报按公告日（ann_date）而非报告期（end_date）入库
2) 每条记录带 available_at，查询默认 <= as_of
3) 提供 as_of(snapshot_date) 视图

禁止：用 end_date 当可用时间；查询不带 as_of 默认取最新。
"""
from __future__ import annotations

from typing import List, Optional

import pandas as pd


def add_available_at(df: pd.DataFrame, ann_date_col: str = "ann_date",
                     end_date_col: str = "end_date",
                     default_ann: str = "19700101") -> pd.DataFrame:
    """为每条记录打 available_at = 公告日（缺失则回退到报告期末，并标注）。"""
    out = df.copy()
    if ann_date_col not in out.columns:
        out[ann_date_col] = out.get(end_date_col, default_ann)
    out["available_at"] = out[ann_date_col].astype("string").str.replace(
        r"[-/\.]", "", regex=True).str[:8]
    # 公告日缺失的记录：不得当作已可用
    mask = out["available_at"].isna() | (out["available_at"] == "")
    if mask.any():
        out.loc[mask, "available_at"] = "99999999"   # 永不可用，避免泄漏
    return out


def as_of_view(df: pd.DataFrame, as_of: str,
               date_col: str = "available_at") -> pd.DataFrame:
    """返回 as_of 时点可见的记录（available_at <= as_of）。

    as_of 必填：不允许默认取最新（防未来函数）。
    """
    if not as_of:
        raise ValueError("as_of 必填（PIT 查询不允许默认取最新）")
    a = str(as_of).replace("-", "").replace("/", "")[:8]
    if date_col not in df.columns:
        raise KeyError(f"缺少 {date_col} 列")
    return df[df[date_col].astype("string").str.replace(
        r"[-/\.]", "", regex=True).str[:8] <= a].copy()


def finance_pit_view(finance: pd.DataFrame, as_of: str) -> pd.DataFrame:
    """财报 PIT 视图：只含 as_of 时点已公告的财报。"""
    df = finance
    if "available_at" not in df.columns:
        df = add_available_at(df)
    return as_of_view(df, as_of)


def is_future_leak(finance: pd.DataFrame, as_of: str) -> int:
    """统计在 as_of 时点不可见但仍被包含的记录数（用于泄露检查）。"""
    if "available_at" not in finance.columns:
        finance = add_available_at(finance)
    a = str(as_of).replace("-", "")[:8]
    return int((finance["available_at"].astype("string").str[:8] > a).sum())


__all__ = ["add_available_at", "as_of_view", "finance_pit_view", "is_future_leak"]
