# -*- coding: utf-8 -*-
"""★ W22-6: 量化真实数据接入管道

ingest(source="tushare", kind="daily", start, end, codes)
  - 调 tushare_source
  - store.write_batch 落 raw parquet + manifest
  - master.build_all → meta 3 张主表
  - clean 标准化
  - 返回版本号与行数
铁律：无 TUSHARE_TOKEN → SKIP-ENV，不生成任何假数据
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import hashlib
import json
import os
import time
from typing import Any, Dict, Optional

import pandas as pd

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _write_frame(df: pd.DataFrame, root: str, kind: str, source: str,
                 version: str, extra: Optional[dict] = None) -> str:
    """★ W25-H: 把 clean 结果真正落盘（此前只算不写）"""
    dt = time.strftime("%Y%m%d")
    out = os.path.join(root, kind, f"dt={dt}")
    os.makedirs(out, exist_ok=True)
    path = os.path.join(out, f"part_{int(time.time())}.parquet")
    df.to_parquet(path, index=False)
    manifest = {
        "source": source, "kind": kind, "version": version,
        "rows": int(len(df)), "columns": list(df.columns),
        "sha256": hashlib.sha256(df.to_json().encode("utf-8")).hexdigest(),
        "written_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }
    if extra:
        manifest.update(extra)
    with open(os.path.join(out, f"_manifest_{int(time.time())}.json"), "w",
              encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)
    return path


def _write_pit(df: pd.DataFrame, root: str, kind: str, source: str,
               version: str) -> str:
    """★ W25-H: 生成 PIT 快照；日线按 T+1 可用，避免未来函数"""
    pit = df.copy()
    if "trade_date" in pit.columns:
        dt = pd.to_datetime(pit["trade_date"], errors="coerce")
        pit["available_at"] = (dt + pd.Timedelta(days=1)).dt.strftime("%Y-%m-%d")
    else:
        pit["available_at"] = time.strftime("%Y-%m-%d")
    return _write_frame(pit, root, kind, source, version,
                        extra={"pit": True})


def _token() -> str:
    return os.environ.get("TUSHARE_TOKEN", "").strip()


def _baostock_available() -> bool:
    try:
        import baostock  # noqa: F401
        return True
    except ImportError:
        return False


def ingest(source: str = "baostock", kind: str = "daily",
           start: str = "", end: str = "", codes: Optional[list] = None,
           out_dir: Optional[str] = None) -> Dict[str, Any]:
    """真实数据接入。

    ★ W23-6: 源优先级 baostock（免费）→ akshare → tushare（可选）。
    无源 → {"skip": True, "reason": "no_source_available"}，禁止假数据兜底。
    """
    # ── 源选择 ──
    src = None
    src_name = None
    if source == "baostock" and _baostock_available():
        try:
            from shared.quant.sources import baostock_source as _bs
            src = _bs
            src_name = "baostock"
        except ImportError:
            logger.debug("suppressed exception")
    if src is None and source == "tushare":
        if not _token():
            return {"skip": True, "reason": "TUSHARE_TOKEN not set",
                    "message": "未设置 TUSHARE_TOKEN，跳过真实数据接入（不生成假数据）"}
        try:
            from shared.quant.sources import tushare_source as _ts
            src = _ts
            src_name = "tushare"
        except ImportError:
            logger.debug("suppressed exception")
    if src is None:
        return {"skip": True, "reason": "no_source_available",
                "message": f"源 {source} 不可用（baostock/tushare 均未安装或无 token）"}

    out_dir = out_dir or os.path.join(_ROOT, "data", "quant")
    raw_root = os.path.join(out_dir, "raw")
    meta_dir = os.path.join(out_dir, "meta")
    clean_dir = os.path.join(out_dir, "clean")
    os.makedirs(raw_root, exist_ok=True)
    os.makedirs(meta_dir, exist_ok=True)
    os.makedirs(clean_dir, exist_ok=True)

    # ── 1. 抓取 ──
    params = {"start_date": start, "end_date": end,
              "ts_code": ",".join(codes) if codes else "",
              "code": ",".join(codes) if codes else "",
              "start": start, "end": end}
    try:
        if src_name == "baostock":
            code = codes[0] if codes else ""
            # baostock 需要 YYYY-MM-DD 格式
            def _fmt(d):
                d = str(d or "")
                if len(d) == 8 and d.isdigit():
                    return f"{d[:4]}-{d[4:6]}-{d[6:]}"
                return d
            df = src.fetch(kind, {"code": code, "start": _fmt(start), "end": _fmt(end)})
        else:
            s = src.TushareSource() if hasattr(src, "TushareSource") else src
            df = s.fetch(kind, params)
    except Exception as e:
        return {"skip": False, "error": f"fetch failed: {str(e)[:160]}"}
    if df is None or len(df) == 0:
        return {"skip": False, "error": "无数据返回（检查源/网络/日期范围）"}
    # ★ W25-H: 单 code 兜底补 ts_code，保证 clean/PIT 可做横截面
    if "ts_code" not in df.columns and codes:
        df = df.copy()
        df["ts_code"] = codes[0] if len(codes) == 1 else ""

    # ── 2. 落 raw ──
    try:
        from shared.quant import store as _store
        res = _store.write_batch(df, source=source, kind=kind, root=raw_root)
    except Exception as e:
        return {"skip": False, "error": f"write_batch failed: {str(e)[:160]}"}

    # ── 3. master 三件套（★ W23-5: 改用 master_real，禁止回退 synthetic）──
    meta_info = None
    try:
        from shared.quant import master_real as _master_real
        meta_info = _master_real.build_all_real(
            out_dir=meta_dir, codes=codes, start=start, end=end)
        if meta_info.get("skip"):
            return {"skip": False, "error": f"master_real skipped: {meta_info.get('reason')}"}
    except ImportError as e:
        return {"skip": False, "error": f"master_real import failed: {str(e)[:120]}"}

    # ── 4. clean 标准化 ──
    clean_info = None
    try:
        from shared.quant import clean as _clean
        _r = _clean.clean(df)
        # clean.clean 返回 (df, stats) tuple
        if isinstance(_r, tuple):
            df, clean_info = _r
        else:
            df, clean_info = _r, {}
    except Exception as e:
        clean_info = {"error": str(e)[:120]}

    version = "v1"
    try:
        h = hashlib.sha256(df.to_json().encode("utf-8")).hexdigest()[:12]
        version = f"v1-{h}"
    except Exception:
        logger.debug("suppressed exception")

    # ★ W25-H: clean / PIT 真正落盘
    clean_path = None
    pit_path = None
    try:
        clean_path = _write_frame(df, clean_dir, kind, source, version)
        pit_path = _write_pit(df, os.path.join(out_dir, "pit"), kind, source, version)
    except Exception as e:
        clean_info = {**(clean_info or {}), "write_error": str(e)[:160]}

    return {
        "skip": False,
        "version": version,
        "rows": int(len(df)),
        "source": source,
        "kind": kind,
        "date_range": [start, end],
        "raw": res,
        "meta": meta_info,
        "clean": clean_info,
        "clean_path": clean_path,
        "pit_path": pit_path,
    }


if __name__ == "__main__":
    import json, sys
    r = ingest()
    print(json.dumps(r, ensure_ascii=False, indent=2, default=str))
    sys.exit(3 if r.get("skip") else (2 if r.get("error") else 0))
