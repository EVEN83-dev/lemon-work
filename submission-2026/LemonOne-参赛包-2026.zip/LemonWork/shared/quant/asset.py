# -*- coding: utf-8 -*-
"""★ W25-H7-T2: 量化数据资产扫描（纯函数，无 Qt）

只读 parquet 元数据统计行数，避免把 230 万行读进内存。
输出结构供 quant_asset_card 渲染：
  {generated_at, source, meta:{...}, layers:[{name,rows,codes,parts,latest}]}
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import glob
import json
import os
import re
import time
from typing import Optional

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DEFAULT_ROOT = os.path.join(_ROOT, "data", "quant")

_META_FILES = ("trade_cal", "securities", "adj_factor")
_LAYERS = (("raw", "原始层"), ("clean", "清洗层"), ("pit", "PIT 层"))


def _csv_rows(path: str) -> int:
    """只数换行，不解析 CSV"""
    try:
        with open(path, "rb") as f:
            n = sum(chunk.count(b"\n") for chunk in iter(lambda: f.read(1 << 20), b""))
        return max(0, n - 1)  # 去表头
    except Exception:
        return 0


def _parquet_rows(path: str) -> int:
    """优先读 parquet footer 元数据（不加载数据）"""
    try:
        import pyarrow.parquet as pq
        return int(pq.ParquetFile(path).metadata.num_rows)
    except Exception:
        logger.debug("suppressed exception")
    try:
        import pandas as pd
        return int(len(pd.read_parquet(path)))
    except Exception:
        return 0


def _layer_codes(parts: list) -> int:
    """统计 ts_code 唯一值（只读该列）"""
    seen = set()
    try:
        import pyarrow.parquet as pq
        for p in parts:
            try:
                t = pq.read_table(p, columns=["ts_code"])
                seen.update(t.column("ts_code").to_pylist())
            except Exception:
                continue
    except Exception:
        return 0
    return len([c for c in seen if c])


def _dt_of(path: str) -> str:
    m = re.search(r"dt=(\d{8})", path.replace("\\", "/"))
    return m.group(1) if m else ""


def scan_assets(root: Optional[str] = None, with_codes: bool = True) -> dict:
    root = root or DEFAULT_ROOT
    out = {
        "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "root": root,
        "source": "",
        "synthetic": False,
        "meta": [],
        "layers": [],
        "total_parquet_rows": 0,
        "total_parts": 0,
    }

    # ── 主数据 CSV ──
    meta_dir = os.path.join(root, "meta")
    for name in _META_FILES:
        p = os.path.join(meta_dir, name + ".csv")
        if os.path.exists(p):
            out["meta"].append({
                "name": name,
                "rows": _csv_rows(p),
                "size_kb": round(os.path.getsize(p) / 1024, 1),
            })

    # ── provenance ──
    prov = os.path.join(meta_dir, "provenance.json")
    if os.path.exists(prov):
        try:
            with open(prov, "r", encoding="utf-8") as f:
                pj = json.load(f)
            out["source"] = pj.get("source", "") or ""
            out["synthetic"] = bool(pj.get("synthetic", False))
            out["fetched_at"] = pj.get("fetched_at", "")
        except Exception:
            logger.debug("suppressed exception")

    # ── 三层 parquet ──
    for layer, label in _LAYERS:
        parts = sorted(glob.glob(os.path.join(root, layer, "**", "part_*.parquet"),
                                 recursive=True))
        rows = sum(_parquet_rows(p) for p in parts)
        dates = [d for d in (_dt_of(p) for p in parts) if d]
        codes = _layer_codes(parts) if (with_codes and layer in ("clean", "pit") and parts) else 0
        out["layers"].append({
            "name": layer,
            "label": label,
            "parts": len(parts),
            "rows": rows,
            "codes": codes,
            "latest": max(dates) if dates else "",
        })
        out["total_parquet_rows"] += rows
        out["total_parts"] += len(parts)

    return out


if __name__ == "__main__":
    print(json.dumps(scan_assets(), ensure_ascii=False, indent=2))
