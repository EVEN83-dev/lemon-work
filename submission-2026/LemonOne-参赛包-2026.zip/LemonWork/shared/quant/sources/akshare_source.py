# -*- coding: utf-8 -*-
"""akshare 备用源适配器（需 akshare 库）。列名与 tushare 源统一。"""
from __future__ import annotations

from typing import Any, Dict, Optional

import pandas as pd

from .base import SourceAdapter

_RENAME = {
    "日期": "trade_date", "开盘": "open", "最高": "high", "最低": "low",
    "收盘": "close", "成交量": "vol", "成交额": "amount", "代码": "ts_code",
}


class AkshareSource(SourceAdapter):
    name = "akshare"

    def fetch(self, kind: str, params: Optional[Dict[str, Any]] = None) -> pd.DataFrame:
        p = params or {}
        import akshare as ak  # type: ignore
        if kind == "daily":
            df = ak.stock_zh_a_hist(symbol=p.get("symbol", ""), period=p.get("period", "daily"),
                                    start_date=p.get("start_date"), end_date=p.get("end_date"),
                                    adjust=p.get("adjust", ""))
            df = df.rename(columns=_RENAME)
            if "ts_code" not in df.columns and "symbol" in df.columns:
                df = df.rename(columns={"symbol": "ts_code"})
            return df
        if kind == "trade_cal":
            df = ak.tool_trade_date_hist_sina()
            df = df.rename(columns={"trade_date": "cal_date"})
            df["is_open"] = 1
            df["pretrade_date"] = df["cal_date"].shift(1).fillna("")
            df["exchange"] = "SSE"
            return df[["exchange", "cal_date", "is_open", "pretrade_date"]]
        raise ValueError(f"akshare 不支持 kind={kind}")


def available() -> bool:
    try:
        import akshare  # noqa: F401
        return True
    except Exception:
        return False


__all__ = ["AkshareSource", "available"]
