# -*- coding: utf-8 -*-
"""★ W25-H7-T3: 巨潮资讯官方公告 JSON 适配器

- 公开 POST 接口：hisAnnouncement/query
- 单请求限速 1.5s，失败返回空 DataFrame（不抛异常）
- 输出列固定：ts_code, ann_date, title, pdf_url, adjunct_url
合规：公开披露数据、单请求、不绕过任何访问控制、不并发。
"""
from __future__ import annotations

import time
from datetime import datetime
from typing import Any, Dict, Optional

import pandas as pd

from .base import SourceAdapter

_API = "http://www.cninfo.com.cn/new/hisAnnouncement/query"
_UA = ("LemonWork-Crawl/1.0 (+https://github.com/EVEN83-dev/lemon-work)")
_COLUMNS = ["ts_code", "ann_date", "title", "pdf_url", "adjunct_url"]


def _fmt_se_date(start: str, end: str) -> str:
    def _one(d: str) -> str:
        d = str(d or "").strip()
        if len(d) == 8 and d.isdigit():
            return f"{d[:4]}-{d[4:6]}-{d[6:]}"
        return d
    s, e = _one(start), _one(end)
    if s and e:
        return f"{s}~{e}"
    return ""


def _ms_to_date(ms: Any) -> str:
    try:
        v = int(ms)
        if v > 10 ** 11:  # 毫秒
            v //= 1000
        return datetime.fromtimestamp(v).strftime("%Y-%m-%d")
    except Exception:
        return ""


class CninfoAdapter(SourceAdapter):
    """巨潮公告 JSON 源"""

    name = "cninfo"
    rate_limit = 1.5

    def __init__(self, timeout: int = 10, **kw):
        super().__init__(**kw)
        self._timeout = timeout

    def _post(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        import requests
        headers = {
            "User-Agent": _UA,
            "Referer": "http://www.cninfo.com.cn/new/commonUrl?url=disclosure/list/notice",
            "X-Requested-With": "XMLHttpRequest",
        }
        r = requests.post(_API, data=payload, headers=headers, timeout=self._timeout)
        if r.status_code != 200:
            raise RuntimeError(f"http_{r.status_code}")
        return r.json() or {}

    def fetch(self, kind: str = "announcement",
              params: Optional[Dict[str, Any]] = None) -> pd.DataFrame:
        if kind != "announcement":
            raise ValueError(f"cninfo 不支持 kind={kind}")
        p = params or {}
        payload = {
            "pageNum": int(p.get("page_num", 1) or 1),
            "pageSize": int(p.get("page_size", 30) or 30),
            "column": str(p.get("column", "szse") or "szse"),
            "tabName": "fulltext",
            "plate": "",
            "stock": "",
            "searchkey": "",
            "secid": "",
            "category": "",
            "trade": "",
            "seDate": _fmt_se_date(p.get("start", ""), p.get("end", "")),
            "sortName": "",
            "sortType": "",
            "isHLtitle": "true",
        }
        try:
            data = self._post(payload)
        except Exception as e:
            print(f"[cninfo] 请求失败: {str(e)[:120]}")
            return pd.DataFrame(columns=_COLUMNS)
        finally:
            time.sleep(1.5)  # 域限速

        rows = []
        for a in (data.get("announcements") or []):
            adj = str(a.get("adjunctUrl") or "")
            pdf_url = ("http://static.cninfo.com.cn/" + adj) if adj else ""
            rows.append({
                "ts_code": str(a.get("secCode") or ""),
                "ann_date": _ms_to_date(a.get("announcementTime")),
                "title": str(a.get("announcementTitle") or "").strip(),
                "pdf_url": pdf_url,
                "adjunct_url": adj,
            })
        if not rows:
            return pd.DataFrame(columns=_COLUMNS)
        return pd.DataFrame(rows, columns=_COLUMNS)


__all__ = ["CninfoAdapter", "_fmt_se_date"]
