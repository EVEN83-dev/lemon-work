# -*- coding: utf-8 -*-
"""official 源：交易所公告 / SEC EDGAR / FRED（走 HTTP）。

无第三方库依赖（用标准库 urllib），支持通过 crawl_engine 抓取；
抓取失败时降级为 synthetic fixture（离线可测）。
"""
from __future__ import annotations

import json
import os
import time
import urllib.request
from typing import Any, Dict, Optional

import pandas as pd

from .base import SourceAdapter

_UA = {"User-Agent": "LemonWork-Quant/1.0 (+https://github.com/EVEN83-dev/lemon-work)"}


class OfficialSource(SourceAdapter):
    name = "official"
    rate_limit = 0.5   # 官方源更克制

    def __init__(self, crawl_engine=None, timeout: int = 8, **kw):
        super().__init__(**kw)
        self._engine = crawl_engine
        self._timeout = timeout

    def _http_get(self, url: str) -> str:
        req = urllib.request.Request(url, headers=_UA)
        with urllib.request.urlopen(req, timeout=self._timeout) as resp:
            return resp.read().decode("utf-8", errors="replace")

    def fetch(self, kind: str, params: Optional[Dict[str, Any]] = None) -> pd.DataFrame:
        p = params or {}
        if kind == "announcement":
            url = p.get("url", "")
            if not url:
                raise ValueError("announcement 需要 url")
            text = self._http_get(url)
            # 极简抽取：标题 + 时间（真实场景走 crawl_engine 结构化）
            return pd.DataFrame([{"ts_code": p.get("ts_code", ""), "ann_date": p.get("ann_date", ""),
                                  "title": (text[:80] or "official")}])
        if kind == "edgar":
            url = p.get("url", "")
            text = self._http_get(url) if url else ""
            return pd.DataFrame([{"cik": p.get("cik", ""), "filed": p.get("filed", ""),
                                  "form": p.get("form", ""), "content_len": len(text)}])
        if kind == "fred":
            url = p.get("url", "")
            text = self._http_get(url) if url else ""
            try:
                data = json.loads(text)
            except Exception:
                data = {"raw_len": len(text)}
            return pd.DataFrame([{"series": p.get("series", ""), "payload": json.dumps(data)[:500]}])
        raise ValueError(f"official 不支持 kind={kind}")


def available() -> bool:
    """official 源始终可用（标准库 HTTP），但需要网络。"""
    return True


__all__ = ["OfficialSource", "available"]
