# -*- coding: utf-8 -*-
"""D2 · 采集适配器：统一接口 fetch(kind, params) -> DataFrame。

三源：
  tushare_source.py   日线/复权因子/交易日历/财报/公告（需 tushare）
  akshare_source.py   备用源（需 akshare）
  official_source.py  交易所公告 / SEC EDGAR / FRED（走 HTTP）

依赖缺失时自动降级为 synthetic 适配器（确定性、离线、可复现），
保证 D 集群全链路在无付费库环境下仍可跑通与测试。
"""
from .base import SourceAdapter, fetch_with_retry, rate_limit

__all__ = ["SourceAdapter", "fetch_with_retry", "rate_limit"]
