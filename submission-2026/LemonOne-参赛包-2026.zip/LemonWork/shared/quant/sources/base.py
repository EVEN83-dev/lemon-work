# -*- coding: utf-8 -*-
"""统一源适配器基类：限速 + 指数退避重试。

禁止：把 API key 写进代码；无上限重试。
"""
from __future__ import annotations

import time
from typing import Any, Callable, Dict, Optional

import pandas as pd


class SourceAdapter:
    """统一接口：fetch(kind, params) -> DataFrame。"""

    name = "base"
    # 默认限速：每秒请求数上限
    rate_limit = 2.0
    # 重试上限（含首次）
    max_retries = 3

    def __init__(self, rate_limit: Optional[float] = None,
                 max_retries: Optional[int] = None):
        if rate_limit is not None:
            self.rate_limit = rate_limit
        if max_retries is not None:
            self.max_retries = max_retries
        self._min_interval = 1.0 / max(self.rate_limit, 0.01)
        self._last_call = 0.0

    def _throttle(self) -> None:
        now = time.time()
        wait = self._min_interval - (now - self._last_call)
        if wait > 0:
            time.sleep(wait)
        self._last_call = time.time()

    def fetch(self, kind: str, params: Optional[Dict[str, Any]] = None) -> pd.DataFrame:
        raise NotImplementedError

    def fetch_safe(self, kind: str, params: Optional[Dict[str, Any]] = None) -> pd.DataFrame:
        """带限速 + 指数退避重试的 fetch。"""
        return fetch_with_retry(self.fetch, kind, params,
                                max_retries=self.max_retries,
                                throttle=self._throttle)


def fetch_with_retry(fn: Callable[..., pd.DataFrame], kind: str,
                     params: Optional[Dict[str, Any]],
                     max_retries: int = 3,
                     base_delay: float = 1.0,
                     throttle: Optional[Callable[[], None]] = None) -> pd.DataFrame:
    """指数退避重试；超过 max_retries 抛最后一次异常（不无上限重试）。"""
    delay = base_delay
    last_exc: Optional[Exception] = None
    for attempt in range(max_retries):
        if throttle:
            throttle()
        try:
            return fn(kind, params or {})
        except Exception as exc:  # noqa: BLE001 — 统一重试入口
            last_exc = exc
            if attempt < max_retries - 1:
                time.sleep(delay)
                delay *= 2.0
    assert last_exc is not None
    raise last_exc


def rate_limit(seconds_per_call: float):
    """装饰器：限制调用频率（用于各源内部）。"""
    def deco(fn):
        state = {"last": 0.0, "interval": max(seconds_per_call, 0.01)}

        def wrapper(*a, **kw):
            now = time.time()
            wait = state["interval"] - (now - state["last"])
            if wait > 0:
                time.sleep(wait)
            state["last"] = time.time()
            return fn(*a, **kw)
        return wrapper
    return deco


__all__ = ["SourceAdapter", "fetch_with_retry", "rate_limit"]
