# -*- coding: utf-8 -*-
"""★ W23-6: Baostock 源（免费、无 token）

统一列：ts_code, trade_date, open, high, low, close, volume, amount, adj_factor
缺库 → available() = False
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import os
import sys
from typing import Any, Dict, Optional

import pandas as pd

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


def available() -> bool:
    try:
        import baostock  # noqa: F401
        return True
    except ImportError:
        return False


def _login():
    import baostock as bs
    lg = bs.login()
    if lg.error_code != "0":
        raise RuntimeError(f"baostock login failed: {lg.error_code}")
    return bs


def _logout(bs):
    try:
        bs.logout()
    except Exception:
        logger.debug("suppressed exception")


def _to_df(rs) -> pd.DataFrame:
    rows = []
    while rs.error_code == "0" and rs.next():
        rows.append(rs.get_row_data())
    return pd.DataFrame(rows, columns=rs.fields)


def query_trade_dates(start: str, end: str) -> pd.DataFrame:
    """交易日历"""
    bs = _login()
    try:
        rs = bs.query_trade_dates(start_date=start, end_date=end)
        return _to_df(rs)
    finally:
        _logout(bs)


def query_stock_basic() -> pd.DataFrame:
    """证券代码表"""
    bs = _login()
    try:
        rs = bs.query_stock_basic()
        return _to_df(rs)
    finally:
        _logout(bs)


def query_history_k_data_plus(code: str, start: str, end: str,
                                fields: str = "date,open,high,low,close,volume,amount,adjustflag",
                                frequency: str = "d") -> pd.DataFrame:
    """日线（含复权标志）"""
    bs = _login()
    try:
        rs = bs.query_history_k_data_plus(code, fields,
                                          start_date=start, end_date=end,
                                          frequency=frequency, adjustflag="3")
        return _to_df(rs)
    finally:
        _logout(bs)


def query_adjust_factor(code: str = "", start: str = "", end: str = "") -> pd.DataFrame:
    """复权因子（需要 code）"""
    bs = _login()
    try:
        rs = bs.query_adjust_factor(code=code, start_date=start, end_date=end)
        return _to_df(rs)
    finally:
        _logout(bs)


def fetch(kind: str, params: Dict[str, Any]) -> Optional[pd.DataFrame]:
    """统一接口 fetch(kind, params) -> DataFrame 或 None"""
    if not available():
        return None
    try:
        if kind == "trade_cal":
            return query_trade_dates(params.get("start", ""), params.get("end", ""))
        elif kind == "stock_basic":
            return query_stock_basic()
        elif kind == "daily":
            df = query_history_k_data_plus(
                params.get("code", ""), params.get("start", ""), params.get("end", ""))
            if df is None or len(df) == 0:
                return None
            # 标准化列名
            df = df.rename(columns={
                "date": "trade_date",
                "open": "open", "high": "high", "low": "low",
                "close": "close", "volume": "volume", "amount": "amount",
                "adjustflag": "adj_factor",
            })
            # 代码格式 baostock: sh.600000 → ts: 600000.SH
            code = params.get("code", "")
            if "." in str(code):
                parts = str(code).split(".")
                df["ts_code"] = f"{parts[1]}.{parts[0].upper()}"
            else:
                df["ts_code"] = str(code)
            for c in ("open", "high", "low", "close", "volume", "amount"):
                if c in df.columns:
                    df[c] = pd.to_numeric(df[c], errors="coerce")
            return df
        return None
    except Exception as e:
        print(f"[baostock_source] fetch error: {e}")
        return None


if __name__ == "__main__":
    print("available:", available())
    if available():
        df = fetch("daily", {"code": "sh.600000", "start": "2026-01-01", "end": "2026-01-31"})
        print(df.head() if df is not None else "no data")
