# -*- coding: utf-8 -*-
"""tushare 源适配器（需 tushare 库）。

列名统一为内部契约：
  日线    ts_code,trade_date,open,high,low,close,vol,amount
  复权因子 ts_code,trade_date,adj_factor
  交易日历 exchange,cal_date,is_open,pretrade_date
  财报    ts_code,ann_date,end_date,revenue,net_profit
  公告    ts_code,ann_date,title

库缺失时抛出 ImportError，由上层降级到 synthetic。
API key 从环境变量 TUSHARE_TOKEN 读取，**绝不写进代码**。
"""
from __future__ import annotations

import os
from typing import Any, Dict, Optional

import pandas as pd

from .base import SourceAdapter


class TushareSource(SourceAdapter):
    name = "tushare"

    def __init__(self, token: Optional[str] = None, **kw):
        super().__init__(**kw)
        self._token = token or os.environ.get("TUSHARE_TOKEN", "")
        self._api = None

    def _connect(self):
        if self._api is not None:
            return self._api
        if not self._token:
            raise RuntimeError("TUSHARE_TOKEN 未设置")
        import tushare as ts  # type: ignore
        ts.set_token(self._token)
        self._api = ts.pro_api()
        return self._api

    def fetch(self, kind: str, params: Optional[Dict[str, Any]] = None) -> pd.DataFrame:
        p = params or {}
        api = self._connect()
        if kind == "daily":
            return api.daily(ts_code=p.get("ts_code", ""), start_date=p.get("start_date"),
                             end_date=p.get("end_date"))
        if kind == "adj_factor":
            return api.adj_factor(ts_code=p.get("ts_code", ""), start_date=p.get("start_date"),
                                  end_date=p.get("end_date"))
        if kind == "trade_cal":
            return api.trade_cal(exchange=p.get("exchange", "SSE"),
                                 start_date=p.get("start_date"), end_date=p.get("end_date"))
        if kind == "finance":
            return api.income(ts_code=p.get("ts_code", ""), period=p.get("period"))
        if kind == "announcement":
            return api.anns(ts_code=p.get("ts_code", ""))
        raise ValueError(f"tushare 不支持 kind={kind}")


def available() -> bool:
    try:
        import tushare  # noqa: F401
        return True
    except Exception:
        return False


__all__ = ["TushareSource", "available"]
