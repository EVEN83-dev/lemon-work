# -*- coding: utf-8 -*-
"""D7 · 跨源比对。

1) 两源按 ts_code+trade_date 对齐
2) 计算 close/volume/amount 差异率
3) 差异 >0.5% 输出明细 CSV（含两源原值）

禁止：只比收盘价不比成交额；差异明细不留原值。
"""
from __future__ import annotations

import os
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

KEYS = ["ts_code", "trade_date"]
COMPARE_FIELDS = ["close", "vol", "amount"]
THRESHOLD = 0.005


def compare(df_a: pd.DataFrame, df_b: pd.DataFrame,
            fields: Optional[List[str]] = None,
            threshold: float = THRESHOLD) -> Dict:
    """返回 {aligned, diffs: [{field, rows, violation_rows, sample}], summary}。"""
    fields = [f for f in (fields or COMPARE_FIELDS)
              if f in df_a.columns and f in df_b.columns]
    keys = [k for k in KEYS if k in df_a.columns and k in df_b.columns]
    if not keys or not fields:
        return {"aligned": 0, "diffs": [], "summary": {"reason": "缺对齐键或字段"}}

    a = df_a[keys + fields].astype({f: float for f in fields})
    b = df_b[keys + fields].astype({f: float for f in fields})
    m = a.merge(b, on=keys, suffixes=("_a", "_b"))
    diffs = []
    for f in fields:
        denom = m[f"{f}_b"].abs().replace(0, np.nan)
        rate = ((m[f"{f}_a"] - m[f"{f}_b"]).abs() / denom)
        bad = rate > threshold
        n = int(bad.sum())
        sample = []
        if n:
            rows = m.loc[bad, keys + [f"{f}_a", f"{f}_b"]].head(10)
            rows = rows.assign(diff_rate=rate[bad].head(10).round(6))
            sample = rows.to_dict("records")
        diffs.append({"field": f, "rows": len(m), "violation_rows": n,
                      "violation_rate": round(n / max(len(m), 1), 6),
                      "sample": sample})
    return {"aligned": len(m), "diffs": diffs,
            "summary": {"violations": sum(d["violation_rows"] for d in diffs),
                        "fields": fields, "threshold": threshold}}


def export_diff_csv(df_a: pd.DataFrame, df_b: pd.DataFrame, out_path: str,
                    fields: Optional[List[str]] = None,
                    threshold: float = THRESHOLD) -> int:
    """差异明细写 CSV（含两源原值），返回写出行数。"""
    fields = [f for f in (fields or COMPARE_FIELDS)
              if f in df_a.columns and f in df_b.columns]
    keys = [k for k in KEYS if k in df_a.columns and k in df_b.columns]
    if not keys or not fields:
        return 0
    a = df_a[keys + fields].astype({f: float for f in fields})
    b = df_b[keys + fields].astype({f: float for f in fields})
    m = a.merge(b, on=keys, suffixes=("_a", "_b"))
    frames = []
    for f in fields:
        denom = m[f"{f}_b"].abs().replace(0, np.nan)
        rate = ((m[f"{f}_a"] - m[f"{f}_b"]).abs() / denom)
        bad = rate > threshold
        if bad.any():
            part = m.loc[bad, keys + [f"{f}_a", f"{f}_b"]].copy()
            part["field"] = f
            part["diff_rate"] = rate[bad].round(6)
            frames.append(part)
    if not frames:
        return 0
    out = pd.concat(frames, ignore_index=True)
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    out.to_csv(out_path, index=False, encoding="utf-8-sig")
    return int(len(out))


__all__ = ["KEYS", "COMPARE_FIELDS", "THRESHOLD", "compare", "export_diff_csv"]
