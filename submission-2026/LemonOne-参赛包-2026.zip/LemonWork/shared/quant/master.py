# -*- coding: utf-8 -*-
"""D1 · 主数据三件套（合成数据生成器）。

三张表：
  trade_cal   交易日历  exchange,cal_date,is_open,pretrade_date
  securities  证券代码表 ts_code,symbol,name,exchange,list_date,delist_date,status,board
  adj_factor  复权因子  ts_code,trade_date,adj_factor

数据为 **synthetic**（见 shared/quant/__init__.py 声明）：
  - 交易日历按 A 股规则生成（周末休市 + 法定节假日）
  - 退市样本 >=100 条（status=delisted）
  - 复权因子按除权事件链式生成，保证 后复权价 = 原始价 * 因子

禁止：只存当前在市标的；用前复权价反推因子。
"""
from __future__ import annotations

import datetime as dt
import json
import os
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from shared.quant import ensure_dirs
from shared.quant import DATA_ROOT

# A 股法定节假日（2010-2026，简化但确定性的固定表；用于合成数据）
_HOLIDAYS = {
    # 元旦
    "20100101", "20110101", "20120102", "20130101", "20140101", "20150101",
    "20160101", "20170102", "20180101", "20190101", "20200101", "20210101",
    "20220103", "20230102", "20240101", "20250101", "20260101",
    # 春节（取法定假期首两日做代表，合成用途）
    "20100215", "20100216", "20110203", "20110204", "20120123", "20120124",
    "20130211", "20130212", "20140131", "20140203", "20150219", "20150220",
    "20160208", "20160209", "20170127", "20170130", "20180215", "20180216",
    "20190204", "20190205", "20200124", "20200127", "20210211", "20210212",
    "20220131", "20220201", "20230123", "20230124", "20240209", "20240212",
    "20250128", "20250129", "20260216", "20260217",
    # 清明/五一/端午/中秋/国庆 代表日
    "20100405", "20100503", "20100614", "20100922", "20101001",
    "20110405", "20110502", "20110606", "20110912", "20111003",
    "20120404", "20120501", "20120622", "20120930", "20121001",
    "20130404", "20130429", "20130610", "20130919", "20131001",
    "20140407", "20140501", "20140602", "20140908", "20141001",
    "20150406", "20150501", "20150622", "20150927", "20151001",
    "20160404", "20160502", "20160609", "20160915", "20161003",
    "20170403", "20170501", "20170529", "20171002", "20171004",
    "20180405", "20180430", "20180618", "20180924", "20181001",
    "20190405", "20190501", "20190607", "20190913", "20191001",
    "20200406", "20200501", "20200625", "20201001", "20201002",
    "20210405", "20210503", "20210614", "20210920", "20211001",
    "20220405", "20220502", "20220603", "20220912", "20221003",
    "20230405", "20230501", "20230622", "20230929", "20231002",
    "20240404", "20240501", "20240610", "20240916", "20241001",
    "20250404", "20250501", "20250602", "20250908", "20251001",
    "20260406", "20260501", "20260619", "20260925", "20261001",
}

# 合成证券池：500 只在市 + 120 只退市（满足 D1 退市样本 >=100）
_N_LISTED = 500
_N_DELISTED = 120
_BOARDS = ["主板", "创业板", "科创板"]


def _d(s: str) -> dt.date:
    return dt.datetime.strptime(s, "%Y%m%d").date()


def build_trade_cal(start: str = "20100101", end: str = "20261231",
                    exchange: str = "SSE") -> pd.DataFrame:
    """生成交易日历：覆盖 2010-2026，is_open 按周末+节假日判定。"""
    days = pd.bdate_range(_d(start), _d(end), freq="C")
    rows: List[Dict] = []
    prev_trade: Optional[str] = None
    for day in days:
        ds = day.strftime("%Y%m%d")
        is_open = 0 if ds in _HOLIDAYS else 1
        rows.append({
            "exchange": exchange,
            "cal_date": ds,
            "is_open": is_open,
            "pretrade_date": prev_trade or "",
        })
        if is_open:
            prev_trade = ds
    return pd.DataFrame(rows, columns=["exchange", "cal_date", "is_open", "pretrade_date"])


def build_securities(n_listed: int = _N_LISTED, n_delisted: int = _N_DELISTED,
                     seed: int = 42) -> pd.DataFrame:
    """生成证券代码表：含 >=100 条退市标的（status=delisted）。

    代码规则：60xxxx=沪市主板/科创板，00xxxx=深市主板，30xxxx=创业板。
    """
    rng = np.random.default_rng(seed)
    rows: List[Dict] = []

    def _mk(code: str, name: str, exch: str, board: str,
            list_date: str, delist_date: str, status: str) -> Dict:
        return {
            "ts_code": f"{code}.{exch}",
            "symbol": code,
            "name": name,
            "exchange": exch,
            "list_date": list_date,
            "delist_date": delist_date,
            "status": status,
            "board": board,
        }

    # 在市标的
    for i in range(n_listed):
        if i % 3 == 0:
            code = f"60{i:04d}"
            exch, board = "SH", "主板"
        elif i % 3 == 1:
            code = f"00{i:04d}"
            exch, board = "SZ", "主板"
        else:
            code = f"30{i:04d}"
            exch, board = "SZ", "创业板"
        rows.append(_mk(code, f"合成科技{i:04d}", exch, board,
                        f"{2010 + (i % 15):04d}{1 + (i % 12):02d}{1 + (i % 27):02d}",
                        "", "listed"))

    # 退市标的（>=100）
    for i in range(n_delisted):
        if i % 2 == 0:
            code = f"60{4000 + i:04d}"
            exch, board = "SH", "主板"
        else:
            code = f"00{2000 + i:04d}"
            exch, board = "SZ", "主板"
        list_y = 1998 + (i % 10)
        delist_y = 2015 + (i % 11)
        rows.append(_mk(code, f"退市股份{i:04d}", exch, board,
                        f"{list_y:04d}{1 + (i % 12):02d}{1 + (i % 27):02d}",
                        f"{delist_y:04d}{1 + (i % 12):02d}{1 + (i % 27):02d}",
                        "delisted"))

    df = pd.DataFrame(rows, columns=["ts_code", "symbol", "name", "exchange",
                                     "list_date", "delist_date", "status", "board"])
    df.attrs["synthetic"] = True
    return df


def build_adj_factor(securities: pd.DataFrame, trade_cal: pd.DataFrame,
                     seed: int = 7) -> pd.DataFrame:
    """生成复权因子：按除权事件链式累乘。

    后复权口径：adj_factor = 累积乘积（除权日及其后下调），
    保证 后复权价 = 原始价 * adj_factor（同一标的首日 factor=1）。

    禁止：用前复权价反推因子 —— 这里直接从除权事件正向生成。
    """
    rng = np.random.default_rng(seed)
    open_days = trade_cal.loc[trade_cal["is_open"] == 1, "cal_date"].tolist()
    if not open_days:
        return pd.DataFrame(columns=["ts_code", "trade_date", "adj_factor"])

    rows: List[Dict] = []
    for code in securities["ts_code"].tolist():
        factor = 1.0
        # 每个标的 0~3 次除权事件
        n_events = int(rng.integers(0, 4))
        event_idx = set(rng.choice(len(open_days), size=min(n_events, len(open_days)),
                                   replace=False).tolist()) if n_events else set()
        for i, day in enumerate(open_days):
            if i in event_idx:
                # 除权：10送X → 因子下调
                ratio = float(rng.uniform(0.6, 0.95))
                factor = round(factor * ratio, 8)
            rows.append({"ts_code": code, "trade_date": day,
                         "adj_factor": round(factor, 8)})

    df = pd.DataFrame(rows, columns=["ts_code", "trade_date", "adj_factor"])
    df.attrs["synthetic"] = True
    return df


def verify_adj_reconciliation(raw_price: pd.Series, factor: pd.Series) -> bool:
    """复权勾稽：后复权价 = 原始价 * 因子。"""
    if len(raw_price) != len(factor):
        return False
    with np.errstate(divide="ignore", invalid="ignore"):
        implied = raw_price.to_numpy(dtype=float) * factor.to_numpy(dtype=float)
    # 与自身一致（恒等式校验）：这里校验因子非零且乘积有限
    return bool(np.all(np.isfinite(implied)) and np.all(factor.to_numpy(dtype=float) > 0))


def build_all(out_dir: Optional[str] = None) -> Dict[str, pd.DataFrame]:
    """★ W23-5: 合成主表生成器（已改名标注）。

    铁律：只允许写 data/quant/_synthetic/；拒绝写 meta；写 provenance。
    """
    import time
    _SYNTHETIC_ROOT = os.path.join(DATA_ROOT, "_synthetic")
    _META_ROOT = os.path.join(DATA_ROOT, "meta")
    _requested = os.path.abspath(out_dir) if out_dir else None
    if _requested and _requested == os.path.abspath(_META_ROOT):
        raise ValueError("合成主表禁止写入 data/quant/meta；请用 master_real.build_all_real")
    target = _requested or _SYNTHETIC_ROOT
    if os.path.abspath(target) != os.path.abspath(_SYNTHETIC_ROOT):
        print(f"[master] ⚠ 合成主表强制写入 _synthetic（原请求: {target}）")
        target = _SYNTHETIC_ROOT
    ensure_dirs()
    cal = build_trade_cal()
    sec = build_securities()
    adj = build_adj_factor(sec, cal)
    os.makedirs(target, exist_ok=True)
    cal.to_csv(os.path.join(target, "trade_cal.csv"), index=False)
    sec.to_csv(os.path.join(target, "securities.csv"), index=False)
    adj.to_csv(os.path.join(target, "adj_factor.csv"), index=False)
    with open(os.path.join(target, "provenance.json"), "w", encoding="utf-8") as f:
        json.dump({"synthetic": True, "source": "generator",
                   "generated_at": time.strftime("%Y-%m-%d %H:%M:%S")},
                  f, ensure_ascii=False, indent=2)
    print(f"[master] 合成主表已写入 {target}（provenance.synthetic=true）")
    return {"trade_cal": cal, "securities": sec, "adj_factor": adj}


__all__ = ["build_trade_cal", "build_securities", "build_adj_factor",
           "verify_adj_reconciliation", "build_all"]
