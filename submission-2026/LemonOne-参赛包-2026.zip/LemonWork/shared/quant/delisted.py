# -*- coding: utf-8 -*-
"""★ W24-6: 退市处理。

1) 识别退市/停牌/ST 状态
2) 退市后价格标记（不参与回测）
3) 防止幸存者偏差：退市股保留历史数据
4) 退市整理期标记

禁止：静默删除退市股；把退市后数据当正常数据。
"""
from __future__ import annotations

from typing import Dict, List, Optional

import numpy as np
import pandas as pd

# 状态标记
STATUS_ACTIVE = "active"
STATUS_DELISTED = "delisted"
STATUS_SUSPENDED = "suspended"
STATUS_ST = "st"
STATUS_PRE_DELIST = "pre_delist"  # 退市整理期


def mark_delisted(prices: pd.DataFrame, delist_date: Optional[str] = None,
                  pre_delist_days: int = 30) -> pd.DataFrame:
    """标记退市状态。

    Args:
        prices: 含 ts_code, trade_date, close 的行情 DataFrame
        delist_date: 退市日（YYYYMMDD），None 表示未退市
        pre_delist_days: 退市整理期天数

    Returns:
        增加 status 列的 DataFrame
    """
    out = prices.copy()
    out["status"] = STATUS_ACTIVE

    if delist_date is None:
        return out

    d = str(delist_date).replace("-", "")[:8]
    out.loc[out["trade_date"].astype(str) > d, "status"] = STATUS_DELISTED

    # 退市整理期：退市日前 pre_delist_days 个交易日
    dates = sorted(out["trade_date"].astype(str).unique())
    if d in dates:
        idx = dates.index(d)
        start = max(0, idx - pre_delist_days)
        pre_dates = dates[start:idx]
        out.loc[out["trade_date"].astype(str).isin(pre_dates), "status"] = STATUS_PRE_DELIST

    return out


def filter_tradable(df: pd.DataFrame, as_of: Optional[str] = None,
                    keep_delisted: bool = False) -> pd.DataFrame:
    """过滤可交易数据。

    Args:
        df: 含 status 列的行情
        as_of: 时点（YYYYMMDD），None 表示全部
        keep_delisted: 是否保留已退市（防幸存者偏差用）

    Returns:
        过滤后的 DataFrame
    """
    out = df
    if as_of is not None:
        a = str(as_of).replace("-", "")[:8]
        out = out[out["trade_date"].astype(str) <= a]

    if not keep_delisted and "status" in out.columns:
        out = out[out["status"].isin([STATUS_ACTIVE, STATUS_PRE_DELIST, STATUS_SUSPENDED])]

    return out


def detect_delist_from_prices(prices: pd.DataFrame,
                              code: str,
                              gap_threshold: int = 60) -> Optional[str]:
    """从价格数据推断退市日（连续 gap_threshold 天无交易）。

    Returns:
        推断的退市日（YYYYMMDD），未退市返回 None
    """
    sub = prices[prices["ts_code"] == code].sort_values("trade_date")
    if len(sub) < 2:
        return None
    dates = pd.to_datetime(sub["trade_date"].astype(str), format="%Y%m%d")
    gaps = dates.diff().dt.days
    if (gaps > gap_threshold).any():
        last_trade = sub.iloc[gaps[gaps > gap_threshold].index[0] - 1]
        return str(last_trade["trade_date"])
    return None


def survivorship_bias_check(universe: pd.DataFrame,
                           delisted_codes: List[str]) -> Dict:
    """幸存者偏差检查：universe 中是否包含已退市股。

    Returns:
        {"total": int, "delisted_in_universe": int, "missing": List[str],
         "bias_ratio": float}
    """
    codes = set(universe["ts_code"].unique()) if "ts_code" in universe.columns else set()
    delisted_in = [c for c in delisted_codes if c in codes]
    missing = [c for c in delisted_codes if c not in codes]
    return {
        "total": len(codes),
        "delisted_in_universe": len(delisted_in),
        "missing": missing,
        "bias_ratio": round(len(missing) / max(len(delisted_codes), 1), 4),
    }


def delist_adjust_factor(adj_factor: pd.DataFrame, delist_date: str) -> pd.DataFrame:
    """退市后复权因子处理：退市后 adj_factor 冻结在最后交易日。"""
    out = adj_factor.copy()
    d = str(delist_date).replace("-", "")[:8]
    mask = out["trade_date"].astype(str) > d
    if mask.any():
        # 冻结在最后交易日值
        last = out[out["trade_date"].astype(str) <= d].iloc[-1]["adj_factor"]
        out.loc[mask, "adj_factor"] = last
    return out


__all__ = [
    "STATUS_ACTIVE", "STATUS_DELISTED", "STATUS_SUSPENDED", "STATUS_ST",
    "STATUS_PRE_DELIST", "mark_delisted", "filter_tradable",
    "detect_delist_from_prices", "survivorship_bias_check",
    "delist_adjust_factor",
]
