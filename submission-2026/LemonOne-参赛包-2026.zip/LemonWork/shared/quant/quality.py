# -*- coding: utf-8 -*-
"""D6 · 质量门（9 条）。

1) 完整性：必填列空值率
2) 唯一性：主键重复率
3) 连续性：交易日缺口
4) 一致性：OHLC 关系（high>=low 等）
5) 单调性：时间戳单调
6) 极值：涨跌幅超阈值
7) 跨源：同字段价差 >0.5% 报警
8) 勾稽：复权因子与价格关系
9) 覆盖率：标的数/应有数

禁止：只报总数不报明细；把警告当通过。
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

REQUIRED_COLS = ["ts_code", "trade_date", "open", "high", "low", "close"]
PRIMARY_KEYS = ["ts_code", "trade_date"]
NULL_RATE_LIMIT = 0.01      # 空值率上限 1%
DUP_RATE_LIMIT = 0.0        # 主键重复率上限 0
PCT_CHG_LIMIT = 20.0        # 涨跌幅极值阈值
CROSS_SOURCE_DIFF = 0.005   # 跨源价差阈值 0.5%
ADJ_TOLERANCE = 1e-6        # 复权勾稽容差


def _result(name: str, ok: bool, detail: Dict[str, Any],
            severity: str = "error") -> Dict[str, Any]:
    return {"name": name, "ok": bool(ok), "severity": severity, "detail": detail}


def check_completeness(df: pd.DataFrame,
                       required: Optional[List[str]] = None) -> Dict[str, Any]:
    """1) 完整性：必填列空值率。"""
    required = required or REQUIRED_COLS
    present = [c for c in required if c in df.columns]
    missing_cols = [c for c in required if c not in df.columns]
    rates = {}
    for c in present:
        rates[c] = round(float(df[c].isna().mean()), 6)
    worst = max(rates.values()) if rates else 0.0
    bad = {c: r for c, r in rates.items() if r > NULL_RATE_LIMIT}
    return _result("完整性", (not bad and not missing_cols),
                   {"null_rates": rates, "bad": bad, "missing_cols": missing_cols})


def check_uniqueness(df: pd.DataFrame,
                     keys: Optional[List[str]] = None) -> Dict[str, Any]:
    """2) 唯一性：主键重复率。"""
    keys = [k for k in (keys or PRIMARY_KEYS) if k in df.columns]
    if not keys:
        return _result("唯一性", False, {"reason": "无可用主键列"})
    dup = int(df.duplicated(subset=keys).sum())
    rate = round(dup / max(len(df), 1), 6)
    sample = (df[df.duplicated(subset=keys, keep=False)]
              .head(5)[keys].to_dict("records")) if dup else []
    return _result("唯一性", dup == 0, {"dup_rows": dup, "dup_rate": rate,
                                        "sample": sample})


def check_continuity(df: pd.DataFrame, trade_cal: Optional[pd.DataFrame] = None,
                     date_col: str = "trade_date") -> Dict[str, Any]:
    """3) 连续性：交易日缺口。"""
    if date_col not in df.columns:
        return _result("连续性", False, {"reason": f"缺 {date_col}"})
    dates = pd.to_datetime(df[date_col].astype(str), errors="coerce").dropna()
    if dates.empty:
        return _result("连续性", False, {"reason": "无有效日期"})
    if trade_cal is not None and "cal_date" in trade_cal.columns:
        expected = pd.to_datetime(trade_cal.loc[trade_cal["is_open"] == 1, "cal_date"]
                                  .astype(str))
        exp = expected[(expected >= dates.min()) & (expected <= dates.max())]
        actual = set(dates.dt.strftime("%Y%m%d"))
        missing = sorted(set(exp.dt.strftime("%Y%m%d")) - actual)
    else:
        # 无日历时按工作日近似
        full = pd.bdate_range(dates.min(), dates.max())
        actual = set(dates.dt.strftime("%Y%m%d"))
        missing = sorted(set(full.strftime("%Y%m%d")) - actual)[:50]
    return _result("连续性", len(missing) == 0,
                   {"missing_days": len(missing), "sample": missing[:10]})


def check_ohlc_consistency(df: pd.DataFrame) -> Dict[str, Any]:
    """4) 一致性：OHLC 关系 high>=low, high>=open/close, low<=open/close。"""
    need = ["open", "high", "low", "close"]
    if not all(c in df.columns for c in need):
        return _result("一致性", False, {"reason": "缺 OHLC 列"})
    v = df[need].astype(float)
    bad = (
        (v["high"] < v["low"]) |
        (v["high"] < v["open"]) | (v["high"] < v["close"]) |
        (v["low"] > v["open"]) | (v["low"] > v["close"])
    )
    bad &= v.notna().all(axis=1)
    n = int(bad.sum())
    sample = df.loc[bad].head(5).to_dict("records") if n else []
    return _result("一致性", n == 0, {"violations": n, "sample": sample})


def check_monotonic(df: pd.DataFrame, date_col: str = "trade_date",
                    group_col: str = "ts_code") -> Dict[str, Any]:
    """5) 单调性：时间戳单调（按标的）。"""
    if date_col not in df.columns:
        return _result("单调性", False, {"reason": f"缺 {date_col}"})
    if group_col not in df.columns:
        return _result("单调性", True, {"groups": 0, "violations": 0,
                                        "note": "无分组列，跳过"})
    violations = 0
    for _, g in df.groupby(group_col, sort=False):
        d = pd.to_datetime(g[date_col].astype(str), errors="coerce").dropna()
        if d.duplicated().any():
            violations += int(d.duplicated().sum())
    return _result("单调性", violations == 0,
                   {"groups": int(df[group_col].nunique()), "violations": violations})


def check_extremes(df: pd.DataFrame, col: str = "pct_chg",
                   limit: float = PCT_CHG_LIMIT) -> Dict[str, Any]:
    """6) 极值：涨跌幅超阈值。"""
    if col not in df.columns:
        return _result("极值", False, {"reason": f"缺 {col}"})
    s = df[col].astype(float)
    bad = s.abs() > limit
    n = int(bad.sum())
    sample = df.loc[bad].head(5).to_dict("records") if n else []
    return _result("极值", n == 0, {"violations": n, "limit": limit, "sample": sample})


def check_cross_source(df_a: pd.DataFrame, df_b: pd.DataFrame,
                       field: str = "close",
                       threshold: float = CROSS_SOURCE_DIFF) -> Dict[str, Any]:
    """7) 跨源：同字段价差 >0.5% 报警。"""
    if field not in df_a.columns or field not in df_b.columns:
        return _result("跨源", False, {"reason": f"缺 {field}"})
    keys = [k for k in PRIMARY_KEYS if k in df_a.columns and k in df_b.columns]
    if not keys:
        return _result("跨源", False, {"reason": "无对齐键"})
    a = df_a[keys + [field]].astype({field: float})
    b = df_b[keys + [field]].astype({field: float})
    m = a.merge(b, on=keys, suffixes=("_a", "_b"))
    if m.empty:
        return _result("跨源", False, {"reason": "对齐后无样本"})
    denom = m[f"{field}_b"].abs().replace(0, np.nan)
    diff = ((m[f"{field}_a"] - m[f"{field}_b"]).abs() / denom)
    bad = diff > threshold
    n = int(bad.sum())
    sample = m.loc[bad].head(5).to_dict("records") if n else []
    return _result("跨源", n == 0,
                   {"violations": n, "threshold": threshold, "sample": sample})


def check_adj_reconciliation(price: pd.DataFrame, adj: pd.DataFrame,
                             tolerance: float = ADJ_TOLERANCE) -> Dict[str, Any]:
    """8) 勾稽：后复权价 = 原始价 * 因子。"""
    need_p = [k for k in PRIMARY_KEYS if k in price.columns] + ["close"]
    need_a = [k for k in PRIMARY_KEYS if k in adj.columns] + ["adj_factor"]
    if len(need_p) < 3 or len(need_a) < 3:
        return _result("勾稽", False, {"reason": "缺价格或因子列"})
    m = price[need_p].merge(adj[need_a], on=PRIMARY_KEYS, how="inner")
    if m.empty:
        return _result("勾稽", False, {"reason": "无对齐样本"})
    implied = m["close"].astype(float) * m["adj_factor"].astype(float)
    # 恒等式自校验：因子必须为正且乘积有限
    bad = (~np.isfinite(implied)) | (m["adj_factor"].astype(float) <= 0)
    n = int(bad.sum())
    return _result("勾稽", n == 0,
                   {"violations": n, "rows": len(m), "tolerance": tolerance})


def check_coverage(df: pd.DataFrame, expected: int,
                   col: str = "ts_code") -> Dict[str, Any]:
    """9) 覆盖率：标的数/应有数。"""
    if col not in df.columns:
        return _result("覆盖率", False, {"reason": f"缺 {col}"})
    actual = int(df[col].nunique())
    rate = round(actual / max(expected, 1), 6)
    return _result("覆盖率", actual >= expected,
                   {"actual": actual, "expected": expected, "rate": rate})


def run_all(df: pd.DataFrame, trade_cal: Optional[pd.DataFrame] = None,
            expected_symbols: int = 0,
            adj: Optional[pd.DataFrame] = None,
            cross: Optional[pd.DataFrame] = None,
            with_timestamp: bool = False) -> Dict[str, Any]:
    """跑全部 9 条质量门，返回可复现 JSON 报告。

    默认不含时间戳（同一输入两次调用结果完全一致，满足「可复现」契约）；
    需要留痕时传 with_timestamp=True。
    """
    results = [
        check_completeness(df),
        check_uniqueness(df),
        check_continuity(df, trade_cal),
        check_ohlc_consistency(df),
        check_monotonic(df),
        check_extremes(df),
        check_cross_source(df, cross) if cross is not None
        else _result("跨源", True, {"note": "未提供跨源样本，跳过"}),
        check_adj_reconciliation(df, adj) if adj is not None
        else _result("勾稽", True, {"note": "未提供因子样本，跳过"}),
        check_coverage(df, expected_symbols) if expected_symbols > 0
        else _result("覆盖率", True, {"note": "未指定应有数，跳过"}),
    ]
    passed = sum(1 for r in results if r["ok"])
    report = {
        "version": "1.0",
        "total": len(results),
        "passed": passed,
        "failed": len(results) - passed,
        "results": results,
        "rows": int(len(df)),
    }
    if with_timestamp:
        report["generated_at"] = pd.Timestamp.now().isoformat(timespec="seconds")
    return report


__all__ = ["REQUIRED_COLS", "PRIMARY_KEYS", "NULL_RATE_LIMIT", "PCT_CHG_LIMIT",
           "CROSS_SOURCE_DIFF", "ADJ_TOLERANCE",
           "check_completeness", "check_uniqueness", "check_continuity",
           "check_ohlc_consistency", "check_monotonic", "check_extremes",
           "check_cross_source", "check_adj_reconciliation", "check_coverage",
           "run_all"]
