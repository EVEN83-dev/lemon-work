# -*- coding: utf-8 -*-
"""D8 · 版本与血缘。

1) 每个数据集 version：v1/v2…，含 schema_hash
2) 记录上游 raw manifest、清洗规则版本、代码 commit
3) 支持 dataset_at(version)

禁止：无版本覆盖写。
"""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
from typing import Any, Dict, List, Optional

import pandas as pd

from shared.quant import ensure_dirs


def schema_hash(df: pd.DataFrame) -> str:
    """列名+类型的稳定指纹。"""
    payload = json.dumps({c: str(t) for c, t in df.dtypes.items()},
                         sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]


def code_commit() -> str:
    """当前代码 commit（取不到返回 unknown，不抛错）。"""
    try:
        root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        out = subprocess.check_output(["git", "rev-parse", "--short", "HEAD"],
                                      cwd=root, stderr=subprocess.DEVNULL)
        return out.decode().strip()
    except Exception:
        return "unknown"


def register_dataset(name: str, df: pd.DataFrame, version: str,
                     upstream_manifests: Optional[List[Dict]] = None,
                     clean_rules_version: str = "1.0",
                     meta: Optional[Dict[str, Any]] = None,
                     root: Optional[str] = None) -> Dict[str, Any]:
    """登记一个数据集版本（写 meta/lineage_{name}.json 与 dataset 文件）。"""
    paths = ensure_dirs(root)
    meta_dir = paths["meta"]
    ds_dir = os.path.join(paths["feature"], f"{name}_{version}")
    os.makedirs(ds_dir, exist_ok=True)
    pq = os.path.join(ds_dir, "data.parquet")
    df.to_parquet(pq, index=False)

    rec = {
        "name": name,
        "version": version,
        "schema_hash": schema_hash(df),
        "rows": int(len(df)),
        "columns": list(df.columns),
        "upstream_manifests": upstream_manifests or [],
        "clean_rules_version": clean_rules_version,
        "code_commit": code_commit(),
        "created_at": pd.Timestamp.now().isoformat(timespec="seconds"),
        "file": os.path.relpath(pq, paths["root"]),
        "meta": meta or {},
    }
    # 追加式血缘日志（不覆盖历史版本）
    lineage_path = os.path.join(meta_dir, f"lineage_{name}.jsonl")
    with open(lineage_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    return rec


def list_versions(name: str, root: Optional[str] = None) -> List[Dict[str, Any]]:
    paths = ensure_dirs(root)
    p = os.path.join(paths["meta"], f"lineage_{name}.jsonl")
    out = []
    if os.path.isfile(p):
        with open(p, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    out.append(json.loads(line))
    return out


def dataset_at(name: str, version: str, root: Optional[str] = None) -> Optional[pd.DataFrame]:
    """按版本取数据集（版本可复现）。"""
    paths = ensure_dirs(root)
    ds_dir = os.path.join(paths["feature"], f"{name}_{version}")
    pq = os.path.join(ds_dir, "data.parquet")
    if not os.path.isfile(pq):
        return None
    return pd.read_parquet(pq)


def lineage_of(name: str, version: str, root: Optional[str] = None) -> Optional[Dict[str, Any]]:
    for rec in list_versions(name, root):
        if rec.get("version") == version:
            return rec
    return None


__all__ = ["schema_hash", "code_commit", "register_dataset",
           "list_versions", "dataset_at", "lineage_of"]
