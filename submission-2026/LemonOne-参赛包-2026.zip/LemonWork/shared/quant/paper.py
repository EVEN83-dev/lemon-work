# -*- coding: utf-8 -*-
"""★ W24-7: Paper Trading（模拟盘）。

1) 日级回测：目标权重 → 下单 → 部分成交 → 持仓更新
2) 集成成本模型（佣金/印花税/过户费/滑点）
3) 净值曲线、回撤、交易记录
4) 涨跌停不可成交、停牌不可成交

禁止：默认满仓成交；忽略成本。
"""
from __future__ import annotations

from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from shared.backtest.cost import trade_cost, can_trade, DEFAULT as COST_DEFAULT


class PaperAccount:
    """模拟账户。"""

    def __init__(self, cash: float = 1_000_000.0,
                 cost_params: Optional[Dict] = None):
        self.initial_cash = cash
        self.cash = cash
        self.positions: Dict[str, Dict] = {}  # code -> {qty, cost, last_price}
        self.trades: List[Dict] = []
        self.daily: List[Dict] = []  # 净值曲线
        self.cost_params = {**COST_DEFAULT, **(cost_params or {})}

    def position_value(self, prices: Dict[str, float]) -> float:
        """持仓市值。"""
        v = 0.0
        for code, pos in self.positions.items():
            px = prices.get(code, pos.get("last_price", 0.0))
            v += pos["qty"] * px
        return v

    def total_value(self, prices: Dict[str, float]) -> float:
        """总权益 = 现金 + 持仓市值。"""
        return self.cash + self.position_value(prices)

    def nav(self, prices: Dict[str, float]) -> float:
        """净值（初始为 1）。"""
        return self.total_value(prices) / self.initial_cash

    def target_weights(self, prices: Dict[str, float]) -> Dict[str, float]:
        """当前权重。"""
        tv = self.total_value(prices)
        if tv <= 0:
            return {}
        w = {code: pos["qty"] * prices.get(code, pos.get("last_price", 0.0)) / tv
             for code, pos in self.positions.items()}
        w["_cash"] = self.cash / tv
        return w

    def rebalance(self, date: str, target_weights: Dict[str, float],
                  prices: Dict[str, float],
                  prev_prices: Optional[Dict[str, float]] = None,
                  volumes: Optional[Dict[str, float]] = None,
                  is_sh: Optional[Dict[str, bool]] = None,
                  max_turnover: float = 1.0) -> List[Dict]:
        """按目标权重调仓。

        Args:
            date: 交易日
            target_weights: {code: weight}，不含 _cash
            prices: {code: price}
            prev_prices: {code: prev_close}，用于涨跌停判断
            volumes: {code: volume}，用于滑点
            is_sh: {code: is_sh}，用于过户费
            max_turnover: 最大换手比例（0-1）

        Returns:
            交易记录列表
        """
        tv = self.total_value(prices)
        trades = []
        codes = set(list(target_weights.keys()) + list(self.positions.keys()))

        # 计算目标持仓
        target_qty = {}
        for code in codes:
            w = target_weights.get(code, 0.0)
            px = prices.get(code, 0.0)
            if px <= 0:
                continue
            target_value = tv * w
            target_qty[code] = int(target_value / px / 100) * 100  # 整百股

        # 当前持仓
        current_qty = {code: pos["qty"] for code, pos in self.positions.items()}

        # 计算总换手
        total_turnover = 0.0
        for code in codes:
            px = prices.get(code, 0.0)
            delta = abs(target_qty.get(code, 0) - current_qty.get(code, 0))
            total_turnover += delta * px
        if total_turnover > 0 and max_turnover < 1.0:
            scale = min(1.0, max_turnover * tv / total_turnover)
        else:
            scale = 1.0

        # 生成交易
        for code in sorted(codes):
            px = prices.get(code, 0.0)
            if px <= 0:
                continue
            cur = current_qty.get(code, 0)
            tgt = target_qty.get(code, 0)
            delta = int((tgt - cur) * scale)
            if delta == 0:
                continue

            side = "buy" if delta > 0 else "sell"
            qty = abs(delta)
            amount = qty * px

            # 涨跌停检查
            if prev_prices and code in prev_prices:
                if not can_trade(prev_prices[code], px, side):
                    trades.append({"date": date, "code": code, "side": side,
                                   "qty": 0, "price": px, "cost": 0.0,
                                   "reason": "limit_move"})
                    continue

            # 成本
            sh = (is_sh or {}).get(code, True)
            cost = trade_cost(amount, side, sh, self.cost_params)
            if side == "buy":
                total = amount + cost
                if total > self.cash:
                    # 资金不足，减量
                    affordable = int((self.cash - cost) / px / 100) * 100
                    if affordable <= 0:
                        trades.append({"date": date, "code": code, "side": side,
                                       "qty": 0, "price": px, "cost": 0.0,
                                       "reason": "insufficient_cash"})
                        continue
                    qty = min(qty, affordable)
                    amount = qty * px
                    cost = trade_cost(amount, side, sh, self.cost_params)
                    total = amount + cost

            # 执行
            if side == "buy":
                self.cash -= amount + cost
                if code in self.positions:
                    pos = self.positions[code]
                    new_qty = pos["qty"] + qty
                    new_cost = (pos["cost"] * pos["qty"] + amount) / new_qty
                    pos["qty"] = new_qty
                    pos["cost"] = new_cost
                    pos["last_price"] = px
                else:
                    self.positions[code] = {"qty": qty, "cost": px, "last_price": px}
            else:
                self.cash += amount - cost
                if code in self.positions:
                    pos = self.positions[code]
                    pos["qty"] -= qty
                    pos["last_price"] = px
                    if pos["qty"] <= 0:
                        del self.positions[code]

            trades.append({"date": date, "code": code, "side": side,
                           "qty": qty, "price": px, "cost": round(cost, 2),
                           "reason": "filled"})

        return trades

    def record_daily(self, date: str, prices: Dict[str, float]):
        """记录每日净值。"""
        tv = self.total_value(prices)
        self.daily.append({
            "date": date,
            "cash": round(self.cash, 2),
            "position_value": round(self.position_value(prices), 2),
            "total_value": round(tv, 2),
            "nav": round(tv / self.initial_cash, 6),
        })

    def summary(self) -> Dict:
        """回测摘要。"""
        if not self.daily:
            return {"trades": len(self.trades), "days": 0}
        navs = [d["nav"] for d in self.daily]
        peak = navs[0]
        max_dd = 0.0
        for n in navs:
            peak = max(peak, n)
            dd = (peak - n) / peak if peak > 0 else 0
            max_dd = max(max_dd, dd)
        return {
            "trades": len(self.trades),
            "days": len(self.daily),
            "final_nav": round(navs[-1], 6),
            "total_return": round(navs[-1] - 1, 6),
            "max_drawdown": round(max_dd, 6),
            "total_cost": round(sum(t["cost"] for t in self.trades), 2),
        }


def run_paper(prices_df: pd.DataFrame,
              weights_df: pd.DataFrame,
              cash: float = 1_000_000.0,
              cost_params: Optional[Dict] = None) -> PaperAccount:
    """日级 paper trading 回测。

    Args:
        prices_df: index=date, columns=code, values=close
        weights_df: index=date, columns=code, values=target weight
        cash: 初始资金
        cost_params: 成本参数

    Returns:
        PaperAccount
    """
    acct = PaperAccount(cash=cash, cost_params=cost_params)
    dates = sorted(set(prices_df.index) & set(weights_df.index))
    prev_prices = None
    for d in dates:
        prices = prices_df.loc[d].dropna().to_dict()
        weights = weights_df.loc[d].dropna().to_dict()
        trades = acct.rebalance(str(d), weights, prices, prev_prices=prev_prices)
        acct.trades.extend(trades)
        acct.record_daily(str(d), prices)
        prev_prices = prices
    return acct


__all__ = ["PaperAccount", "run_paper"]
