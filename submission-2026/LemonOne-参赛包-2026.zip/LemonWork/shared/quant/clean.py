# -*- coding: utf-8 -*-
"""D4 · clean 层标准化。

1) 列名/类型/单位统一（金额元、成交量股、日期 YYYYMMDD）
2) 去重键：ts_code+trade_date
3) 停牌/退市/ST 标记
4) 异常值处理：涨跌幅 > 阈值标记不删除

禁止：静默丢行；把异常值直接删掉。
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

# 列规范：列名 -> (目标类型, 单位说明)
SCHEMA = {
    "ts_code": ("string", "代码"),
    "trade_date": ("string", "YYYYMMDD"),
    "open": ("float64", "元"),
    "high": ("float64", "元"),
    "low": ("float64", "元"),
    "close": ("float64", "元"),
    "pre_close": ("float64", "元"),
    "vol": ("float64", "股"),
    "amount": ("float64", "元"),
    "pct_chg": ("float64", "百分比"),
    "adj_factor": ("float64", "倍"),
    "is_suspended": ("int64", "0/1"),
    "is_st": ("int64", "0/1"),
    "is_delisted": ("int64", "0/1"),
    "is_abnormal": ("int64", "0/1"),
}

# 涨跌幅异常阈值（|A股| 20% 视为异常标记，不删除）
PCT_CHG_LIMIT = 20.0

# 别名归一
_RENAME = {
    "symbol": "ts_code", "code": "ts_code",
    "date": "trade_date", "dt": "trade_date",
    "volume": "vol", "turnover": "amount",
    "pct_change": "pct_chg", "factor": "adj_factor",
}

DEDUP_KEYS = ["ts_code", "trade_date"]


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    """列名归一 + 类型统一。"""
    df = df.rename(columns=_RENAME)
    out = df.copy()
    for col, (dtype, _unit) in SCHEMA.items():
        if col not in out.columns:
            continue
        try:
            if dtype == "string":
                out[col] = out[col].astype("string")
            else:
                out[col] = pd.to_numeric(out[col], errors="coerce").astype(dtype)
        except Exception:
            logger.debug("suppressed exception")
    # 日期统一 YYYYMMDD
    if "trade_date" in out.columns:
        out["trade_date"] = (out["trade_date"].astype("string")
                             .str.replace(r"[-/\.]", "", regex=True).str[:8])
    return out


def add_marks(df: pd.DataFrame, securities: Optional[pd.DataFrame] = None) -> pd.DataFrame:
    """停牌/退市/ST 标记。"""
    out = df.copy()
    # 停牌：成交量为 0 或缺失
    if "vol" in out.columns:
        out["is_suspended"] = ((out["vol"].isna()) | (out["vol"] == 0)).astype("int64")
    else:
        out["is_suspended"] = 0

    # 退市 / ST：从 securities 表关联
    if securities is not None and "ts_code" in out.columns:
        smap = securities.set_index("ts_code")
        out["is_delisted"] = out["ts_code"].map(
            smap["status"].eq("delisted")).fillna(False).astype("int64")
        out["is_st"] = out["ts_code"].map(
            smap["name"].str.contains("ST", na=False)).fillna(False).astype("int64")
    else:
        out["is_delisted"] = 0
        out["is_st"] = 0
    return out


def mark_abnormal(df: pd.DataFrame, limit: float = PCT_CHG_LIMIT) -> pd.DataFrame:
    """异常值标记（不删除）。"""
    out = df.copy()
    if "pct_chg" not in out.columns:
        # 由收盘价推算
        if "close" in out.columns and "pre_close" in out.columns:
            pc = (out["close"] - out["pre_close"]) / out["pre_close"].replace(0, np.nan) * 100.0
            out["pct_chg"] = pc
        else:
            out["pct_chg"] = np.nan
    out["is_abnormal"] = (out["pct_chg"].abs() > limit).fillna(False).astype("int64")
    return out


def dedup(df: pd.DataFrame, keys: Optional[List[str]] = None) -> Tuple[pd.DataFrame, int]:
    """按主键去重；返回 (去重后, 丢弃行数)。"""
    keys = keys or [k for k in DEDUP_KEYS if k in df.columns]
    if not keys:
        return df, 0
    before = len(df)
    out = df.drop_duplicates(subset=keys, keep="last")
    return out, before - len(out)


def clean(df: pd.DataFrame, securities: Optional[pd.DataFrame] = None,
          dedup_keys: Optional[List[str]] = None) -> Tuple[pd.DataFrame, Dict]:
    """完整清洗流程，返回 (clean_df, 统计)。

    统计含 rows_raw/rows_clean/dropped_dup，供质量门核对。
    """
    rows_raw = len(df)
    out = normalize_columns(df)
    out = add_marks(out, securities)
    out = mark_abnormal(out)
    out, dropped = dedup(out, dedup_keys)
    stats = {
        "rows_raw": rows_raw,
        "rows_clean": len(out),
        "dropped_dup": dropped,
        "dup_keys": dedup_keys or [k for k in DEDUP_KEYS if k in out.columns],
    }
    return out, stats


__all__ = ["SCHEMA", "PCT_CHG_LIMIT", "DEDUP_KEYS", "normalize_columns",
           "add_marks", "mark_abnormal", "dedup", "clean"]
