# -*- coding: utf-8 -*-
"""LemonWork 量化数据治理层（D 集群）。

契约：
  DATA_ROOT = data/quant
  子目录：raw/ clean/ feature/ pit/ meta/
  QUANT_VERSION = "1.0"
  数据集命名：{market}_{freq}_{name}_{version}

数据真实性声明
--------------
本层的数据生成器产出 **合成数据（synthetic）**，用于打通
「采集 → 落盘 → 清洗 → PIT → 质量门 → 跨源比对 → 血缘」全链路的
可复现验证。合成数据按真实市场规则构造（A 股交易日历、
除权链式复权因子、OHLC 关系、公告日滞后），但**不是真实行情**，
任何场景不得将其当作真实市场数据使用。

接入真实数据时只需替换 shared/quant/sources/ 下的适配器实现，
下游 store/clean/pit/quality/compare/lineage 无需改动。
"""
from __future__ import annotations

import os

# ── D0 契约 ──────────────────────────────────────────────────────────
DATA_ROOT = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
    "data", "quant")
QUANT_VERSION = "1.0"

SUBDIRS = ("raw", "clean", "feature", "pit", "meta")

# 数据集命名：{market}_{freq}_{name}_{version}
DATASET_NAMING = "{market}_{freq}_{name}_{version}"


def ensure_dirs(root: str = DATA_ROOT) -> dict:
    """创建并返回子目录映射（幂等）。"""
    paths = {}
    for name in SUBDIRS:
        p = os.path.join(root, name)
        os.makedirs(p, exist_ok=True)
        paths[name] = p
    os.makedirs(root, exist_ok=True)
    paths["root"] = root
    return paths


def dataset_name(market: str, freq: str, name: str, version: str) -> str:
    """按契约生成数据集名。"""
    return DATASET_NAMING.format(market=market, freq=freq, name=name, version=version)


__all__ = ["DATA_ROOT", "QUANT_VERSION", "SUBDIRS", "DATASET_NAMING",
           "ensure_dirs", "dataset_name"]
