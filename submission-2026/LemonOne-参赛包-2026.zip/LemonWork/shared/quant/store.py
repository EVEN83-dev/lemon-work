# -*- coding: utf-8 -*-
"""D3 · raw 层（不可变）。

落盘：raw/{source}/{kind}/dt=YYYYMMDD/*.parquet
每批写 _manifest.json：行数 / sha256 / 抓取时间 / 参数

raw 只追加，不覆盖，不修改。
"""
from __future__ import annotations

import hashlib
import json
import os
import time
from typing import Any, Dict, Optional

import pandas as pd

from shared.quant import ensure_dirs


def _sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def write_batch(df: pd.DataFrame, source: str, kind: str,
                params: Optional[Dict[str, Any]] = None,
                dt: Optional[str] = None,
                root: Optional[str] = None) -> Dict[str, Any]:
    """写一批 raw 数据 + manifest，返回 manifest 字典。

    同一参数两次调用生成两个不同的 manifest（不同抓取时间戳）。
    """
    paths = ensure_dirs(root)
    dt = dt or time.strftime("%Y%m%d")
    batch_dir = os.path.join(paths["raw"], source, kind, f"dt={dt}")
    os.makedirs(batch_dir, exist_ok=True)

    # 文件名带时间戳，避免覆盖
    ts = time.strftime("%H%M%S")
    stamp = f"{ts}_{os.getpid()}_{int(time.time() * 1000) % 1000}"
    pq_path = os.path.join(batch_dir, f"part_{stamp}.parquet")
    df.to_parquet(pq_path, index=False)

    with open(pq_path, "rb") as f:
        raw_bytes = f.read()

    manifest = {
        "source": source,
        "kind": kind,
        "dt": dt,
        "rows": int(len(df)),
        "columns": list(df.columns),
        "sha256": _sha256_bytes(raw_bytes),
        "fetched_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "params": params or {},
        "file": os.path.basename(pq_path),
    }
    mpath = os.path.join(batch_dir, f"_manifest_{stamp}.json")
    with open(mpath, "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=1)
    return manifest


def list_manifests(source: str, kind: str, root: Optional[str] = None) -> list:
    """列出某 source/kind 下全部 manifest（按抓取时间升序）。"""
    paths = ensure_dirs(root)
    base = os.path.join(paths["raw"], source, kind)
    out = []
    if not os.path.isdir(base):
        return out
    for dt_dir in sorted(os.listdir(base)):
        full = os.path.join(base, dt_dir)
        if not os.path.isdir(full):
            continue
        for fn in sorted(os.listdir(full)):
            if fn.startswith("_manifest_") and fn.endswith(".json"):
                with open(os.path.join(full, fn), encoding="utf-8") as f:
                    out.append(json.load(f))
    return out


def verify_manifest(manifest: Dict[str, Any], root: Optional[str] = None) -> bool:
    """按 manifest 复核 sha256 与行数。"""
    paths = ensure_dirs(root)
    base = os.path.join(paths["raw"], manifest["source"], manifest["kind"],
                       f"dt={manifest['dt']}")
    pq = os.path.join(base, manifest["file"])
    if not os.path.isfile(pq):
        return False
    with open(pq, "rb") as f:
        digest = _sha256_bytes(f.read())
    if digest != manifest["sha256"]:
        return False
    try:
        df = pd.read_parquet(pq)
    except Exception:
        return False
    return int(len(df)) == int(manifest["rows"])


__all__ = ["write_batch", "list_manifests", "verify_manifest"]
