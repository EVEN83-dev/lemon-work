# -*- coding: utf-8 -*-
"""★ W24-6: PIT 版本管理。

1) 数据版本号（语义化：major.minor.patch）
2) 每次数据更新产生新版本快照
3) 版本可回溯、可回滚
4) 版本元数据（来源、时间、行数、校验和）

禁止：无版本覆盖写；版本不可追溯。
"""
from __future__ import annotations

import hashlib
import json
import os
import time
from typing import Dict, List, Optional

import pandas as pd


def bump_version(current: str, level: str = "patch") -> str:
    """语义化版本号递增。

    Args:
        current: 当前版本 "major.minor.patch"
        level: "major" | "minor" | "patch"

    Returns:
        新版本号
    """
    parts = current.split(".")
    while len(parts) < 3:
        parts.append("0")
    major, minor, patch = int(parts[0]), int(parts[1]), int(parts[2])
    if level == "major":
        major, minor, patch = major + 1, 0, 0
    elif level == "minor":
        minor, patch = minor + 1, 0
    else:
        patch += 1
    return f"{major}.{minor}.{patch}"


def compute_checksum(df: pd.DataFrame) -> str:
    """计算 DataFrame 内容校验和（排序后哈希）。"""
    cols = sorted(df.columns)
    h = hashlib.sha256()
    for col in cols:
        for v in df[col].astype(str).tolist():
            h.update(v.encode("utf-8"))
    return h.hexdigest()[:16]


class DataVersion:
    """PIT 数据版本管理。"""

    def __init__(self, store_dir: str = ".quant_versions"):
        self.store_dir = store_dir
        os.makedirs(store_dir, exist_ok=True)

    def _meta_path(self, dataset: str, version: str) -> str:
        return os.path.join(self.store_dir, f"{dataset}@{version}.json")

    def _data_path(self, dataset: str, version: str) -> str:
        return os.path.join(self.store_dir, f"{dataset}@{version}.parquet")

    def snapshot(self, dataset: str, df: pd.DataFrame,
                 source: str = "", note: str = "",
                 level: str = "patch") -> Dict:
        """创建数据快照，返回版本元数据。"""
        versions = self.list_versions(dataset)
        current = versions[-1]["version"] if versions else "0.0.0"
        version = bump_version(current, level)

        checksum = compute_checksum(df)
        meta = {
            "dataset": dataset,
            "version": version,
            "parent": current,
            "source": source,
            "note": note,
            "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "rows": int(len(df)),
            "columns": list(df.columns),
            "checksum": checksum,
        }
        # 写元数据
        with open(self._meta_path(dataset, version), "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False, indent=2)
        # 写数据（parquet 优先，回退 pickle）
        try:
            df.to_parquet(self._data_path(dataset, version), index=False)
        except Exception:
            df.to_pickle(self._data_path(dataset, version).replace(".parquet", ".pkl"))
        return meta

    def load(self, dataset: str, version: str) -> Optional[pd.DataFrame]:
        """加载指定版本数据。"""
        pq = self._data_path(dataset, version)
        pk = pq.replace(".parquet", ".pkl")
        if os.path.exists(pq):
            return pd.read_parquet(pq)
        if os.path.exists(pk):
            return pd.read_pickle(pk)
        return None

    def get_meta(self, dataset: str, version: str) -> Optional[Dict]:
        """获取版本元数据。"""
        p = self._meta_path(dataset, version)
        if not os.path.exists(p):
            return None
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)

    def list_versions(self, dataset: str) -> List[Dict]:
        """列出某数据集的所有版本（按语义化版本排序）。"""
        out = []
        for fn in os.listdir(self.store_dir):
            if fn.startswith(f"{dataset}@") and fn.endswith(".json"):
                with open(os.path.join(self.store_dir, fn), "r", encoding="utf-8") as f:
                    out.append(json.load(f))
        out.sort(key=lambda m: [int(x) for x in m["version"].split(".")])
        return out

    def rollback(self, dataset: str, version: str) -> Optional[pd.DataFrame]:
        """回滚到指定版本（返回数据，不删除后续版本）。"""
        return self.load(dataset, version)

    def verify(self, dataset: str, version: str) -> bool:
        """校验数据完整性（checksum 比对）。"""
        meta = self.get_meta(dataset, version)
        if not meta:
            return False
        df = self.load(dataset, version)
        if df is None:
            return False
        return compute_checksum(df) == meta["checksum"]

    def diff_versions(self, dataset: str, v1: str, v2: str) -> Dict:
        """比较两个版本的差异。"""
        m1 = self.get_meta(dataset, v1)
        m2 = self.get_meta(dataset, v2)
        if not m1 or not m2:
            return {"error": "版本不存在"}
        return {
            "dataset": dataset,
            "v1": v1, "v2": v2,
            "rows_v1": m1["rows"], "rows_v2": m2["rows"],
            "rows_diff": m2["rows"] - m1["rows"],
            "checksum_same": m1["checksum"] == m2["checksum"],
            "columns_v1": m1["columns"], "columns_v2": m2["columns"],
            "created_v1": m1["created_at"], "created_v2": m2["created_at"],
        }


__all__ = ["bump_version", "compute_checksum", "DataVersion"]
