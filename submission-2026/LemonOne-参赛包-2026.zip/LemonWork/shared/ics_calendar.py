# -*- coding: utf-8 -*-
"""★ D6-04: 日历 / ICS 集成（VEVENT ⇄ scheduler jobs）。

- ICS 导入：解析 VEVENT（SUMMARY/DTSTART/DTEND/RRULE/UID/DESCRIPTION/LOCATION）
  → jobs.json 结构（trigger 由 DTSTART 时间推导）
- ICS 导出：jobs → 可导入系统日历的 .ics 文本
- 行折行（RFC 5545：>75 字节折行，续行以空格开头）与反转行
- 自实现，无第三方依赖
"""
from __future__ import annotations

import re
from datetime import datetime, timedelta
from typing import Dict, List, Optional

PRODID = "-//LemonWork//Scheduler//CN"
VERSION = "2.0"


# ── 折行 / 反转行 ──
def _unfold(text: str) -> List[str]:
    """RFC 5545 反转行：续行以空格/制表符开头。"""
    out: List[str] = []
    for raw in (text or "").replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        if raw[:1] in (" ", "\t") and out:
            out[-1] += raw[1:]
        else:
            out.append(raw)
    return out


def _fold(line: str, limit: int = 74) -> str:
    """RFC 5545 折行（按字符近似）。"""
    if len(line) <= limit:
        return line
    parts = []
    while len(line) > limit:
        parts.append(line[:limit])
        line = " " + line[limit:]
    parts.append(line)
    return "\r\n".join(parts)


def _fmt_dt(dt: datetime) -> str:
    return dt.strftime("%Y%m%dT%H%M%S")


def _parse_dt(s: str) -> Optional[datetime]:
    s = (s or "").strip().rstrip("Z")
    for f in ("%Y%m%dT%H%M%S", "%Y%m%dT%H%M", "%Y%m%d"):
        try:
            return datetime.strptime(s[:len(f) + 2], f)
        except ValueError:
            continue
    return None


def _parse_rrule(rrule: str, dtstart: datetime) -> Optional[str]:
    """RRULE → scheduler trigger（仅支持 FREQ=DAILY/WEEKLY + INTERVAL）。"""
    if not rrule:
        return None
    m = re.search(r"FREQ=(DAILY|WEEKLY)", rrule, re.I)
    if not m:
        return None
    freq = m.group(1).upper()
    mi = re.search(r"INTERVAL=(\d+)", rrule, re.I)
    interval = int(mi.group(1)) if mi else 1
    if freq == "DAILY":
        return dtstart.strftime("%H:%M")
    # WEEKLY：用 BYDAY
    days = re.search(r"BYDAY=([A-Z,]+)", rrule, re.I)
    if days:
        return dtstart.strftime("%H:%M")
    return dtstart.strftime("%H:%M")


def ics_to_jobs(text: str) -> List[Dict]:
    """ICS 文本 → jobs 列表（scheduler jobs.json 结构）。"""
    lines = _unfold(text)
    jobs: List[Dict] = []
    cur: Dict[str, str] = {}
    in_event = False

    def flush():
        if not in_event or not cur.get("DTSTART"):
            return
        dt = _parse_dt(cur["DTSTART"])
        if dt is None:
            return
        trig = _parse_rrule(cur.get("RRULE", ""), dt) or dt.strftime("%H:%M")
        jobs.append({
            "job_id": "ics_" + (cur.get("UID") or dt.strftime("%Y%m%d%H%M%S"))[-12:],
            "name": cur.get("SUMMARY", "未命名日程")[:40],
            "trigger": trig,
            "trigger_parsed": "daily",
            "action": {"type": "skill", "skill": "ics_reminder",
                       "args": {"title": cur.get("SUMMARY", ""),
                                "location": cur.get("LOCATION", ""),
                                "description": cur.get("DESCRIPTION", "")}},
            "enabled": True,
            "max_retry": 0,
            "ics_uid": cur.get("UID", ""),
            "ics_dtstart": cur.get("DTSTART", ""),
            "ics_rrule": cur.get("RRULE", ""),
        })

    for ln in lines:
        s = ln.strip()
        if s == "BEGIN:VEVENT":
            in_event, cur = True, {}
            continue
        if s == "END:VEVENT":
            flush()
            in_event, cur = False, {}
            continue
        if not in_event or ":" not in s:
            continue
        key, _, val = s.partition(":")
        key = key.split(";")[0].strip().upper()
        cur[key] = val
    return jobs


def jobs_to_ics(jobs: List[Dict]) -> str:
    """jobs 列表 → ICS 文本。"""
    out = ["BEGIN:VCALENDAR", f"VERSION:{VERSION}", f"PRODID:{PRODID}", "CALSCALE:GREGORIAN"]
    for j in jobs or []:
        dtstart = j.get("ics_dtstart") or ""
        if not dtstart:
            # 由 trigger(HH:MM) 推导当日时间
            hhmm = (j.get("trigger") or "09:00")[:5]
            try:
                d = datetime.now().replace(hour=int(hhmm[:2]), minute=int(hhmm[3:5]),
                                           second=0, microsecond=0)
                dtstart = _fmt_dt(d)
            except Exception:
                dtstart = _fmt_dt(datetime.now())
        out.append("BEGIN:VEVENT")
        out.append(f"UID:{j.get('ics_uid') or (j.get('job_id','ics'))}@lemonwork")
        out.append(f"DTSTART:{dtstart}")
        try:
            d0 = _parse_dt(dtstart) or datetime.now()
            out.append(f"DTEND:{_fmt_dt(d0 + timedelta(minutes=30))}")
        except Exception:
            out.append(f"DTEND:{dtstart}")
        out.append(_fold(f"SUMMARY:{j.get('name', '未命名')}"))
        if j.get("action", {}).get("args", {}).get("location"):
            out.append(_fold("LOCATION:" + str(j["action"]["args"]["location"])))
        if j.get("action", {}).get("args", {}).get("description"):
            out.append(_fold("DESCRIPTION:" + str(j["action"]["args"]["description"])))
        out.append("END:VEVENT")
    out.append("END:VCALENDAR")
    return "\r\n".join(out) + "\r\n"


def roundtrip(jobs: List[Dict]) -> List[Dict]:
    """导出 → 导入，供测试验证结构等价。"""
    return ics_to_jobs(jobs_to_ics(jobs))


__all__ = ["ics_to_jobs", "jobs_to_ics", "roundtrip"]
