# -*- coding: utf-8 -*-
"""★ 会话注册表（收口项 20）：公司 / 爬虫 / 普通 三类会话统一字段列表。

统一形状（三类一律同键，禁缺键禁改名）：
  {session_id, name, kind ∈ company|crawl|normal, state,
   created_at, parent_id, source}

真源（只读，禁 mock）：
  · company → data/company/company.db session 表（dm|group|approval 台账）
  · crawl   → data/crawl.db crawl_session 表
  · normal  → data/chat.db chat_session 表（不在 company 台账中的普通会话）

判定口径：chat_session 里同时出现在 company 台账的 → 归 company（同 id 双登记
以 company 台账为准，members/topic 信息更全）；其余为 normal。缺失的库降级为
空集合（不抛错、不伪造）。1s 内存缓存（与 crawler.stats 同族口径）。
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import os
import sqlite3
import time
from typing import Any, Dict, List, Optional

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_LIST_TTL_S = 1.0

_CACHE: Dict[str, Any] = {"ts": 0.0, "rows": None}


def _db(path: str) -> Optional[sqlite3.Connection]:
    if not os.path.exists(path):
        return None
    try:
        c = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=5)
        c.row_factory = sqlite3.Row
        return c
    except sqlite3.Error:
        return None


def _company_sessions() -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    c = _db(os.path.join(_PROJECT_ROOT, "data", "company", "company.db"))
    if c is None:
        return rows
    try:
        for r in c.execute(
                "SELECT session_id, kind AS ckind, topic, members, created_ts "
                "FROM session ORDER BY created_ts DESC LIMIT 500"):
            rows.append({
                "session_id": str(r["session_id"] or ""),
                "name": str(r["topic"] or r["session_id"] or ""),
                "kind": "company",
                "state": str(r["ckind"] or "dm"),
                "created_at": float(r["created_ts"] or 0),
                "parent_id": "",
                "source": "company.db",
            })
    except sqlite3.Error:
        logger.debug("suppressed exception")
    finally:
        c.close()
    return rows


def _crawl_sessions() -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    c = _db(os.path.join(_PROJECT_ROOT, "data", "crawl.db"))
    if c is None:
        return rows
    try:
        for r in c.execute(
                "SELECT session_id, name, state, created_at FROM crawl_session "
                "ORDER BY created_at DESC LIMIT 500"):
            rows.append({
                "session_id": str(r["session_id"] or ""),
                "name": str(r["name"] or r["session_id"] or ""),
                "kind": "crawl",
                "state": str(r["state"] or ""),
                "created_at": str(r["created_at"] or ""),
                "parent_id": "",
                "source": "crawl.db",
            })
    except sqlite3.Error:
        logger.debug("suppressed exception")
    finally:
        c.close()
    return rows


def _normal_sessions(company_ids: set) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    c = _db(os.path.join(_PROJECT_ROOT, "data", "chat.db"))
    if c is None:
        return rows
    try:
        for r in c.execute(
                "SELECT session_id, parent_id, role, title, created_at, state "
                "FROM chat_session ORDER BY created_at DESC LIMIT 500"):
            sid = str(r["session_id"] or "")
            if sid in company_ids:
                continue   # 双登记：company 台账为准（收口项 20 归类口径）
            rows.append({
                "session_id": sid,
                "name": str(r["title"] or sid or ""),
                "kind": "normal",
                "state": str(r["state"] or ""),
                "created_at": float(r["created_at"] or 0),
                "parent_id": str(r["parent_id"] or ""),
                "source": "chat.db",
            })
    except sqlite3.Error:
        logger.debug("suppressed exception")
    finally:
        c.close()
    return rows


def unified_sessions(limit: int = 500, force: bool = False) -> List[Dict[str, Any]]:
    """三类会话统一字段列表（created_at 降序；1s 缓存）。"""
    now = time.time()
    if not force and _CACHE["rows"] is not None and now - _CACHE["ts"] < _LIST_TTL_S:
        return _CACHE["rows"][:limit]
    company = _company_sessions()
    company_ids = {r["session_id"] for r in company}
    rows = company + _crawl_sessions() + _normal_sessions(company_ids)
    rows.sort(key=lambda r: str(r.get("created_at") or ""), reverse=True)
    _CACHE["ts"] = now
    _CACHE["rows"] = rows
    return rows[:limit]


if __name__ == "__main__":
    import json
    rows = unified_sessions(force=True)
    print(json.dumps({"count": len(rows),
                      "kinds": {k: sum(1 for r in rows if r["kind"] == k)
                                for k in ("company", "crawl", "normal")},
                      "first": rows[0] if rows else None},
                     ensure_ascii=False, indent=2))
