# -*- coding: utf-8 -*-
"""★ D6-06: 长任务后台化（关窗存活）。

- 独立 worker 进程（scripts/lemon_worker.py）：读 job 文件 → 执行 →
  写结果 JSONL + 心跳 → 完成通知
- 主程序关窗时把正在跑的长任务转交 worker（spawn detached）
- 重启后检测未收尾任务 → 断点续跑（resume）
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from typing import Dict, List, Optional

# shared/worker.py → 仓库根 = 上两级
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORKER_DIR = os.path.join(_ROOT, "data", "worker")
JOBS_DIR = os.path.join(WORKER_DIR, "jobs")
RESULTS_DIR = os.path.join(WORKER_DIR, "results")
HEARTBEAT_DIR = os.path.join(WORKER_DIR, "heartbeat")
WORKER_SCRIPT = os.path.join(_ROOT, "scripts", "lemon_worker.py")


def _ensure_dirs():
    for d in (JOBS_DIR, RESULTS_DIR, HEARTBEAT_DIR):
        os.makedirs(d, exist_ok=True)


def _job_path(job_id: str) -> str:
    return os.path.join(JOBS_DIR, f"{job_id}.json")


def _result_path(job_id: str) -> str:
    return os.path.join(RESULTS_DIR, f"{job_id}.jsonl")


def _hb_path(job_id: str) -> str:
    return os.path.join(HEARTBEAT_DIR, f"{job_id}.json")


def submit(cmd: str, session_id: str = "", timeout: int = 0,
           job_id: str = None) -> Dict:
    """提交长任务：写 job 文件 → spawn detached worker。"""
    _ensure_dirs()
    jid = job_id or ("job_" + str(int(time.time() * 1000)))
    payload = {"job_id": jid, "cmd": cmd, "session_id": session_id,
               "timeout": int(timeout or 0),
               "created_at": time.strftime("%Y-%m-%d %H:%M:%S")}
    with open(_job_path(jid), "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    spawn(jid)
    return {"ok": True, "job_id": jid, "job_file": _job_path(jid)}


def spawn(job_id: str) -> bool:
    """分离式启动 worker（关窗不受影响）。"""
    _ensure_dirs()
    if not os.path.exists(WORKER_SCRIPT):
        return False
    py = os.path.join(_ROOT, "_py312", "python.exe")
    if not os.path.exists(py):
        py = sys.executable
    flags = 0
    if os.name == "nt":
        flags = getattr(subprocess, "DETACHED_PROCESS", 0)
    try:
        env = dict(os.environ)
        # ★ 把 worker 根传给子进程（测试/外部可重定向到临时目录）
        env["LW_WORKER_ROOT"] = os.path.dirname(os.path.abspath(JOBS_DIR))
        subprocess.Popen(
            [py, "-u", WORKER_SCRIPT, job_id],
            cwd=_ROOT, stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            env=env, creationflags=flags,
        )
        return True
    except Exception as e:
        print(f"[worker] spawn 失败: {e}")
        return False


def list_pending() -> List[Dict]:
    """未收尾任务：有 job 文件但无完成结果。"""
    _ensure_dirs()
    out = []
    for fn in sorted(os.listdir(JOBS_DIR)):
        if not fn.endswith(".json"):
            continue
        jid = fn[:-5]
        if os.path.exists(_result_path(jid)):
            continue
        try:
            with open(_job_path(jid), "r", encoding="utf-8") as f:
                out.append(json.load(f))
        except Exception:
            continue
    return out


def resume() -> Dict:
    """断点续跑：重启后把未收尾任务重新交给 worker。"""
    pend = list_pending()
    spawned = []
    for j in pend:
        if spawn(j["job_id"]):
            spawned.append(j["job_id"])
    return {"ok": True, "pending": [j["job_id"] for j in pend],
            "spawned": spawned}


def result(job_id: str) -> Optional[Dict]:
    p = _result_path(job_id)
    if not os.path.exists(p):
        return None
    try:
        with open(p, "r", encoding="utf-8") as f:
            lines = [json.loads(x) for x in f if x.strip()]
        return lines[-1] if lines else None
    except Exception:
        return None


def heartbeat(job_id: str) -> Optional[Dict]:
    p = _hb_path(job_id)
    if not os.path.exists(p):
        return None
    try:
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


__all__ = ["submit", "spawn", "list_pending", "resume", "result",
           "heartbeat", "JOBS_DIR", "RESULTS_DIR", "HEARTBEAT_DIR"]
