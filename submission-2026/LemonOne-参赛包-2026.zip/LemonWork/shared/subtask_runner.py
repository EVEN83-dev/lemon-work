# -*- coding: utf-8 -*-
"""
F2 · 并行子任务运行器 (shared/subtask_runner.py) V1.6-WPD
==========================================================
主任务可派生 N 个子任务，独立上下文、独立预算、并行执行。
面板状态 queued/running/done/failed；父任务可等待/取消/汇总。

铁律：
  - 子任务不共享可变全局状态（每个子任务独立上下文 dict）
  - 单子任务失败不影响其他
  - 全部函数 try/except 自包
"""
from __future__ import annotations

import logging
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, Future
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

_VALID_STATES = {"queued", "running", "done", "failed", "cancelled"}
_MAX_WORKERS = 4


@dataclass
class SubTask:
    """单个并行子任务"""
    task_id: str
    name: str
    prompt: str
    state: str = "queued"
    context: Dict[str, Any] = field(default_factory=dict)
    budget: int = 0            # token 预算上限（0=不限）
    result: Any = None
    error: str = ""
    started_at: float = 0.0
    finished_at: float = 0.0
    elapsed_ms: float = 0.0
    parent_id: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id, "name": self.name, "prompt": self.prompt,
            "state": self.state, "budget": self.budget,
            "result": self.result, "error": self.error,
            "started_at": self.started_at, "finished_at": self.finished_at,
            "elapsed_ms": self.elapsed_ms, "parent_id": self.parent_id,
        }


class SubTaskRunner:
    """并行子任务运行器。

    用法:
        runner = SubTaskRunner()
        runner.spawn(parent_id, "任务A", prompt, context={...}, budget=1000)
        runner.wait_all(timeout=30)
        summary = runner.summarize()
    """

    def __init__(self, max_workers: int = _MAX_WORKERS):
        self._tasks: Dict[str, SubTask] = {}
        self._futures: Dict[str, Future] = {}
        self._executor = ThreadPoolExecutor(max_workers=max_workers)
        self._lock = threading.RLock()
        self._handlers: Dict[str, Callable] = {}

    # ── 注册处理器 ──────────────────────────────────────────────
    def register_handler(self, name: str, fn: Callable[[SubTask], Any]) -> None:
        """注册子任务处理器 fn(task) -> result"""
        self._handlers[name] = fn

    # ── 派生 ────────────────────────────────────────────────────
    def spawn(self, parent_id: str, name: str, prompt: str,
              context: Optional[Dict[str, Any]] = None,
              budget: int = 0, handler: Optional[str] = None) -> SubTask:
        """派生一个子任务（独立上下文，不共享全局状态）。"""
        with self._lock:
            task_id = f"sub_{uuid.uuid4().hex[:12]}"
            task = SubTask(
                task_id=task_id, name=name, prompt=prompt,
                context=dict(context or {}), budget=budget,
                parent_id=parent_id,
            )
            self._tasks[task_id] = task
            if handler and handler in self._handlers:
                fn = self._handlers[handler]
                self._futures[task_id] = self._executor.submit(
                    self._run_one, task, fn)
            return task

    def _run_one(self, task: SubTask, fn: Callable) -> None:
        """执行单个子任务，失败不影响其他。"""
        with self._lock:
            if task.state == "cancelled":
                return
            task.state = "running"
            task.started_at = time.time()
        try:
            result = fn(task)
            with self._lock:
                task.result = result
                task.state = "done"
                task.finished_at = time.time()
                task.elapsed_ms = (task.finished_at - task.started_at) * 1000
        except Exception as e:
            with self._lock:
                task.error = str(e)
                task.state = "failed"
                task.finished_at = time.time()
                task.elapsed_ms = (task.finished_at - task.started_at) * 1000
            logger.warning(f"[SubTask] {task.name} 失败: {e}")

    # ── 等待 ────────────────────────────────────────────────────
    def wait_all(self, timeout: float = 30.0) -> bool:
        """等待全部子任务完成，超时返回 False。"""
        deadline = time.time() + timeout
        while time.time() < deadline:
            with self._lock:
                active = [t for t in self._tasks.values()
                          if t.state in ("queued", "running")]
            if not active:
                return True
            time.sleep(0.05)
        return False

    def wait_one(self, task_id: str, timeout: float = 30.0) -> Optional[SubTask]:
        """等待单个子任务。"""
        fut = self._futures.get(task_id)
        if fut:
            try:
                fut.result(timeout=timeout)
            except Exception:
                logger.debug("suppressed exception")
        return self._tasks.get(task_id)

    # ── 取消 ────────────────────────────────────────────────────
    def cancel(self, task_id: str) -> bool:
        """取消单个子任务。"""
        with self._lock:
            task = self._tasks.get(task_id)
            if not task:
                return False
            if task.state in ("queued", "running"):
                task.state = "cancelled"
                task.finished_at = time.time()
                fut = self._futures.get(task_id)
                if fut:
                    fut.cancel()
                return True
            return False

    def cancel_all(self) -> int:
        """取消全部未完成子任务，返回取消数。"""
        n = 0
        with self._lock:
            for t in self._tasks.values():
                if t.state in ("queued", "running"):
                    t.state = "cancelled"
                    t.finished_at = time.time()
                    fut = self._futures.get(t.task_id)
                    if fut:
                        fut.cancel()
                    n += 1
        return n

    # ── 汇总 ────────────────────────────────────────────────────
    def get(self, task_id: str) -> Optional[SubTask]:
        return self._tasks.get(task_id)

    def list_all(self) -> List[Dict[str, Any]]:
        """返回全部子任务状态（供面板渲染）。"""
        with self._lock:
            return [t.to_dict() for t in self._tasks.values()]

    def summarize(self) -> Dict[str, Any]:
        """汇总：成功/失败/耗时。"""
        with self._lock:
            tasks = list(self._tasks.values())
        done = [t for t in tasks if t.state == "done"]
        failed = [t for t in tasks if t.state == "failed"]
        cancelled = [t for t in tasks if t.state == "cancelled"]
        total_elapsed = sum(t.elapsed_ms for t in done + failed)
        return {
            "total": len(tasks), "done": len(done), "failed": len(failed),
            "cancelled": len(cancelled),
            "results": [t.result for t in done],
            "errors": [{"task_id": t.task_id, "name": t.name, "error": t.error} for t in failed],
            "total_elapsed_ms": round(total_elapsed, 2),
        }

    def shutdown(self) -> None:
        """关闭执行器。"""
        try:
            self._executor.shutdown(wait=False)
        except Exception:
            logger.debug("suppressed exception")


# ════════════════════════════════════════════════════════════════
# 单例
# ════════════════════════════════════════════════════════════════
_runner: Optional[SubTaskRunner] = None
_runner_lock = threading.Lock()


def get_subtask_runner() -> SubTaskRunner:
    global _runner
    if _runner is None:
        with _runner_lock:
            if _runner is None:
                _runner = SubTaskRunner()
    return _runner
