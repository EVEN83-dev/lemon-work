# -*- coding: utf-8 -*-
"""★ W23-10: 统一工具返回语义

- dict{"ok": false} → SkillResult(success=False)
- JSON 字符串 {"ok": false} → success=False
- 不再把业务失败包装成 success=True
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import json
from typing import Any, Dict, Optional


def normalize_result(result: Any) -> Dict[str, Any]:
    """分析 handler 返回值，判定 success 语义

    Returns:
        {"success": bool, "output": str, "error": str|None, "data": dict|None}
    """
    # 已经是 SkillResult
    if hasattr(result, "success") and hasattr(result, "output"):
        return {"success": bool(result.success),
                "output": str(result.output or ""),
                "error": getattr(result, "error", None),
                "data": getattr(result, "data", None)}

    # dict
    if isinstance(result, dict):
        ok = result.get("ok")
        if ok is False:
            return {"success": False,
                    "output": str(result.get("output") or result.get("error") or ""),
                    "error": result.get("error"),
                    "data": result}
        if ok is True:
            return {"success": True,
                    "output": str(result.get("output") or ""),
                    "error": None,
                    "data": result}
        # 无 ok 字段：默认 success=True（向后兼容）
        return {"success": True,
                "output": json.dumps(result, ensure_ascii=False),
                "error": None,
                "data": result}

    # 字符串：尝试解析 JSON
    if isinstance(result, str):
        s = result.strip()
        if s.startswith("{") and s.endswith("}"):
            try:
                parsed = json.loads(s)
                if isinstance(parsed, dict):
                    return normalize_result(parsed)
            except Exception:
                logger.debug("suppressed exception")
        return {"success": True, "output": result, "error": None, "data": None}

    # 其他类型
    return {"success": True, "output": str(result), "error": None, "data": None}


def make_skill_result(result: Any, auto_mode: bool = False):
    """转换为 SkillResult（统一入口）"""
    from standard_mode.core.skills_registry import SkillResult
    n = normalize_result(result)
    data = n.get("data")
    if auto_mode:
        data = dict(data) if isinstance(data, dict) else {}
        data["_auto_mode"] = True
    elif data is None and auto_mode:
        data = {"_auto_mode": True}
    return SkillResult(success=n["success"], output=n["output"],
                       error=n.get("error"), data=data)


if __name__ == "__main__":
    # 测试
    print(normalize_result({"ok": False, "error": "参数错误"}))
    print(normalize_result('{"ok": false, "error": "JSON错误"}'))
    print(normalize_result({"ok": True, "output": "成功"}))
    print(normalize_result("普通字符串"))
    print(normalize_result(123))
