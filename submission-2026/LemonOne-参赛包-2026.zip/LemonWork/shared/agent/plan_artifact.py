# -*- coding: utf-8 -*-
"""★ D7-01: 计划工件（Plan Artifact）—— 外部状态，防 goal loss。

工件结构：
  {
    "goal": str,
    "steps": [{"id": str, "desc": str, "status": "pending|running|done|failed|skipped",
               "findings": str}],
    "updated_at": "..."
  }

- 落盘 data/agent_plans/<session>.json，每步变更**原子写**（tmp + replace）
- 计划全部终态才允许自然收尾（调用方判定）
- 计划工件全文永不进压缩（D7-04 豁免）
"""
from __future__ import annotations

import json
import os
import time
from typing import Dict, List, Optional

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PLAN_DIR = os.path.join(_ROOT, "data", "agent_plans")

TERMINAL = ("done", "failed", "skipped")


def _path(session: str) -> str:
    safe = "".join(c for c in str(session or "default") if c.isalnum() or c in "-_")
    return os.path.join(PLAN_DIR, f"{safe or 'default'}.json")


def new_plan(goal: str, steps: List[str]) -> Dict:
    return {
        "goal": str(goal or ""),
        "steps": [{"id": f"s{i + 1}", "desc": str(d), "status": "pending",
                   "findings": ""} for i, d in enumerate(steps or [])],
        "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }


def load(session: str) -> Optional[Dict]:
    p = _path(session)
    if not os.path.exists(p):
        return None
    try:
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def save(session: str, plan: Dict) -> Dict:
    """原子写（tmp + replace）。"""
    p = _path(session)
    try:
        os.makedirs(os.path.dirname(p), exist_ok=True)
        plan = dict(plan)
        plan["updated_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
        tmp = p + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(plan, f, ensure_ascii=False, indent=2)
        os.replace(tmp, p)
        return {"ok": True, "path": p}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": str(e)[:200]}


def update_step(session: str, step_id: str, status: str = None,
                findings: str = None) -> Dict:
    plan = load(session)
    if not plan:
        return {"ok": False, "error": "no plan"}
    for s in plan.get("steps", []):
        if s.get("id") == step_id:
            if status:
                s["status"] = status
            if findings is not None:
                s["findings"] = findings
            break
    else:
        return {"ok": False, "error": f"no step {step_id}"}
    return save(session, plan)


def first_pending(session: str) -> Optional[int]:
    """返回第一个非终态步骤的索引；全终态返回 None。"""
    plan = load(session)
    if not plan:
        return None
    for i, s in enumerate(plan.get("steps", [])):
        if s.get("status") not in TERMINAL:
            return i
    return None


def is_complete(session: str) -> bool:
    plan = load(session)
    if not plan:
        return True
    return all(s.get("status") in TERMINAL for s in plan.get("steps", []))


def remaining(session: str) -> int:
    plan = load(session)
    if not plan:
        return 0
    return sum(1 for s in plan.get("steps", []) if s.get("status") not in TERMINAL)


def continuation_text(session: str) -> Optional[str]:
    """返回计划续跑提示；计划不存在/已全终态 → None（可自然收尾）。"""
    plan = load(session)
    if not plan or is_complete(session):
        return None
    idx = first_pending(session)
    steps = plan.get("steps") or []
    if idx is None or idx >= len(steps):
        return None
    desc = steps[idx].get("desc") or ""
    return (f"【计划续跑】当前计划仍有未完项（第 {idx + 1}/{len(steps)} 步：{desc}）。"
            f"请继续执行该步（可调用工具），完成后更新计划状态；不要提前收尾。")


def list_sessions() -> List[str]:
    if not os.path.isdir(PLAN_DIR):
        return []
    return [f[:-5] for f in sorted(os.listdir(PLAN_DIR)) if f.endswith(".json")]


__all__ = ["new_plan", "load", "save", "update_step", "first_pending",
           "is_complete", "remaining", "list_sessions", "PLAN_DIR", "TERMINAL"]
