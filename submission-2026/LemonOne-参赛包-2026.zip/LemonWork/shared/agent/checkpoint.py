# -*- coding: utf-8 -*-
"""★ D7-03: checkpoint / resume（持久化，关窗可恢复）。

快照内容：消息截尾 + 计划工件全文（恢复真源）+ 工具结果摘要。
落盘 data/agent_checkpoints/<session>.json（原子写）。

- 每 10 轮自动 checkpoint
- 撞顶 / 异常 / 关窗 → checkpoint
- 重开窗口同会话检测到 checkpoint → 「继续上次任务」
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import json
import os
import time
from typing import Dict, List, Optional

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CKPT_DIR = os.path.join(_ROOT, "data", "agent_checkpoints")

MSG_TAIL = 8            # 消息截尾保留条数
TOOL_SUMMARY_CAP = 20   # 工具结果摘要条数


def _path(session: str) -> str:
    safe = "".join(c for c in str(session or "default") if c.isalnum() or c in "-_")
    return os.path.join(CKPT_DIR, f"{safe or 'default'}.json")


def _tool_summary(tool_calls: List[dict]) -> List[Dict]:
    out = []
    for t in (tool_calls or [])[-TOOL_SUMMARY_CAP:]:
        args = t.get("arguments") or t.get("args") or {}
        if isinstance(args, str):
            args = args[:200]
        out.append({"name": t.get("name") or t.get("tool_name"),
                    "args": args})
    return out


def save(session: str, iteration: int, messages: List[dict],
         tool_calls_made: Optional[List[dict]] = None) -> Dict:
    """落盘 checkpoint（含计划工件全文——恢复真源）。"""
    try:
        from shared.agent import plan_artifact as pa
        plan = pa.load(session)
    except Exception:
        plan = None
    try:
        os.makedirs(CKPT_DIR, exist_ok=True)
        snap = {
            "session": session,
            "iteration": int(iteration),
            "saved_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "messages_tail": [m for m in (messages or [])[-MSG_TAIL:]],
            "plan": plan,
            "tool_summary": _tool_summary(tool_calls_made or []),
            "tool_count": len(tool_calls_made or []),
        }
        p = _path(session)
        tmp = p + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(snap, f, ensure_ascii=False, indent=2)
        os.replace(tmp, p)
        return {"ok": True, "path": p, "iteration": snap["iteration"],
                "has_plan": plan is not None}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": str(e)[:200]}


def load(session: str) -> Optional[Dict]:
    p = _path(session)
    if not os.path.exists(p):
        return None
    try:
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def clear(session: str) -> bool:
    p = _path(session)
    try:
        if os.path.exists(p):
            os.remove(p)
        return True
    except Exception:
        return False


def has_pending(session: str) -> bool:
    """是否存在未收尾 checkpoint（供「继续上次任务」入口判定）。"""
    snap = load(session)
    if not snap:
        return False
    plan = snap.get("plan")
    if plan:
        from shared.agent import plan_artifact as pa
        try:
            if not pa.is_complete(session):
                return True
        except Exception:
            logger.debug("suppressed exception")
    # 无计划工件时：只要有 checkpoint 就认为可续
    return True


def every_n_iterations(n: int = 10):
    """返回判定函数：每 n 轮 checkpoint。"""
    return lambda iteration: iteration > 0 and iteration % n == 0


__all__ = ["save", "load", "clear", "has_pending", "every_n_iterations",
           "CKPT_DIR", "MSG_TAIL"]
