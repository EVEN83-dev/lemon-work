# -*- coding: utf-8 -*-
"""★ D7-04: 压缩升级 —— 滚动摘要 + 计划豁免 + 目标回顾。

- 压缩触发时对被裁的早期轮次做 LLM 滚动摘要（≤300 字「此前进展」）；
  失败降级现行规则（首末各 2 条 + 计数）
- **计划工件全文永不进压缩**（外部状态豁免 —— goal loss 的直接防御）
- 压缩后注入「目标回顾」段（goal + 剩余步骤）
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import os
import re
from typing import Dict, List, Optional

MAX_SUMMARY_CHARS = 300

# 计划相关消息的识别（这些消息不参与压缩摘要）
_PLAN_MARKERS = ("【计划续跑】", "计划工件", "[计划", "step_id", "计划状态")


def is_plan_message(m: dict) -> bool:
    c = str((m or {}).get("content") or "")
    return any(k in c for k in _PLAN_MARKERS)


def split_plan_messages(messages: List[dict]) -> (List[dict], List[dict]):
    """把计划相关消息单独抽出（永不进压缩）。"""
    plan, rest = [], []
    for m in messages or []:
        (plan if is_plan_message(m) else rest).append(m)
    return plan, rest


def rolling_early_summary(early_messages: List[dict],
                          engine: str = "ollama") -> Dict:
    """对被裁的早期轮次做滚动摘要；失败降级规则摘要。"""
    msgs = [m for m in (early_messages or [])
            if str(m.get("content") or "").strip()]
    if not msgs:
        return {"summary": "", "engine": "none", "degraded": False}

    # LLM 摘要（复用 D6-08 的 rolling_summary）
    try:
        from shared.llm.activate import rolling_summary as _rs
        r = _rs([{"role": m.get("role", "user"), "content": m.get("content", "")}
                 for m in msgs], threshold=1)
        if r.get("summary") and not r.get("degraded"):
            s = r["summary"][:MAX_SUMMARY_CHARS]
            return {"summary": s, "engine": "ollama", "degraded": False}
        if r.get("summary"):
            return {"summary": r["summary"][:MAX_SUMMARY_CHARS],
                    "engine": r.get("engine", "rule_fallback"), "degraded": True}
    except Exception:
        logger.debug("suppressed exception")

    # 规则降级：首末各 2 条 + 计数
    head = [f"{m.get('role','?')}: {str(m.get('content',''))[:60]}"
            for m in msgs[:2]]
    tail = [f"{m.get('role','?')}: {str(m.get('content',''))[:60]}"
            for m in msgs[-2:]]
    s = f"共 {len(msgs)} 条被压缩。开头：{' / '.join(head)}；结尾：{' / '.join(tail)}"
    return {"summary": s[:MAX_SUMMARY_CHARS], "engine": "rule_fallback",
            "degraded": True}


def goal_review(goal: str, remaining_steps: List[str]) -> str:
    """压缩后注入的「目标回顾」段。"""
    steps = "；".join(remaining_steps) if remaining_steps else "（无）"
    return (f"【目标回顾，请勿遗忘】原始目标：{goal}。"
            f"尚未完成的步骤：{steps}。请围绕该目标继续推进。")


def compact(messages: List[dict], goal: str = "",
            remaining_steps: Optional[List[str]] = None) -> Dict:
    """压缩一条链：抽离计划 → 早期滚动摘要 → 保留近期 + 目标回顾。

    Returns:
        {"messages": [...], "summary": str, "engine": str, "degraded": bool,
         "plan_kept": int}
    """
    plan_msgs, rest = split_plan_messages(messages)
    if len(rest) <= 8:
        return {"messages": messages, "summary": "", "engine": "skipped",
                "degraded": False, "plan_kept": len(plan_msgs)}
    system_msgs = [m for m in rest if m.get("role") == "system"]
    tail = rest[-6:]
    early = rest[:-6]
    s = rolling_early_summary(early)
    inject = [{"role": "system",
               "content": f"[此前进展（滚动摘要，{s['engine']}）] {s['summary']}"}]
    if goal:
        inject.append({"role": "user", "content": goal_review(goal, remaining_steps or [])})
    return {"messages": system_msgs + inject + tail,
            "summary": s["summary"], "engine": s["engine"],
            "degraded": s["degraded"], "plan_kept": len(plan_msgs)}


__all__ = ["is_plan_message", "split_plan_messages", "rolling_early_summary",
           "goal_review", "compact", "MAX_SUMMARY_CHARS"]
