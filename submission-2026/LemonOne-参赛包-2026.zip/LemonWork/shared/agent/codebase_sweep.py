# -*- coding: utf-8 -*-
"""★ D7-05: codebase_sweep 编排（逐模块批量排查 SOP）。

流程：
  a) 扫描生成 modules.json（模块清单 + 行数 + 依赖排序，唯一手工编辑结构文件）
  b) 逐模块派 worker（隔离上下文，brief=三线审查：注释完整性 / 安全 / 逻辑缺陷）
  c) 并行 ≤4、单 worker 超时 600s、失败重派 1 次
  d) findings 合并 + 全局一致性检查（跨模块命名/接口统一）
  e) audit_report（分模块问题 + 风险分级 + 修复建议）+ 逐模块进度

反模式防护：worker brief 写死「穷尽本模块所有发现，禁止见首个问题即停」。
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import ast
import json
import os
import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Callable, Dict, List, Optional

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SWEEP_LINES = ("annotate", "security", "logic")
MAX_PARALLEL = 4
WORKER_TIMEOUT = 600
MAX_RETRIES = 1

FINDING_SCHEMA = {"module", "line", "severity", "kind", "desc", "suggestion"}
SEVERITIES = ("info", "warn", "err")


# ── a) 扫描 ──
def scan_modules(scope: str) -> List[Dict]:
    """扫描 .py 模块：路径 / 行数 / 导入的本地模块（用于依赖排序）。"""
    out = []
    for root, dirs, files in os.walk(scope):
        dirs[:] = [d for d in dirs if d not in ("__pycache__", ".git", "node_modules")]
        for fn in sorted(files):
            if not fn.endswith(".py"):
                continue
            if fn == "__init__.py":
                continue          # 包标记，非审查模块
            p = os.path.join(root, fn)
            try:
                with open(p, "r", encoding="utf-8", errors="replace") as f:
                    src = f.read()
            except Exception:
                continue
            rel = os.path.relpath(p, scope).replace("\\", "/")
            imports = _local_imports(src, scope)
            out.append({"path": rel, "lines": src.count("\n") + 1,
                        "imports": imports, "deps": [], "status": "pending"})
    return _order_by_deps(out)


def _local_imports(src: str, scope: str) -> List[str]:
    mods = set()
    try:
        tree = ast.parse(src)
        for n in ast.walk(tree):
            if isinstance(n, ast.Import):
                for a in n.names:
                    mods.add(a.name.split(".")[0])
            elif isinstance(n, ast.ImportFrom):
                if n.module:
                    mods.add(n.module.split(".")[0])
                # `from pkg import mod` —— 被导入名可能是本地模块
                for a in n.names:
                    mods.add(a.name.split(".")[0])
    except Exception:
        logger.debug("suppressed exception")
    # 只保留指向本 scope 内文件的模块名
    local = set()
    for m in mods:
        if os.path.exists(os.path.join(scope, m + ".py")) or \
           os.path.exists(os.path.join(scope, m, "__init__.py")):
            local.add(m)
    return sorted(local)


def _order_by_deps(mods: List[Dict]) -> List[Dict]:
    """简单拓扑排序（被依赖者在前）；环则按路径兜底。"""
    by_name = {}
    for m in mods:
        name = os.path.splitext(os.path.basename(m["path"]))[0]
        by_name[name] = m
    seen, order, visiting = set(), [], set()

    def visit(m):
        # 用全路径作 key —— basename 去重会误删同名不同目录的模块
        key = m["path"]
        if key in seen or key in visiting:
            return
        visiting.add(key)
        for dep in m["imports"]:
            cand = by_name.get(dep)
            if cand is not None and cand["path"] != key:
                visit(cand)
        visiting.discard(key)
        seen.add(key)
        order.append(m)

    for m in sorted(mods, key=lambda x: x["path"]):
        visit(m)
    return order


def write_modules_json(scope: str, out_path: str) -> Dict:
    mods = scan_modules(scope)
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    payload = {"scope": os.path.abspath(scope), "generated_at": time.strftime(
        "%Y-%m-%d %H:%M:%S"), "modules": mods}
    tmp = out_path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    os.replace(tmp, out_path)
    return payload


# ── b) worker brief ──
def worker_brief(module: Dict, lines: List[str]) -> str:
    lines_txt = " / ".join(lines)
    return (
        f"审查模块 {module['path']}（{module['lines']} 行）。\n"
        f"审查线：{lines_txt}。\n"
        "要求：\n"
        "  1) 注释完整性：公开类/函数是否缺 docstring 或注释与实现不符。\n"
        "  2) 安全：注入、越权、敏感信息明文、不安全的命令/路径拼接。\n"
        "  3) 逻辑缺陷：边界、异常吞没、竞态、错误处理缺失。\n"
        "★ 穷尽本模块所有发现，禁止见首个问题即停；无问题则显式返回 clean。\n"
        "输出 findings JSON（固定 schema）："
        + json.dumps(sorted(FINDING_SCHEMA), ensure_ascii=False)
    )


# ── c) 调度 ──
def run_sweep(scope: str, worker_fn: Callable[[Dict, List[str]], Dict],
              lines: Optional[List[str]] = None,
              max_parallel: int = MAX_PARALLEL,
              timeout: int = WORKER_TIMEOUT,
              retries: int = MAX_RETRIES) -> Dict:
    """逐模块派 worker；并行 ≤max_parallel；失败重派 retries 次。

    worker_fn(module, lines) -> {"findings": [...], "clean": bool} 或抛异常
    """
    lines = list(lines or SWEEP_LINES)
    mods = scan_modules(scope)
    results: Dict[str, Dict] = {}

    def call(m, attempt):
        try:
            r = worker_fn(m, lines)
            fs_ = r.get("findings") or []
            bad = [f for f in fs_ if set(f) != FINDING_SCHEMA]
            return {"module": m["path"], "findings": fs_,
                    "clean": bool(r.get("clean")) or not fs_,
                    "invalid": len(bad), "attempt": attempt, "error": None}
        except Exception as e:  # noqa: BLE001
            return {"module": m["path"], "findings": [], "clean": False,
                    "invalid": 0, "attempt": attempt, "error": str(e)[:160]}

    pending = list(mods)
    with ThreadPoolExecutor(max_workers=max(1, min(max_parallel, 4))) as ex:
        futs = {ex.submit(call, m, 0): m for m in pending}
        for f in as_completed(futs):
            r = f.result()
            results[r["module"]] = r
    # 失败重派
    for m in mods:
        key = m["path"]
        if results.get(key, {}).get("clean") or not results.get(key, {}).get("error"):
            continue
        if results[key]["attempt"] <= retries:
            r2 = call(m, results[key]["attempt"] + 1)
            if not r2["error"]:
                results[key] = r2

    report = build_report(mods, results, lines)
    return report


# ── d/e) 合并 + 全局一致性 + 报告 ──
def _dedupe_name_conflicts(mods: List[Dict]) -> List[Dict]:
    """全局一致性：同名不同路径的模块（潜在复制粘贴）。"""
    seen = {}
    out = []
    for m in mods:
        name = os.path.splitext(os.path.basename(m["path"]))[0]
        if name in seen:
            out.append({"kind": "global_naming", "severity": "warn",
                        "desc": f"同名模块 {name}：{seen[name]} 与 {m['path']}",
                        "suggestion": "确认是否为复制粘贴，抽公共实现"})
        else:
            seen[name] = m["path"]
    return out


def build_report(mods: List[Dict], results: Dict[str, Dict],
                 lines: List[str]) -> Dict:
    per_module = []
    counts = {"info": 0, "warn": 0, "err": 0}
    for m in mods:
        r = results.get(m["path"], {"findings": [], "clean": True, "error": None})
        fs_ = r.get("findings") or []
        for f in fs_:
            sev = f.get("severity") if f.get("severity") in SEVERITIES else "info"
            counts[sev] += 1
        per_module.append({"path": m["path"], "lines": m["lines"],
                           "clean": bool(r.get("clean")),
                           "findings": fs_, "error": r.get("error")})
    global_issues = _dedupe_name_conflicts(mods)
    counts["warn"] += sum(1 for g in global_issues if g["severity"] == "warn")
    total = sum(counts.values())
    return {
        "scope_modules": len(mods),
        "lines": lines,
        "per_module": per_module,
        "counts": counts,
        "total_findings": total,
        "global_issues": global_issues,
        "clean_modules": sum(1 for x in per_module if x["clean"]),
        "audit_report": {
            "summary": f"{len(mods)} 模块 / {total} 条发现（err {counts['err']} / "
                       f"warn {counts['warn']} / info {counts['info']}）",
            "risk_level": "err" if counts["err"] else ("warn" if counts["warn"] else "ok"),
        },
        "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }


def save_report(report: Dict, out_path: str) -> Dict:
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    tmp = out_path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    os.replace(tmp, out_path)
    return {"ok": True, "path": out_path}


__all__ = ["scan_modules", "write_modules_json", "worker_brief", "run_sweep",
           "build_report", "save_report", "SWEEP_LINES", "FINDING_SCHEMA",
           "MAX_PARALLEL", "WORKER_TIMEOUT"]
