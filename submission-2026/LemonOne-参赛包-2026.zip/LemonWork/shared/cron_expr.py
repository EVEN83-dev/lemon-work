# -*- coding: utf-8 -*-
"""★ D6-09: cron 表达式（5 段，自实现，无第三方依赖）。

段：分(0-59) 时(0-23) 日(1-31) 月(1-12) 周(0-7, 0/7=周日)
支持：`*`、`?`、`*/n`、`a-b`、`a-b/n`、`a,b,c`、字面量
"""
from __future__ import annotations

from datetime import datetime, timedelta
from typing import List, Optional, Set, Tuple

FIELDS = [
    ("minute", 0, 59),
    ("hour", 0, 23),
    ("day", 1, 31),
    ("month", 1, 12),
    ("weekday", 0, 7),
]


def parse_field(expr: str, lo: int, hi: int) -> Set[int]:
    """解析单个 cron 段为取值集合。"""
    out: Set[int] = set()
    e = (expr or "").strip()
    if e in ("*", "?"):
        return set(range(lo, hi + 1))
    for part in e.split(","):
        part = part.strip()
        if not part:
            continue
        step = 1
        if "/" in part:
            base, _, s = part.partition("/")
            try:
                step = int(s)
            except ValueError:
                raise ValueError(f"非法步长: {part}")
            if step <= 0:
                raise ValueError(f"步长必须为正: {part}")
        else:
            base = part
        if base in ("*", ""):
            a, b = lo, hi
        elif "-" in base:
            x, _, y = base.partition("-")
            a, b = int(x), int(y)
        else:
            a = b = int(base)
        if a < lo or b > hi or a > b:
            raise ValueError(f"段越界: {part}")
        raw = set(range(a, b + 1, step))
        # 周字段：7 与 0 同为周日
        if hi == 7:
            raw = set((0 if x == 7 else x) for x in raw)
        out.update(raw)
    return out


def parse_cron(expr: str) -> Tuple[Set[int], Set[int], Set[int], Set[int], Set[int]]:
    """5 段 cron → 五个取值集合；非法表达式抛 ValueError。"""
    parts = (expr or "").split()
    if len(parts) != 5:
        raise ValueError(f"cron 需 5 段，实得 {len(parts)}: {expr!r}")
    sets = []
    for (name, lo, hi), p in zip(FIELDS, parts):
        try:
            sets.append(parse_field(p, lo, hi))
        except ValueError as e:
            raise ValueError(f"{name} 段: {e}")
    for name, s in zip([f[0] for f in FIELDS], sets):
        if not s:
            raise ValueError(f"{name} 段解析为空")
    return tuple(sets)  # type: ignore[return-value]


def _matches(dt: datetime, mi, ho, da, mo, wd) -> bool:
    # 周日归一：cron 的 0/7 都算周日
    iso = dt.isoweekday() % 7      # 周一=1 … 周日=0
    return (dt.minute in mi and dt.hour in ho and dt.day in da
            and dt.month in mo and iso in wd)


def next_run(expr: str, after: Optional[datetime] = None,
             limit: int = 366 * 24 * 60) -> Optional[datetime]:
    """计算下一次触发时间；无解返回 None。"""
    mi, ho, da, mo, wd = parse_cron(expr)
    t = (after or datetime.now()).replace(second=0, microsecond=0) + timedelta(minutes=1)
    for _ in range(limit):
        if _matches(t, mi, ho, da, mo, wd):
            return t
        t += timedelta(minutes=1)
    return None


def describe(expr: str) -> str:
    """人类可读描述（用于 UI/日志）。"""
    mi, ho, da, mo, wd = parse_cron(expr)
    def _fmt(s, names=None):
        if len(s) > 8:
            return "*"
        v = sorted(s)
        if names:
            return ",".join(names[x] for x in v)
        return ",".join(str(x) for x in v)
    wd_names = {0: "日", 1: "一", 2: "二", 3: "三", 4: "四", 5: "五", 6: "六", 7: "日"}
    return (f"分 {_fmt(mi)} / 时 {_fmt(ho)} / 日 {_fmt(da)} / "
            f"月 {_fmt(mo)} / 周 {_fmt(wd, wd_names)}")


__all__ = ["parse_cron", "parse_field", "next_run", "describe", "FIELDS"]
