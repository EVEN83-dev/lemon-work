# -*- coding: utf-8 -*-
"""shared/artifacts.py — 交付物注册表 V1.6-WPD

ArtifactRegistry 单例：统一管理 Agent 产出的可交付文件（html/csv/md/json/pptx）。
文件落盘到 LemonWork/data/artifacts/；内存保留最近 50 条索引。

用法:
    from shared.artifacts import get_artifact_registry
    reg = get_artifact_registry()
    reg.register("report", "/path/to/report.html", "html", 1234)
    items = reg.list()
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import json
import os
import time

_ARTIFACT_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "data", "artifacts")
_INDEX_FILE = os.path.join(_ARTIFACT_DIR, "_index.json")
_MAX_KEEP = 50
_VALID_KINDS = {"html", "csv", "md", "json", "pptx"}


class ArtifactRegistry:
    """交付物注册表单例"""

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._items = []
            cls._instance._loaded = False
        return cls._instance

    def _ensure_dir(self):
        os.makedirs(_ARTIFACT_DIR, exist_ok=True)

    def _load_index(self):
        """从磁盘加载索引（仅一次）"""
        if self._loaded:
            return
        self._loaded = True
        try:
            with open(_INDEX_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, list):
                self._items = [x for x in data if isinstance(x, dict)]
        except Exception:
            self._items = []

    def _save_index(self):
        """持久化索引到磁盘"""
        self._ensure_dir()
        try:
            with open(_INDEX_FILE, "w", encoding="utf-8") as f:
                json.dump(self._items[-_MAX_KEEP:], f, ensure_ascii=False, indent=1)
        except Exception:
            logger.debug("suppressed exception")

    def register(self, name: str, path: str, kind: str, size: int) -> dict:
        """注册一个交付物。

        Args:
            name: 显示名称
            path: 绝对路径
            kind: 文件类型 ∈ {html, csv, md, json, pptx}
            size: 文件大小（字节）

        Returns:
            注册成功的条目 dict；失败返回 {"error": "..."}
        """
        self._load_index()
        if kind not in _VALID_KINDS:
            return {"error": f"kind 必须是 {_VALID_KINDS} 之一，收到: {kind}"}
        if not name:
            return {"error": "name 不能为空"}
        if not path:
            return {"error": "path 不能为空"}
        item = {
            "id": f"art_{int(time.time() * 1000)}_{len(self._items)}",
            "name": name,
            "path": path,
            "kind": kind,
            "size": int(size or 0),
            "created_at": int(time.time()),
        }
        self._items.append(item)
        # 保留最近 50 个
        if len(self._items) > _MAX_KEEP:
            self._items = self._items[-_MAX_KEEP:]
        self._save_index()
        return item

    def list(self) -> list:
        """返回全部交付物条目（按创建时间倒序）"""
        self._load_index()
        return sorted(self._items, key=lambda x: x.get("created_at", 0), reverse=True)

    def get(self, artifact_id: str) -> dict | None:
        """按 ID 获取单个交付物"""
        self._load_index()
        for it in self._items:
            if it.get("id") == artifact_id:
                return it
        return None

    def prune(self) -> int:
        """清理超过 50 条的旧条目，返回清理数量"""
        self._load_index()
        before = len(self._items)
        self._items = self._items[-_MAX_KEEP:]
        self._save_index()
        return before - len(self._items)


def get_artifact_registry() -> ArtifactRegistry:
    """获取 ArtifactRegistry 单例"""
    return ArtifactRegistry()
