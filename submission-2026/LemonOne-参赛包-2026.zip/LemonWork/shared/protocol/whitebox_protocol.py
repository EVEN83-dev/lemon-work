# -*- coding: utf-8 -*-
"""A-10: 白盒协议唯一真源（跨端共享）。

三端（A 桥 / B HarmonyOS / C 小程序）共享的白盒事件模型：
  Run(L1) → Step(L2) → ToolCall(L3) + Approval/Artifact

- 事件名对齐 shared/tracer.py 的 TrajectoryEventType（当前 18 类，re-export 不复制值）
- 卡片类型对齐 bridge/protocol/card_protocol.py 的 CardType（当前 17 类）
- 投影幂等：对齐 standard_mode/ui/whitebox/state_projector.py 的
  _dedup_key / _seen_tool_calls（tool_call 去重键 = run_id + call_id）
- Run 可序列化回放：to_dict / from_dict 往返无损（对齐 RunRegistry
  serialize_run/deserialize_run/save_session/load_session 语义）

禁止三端各自定义同名不同值的枚举；本模块是唯一导出口。
"""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

PROTOCOL_VERSION = "1.0.0"

# ── 事件类型：唯一真源是 shared/tracer.py（re-export，不复制值） ──
try:
    from shared.tracer import TrajectoryEventType  # noqa: F401
except ImportError:  # pragma: no cover
    import sys
    import os
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from shared.tracer import TrajectoryEventType  # noqa: F401

TRAJECTORY_EVENT_TYPES: Dict[str, str] = {
    k: v for k, v in vars(TrajectoryEventType).items()
    if not k.startswith("_") and isinstance(v, str)
}
EVENT_TYPE_COUNT = len(TRAJECTORY_EVENT_TYPES)

# ── 卡片类型：唯一真源是 bridge/protocol/card_protocol.py ──
try:
    from bridge.protocol.card_protocol import CardType  # noqa: F401
except ImportError:  # pragma: no cover
    import sys
    import os
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from bridge.protocol.card_protocol import CardType  # noqa: F401

CARD_TYPES: Dict[str, str] = {
    k: v.value for k, v in vars(CardType).items()
    if isinstance(v, CardType)
}
CARD_TYPE_COUNT = len(CARD_TYPES)


# ── 工具调用去重键（幂等投影；对齐 state_projector._dedup_key） ──
def dedup_key(run_id: str, tool_call_id: str) -> str:
    """幂等投影去重键：同一 run 内的 tool_call 以 (run_id, call_id) 唯一。"""
    return f"{run_id}::{tool_call_id}"


@dataclass
class ToolCall:
    """L3：一次工具调用（可回放）。"""
    call_id: str = ""
    name: str = ""
    arguments: Dict[str, Any] = field(default_factory=dict)
    status: str = "pending"          # pending | ok | failed | timeout | denied
    result_summary: str = ""
    ts: float = field(default_factory=time.time)

    def __post_init__(self):
        if not self.call_id:
            self.call_id = "tc-" + uuid.uuid4().hex[:10]

    def to_dict(self) -> Dict[str, Any]:
        return {"call_id": self.call_id, "name": self.name,
                "arguments": self.arguments, "status": self.status,
                "result_summary": self.result_summary, "ts": self.ts}

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ToolCall":
        return cls(call_id=d.get("call_id", ""), name=d.get("name", ""),
                   arguments=d.get("arguments") or {}, status=d.get("status", "pending"),
                   result_summary=d.get("result_summary", ""), ts=d.get("ts", 0.0))


@dataclass
class Approval:
    """审批票据（与 A-05 鉴权票据共用同一结构）。"""
    approval_id: str = ""
    kind: str = "tool_call"          # tool_call | plan | permission
    subject: str = ""                # 被审批对象标识
    status: str = "pending"          # pending | approved | rejected | timeout
    created_at: float = field(default_factory=time.time)
    decided_at: float = 0.0
    timeout_ms: int = 600000         # 对齐 APPROVAL_TIMEOUT_MS=600000

    def to_dict(self) -> Dict[str, Any]:
        return {"approval_id": self.approval_id, "kind": self.kind,
                "subject": self.subject, "status": self.status,
                "created_at": self.created_at, "decided_at": self.decided_at,
                "timeout_ms": self.timeout_ms}

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Approval":
        return cls(approval_id=d.get("approval_id", ""), kind=d.get("kind", "tool_call"),
                   subject=d.get("subject", ""), status=d.get("status", "pending"),
                   created_at=d.get("created_at", 0.0), decided_at=d.get("decided_at", 0.0),
                   timeout_ms=int(d.get("timeout_ms", 600000)))


@dataclass
class Artifact:
    """产物引用（文件/卡片/截图）。"""
    artifact_id: str = ""
    kind: str = "file"               # file | card | screenshot | data
    path: str = ""
    digest: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {"artifact_id": self.artifact_id, "kind": self.kind,
                "path": self.path, "digest": self.digest}

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Artifact":
        return cls(artifact_id=d.get("artifact_id", ""), kind=d.get("kind", "file"),
                   path=d.get("path", ""), digest=d.get("digest", ""))


@dataclass
class Step:
    """L2：一个执行步骤（聚合若干 ToolCall）。"""
    step_id: str = ""
    run_id: str = ""
    index: int = 0
    kind: str = "action"             # plan | action | observation | final
    title: str = ""
    detail: str = ""
    tool_calls: List[ToolCall] = field(default_factory=list)
    ts: float = field(default_factory=time.time)

    def __post_init__(self):
        if not self.step_id:
            self.step_id = "st-" + uuid.uuid4().hex[:10]

    def to_dict(self) -> Dict[str, Any]:
        return {"step_id": self.step_id, "run_id": self.run_id, "index": self.index,
                "kind": self.kind, "title": self.title, "detail": self.detail,
                "tool_calls": [t.to_dict() for t in self.tool_calls], "ts": self.ts}

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Step":
        return cls(step_id=d.get("step_id", ""), run_id=d.get("run_id", ""),
                   index=int(d.get("index", 0)), kind=d.get("kind", "action"),
                   title=d.get("title", ""), detail=d.get("detail", ""),
                   tool_calls=[ToolCall.from_dict(t) for t in d.get("tool_calls") or []],
                   ts=d.get("ts", 0.0))


@dataclass
class Run:
    """L1：一次运行（可序列化回放的最小完整单元）。"""
    run_id: str = ""
    session_id: str = ""
    status: str = "pending"          # pending | running | done | failed | cancelled
    prompt: str = ""
    reply: str = ""
    steps: List[Step] = field(default_factory=list)
    approvals: List[Approval] = field(default_factory=list)
    artifacts: List[Artifact] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)
    ended_at: float = 0.0
    protocol_version: str = PROTOCOL_VERSION

    def __post_init__(self):
        if not self.run_id:
            self.run_id = "run-" + uuid.uuid4().hex[:12]

    def pending_approvals(self) -> List[Approval]:
        """A-11 对齐：pending_approvals 返回真实审批队列（非恒 []）。"""
        return [a for a in self.approvals if a.status == "pending"]

    def seen_tool_call_ids(self) -> List[str]:
        """幂等投影用：本 run 已见的 tool_call 去重键列表。"""
        keys = []
        for s in self.steps:
            for t in s.tool_calls:
                keys.append(dedup_key(self.run_id, t.call_id))
        return keys

    def to_dict(self) -> Dict[str, Any]:
        return {"run_id": self.run_id, "session_id": self.session_id,
                "status": self.status, "prompt": self.prompt, "reply": self.reply,
                "steps": [s.to_dict() for s in self.steps],
                "approvals": [a.to_dict() for a in self.approvals],
                "artifacts": [a.to_dict() for a in self.artifacts],
                "created_at": self.created_at, "ended_at": self.ended_at,
                "protocol_version": self.protocol_version}

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Run":
        return cls(run_id=d.get("run_id", ""), session_id=d.get("session_id", ""),
                   status=d.get("status", "pending"), prompt=d.get("prompt", ""),
                   reply=d.get("reply", ""),
                   steps=[Step.from_dict(s) for s in d.get("steps") or []],
                   approvals=[Approval.from_dict(a) for a in d.get("approvals") or []],
                   artifacts=[Artifact.from_dict(a) for a in d.get("artifacts") or []],
                   created_at=d.get("created_at", 0.0), ended_at=d.get("ended_at", 0.0),
                   protocol_version=d.get("protocol_version", PROTOCOL_VERSION))


def summary() -> Dict[str, Any]:
    """协议摘要（供三端机检比对与 /api 暴露）。"""
    return {"protocol_version": PROTOCOL_VERSION,
            "event_type_count": EVENT_TYPE_COUNT,
            "card_type_count": CARD_TYPE_COUNT,
            "event_types": dict(sorted(TRAJECTORY_EVENT_TYPES.items())),
            "card_types": dict(sorted(CARD_TYPES.items()))}


__all__ = [
    "PROTOCOL_VERSION", "TrajectoryEventType", "TRAJECTORY_EVENT_TYPES",
    "EVENT_TYPE_COUNT", "CardType", "CARD_TYPES", "CARD_TYPE_COUNT",
    "dedup_key", "ToolCall", "Approval", "Artifact", "Step", "Run",
    "summary",
]
