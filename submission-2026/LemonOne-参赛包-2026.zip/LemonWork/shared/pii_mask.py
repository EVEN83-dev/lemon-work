# -*- coding: utf-8 -*-
"""pii_mask —— 个人信息脱敏统一实现（v10 · 铁律 2 的唯一真源）

简历 / 手机号 / 身份证 / 邮箱 / 微信号 / 银行卡号在**数据库、审计、日志、对话产物**
里一律脱敏；明文只允许出现在用户确认导出的最终成品 PDF 中。

本模块被三处共用，故单独成文件（放 career_kb 里会让 browser_policy 反向依赖业务层）：
  · shared/career_kb.py        面经入库前
  · shared/browser_policy.py   审计落库前（url / detail）
  · resume_studio              简历进 LLM 前

刻意不做的两件事，避免"看起来安全其实不安全"：
  1) 不做可逆变换。脱敏后不留原文副本，也不留映射表 —— 留了等于没脱敏。
  2) 不宣称覆盖全部 PII。下面是常见高置信模式；中文姓名歧义太高，
     只按显式上下文（"姓名：" "联系人："）打码，见 mask_names。
"""
from __future__ import annotations

import re
from typing import Callable, Dict, List, Tuple

_KEEP = 2      # 保留可见的尾部字符数
_MASK = "***"

# URL query 里的敏感参数（审计日志的主要泄露面）
_URL_PARAM = re.compile(
    r"([?&])([A-Za-z_]*(?:token|auth|apikey|api_key|secret|passwd|password|pwd|"
    r"session|sid|phone|mobile|tel|idcard|id_no|identity|wechat|wxid)[A-Za-z_]*)"
    r"=([^&\s#]*)", re.I)


def _r_phone(m):      # 138****5678 → 保留 3+4，中段全遮
    return f"{m.group(1)}{_MASK}{m.group(3)}"


def _r_idcard(m):
    return f"{m.group(1)}{_MASK}{m.group(3)[-2:]}"


def _r_bankcard(m):
    return f"{m.group(1)}{_MASK}{m.group(3)[-2:]}"


def _r_email(m):      # ***@example.com —— 本地部全遮，域名完整保留
    return f"{_MASK}{m.group(2)}"


def _r_wechat(m):
    return f"{m.group(1)}{_MASK}"


_PATTERNS: List[Tuple[str, "re.Pattern[str]", "Callable"]] = [
    ("idcard", re.compile(r"(?<![0-9Xx])(\d{6})(\d{8})(\d{3}[0-9Xx])(?![0-9Xx])"), _r_idcard),
    # 手机号：11 位，1[3-9] 开头，前后不能再接数字
    ("phone", re.compile(r"(?<!\d)(1[3-9]\d)(\d{4})(\d{4})(?!\d)"), _r_phone),
    # 微信号先于银行卡：微信值可能是字母数字混合，避免被数字模式误吃
    ("wechat", re.compile(r"((?:微信|微信号|wx|weixin|vx)\s*[:：为]?\s*)"
                          r"([A-Za-z][-_A-Za-z0-9]{5,19})", re.I), _r_wechat),
    ("email", re.compile(r"([A-Za-z0-9._%+-]+)(@[A-Za-z0-9.-]+\.[A-Za-z]{2,})"), _r_email),
    # 银行卡：16–19 位连续数字（带分隔符的写法先不处理，避免误伤金额）
    ("bankcard", re.compile(r"(?<!\d)(\d{4})(\d{8,11})(\d{4})(?!\d)"), _r_bankcard),
]


def mask_pii(text: str) -> str:
    """把常见 PII 打码。非字符串入参原样返回（审计路径常在 str() 前调用）。"""
    if not isinstance(text, str) or not text:
        return text
    out = text
    for _kind, pat, repl in _PATTERNS:
        out = pat.sub(repl, out)
    return out


def mask_url(url: str) -> str:
    """URL 专项：脱敏 query 里的 token/手机号等参数值，保留路径可读性。"""
    if not isinstance(url, str) or not url:
        return url
    # 先清 query 参数，再跑通用模式（路径里直接写手机号的站点也能覆盖）
    out = _URL_PARAM.sub(lambda m: f"{m.group(1)}{m.group(2)}={_MASK}", url)
    return mask_pii(out)


_NAME_LABEL = re.compile(r"((?:姓名|联系人|申请人|考生|面试官|称呼)\s*[:：]\s*)"
                         r"([\u4e00-\u9fa5·]{2,4})")


def mask_names(text: str) -> str:
    """姓名按显式标签打码（默认启用；简历场景由 mask_resume_text 调用）。

    不做无标签的中文人名识别 —— 中文姓名与公司名/术语同形，误伤率过高，
    与其假装能识别，不如只处理有明确标签的情形并如实说明边界。
    """
    if not isinstance(text, str) or not text:
        return text
    return _NAME_LABEL.sub(lambda m: m.group(1) + (m.group(2)[0] + _MASK), text)


def mask_resume_text(text: str, mask_name: bool = True) -> str:
    """简历专用全量脱敏：PII + 可选姓名。"""
    out = mask_pii(text or "")
    return mask_names(out) if mask_name else out


def find_pii(text: str) -> Dict[str, int]:
    """命中统计（测试与"是否含 PII"提示用；不回传原文，避免二次泄露）。

    逐类"检测即遮蔽"再检测下一类：18 位身份证同时满足 16-19 位银行卡的形状，
    并列统计会把一张身份证数成两条 PII。
    """
    counts: Dict[str, int] = {}
    if not isinstance(text, str) or not text:
        return counts
    work = text
    for kind, pat, repl in _PATTERNS:
        n = len(pat.findall(work))
        if n:
            counts[kind] = n
            work = pat.sub(repl, work)
    if _URL_PARAM.search(text):
        counts["url_param"] = len(_URL_PARAM.findall(text))
    nh = len(_NAME_LABEL.findall(text))
    if nh:
        counts["name_label"] = nh
    return counts


def contains_pii(text: str) -> bool:
    return bool(find_pii(text))


# 铁律 2 原文用词是 _mask_pii，保留同名别名，避免两处实现漂移
_mask_pii = mask_pii

__all__ = ["mask_pii", "mask_url", "mask_names", "mask_resume_text",
           "find_pii", "contains_pii", "_mask_pii"]
