# -*- coding: utf-8 -*-
"""★ D6-09: 多分身产物交接（文件级）+ LLM 聚合汇总。

- write_artifact / read_artifacts / list_artifacts：workspace 目录内文件交接
- aggregate：把多个分身产物交 LLM 汇总（替换规则拼接），失败降级规则摘要
- 产物带 author/timestamp，可追溯
"""
from __future__ import annotations

import json
import os
import time
from typing import Dict, List, Optional

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_WS = os.path.join(_ROOT, "data", "handoffs")


def write_artifact(workspace: str, name: str, content: str,
                   author: str = "", meta: Optional[Dict] = None) -> Dict:
    """写分身产物到 workspace（文件名带 author 前缀，避免互相覆盖）。"""
    ws = os.path.abspath(workspace or DEFAULT_WS)
    os.makedirs(ws, exist_ok=True)
    safe = os.path.basename(str(name))
    prefix = (str(author) + "__") if author else ""
    fname = prefix + safe
    if not fname.endswith(".json"):
        fname += ".json"      # 内容为 JSON，统一 .json 后缀供列举
    path = os.path.join(ws, fname)
    payload = {"name": safe, "author": author,
               "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
               "meta": meta or {}, "content": content}
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    return {"ok": True, "path": path, "author": author, "name": safe}


def list_artifacts(workspace: str) -> List[Dict]:
    ws = os.path.abspath(workspace or DEFAULT_WS)
    if not os.path.isdir(ws):
        return []
    out = []
    for fn in sorted(os.listdir(ws)):
        if not fn.endswith(".json"):
            continue
        try:
            with open(os.path.join(ws, fn), "r", encoding="utf-8") as f:
                d = json.load(f)
            out.append({"name": d.get("name", fn), "author": d.get("author", ""),
                        "timestamp": d.get("timestamp", ""),
                        "path": os.path.join(ws, fn),
                        "chars": len(d.get("content") or "")})
        except Exception:
            continue
    return out


def read_artifacts(workspace: str) -> List[Dict]:
    return [dict(a, content=_read(a["path"])) for a in list_artifacts(workspace)]


def _read(path: str) -> str:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return str(json.load(f).get("content") or "")
    except Exception:
        return ""


def aggregate(artifacts: List[Dict], query: str = "",
              model: Optional[str] = None) -> Dict:
    """LLM 聚合多分身产物；失败降级为「规则摘要」（标题 + 各产物首段）。"""
    arts = [a for a in (artifacts or []) if (a.get("content") or "").strip()]
    if not arts:
        return {"ok": True, "summary": "（无分身产物）", "engine": "none",
                "n": 0, "degraded": False}

    from shared.llm.activate import _ollama_chat
    m = model or os.environ.get("LW_CHAT_MODEL", "qwen3.5:4b-ctx8k")
    body = "\n\n".join(
        f"### 产物 {i + 1}（{a.get('author') or '未知'} · {a.get('name')}）\n"
        + str(a.get("content") or "")[:2000]
        for i, a in enumerate(arts))
    out = _ollama_chat([
        {"role": "system",
         "content": "你在汇总多个子任务产物。输出一份合并后的中文报告："
                    "去重、按主题归类、保留关键结论与数据。"},
        {"role": "user", "content": f"目标：{query}\n\n{body}"},
    ], model=m)
    if out and out.strip():
        return {"ok": True, "summary": out.strip(), "engine": "ollama",
                "n": len(arts), "degraded": False}

    # 规则降级：各产物首段拼接 + 计数
    parts = []
    for a in arts:
        first = str(a.get("content") or "").strip().splitlines()
        parts.append(f"【{a.get('author') or '未知'}·{a.get('name')}】"
                     + (first[0] if first else "（空）"))
    return {"ok": True,
            "summary": f"共 {len(arts)} 份产物。\n" + "\n".join(parts),
            "engine": "rule_fallback", "n": len(arts), "degraded": True}


def dispatch(workspace: str, query: str, model: Optional[str] = None) -> Dict:
    """交接 + 聚合一条链（供 orchestrator 调用）。"""
    arts = read_artifacts(workspace)
    agg = aggregate(arts, query=query, model=model)
    return {"ok": True, "workspace": workspace, "artifacts": len(arts),
            "aggregate": agg}


__all__ = ["write_artifact", "read_artifacts", "list_artifacts", "aggregate",
           "dispatch", "DEFAULT_WS"]
