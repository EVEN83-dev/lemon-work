# -*- coding: utf-8 -*-
"""shared.notify —— 主动通知层（桌面 + webhook 双通道）。"""
from .desktop import send_desktop, set_tray, get_tray

__all__ = ["send_desktop", "set_tray", "get_tray"]
