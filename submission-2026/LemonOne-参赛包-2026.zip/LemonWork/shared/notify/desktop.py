# -*- coding: utf-8 -*-
"""★ D6-05: 桌面主动通知层（QSystemTrayIcon.showMessage 统一封装）。

- 标题 / 正文 / 点击回跳会话（on_click 回调）
- 无 QApplication / 无系统托盘时**显式降级**（记录 + 返回 reason），不抛异常
- 设置项开关 lw.notify.desktop（默认开）
- 单例托盘图标，重复调用复用
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import os
from typing import Callable, Optional

_TRAY = None
_LOG = []


def set_tray(tray) -> None:
    """注入托盘图标（测试可注入 mock）。"""
    global _TRAY
    _TRAY = tray


def get_tray():
    return _TRAY


def _enabled() -> bool:
    v = os.environ.get("LW_NOTIFY_DESKTOP", "1").strip().lower()
    return v not in ("0", "false", "no", "off")


def _ensure_tray():
    """懒创建系统托盘图标；不可用返回 None。"""
    global _TRAY
    if _TRAY is not None:
        return _TRAY
    if not _enabled():
        return None
    try:
        from PyQt5.QtWidgets import QApplication, QSystemTrayIcon
        from PyQt5.QtGui import QIcon
    except Exception as e:  # noqa: BLE001
        _LOG.append({"degraded": f"PyQt5 不可用: {type(e).__name__}"})
        return None
    try:
        app = QApplication.instance()
        if app is None:
            _LOG.append({"degraded": "无 QApplication（命令行环境）"})
            return None
        if not QSystemTrayIcon.isSystemTrayAvailable():
            _LOG.append({"degraded": "系统托盘不可用"})
            return None
        icon = QIcon()
        _TRAY = QSystemTrayIcon(icon, app)
        _TRAY.setVisible(True)
        return _TRAY
    except Exception as e:  # noqa: BLE001
        _LOG.append({"degraded": f"托盘创建失败: {type(e).__name__}"})
        return None


def send_desktop(title: str, message: str,
                 session_id: Optional[str] = None,
                 on_click: Optional[Callable] = None) -> dict:
    """弹系统通知。

    Returns:
        {"ok": bool, "channel": "desktop", "reason": str?}
    """
    tray = _ensure_tray()
    if tray is None:
        reason = (_LOG[-1].get("degraded") if _LOG else "tray_unavailable")
        print(f"[notify.desktop] 降级（{reason}）：{title} · {message}")
        return {"ok": False, "channel": "desktop", "reason": reason}
    try:
        msecs = 5000
        # QSystemTrayIcon.showMessage(title, message, icon, msecs)
        tray.showMessage(str(title or "Lemon Work"), str(message or ""),
                         msecs)
        if on_click is not None and session_id:
            try:
                tray.messageClicked.connect(lambda: on_click(session_id))
            except Exception:
                logger.debug("suppressed exception")
        print(f"[notify.desktop] 已弹：{title} · {message}")
        return {"ok": True, "channel": "desktop"}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "channel": "desktop", "reason": str(e)[:120]}


__all__ = ["send_desktop", "set_tray", "get_tray"]
