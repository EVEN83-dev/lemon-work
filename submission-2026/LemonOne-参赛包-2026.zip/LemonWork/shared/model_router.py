# -*- coding: utf-8 -*-
"""
【EXPERIMENTAL · 收口项 11】本模块未接入主对话/Agent 主流程——当前唯一
消费方是 shared/skills_builtin/router_skills.py（显式技能调用）。主流程
（shared.engine_manager.chat / bridge.agent_loop）不经过此路由。接入主流程
前禁止在生产路径依赖其预算/降级决策。
F6 · 成本路由 (shared/model_router.py) V1.6-WPD
=================================================
按任务类型 / 上下文长度 / 预算选模型。
记录每任务 token 与费用；预算越线降级或停止。

铁律：
  - 禁止静默换模型不记录（每次路由决策落日志 + cost_log）
  - 预算硬顶生效（越线即降级或停止，绝不超支）
"""
from __future__ import annotations

import json
import logging
import os
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
COST_LOG = os.path.join(_ROOT, "data", "cost", "model_router_log.jsonl")

# 模型分级（成本从低到高）
MODEL_TIERS: Dict[str, Dict[str, Any]] = {
    "economy": {"model": "qwen3.5:4b", "cost_per_1k": 0.0001, "max_ctx": 8000},
    "standard": {"model": "qwen3.5:8b", "cost_per_1k": 0.0003, "max_ctx": 16000},
    "premium": {"model": "qwen3.5:32b", "cost_per_1k": 0.0010, "max_ctx": 32000},
}

# 任务类型 → 默认分级
TASK_TIER_MAP: Dict[str, str] = {
    "chat": "economy",
    "tool_selection": "standard",
    "multi_step": "standard",
    "correction": "standard",
    "compliance": "premium",
    "long_task": "premium",
    "summarize": "economy",
    "extract": "economy",
}

_lock = threading.Lock()


@dataclass
class RouteDecision:
    """一次路由决策"""
    task_type: str
    ctx_len: int
    budget: float
    chosen_tier: str
    chosen_model: str
    reason: str
    ts: float = field(default_factory=time.time)


def _estimate_ctx(prompt: str, history: Optional[List[Dict]] = None) -> int:
    """估算上下文长度（字符数近似 token）"""
    n = len(prompt or "")
    for h in history or []:
        n += len(str(h.get("content", "")))
    return n


def route(task_type: str, prompt: str, history: Optional[List[Dict]] = None,
          budget: float = 1.0, preferred_tier: Optional[str] = None) -> RouteDecision:
    """选择模型分级。

    Args:
        task_type: 任务类型（chat/tool_selection/...）
        prompt: 提示词
        history: 历史
        budget: 预算上限（美元）
        preferred_tier: 强制分级（覆盖自动）
    Returns:
        RouteDecision
    """
    ctx = _estimate_ctx(prompt, history)
    default_tier = preferred_tier or TASK_TIER_MAP.get(task_type, "standard")
    tier_name = default_tier
    tier = MODEL_TIERS.get(tier_name, MODEL_TIERS["standard"])

    reason = f"task_type={task_type}, ctx={ctx}, budget=${budget}"

    # ① 上下文需求：只升级不降级（ctx 超默认分级容量时升档）
    _ORDER = ["economy", "standard", "premium"]
    while tier_name != "premium" and ctx > tier["max_ctx"]:
        reason += f" → 升级（ctx {ctx} > {tier['max_ctx']}）"
        idx = _ORDER.index(tier_name)
        tier_name = _ORDER[min(idx + 1, len(_ORDER) - 1)]
        tier = MODEL_TIERS[tier_name]

    # ② 预算硬顶：越线降级（最终权威，覆盖上下文升级）
    while tier_name != "economy":
        est_cost = (ctx / 1000.0) * tier["cost_per_1k"]
        if est_cost > budget:
            reason += f" → 降级（预估 ${est_cost:.4f} > 预算 ${budget:.4f}）"
            idx = _ORDER.index(tier_name)
            tier_name = _ORDER[max(idx - 1, 0)]
            tier = MODEL_TIERS[tier_name]
        else:
            break

    dec = RouteDecision(
        task_type=task_type, ctx_len=ctx, budget=budget,
        chosen_tier=tier_name, chosen_model=tier["model"], reason=reason)
    _log_decision(dec)
    return dec


def _log_decision(dec: RouteDecision) -> None:
    """记录路由决策（禁止静默换模型）。"""
    try:
        os.makedirs(os.path.dirname(COST_LOG), exist_ok=True)
        with _lock:
            with open(COST_LOG, "a", encoding="utf-8") as f:
                f.write(json.dumps(dec.__dict__, ensure_ascii=False) + "\n")
    except Exception:
        logger.debug("suppressed exception")


def record_cost(task_id: str, model: str, input_tokens: int, output_tokens: int,
                duration_ms: float, cost_usd: float) -> Dict[str, Any]:
    """记录每任务 token 与费用。"""
    rec = {
        "task_id": task_id, "model": model,
        "input_tokens": input_tokens, "output_tokens": output_tokens,
        "total_tokens": input_tokens + output_tokens,
        "duration_ms": round(duration_ms, 2), "cost_usd": round(cost_usd, 6),
        "ts": time.time(),
    }
    try:
        os.makedirs(os.path.dirname(COST_LOG), exist_ok=True)
        with _lock:
            with open(COST_LOG, "a", encoding="utf-8") as f:
                f.write(json.dumps({"type": "cost", **rec}, ensure_ascii=False) + "\n")
    except Exception:
        logger.debug("suppressed exception")
    return rec


def estimate_cost(model: str, tokens: int) -> float:
    """估算费用（美元）。"""
    for tier in MODEL_TIERS.values():
        if tier["model"] == model:
            return (tokens / 1000.0) * tier["cost_per_1k"]
    return (tokens / 1000.0) * 0.0003  # 默认 standard


def get_budget_status(budget: float) -> Dict[str, Any]:
    """返回预算使用状态。"""
    try:
        total = 0.0
        if os.path.exists(COST_LOG):
            with open(COST_LOG, "r", encoding="utf-8") as f:
                for line in f:
                    try:
                        rec = json.loads(line)
                        if rec.get("type") == "cost":
                            total += rec.get("cost_usd", 0)
                    except Exception:
                        continue
        return {
            "budget": budget, "spent": round(total, 6),
            "remaining": round(max(0, budget - total), 6),
            "exceeded": total > budget,
        }
    except Exception:
        return {"budget": budget, "spent": 0, "remaining": budget, "exceeded": False}


def enforce_budget(budget: float) -> bool:
    """预算硬顶：越线返回 False，调用方应停止或降级。"""
    status = get_budget_status(budget)
    return not status["exceeded"]
