# -*- coding: utf-8 -*-
"""结构化事件日志（JSONL，单文件按日/按大小滚动）。

用途：给看板与排障提供可检索的运行时事件（company.* / engine.*），
与人类日志（print/logger）并存，不替代它们。

约定：
  · 目录 data/logs/events-YYYYMMDD.jsonl，单文件超过 20MB 自动滚动为 .1/.2；
  · 线程安全；任何异常都被吞掉并降级为 no-op —— 日志绝不能影响主流程；
  · 事件名统一小写点分：company.task_done / engine.call_failed / bridge.hire_agent。
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import json
import os
import threading
import time

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOG_DIR = os.path.join(_ROOT, "data", "logs")
_MAX_BYTES = 20 * 1024 * 1024
_LOCK = threading.Lock()
_MAX_FIELDS = 40
_MAX_STR = 500


def _path(ts: float) -> str:
    return os.path.join(LOG_DIR, "events-%s.jsonl" % time.strftime("%Y%m%d", time.localtime(ts)))


def _trim(v):
    if isinstance(v, str):
        return v[:_MAX_STR]
    if isinstance(v, (int, float, bool)) or v is None:
        return v
    if isinstance(v, (list, tuple)):
        return [_trim(x) for x in list(v)[:10]]
    if isinstance(v, dict):
        return {str(k)[:40]: _trim(val) for k, val in list(v.items())[:_MAX_FIELDS]}
    return str(v)[:_MAX_STR]


def log_event(event: str, **fields) -> None:
    """写一条结构化事件。绝不影响调用方（异常静默降级）。"""
    try:
        ts = time.time()
        rec = {"ts": round(ts, 3), "event": str(event)[:80], "pid": os.getpid()}
        for k, v in list(fields.items())[:_MAX_FIELDS]:
            rec[str(k)[:40]] = _trim(v)
        line = json.dumps(rec, ensure_ascii=False, default=str) + "\n"
        with _LOCK:
            os.makedirs(LOG_DIR, exist_ok=True)
            p = _path(ts)
            try:
                if os.path.getsize(p) > _MAX_BYTES:
                    for i in (2, 1):
                        src = p + (".%d" % i if i > 1 else "")
                        dst = p + ".%d" % (i + 1)
                        if os.path.exists(src):
                            os.replace(src, dst)
                    os.replace(p, p + ".1")
            except OSError:
                logger.debug("suppressed exception")
            with open(p, "a", encoding="utf-8") as f:
                f.write(line)
    except Exception:
        logger.debug("suppressed exception")


__all__ = ["log_event", "LOG_DIR"]