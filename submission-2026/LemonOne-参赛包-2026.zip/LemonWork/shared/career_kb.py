# -*- coding: utf-8 -*-
"""career_kb —— 面经临时知识库（v10 · T1）

三通道采集 → 分块入库 → 带出处检索 → 会话即弃。

与既有资产的关系（T0 实测结论决定了这里的写法）：
  · shared/vector_database.py 的 ChromaDB **未安装**（CHROMADB_AVAILABLE=False），
    且其内置存储 `_builtin_store` 是**纯进程内 dict、零落盘**；
    它的 `_sparse_to_dense` 还把稀疏向量按"token 字母序"写进定长槽位，
    跨文本维度不对齐 → 内置路径的 cosine 排序不可用。
    所以：记录的**唯一真源是本模块自己的 JSON 文件**；检索排序用
    knowledge_base.TFIDFVectorizer 的真稀疏向量（token 键 cosine），
    只有在确实检测到 ChromaDB 时才把语料交给 vector_database 走持久化向量库。
  · shared/web_capture.fetch_page 对 robots 只做**软提示不拦截**
    （源码原话："robots 作软提示不拦截"）。铁律 3 要求 Disallow 站点禁止批量抓取，
    因此 link 通道不能直接委托给它 —— 本模块自己先过严格 robots 判定。
  · check_robots 在超时/404 时 fail-open 返回 allowed，且缓存 600s。
    本模块把 "robots_unavailable" 归为 manual_only 而不是 batch_ok：
    读不到规则 ≠ 获得授权。

注入防线（铁律 4）：每条记录强制 non_instruction=True，检索结果只作为
**被引用的资料**返回给上层，本模块任何函数都不把库内容拼进系统提示。
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import json
import os
import re
import time
import uuid
from typing import Any, Dict, List, Optional, Tuple

from shared.pii_mask import mask_pii, mask_resume_text, mask_url, find_pii

try:
    from standard_mode.core.skills_registry import SkillDef, SkillResult, get_skills_registry
except ImportError:  # 兼容 standard_mode 在 sys.path 上的直连导入
    from core.skills_registry import SkillDef, SkillResult, get_skills_registry

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KB_DIR = os.path.join(_ROOT, "data", "career_kb")

CHUNK_SIZE = 500
CHUNK_OVERLAP = 80
STALE_DAYS = 30
DEFAULT_SESSION = "default"
MAX_TEXT_CHARS = 200000          # 单条入库文本上限，防御性截断
DEFAULT_STORE_VERSION = 1

# robots 三档（T0.3 实测结论见 data/studio/research_agents_*.md 与本轮交付）
TIER_BATCH = "batch_ok"          # 明示允许 → 可 link 自动抓
TIER_MANUAL = "manual_only"      # 读不到规则/仅人工访问 → 只能 browser_current 或 paste
TIER_FORBIDDEN = "forbidden"     # 明示 Disallow 或 URL 不合规 → 拒绝


# ══════════════════════════ 会话与存储 ══════════════════════════
# ★ v10 (T5.2): 面经库静态加密。密钥派生自本机机器指纹（Windows MachineGuid，
#   取不到时退到 MAC + 用户名），口令不落盘、不写文件。
#
#   安全边界必须说清楚，别把它当"加密=安全"：
#     ✅ 挡住：库文件被拷到别的机器/别的用户后被读出内容
#     ❌ 挡不住：同一台机器上以同一用户运行的任何进程 —— 它能重新派生出同一把钥
#   即"本机可解"。真正的威胁模型是防外泄文件，不是防本机恶意软件。
#   **丢失密钥（换机 / 重装系统导致 MachineGuid 变化）= 旧库不可恢复**，
#   这一点同步写在技能描述里，不事后诸葛。
_KEY_SALT = b"LemonWork.career_kb.v1.static-salt.not-a-secret"
_ENC_PREFIX = b"CARBKB1:"


def _machine_secret() -> bytes:
    parts: List[bytes] = []
    try:
        import winreg                                    # Windows: 机器级稳定标识
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                            r"SOFTWARE\Microsoft\Cryptography") as k:
            parts.append(str(winreg.QueryValueEx(k, "MachineGuid")[0]).encode("utf-8"))
    except Exception:
        logger.debug("suppressed exception")
    if not parts:                                        # 非 Windows / 读不到注册表
        import getpass
        import socket
        parts = [(socket.gethostname() or "").encode("utf-8"),
                 str(uuid.getnode()).encode("utf-8"),
                 getpass.getuser().encode("utf-8")]
    return b"|".join(p for p in parts if p)


def _fernet():
    try:
        import base64
        import hashlib
        from cryptography.fernet import Fernet
    except ImportError:
        return None
    digest = hashlib.pbkdf2_hmac("sha256", _machine_secret(), _KEY_SALT, 200_000, dklen=32)
    return Fernet(base64.urlsafe_b64encode(digest))


def encryption_state() -> Dict[str, Any]:
    """如实报告加密是否真的生效（供技能描述/测试断言，不做乐观默认）。"""
    f = _fernet()
    return {"enabled": f is not None,
            "backend": "fernet/PBKDF2-MachineGuid" if f else "plaintext",
            "reason": "" if f else "cryptography 未安装，面经库将以明文落盘",
            "boundary": "本机可解：防库文件外泄，不防本机同权限进程；密钥随机器指纹变化即不可恢复"}


def normalize_session(session_id: str = "") -> str:
    """会话 id 只留 [A-Za-z0-9_-]，防止路径穿越（会话名会直接做文件名）。"""
    s = re.sub(r"[^A-Za-z0-9_-]", "", str(session_id or "").strip())
    return s[:64] or DEFAULT_SESSION


def _session_path(sid: str) -> str:
    return os.path.join(KB_DIR, normalize_session(sid) + ".json")


def _decode(raw: bytes) -> Dict[str, Any]:
    """存储解码：先按密文解，解不动再当明文 JSON 读（兼容 T5.2 之前已存在的库）。"""
    if raw.startswith(_ENC_PREFIX):
        f = _fernet()
        if f is None:
            raise RuntimeError("库已加密但 cryptography 不可用，无法读取")
        from cryptography.fernet import InvalidToken
        try:
            raw = f.decrypt(raw[len(_ENC_PREFIX):])
        except InvalidToken:
            # 机器指纹变了（换机/重装）—— 如实说明，不做静默清空
            raise RuntimeError("密钥与本机不匹配：换机或系统重装后旧面经库不可恢复")
    return json.loads(raw.decode("utf-8"))


def _encode(store: Dict[str, Any]) -> bytes:
    """存储编码：可用则加密，不可用则明文（并由 encryption_state 如实上报）。"""
    plain = json.dumps(store, ensure_ascii=False).encode("utf-8")
    f = _fernet()
    if f is None:
        return plain
    return _ENC_PREFIX + f.encrypt(plain)


def _new_store(sid: str) -> Dict[str, Any]:
    return {"version": DEFAULT_STORE_VERSION, "session_id": sid,
            "created_at": time.strftime("%Y-%m-%d %H:%M:%S"), "records": []}


def read_store(session_id: str = "") -> Dict[str, Any]:
    sid = normalize_session(session_id)
    path = _session_path(sid)
    if not os.path.exists(path):
        return _new_store(sid)
    try:
        with open(path, "rb") as fh:
            store = _decode(fh.read())
        if not isinstance(store, dict) or not isinstance(store.get("records"), list):
            raise ValueError("结构不合法")
        store["session_id"] = sid
        return store
    except Exception as e:
        # 不把文件内容回显到错误里：坏文件可能正是含 PII 的那份。
        # 但原因本身要留下（密钥不匹配 vs 文件损坏 是两种完全不同的处置）。
        return _new_store(sid) | {"_load_error": f"{type(e).__name__}: {str(e)[:180]}"}


def write_store(store: Dict[str, Any]) -> bool:
    sid = normalize_session(store.get("session_id", ""))
    os.makedirs(KB_DIR, exist_ok=True)
    path = _session_path(sid)
    tmp = path + ".tmp"
    try:
        with open(tmp, "wb") as fh:
            fh.write(_encode(store))
        os.replace(tmp, path)
        return True
    except Exception:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except OSError:
            logger.debug("suppressed exception")
        return False


# ══════════════════════════ 分块与脱敏 ══════════════════════════
def chunk_text(text: str, size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> List[str]:
    """按字符窗口切块（500/80）。段边界优先，避免把一句话劈成两半。"""
    t = re.sub(r"\r\n?", "\n", str(text or "")).strip()
    if not t:
        return []
    if len(t) <= size:
        return [t]
    chunks: List[str] = []
    start = 0
    while start < len(t):
        end = min(len(t), start + size)
        if end < len(t):
            # 回退到最近的段落/句子边界
            back = max(t.rfind("\n\n", start, end), t.rfind("。", start, end),
                       t.rfind("！", start, end), t.rfind("？", start, end),
                       t.rfind(".", start, end))
            if back > start + size // 3:
                end = back + 1
        seg = t[start:end].strip()
        if seg:
            chunks.append(seg)
        if end >= len(t):
            break
        start = max(end - overlap, start + 1)
    return chunks


def sanitize_record_text(text: str, mask_name: bool = True) -> Tuple[str, Dict[str, int]]:
    """入库前脱敏；返回 (脱敏后文本, 命中统计)。命中统计不回传原文。"""
    hits = find_pii(text or "")
    cleaned = mask_resume_text(text or "", mask_name=mask_name)
    return cleaned, hits


# ══════════════════════════ 合规判定 ══════════════════════════
def classify_url(url: str) -> Dict[str, Any]:
    """该 URL 的采集档位。三档见模块头注释。"""
    u = str(url or "").strip()
    if not u:
        return {"tier": TIER_FORBIDDEN, "reason": "empty_url", "domain": ""}
    try:
        from shared.browser_policy import check_robots, check_url
    except ImportError as e:
        # 策略模块缺失时一律按最严档处理，绝不"读不到就放行"
        return {"tier": TIER_MANUAL, "reason": f"policy_unavailable:{e}", "domain": ""}
    cu = check_url(u)
    if not cu.get("allowed"):
        return {"tier": TIER_FORBIDDEN, "reason": cu.get("reason", "url_blocked"),
                "domain": cu.get("domain", "")}
    domain = cu.get("domain", "")
    try:
        cr = check_robots(u)
    except Exception as e:
        return {"tier": TIER_MANUAL, "reason": f"robots_check_failed:{str(e)[:60]}",
                "domain": domain}
    if not cr.get("allowed"):
        return {"tier": TIER_FORBIDDEN, "reason": cr.get("reason", "robots_disallow"),
                "domain": domain}
    reason = cr.get("reason") or ""
    if reason == "robots_unavailable":
        # fail-open 不等于授权：只允许"用户已人工打开该页 → 一键沉淀"
        return {"tier": TIER_MANUAL, "reason": "robots_unavailable_fail_open",
                "domain": domain}
    return {"tier": TIER_BATCH, "reason": "", "domain": domain}


# ══════════════════════════ 入库 ══════════════════════════
def _build_record(*, text: str, source_type: str, source_url: str, session_id: str,
                  company: str, position: str, round_: str, year: str,
                  mask_name: bool) -> Dict[str, Any]:
    cleaned, hits = sanitize_record_text(text, mask_name=mask_name)
    chunks = chunk_text(cleaned)
    return {
        "id": f"kb_{uuid.uuid4().hex[:10]}",
        "session_id": normalize_session(session_id),
        "company": mask_pii(str(company or "").strip()),
        "position": mask_pii(str(position or "").strip()),
        "round": mask_pii(str(round_ or "").strip()),
        "year": mask_pii(str(year or "").strip()),
        "source_url": mask_url(source_url or "") if source_type != "paste" else "",
        "source_type": source_type,
        "collected_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "text": cleaned[:MAX_TEXT_CHARS],
        "chunks": [{"idx": i, "text": c} for i, c in enumerate(chunks)],
        # 铁律 4②：入库即定性为"资料"，不是指令。上层引用时必须按此标记处理。
        "non_instruction": True,
        "pii_hits": hits,
    }


def ingest_paste(text: str, session_id: str = "", company: str = "", position: str = "",
                 round: str = "", year: str = "", mask_name: bool = True) -> Dict[str, Any]:
    """通道①：用户直接粘贴面经 —— 一等公民接口，合规上无任何前置。"""
    body = str(text or "").strip()
    # 下限取 8 字而不是更长：复试/面试真题回忆的天然形态就是一句话
    # （"问了数据库事务隔离级别"），门槛设高了会把最有用的条目挡在库外。
    if len(body) < 8:
        return {"success": False, "error": "粘贴内容过短（<8 字），没有可沉淀的信息量"}
    rec = _build_record(text=body, source_type="paste", source_url="", session_id=session_id,
                        company=company, position=position, round_=round, year=year,
                        mask_name=mask_name)
    return _append(rec)


def ingest_link(url: str, session_id: str = "", company: str = "", position: str = "",
                round: str = "", year: str = "", mask_name: bool = True) -> Dict[str, Any]:
    """通道②：给 URL → 先过严格 robots 判定，只有 batch_ok 才自动抓。"""
    verdict = classify_url(url)
    if verdict["tier"] == TIER_FORBIDDEN:
        return {"success": False,
                "error": (f"robots.txt 明确禁止自动抓取该站点（{verdict['reason']}），"
                          f"已按铁律 3 拒绝批量采集。合规替代路径：你在内置浏览器里人工打开这一页，"
                          f"再用 career_kb_ingest(source=\"browser_current\") 一键沉淀；"
                          f"或直接把正文粘贴给我（source=\"paste\"）。"),
                "data": {"tier": verdict["tier"], "domain": verdict["domain"],
                         "guidance": "browser_current 或 paste"}}
    if verdict["tier"] == TIER_MANUAL:
        return {"success": False,
                "error": (f"该站点没有可读的 robots 规则（{verdict['reason']}），"
                          f"按'读不到规则 ≠ 获得授权'不做自动抓取。"
                          f"请在内置浏览器人工打开该页后用 source=\"browser_current\" 沉淀，"
                          f"或直接粘贴正文。"),
                "data": {"tier": verdict["tier"], "domain": verdict["domain"],
                         "guidance": "browser_current 或 paste"}}
    try:
        from shared.web_capture import fetch_page
    except ImportError as e:
        return {"success": False, "error": f"抓取模块不可用: {e}"}
    r = fetch_page(url, mode="reader")
    if not r.get("success"):
        return {"success": False, "error": f"抓取失败: {r.get('error', '未知原因')}"}
    body = r.get("preview") or r.get("text") or ""
    if not str(body).strip():
        return {"success": False, "error": "抓到页面但正文为空（可能是 JS 渲染站），"
                                           "请改用 browser_current 或粘贴正文"}
    rec = _build_record(text=str(body), source_type="link",
                        source_url=r.get("url") or url, session_id=session_id,
                        company=company, position=position, round_=round, year=year,
                        mask_name=mask_name)
    out = _append(rec)
    if out.get("success") and r.get("robots_note"):
        out["note"] = r["robots_note"]
    return out


def ingest_browser_current(session_id: str = "", company: str = "", position: str = "",
                           round: str = "", year: str = "", mask_name: bool = True) -> Dict[str, Any]:
    """通道③：读内置浏览器**当前页** —— 知乎/小红书这类站点的唯一合规入口。

    合规依据：页面是用户自己人工打开的，我们只是把已呈现的内容沉淀下来，
    不构成自动抓取；因此这条通道不经过 fetch_page，也不新增任何网络请求。
    """
    try:
        from skills.browser_automation import execute as _bexec
    except ImportError:
        try:
            from standard_mode.core.skills.browser_automation import execute as _bexec
        except ImportError as e:
            return {"success": False,
                    "error": f"内置浏览器通道不可用（{e}）。请改用粘贴通道 source=\"paste\"。"}
    url_res = _bexec(action="extract_url")
    cur_url = ""
    if url_res and getattr(url_res, "success", False):
        cur_url = str((getattr(url_res, "data", None) or {}).get("url", "") or "")
    txt_res = _bexec(action="extract")
    if not txt_res or not getattr(txt_res, "success", False):
        return {"success": False,
                "error": (f"未能从内置浏览器取到文本："
                          f"{getattr(txt_res, 'error', '浏览器会话未就绪')}。"
                          f"请先在内置浏览器里打开那一页，或直接粘贴正文。")}
    body = str((getattr(txt_res, "data", None) or {}).get("text", "") or "")
    rec = _build_record(text=body, source_type="browser_current", source_url=cur_url,
                        session_id=session_id, company=company, position=position,
                        round_=round, year=year, mask_name=mask_name)
    return _append(rec)


def _append(rec: Dict[str, Any]) -> Dict[str, Any]:
    store = read_store(rec["session_id"])
    store["records"].append(rec)
    if not write_store(store):
        return {"success": False, "error": "入库落盘失败（检查 data/career_kb 写权限）"}
    _INDEX_BUST.add(rec["session_id"])
    leaked = _rescan_for_pii(rec)
    return {"success": True,
            "output": (f"已沉淀 1 条面经（{rec['source_type']}，{len(rec['chunks'])} 块，"
                       f"id={rec['id']}）"
                       + (f"，入库前自动脱敏 {sum(rec['pii_hits'].values())} 处" if rec['pii_hits'] else "")),
            "data": {"id": rec["id"], "session_id": rec["session_id"],
                     "chunks": len(rec["chunks"]), "pii_masked": rec["pii_hits"],
                     "source_url": rec["source_url"], "non_instruction": True,
                     "post_mask_residue": leaked}}


def _rescan_for_pii(rec: Dict[str, Any]) -> Dict[str, int]:
    """落盘后再扫一遍成品记录 —— 脱敏是否真的生效，以复检为准而非以'跑过函数'为准。"""
    blob = json.dumps({"t": rec.get("text", ""), "c": rec.get("chunks", []),
                       "u": rec.get("source_url", "")}, ensure_ascii=False)
    return find_pii(blob)


# ══════════════════════════ 检索 ══════════════════════════
_INDEX_BUST: set = set()
_INDEX_CACHE: Dict[str, Any] = {}


def _tokenize(text: str) -> List[str]:
    """中文按字 + 二元组，英文按词。与 role_system 的分词口径保持一致。"""
    out: List[str] = []
    han = re.findall(r"[\u4e00-\u9fff]", text or "")
    out.extend(han)
    out.extend(han[i] + han[i + 1] for i in range(len(han) - 1))
    out.extend(re.findall(r"[A-Za-z][A-Za-z0-9+#.]{1,}", (text or "").lower()))
    return out


def _tfidf_vectors(pairs: List[Tuple[str, str]], query: str) -> Dict[str, float]:
    """真稀疏 TF-IDF（token 键）：文档向量 + 查询向量。

    刻意不走 vector_database 的 dense 投影 —— 它按字母序把值塞进定长槽位，
    跨文本维度不对齐，cosine 结果没有意义（T0.1 实测结论）。
    """
    import math
    from collections import defaultdict
    docs = [p[1] for p in pairs] + [query]
    toks = [_tokenize(d) for d in docs]
    df: Dict[str, int] = defaultdict(int)
    for tk in toks:
        for t in set(tk):
            df[t] += 1
    n = max(len(toks), 1)
    idf = {t: math.log((n + 1) / (c + 1)) + 1 for t, c in df.items()}

    def vec(tk: List[str]) -> Dict[str, float]:
        tf: Dict[str, int] = defaultdict(int)
        for t in tk:
            tf[t] += 1
        tot = max(len(tk), 1)
        return {t: (c / tot) * idf.get(t, 0.0) for t, c in tf.items()}

    return {"docs": [vec(t) for t in toks[:-1]], "query": vec(toks[-1])}


def _cosine(a: Dict[str, float], b: Dict[str, float]) -> float:
    if not a or not b:
        return 0.0
    import math
    common = set(a) & set(b)
    dot = sum(a[k] * b[k] for k in common)
    n1 = math.sqrt(sum(v * v for v in a.values()))
    n2 = math.sqrt(sum(v * v for v in b.values()))
    return dot / (n1 * n2) if n1 and n2 else 0.0


def query(text: str, company: Optional[str] = None, top_k: int = 5,
          session_id: str = "", min_score: float = 0.02) -> Dict[str, Any]:
    """检索面经。结果**必须**带 source_url + collected_at，缺出处的一律不返回（1.3）。"""
    q = str(text or "").strip()
    if not q:
        return {"success": False, "error": "查询内容为空"}
    sid = normalize_session(session_id)
    store = read_store(sid)
    records = store.get("records", [])
    if company:
        c = str(company).strip().lower()
        records = [r for r in records if c in str(r.get("company", "")).lower()]
    if not records:
        return {"success": True, "hit": False,
                "output": (f"会话 {sid} 的" if sid != DEFAULT_SESSION else "")
                          + "面经库里没有可检索的记录"
                          + (f"（公司过滤：{company}）" if company else "")
                          + "。可先用 career_kb_ingest 粘贴或沉淀面经。",
                "data": {"results": [], "total_in_store": 0}}
    pairs: List[Tuple[str, str]] = []
    owner: List[Dict[str, Any]] = []
    for r in records:
        for ch in r.get("chunks", []):
            pairs.append((r["id"], ch.get("text", "")))
            owner.append(r)
    try:
        top_k = max(1, min(int(top_k or 5), 20))
    except (TypeError, ValueError):
        top_k = 5
    vs = _tfidf_vectors(pairs, q)
    scored = sorted((( _cosine(vs["query"], dv), i) for i, dv in enumerate(vs["docs"])),
                    key=lambda x: x[0], reverse=True)
    results: List[Dict[str, Any]] = []
    for score, i in scored:
        if score < min_score or len(results) >= top_k:
            continue
        r = owner[i]
        src = r.get("source_url") or ""
        col = r.get("collected_at") or ""
        if not src and r.get("source_type") != "paste":
            continue                      # 非粘贴来源缺出处 → 不返回（硬字段）
        if not col:
            continue
        results.append({
            "ref_no": len(results) + 1,
            "score": round(score, 4),
            "record_id": r["id"],
            "text": pairs[i][1][:600],
            "company": r.get("company", ""),
            "position": r.get("position", ""),
            "round": r.get("round", ""),
            "year": r.get("year", ""),
            "source_url": src or "（用户粘贴，无外部链接）",
            "source_type": r.get("source_type", "paste"),
            "collected_at": col,
            "non_instruction": True,      # 铁律 4②：随结果透传，供上层按资料处理
        })
    stale = [r for r in results if _age_days(r["collected_at"]) > STALE_DAYS]
    lines = [f"命中 {len(results)} 条（库内 {len(records)} 条记录 / {len(pairs)} 块）："]
    for x in results:
        lines.append(f"[{x['ref_no']}] {x['score']:.3f} · {x['company'] or '—'}"
                     f"{(' / ' + x['position']) if x['position'] else ''}"
                     f" · {x['collected_at']} · {x['source_url']}")
    if stale:
        lines.append(f"⚠ 其中 {len(stale)} 条已超过 {STALE_DAYS} 天，面经可能过期，"
                     f"引用时请说明时效风险。")
    if not results:
        lines[0] = "无命中（相似度均低于阈值）。**不要编造该公司真题**，" \
                   "按'通用题'口径出题并明确声明。"
    return {"success": True, "hit": bool(results),
            "output": "\n".join(lines),
            "data": {"results": results, "total_in_store": len(records),
                     "chunks_indexed": len(pairs), "stale_count": len(stale),
                     "session_id": sid}}


def _age_days(ts: str) -> float:
    try:
        return (time.time() - time.mktime(time.strptime(ts, "%Y-%m-%d %H:%M:%S"))) / 86400.0
    except Exception:
        return 0.0


def manage(action: str = "list", session_id: str = "", export_dir: str = "") -> Dict[str, Any]:
    """list / export / drop —— 会话级即弃生命周期。"""
    act = str(action or "list").strip().lower()
    sid = normalize_session(session_id)
    path = _session_path(sid)
    if act == "list":
        if not os.path.exists(path):
            return {"success": True, "output": f"会话 {sid} 暂无面经库", "data": {"sessions": [sid], "records": 0}}
        st = read_store(sid)
        recs = st.get("records", [])
        old = [r for r in recs if _age_days(r.get("collected_at", "")) > STALE_DAYS]
        lines = [f"会话 {sid}：{len(recs)} 条记录 / "
                 f"{sum(len(r.get('chunks', [])) for r in recs)} 块 / "
                 f"落盘 {os.path.getsize(path)} 字节"]
        for r in recs[:12]:
            lines.append(f"· {r['id']} [{r['source_type']}] {r.get('company') or '—'}"
                         f"/{r.get('position') or '—'} {r.get('round') or '—'} "
                         f"{len(r.get('chunks', []))}块 @{r.get('collected_at')}")
        if len(recs) > 12:
            lines.append(f"… 其余 {len(recs) - 12} 条略")
        if old:
            lines.append(f"⚠ {len(old)} 条超过 {STALE_DAYS} 天，面经可能过期，建议 drop 后重新沉淀。")
        return {"success": True, "output": "\n".join(lines),
                "data": {"session_id": sid, "records": len(recs),
                         "stale": len(old), "bytes": os.path.getsize(path)}}
    if act == "export":
        st = read_store(sid)
        if not st.get("records"):
            return {"success": False, "error": f"会话 {sid} 为空，无可导出内容"}
        out_dir = export_dir or os.path.join(_ROOT, "data", "career_kb", "export")
        os.makedirs(out_dir, exist_ok=True)
        p = os.path.join(out_dir, f"{sid}_{time.strftime('%Y%m%d_%H%M%S')}.json")
        # 导出件与库体同权：也走 _encode，否则"导出"就成了绕过 T5.2 的明文旁路
        with open(p, "wb") as fh:
            fh.write(_encode(st))
        enc = encryption_state()["enabled"]
        return {"success": True,
                "output": (f"已导出 {len(st['records'])} 条 → {p}"
                           + ("（密文，仅本机可解）" if enc else "（⚠ 明文导出：cryptography 不可用）")),
                "data": {"path": p, "records": len(st["records"]), "encrypted": enc}}
    if act == "drop":
        existed = os.path.exists(path)
        if existed:
            os.remove(path)
        _INDEX_BUST.add(sid)
        return {"success": True,
                "output": (f"已销毁会话 {sid} 的面经库（含全部检索索引）"
                           if existed else f"会话 {sid} 本就没有库，无需销毁"),
                "data": {"session_id": sid, "existed": existed}}
    return {"success": False, "error": f"未知 action={action!r}，可用 list/export/drop"}


# ══════════════════════════ 技能封装 ══════════════════════════
def _to_skill(d: Dict[str, Any]) -> "SkillResult":
    if d.get("success"):
        return SkillResult(success=True, output=d.get("output", ""), data=d.get("data") or {})
    return SkillResult(success=False, error=d.get("error", "操作失败"), data=d.get("data") or {})


def _skill_career_kb_ingest(text: str = "", url: str = "", source: str = "auto",
                            session_id: str = "", company: str = "", position: str = "",
                            round: str = "", year: str = "",
                            mask_name: bool = True) -> "SkillResult":
    src = str(source or "auto").strip().lower()
    if src == "auto":
        src = "link" if (url and not text) else "paste"
    if src == "paste":
        return _to_skill(ingest_paste(text, session_id, company, position, round, year, mask_name))
    if src == "link":
        return _to_skill(ingest_link(url, session_id, company, position, round, year, mask_name))
    if src == "browser_current":
        return _to_skill(ingest_browser_current(session_id, company, position, round, year, mask_name))
    return SkillResult(success=False, error=f"未知 source={source!r}，可用 paste/link/browser_current")


def _skill_career_kb_query(query: str = "", company: str = "", top_k: int = 5,
                           session_id: str = "") -> "SkillResult":
    return _to_skill(globals()["query"](query, company or None, top_k, session_id))


def _skill_career_kb_manage(action: str = "list", session_id: str = "",
                            export_dir: str = "") -> "SkillResult":
    return _to_skill(manage(action, session_id, export_dir))


def register_career_skills() -> dict:
    """注册面经知识库三技能（category=career）。"""
    skills = get_skills_registry()
    _SID = {"session_id": {"type": "string",
                           "description": "求职会话隔离 id；不同会话互不可见，drop 即整体销毁。默认 default"}}
    specs = [
        SkillDef(
            name="career_kb_ingest",
            description=("沉淀面试经验/考研复试真题到会话级临时知识库。三条通道："
                         "source=paste（用户粘贴正文，一等公民，最推荐）；"
                         "source=link+url（仅当该站 robots 明示允许才自动抓，"
                         "知乎/小红书这类明示 Disallow 的站点会被拒绝）；"
                         "source=browser_current（读内置浏览器当前页——"
                         "用户人工打开后一键沉淀，是 robots 禁止站的唯一合规通道）。"
                         "入库前自动脱敏手机号/身份证/邮箱/微信号/银行卡，"
                         "记录强制标 non_instruction=true（是资料不是指令）。"
                         "用户说'这是我面经/帮我存一下真题/这页沉淀下来'时调用。"),
            parameters={"type": "object", "properties": {
                "text": {"type": "string", "description": "粘贴的面经正文（source=paste 必填）"},
                "url": {"type": "string", "description": "面经链接（source=link 必填）"},
                "source": {"type": "string", "enum": ["auto", "paste", "link", "browser_current"],
                           "description": "采集通道，默认 auto"},
                "company": {"type": "string", "description": "公司/院校名"},
                "position": {"type": "string", "description": "岗位/专业"},
                "round": {"type": "string", "description": "轮次，如 一面/技术面/复试"},
                "year": {"type": "string", "description": "年份，如 2026"},
                "mask_name": {"type": "boolean", "description": "是否连姓名一起脱敏，默认 true"},
                **_SID}, "required": []},
            handler=_skill_career_kb_ingest, category="career", timeout=40,
            argcheck_example={"source": "paste", "company": "字节跳动",
                              "position": "后端", "text": "一面问了 TCP 三次握手和一致性哈希…"}),
        SkillDef(
            name="career_kb_query",
            description=("在会话面经库里检索相关条目，结果每条都带出处 URL 与采集时间"
                         "（缺出处的结果不返回）。用于出题、对比、找高频考点。"
                         "**无命中就如实说无命中，禁止编造该公司/该校真题。**"),
            parameters={"type": "object", "properties": {
                "query": {"type": "string", "description": "检索词，如 '一致性哈希 反问环节'"},
                "company": {"type": "string", "description": "按公司/院校过滤，可留空"},
                "top_k": {"type": "integer", "description": "返回条数，默认 5，上限 20"},
                **_SID}, "required": ["query"]},
            handler=_skill_career_kb_query, category="career", timeout=20,
            argcheck_example={"query": "TCP 三次握手", "top_k": 5}),
        SkillDef(
            name="career_kb_manage",
            description=("面经库生命周期管理：list 看会话内有多少条与是否过期"
                         "（>30 天提示可能过期）、export 导出该会话 JSON、"
                         "drop 整体销毁（求职结束后即弃，含索引一并清掉）。"),
            parameters={"type": "object", "properties": {
                "action": {"type": "string", "enum": ["list", "export", "drop"],
                           "description": "操作，默认 list"},
                "export_dir": {"type": "string", "description": "export 自定义目录，默认 data/career_kb/export"},
                **_SID}, "required": []},
            handler=_skill_career_kb_manage, category="career", timeout=20,
            argcheck_example={"action": "list"}),
    ]
    for d in specs:
        skills.register(d)
    names = set()
    try:
        for d in skills.get_tool_definitions():
            names.add((d.get("function") or {}).get("name") or d.get("name") or "")
    except Exception:
        logger.debug("suppressed exception")
    internal = set(getattr(skills, "_skills", {}) or {})
    missing = [s.name for s in specs if s.name not in (names | internal)]
    return {"success": not missing, "skills": [s.name for s in specs],
            "error": "" if not missing else f"注册后 schema 发现失败: {missing}"}
