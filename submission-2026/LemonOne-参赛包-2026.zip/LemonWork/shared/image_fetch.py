# -*- coding: utf-8 -*-
"""★ ui-fix-cluster Q5: 网页图片真抓取（直链下载 → dataURL 内联）。

背景：web_capture 过去只保留外链 <img> 由 iframe 请求原站 —— 防盗链站点
（Referer 校验）一律裂图，且图片随原站策略随时消失。

本模块按"图片直链"逐张下载：
  - 校验 Content-Type 为 image/*（魔数兜底：PNG/JPEG/GIF/WEBP）
  - 单图字节上限 max_bytes（默认 8MB），超限返回结构化错误
  - 401/403/412/429 判定为疑似防盗链（reason_code=hotlink_protect）
  - 成功项返回 data:{mime};base64,...，可直接内联进消息流（禁止外链直塞 iframe）

返回结构（逐项）：{url, ok, data_url?, bytes?, error?, reason_code?}
reason_code ∈ hotlink_protect / timeout / too_large / not_image / fetch_error
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import base64
from typing import Dict, List

_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/126.0 Safari/537.36 LemonAgent/1.0")

_DEFAULT_MAX_BYTES = 8 * 1024 * 1024  # 单图 8MB 上限


def _referer_of(url: str) -> str:
    """防盗链友好：带图片所在页面的 origin 作 Referer。"""
    try:
        from urllib.parse import urlparse
        p = urlparse(url)
        if p.scheme and p.netloc:
            return f"{p.scheme}://{p.netloc}/"
    except Exception:
        logger.debug("suppressed exception")
    return ""


def _sniff_mime(content: bytes) -> str:
    """魔数兜底（Content-Type 缺失/泛型时用）。"""
    if content[:8] == b"\x89PNG\r\n\x1a\n":
        return "image/png"
    if content[:3] == b"\xff\xd8\xff":
        return "image/jpeg"
    if content[:6] in (b"GIF87a", b"GIF89a"):
        return "image/gif"
    if content[:4] == b"RIFF" and content[8:12] == b"WEBP":
        return "image/webp"
    if content[:2] == b"BM":
        return "image/bmp"
    return ""


def fetch_images(urls: List[str], max_n: int = 6, timeout: int = 10,
                 max_bytes: int = _DEFAULT_MAX_BYTES) -> List[Dict]:
    """按直链批量下载图片 → dataURL 列表（保序，失败项带结构化错误）。"""
    if not urls:
        return []
    try:
        import requests
    except Exception as e:  # 依赖异常不冒充成功
        return [{"url": u, "ok": False,
                 "error": f"requests 不可用: {e}", "reason_code": "fetch_error"}
                for u in list(urls)[:max(0, max_n)]]

    session = requests.Session()
    results: List[Dict] = []
    for u in list(urls)[:max(0, max_n)]:
        item: Dict = {"url": u, "ok": False}
        try:
            resp = session.get(
                u,
                headers={"User-Agent": _UA,
                         "Referer": _referer_of(u),
                         "Accept": "image/*,*/*;q=0.8"},
                timeout=timeout, allow_redirects=True, verify=True)
            if resp.status_code in (401, 403, 412, 429):
                item.update(error=f"HTTP {resp.status_code}（疑似防盗链）",
                            reason_code="hotlink_protect")
                results.append(item)
                continue
            resp.raise_for_status()
            content = resp.content or b""
            ctype = (resp.headers.get("Content-Type") or "").split(";")[0].strip().lower()
            mime = ctype if ctype.startswith("image/") else _sniff_mime(content)
            if not mime:
                item.update(error=f"Content-Type 非 image/*（{ctype or 'unknown'}）",
                            reason_code="not_image")
                results.append(item)
                continue
            if len(content) > max_bytes:
                item.update(error=f"图片超限（{len(content)}B > {max_bytes}B）",
                            reason_code="too_large")
                results.append(item)
                continue
            if not content:
                item.update(error="空响应", reason_code="not_image")
                results.append(item)
                continue
            item["ok"] = True
            item["bytes"] = len(content)
            item["data_url"] = (f"data:{mime};base64,"
                                + base64.b64encode(content).decode("ascii"))
        except Exception as e:
            # requests.Timeout 等统一归 timeout / fetch_error 两类
            name = type(e).__name__
            item.update(error=f"{name}: {e}",
                        reason_code="timeout" if "Timeout" in name else "fetch_error")
        results.append(item)
    return results
