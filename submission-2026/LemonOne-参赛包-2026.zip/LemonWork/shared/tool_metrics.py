# -*- coding: utf-8 -*-
"""★ W24-8: 工具选择质量指标。

1) 工具调用成功率
2) 工具选择准确率（选中工具是否正确）
3) 工具耗时分布
4) A/B 测试：不同工具包对比
5) R3 双轨评分（文本标准 + 产出标准）

禁止：只测调用次数不测准确率。
"""
from __future__ import annotations

from typing import Dict, List, Optional

import numpy as np
import pandas as pd


def tool_call_metrics(calls: List[Dict]) -> Dict:
    """工具调用指标。

    Args:
        calls: [{"tool": str, "success": bool, "latency_ms": float, "expected": str}]

    Returns:
        {"total": int, "success_rate": float, "avg_latency_ms": float,
         "p50_ms": float, "p95_ms": float, "accuracy": float,
         "by_tool": {...}}
    """
    if not calls:
        return {"total": 0, "success_rate": 0.0, "avg_latency_ms": 0.0,
                "p50_ms": 0.0, "p95_ms": 0.0, "accuracy": 0.0, "by_tool": {}}

    total = len(calls)
    successes = sum(1 for c in calls if c.get("success"))
    latencies = [c.get("latency_ms", 0.0) for c in calls]
    correct = sum(1 for c in calls if c.get("expected") and c.get("tool") == c.get("expected"))

    by_tool = {}
    for c in calls:
        t = c.get("tool", "unknown")
        if t not in by_tool:
            by_tool[t] = {"calls": 0, "success": 0, "latencies": []}
        by_tool[t]["calls"] += 1
        by_tool[t]["success"] += int(c.get("success", False))
        by_tool[t]["latencies"].append(c.get("latency_ms", 0.0))

    for t, m in by_tool.items():
        m["success_rate"] = round(m["success"] / m["calls"], 4)
        m["avg_latency_ms"] = round(np.mean(m["latencies"]), 2)
        m["p95_ms"] = round(np.percentile(m["latencies"], 95), 2)
        del m["latencies"]

    return {
        "total": total,
        "success_rate": round(successes / total, 4),
        "avg_latency_ms": round(np.mean(latencies), 2),
        "p50_ms": round(np.percentile(latencies, 50), 2),
        "p95_ms": round(np.percentile(latencies, 95), 2),
        "accuracy": round(correct / total, 4),
        "by_tool": by_tool,
    }


def ab_test(group_a: List[Dict], group_b: List[Dict]) -> Dict:
    """A/B 测试对比。

    Returns:
        {"a": {...}, "b": {...}, "winner": "a"|"b"|"tie", "delta_success": float,
         "delta_accuracy": float}
    """
    ma = tool_call_metrics(group_a)
    mb = tool_call_metrics(group_b)
    ds = mb["success_rate"] - ma["success_rate"]
    da = mb["accuracy"] - ma["accuracy"]
    if ds > 0.01 and da > 0.01:
        winner = "b"
    elif ds < -0.01 and da < -0.01:
        winner = "a"
    else:
        winner = "tie"
    return {"a": ma, "b": mb, "winner": winner,
            "delta_success": round(ds, 4), "delta_accuracy": round(da, 4)}


def r3_dual_score(text_score: float, artifact_score: float,
                  weights: Optional[Dict[str, float]] = None) -> Dict:
    """R3 双轨评分：文本标准 + 产出标准。

    Args:
        text_score: 文本标准得分（0-100）
        artifact_score: 产出标准得分（0-100）
        weights: {"text": 0.4, "artifact": 0.6}

    Returns:
        {"text": float, "artifact": float, "combined": float, "grade": str}
    """
    w = weights or {"text": 0.4, "artifact": 0.6}
    combined = text_score * w["text"] + artifact_score * w["artifact"]
    if combined >= 90:
        grade = "A"
    elif combined >= 80:
        grade = "B"
    elif combined >= 70:
        grade = "C"
    elif combined >= 60:
        grade = "D"
    else:
        grade = "F"
    return {"text": round(text_score, 2), "artifact": round(artifact_score, 2),
            "combined": round(combined, 2), "grade": grade}


def domain_pack_metrics(calls: List[Dict], domain: str) -> Dict:
    """按领域包统计工具指标。"""
    filtered = [c for c in calls if c.get("domain") == domain]
    return tool_call_metrics(filtered)


__all__ = ["tool_call_metrics", "ab_test", "r3_dual_score", "domain_pack_metrics"]
