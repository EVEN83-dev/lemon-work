# -*- coding: utf-8 -*-
"""
Engine Adapter 统一基类 — ★ 引擎收口（本窗口）：全仓唯一 BaseEngineAdapter
==============================================================================

★ 收口说明（引擎收口项 3/4）：
- 历史上存在两份定义：本文件（精简 ABC，供 shared.engine_manager 内嵌适配器）
  与 bridge/engines/base.py（富接口：EngineStatus/EngineCapability/EngineConfig
  + 回调机制，供 bridge Qt-free 适配器）。本文件现在合并两者，成为唯一真源；
  bridge/engines/base.py 降级为兼容 facade（仅 re-export，无第二份定义）。

统一接口（四方法契约，两栈原样保留）：
    chat(messages, **kwargs) -> str
    generate_with_tools(messages, tools, **kwargs) -> Dict[str, Any]
    is_available() -> bool
    cleanup() -> None

可选覆盖：list_models / stream / cancel / get_status_info
共享助手：_make_http_session()（双风格签名，见方法注释）

行为保持（不改业务功能）：
- shared 内嵌适配器（Ollama/MimoCode/MiemieV1/DeepSeek/OpenAICompat）不调用
  super().__init__，仅依赖 self.config 与 _make_http_session(scheme=...)；
- bridge 适配器（Qt-free）调用 super().__init__(config)，依赖 EngineStatus /
  capabilities / 回调 / stream / cancel。
- supports_tools 默认值：基类 capabilities 默认含 TOOL_CALLING（等价旧 shared
  隐式 True）；bridge 各适配器均在 __init__ 显式赋值 _capabilities，语义不变。
"""

from abc import ABC, abstractmethod
from enum import Enum
from typing import Any, Callable, Dict, Generator, List, Optional

try:
    import requests
except ImportError:
    requests = None


class EngineStatus(str, Enum):
    """引擎运行状态（bridge 栈原样收编）"""
    IDLE = "idle"
    GENERATING = "generating"
    THINKING = "thinking"
    USING_TOOL = "using_tool"
    ERROR = "error"
    DISCONNECTED = "disconnected"


class EngineCapability(str, Enum):
    """引擎能力位（bridge 栈原样收编）"""
    STREAMING = "streaming"
    TOOL_CALLING = "tool_calling"
    FILE_OPERATIONS = "file_operations"
    CODE_EXECUTION = "code_execution"
    WEB_SEARCH = "web_search"
    LONG_CONTEXT = "long_context"
    MULTI_MODAL = "multi_modal"
    LOCAL_ONLY = "local_only"
    CLOUD_ONLY = "cloud_only"


class EngineConfig:
    """适配器级引擎配置（bridge 栈原样收编；与 engine_manager.EngineConfig
    dataclass 无继承关系——后者是 shared.engine_manager 内部配置，互不影响）"""

    def __init__(self, **kwargs):
        self.model: str = kwargs.get("model", "")
        self.temperature: float = kwargs.get("temperature", 0.7)
        self.max_tokens: int = kwargs.get("max_tokens", 4096)
        self.top_p: float = kwargs.get("top_p", 0.9)
        self.timeout: int = kwargs.get("timeout", 60)
        self.system_prompt: str = kwargs.get("system_prompt", "")
        self.enable_skills: bool = kwargs.get("enable_skills", True)
        self.host: str = kwargs.get("host", "127.0.0.1")
        self.port: int = kwargs.get("port", 11434)
        self.api_key: str = kwargs.get("api_key", "")
        self.api_base: str = kwargs.get("api_base", "")

    @property
    def base_url(self) -> str:
        if self.api_base:
            return self.api_base.rstrip("/")
        return f"http://{self.host}:{self.port}"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "model": self.model,
            "temperature": self.temperature,
            "maxTokens": self.max_tokens,
            "topP": self.top_p,
            "host": self.host,
            "port": self.port,
            "baseUrl": self.base_url,
        }


class BaseEngineAdapter(ABC):
    """
    所有引擎适配器的唯一抽象基类（shared 与 bridge 两栈共用）。

    子类必须实现：chat / generate_with_tools / is_available / cleanup
    子类可选覆盖：list_models / stream
    bridge 适配器在 __init__ 中调用 super().__init__(config) 以获得
    状态机/回调/cancel 机制；shared 内嵌适配器不调用 super().__init__
    （仅用 self.config + _make_http_session，保持旧行为）。
    """

    # 引擎标识，子类应覆盖为具体名称
    name: str = "abstract_engine"
    display_name: str = "Abstract Engine"

    # ★ 默认含 TOOL_CALLING：等价旧 shared 基类 supports_tools 隐式 True；
    #   bridge 适配器在 __init__ 显式覆盖 _capabilities（元组防类级可变共享）
    _capabilities = (EngineCapability.TOOL_CALLING,)

    def __init__(self, config: Any = None):
        # shared 风格：self.config 保存调用方传入的任意配置对象
        if config is not None:
            self.config = config
        # bridge 风格：self._config 恒为 EngineConfig（供 get_status_info 等）
        self._config = config if isinstance(config, EngineConfig) else EngineConfig()
        self._status = EngineStatus.IDLE
        self._on_token: Optional[Callable[[str], None]] = None
        self._on_message: Optional[Callable[[str], None]] = None
        self._on_thinking: Optional[Callable[[str], None]] = None
        self._on_tool_call: Optional[Callable[[dict], None]] = None
        self._on_error: Optional[Callable[[str], None]] = None
        self._on_status_change: Optional[Callable[[EngineStatus], None]] = None
        self._cancelled = False

    # ==================== 抽象接口（四方法契约）====================

    @abstractmethod
    def chat(self, messages: List[Dict], **kwargs) -> str:
        """非流式对话，返回完整回复文本。"""
        raise NotImplementedError

    @abstractmethod
    def generate_with_tools(self, messages: List[Dict], tools: List[Dict],
                            **kwargs) -> Dict[str, Any]:
        """带工具调用的生成。至少返回 {'content': str, 'tool_calls': list}。"""
        raise NotImplementedError

    @abstractmethod
    def is_available(self) -> bool:
        """检查引擎当前是否可达/可用。"""
        raise NotImplementedError

    @abstractmethod
    def cleanup(self) -> None:
        """释放连接池等资源。"""
        raise NotImplementedError

    # ==================== 状态机与回调（bridge 栈原样）====================

    @property
    def status(self) -> EngineStatus:
        return self._status

    @property
    def capabilities(self) -> List[EngineCapability]:
        return list(self._capabilities)

    def has_capability(self, cap: EngineCapability) -> bool:
        return cap in self._capabilities

    def on_token(self, callback: Callable[[str], None]) -> None:
        self._on_token = callback

    def on_message(self, callback: Callable[[str], None]) -> None:
        self._on_message = callback

    def on_thinking(self, callback: Callable[[str], None]) -> None:
        self._on_thinking = callback

    def on_tool_call(self, callback: Callable[[dict], None]) -> None:
        self._on_tool_call = callback

    def on_error(self, callback: Callable[[str], None]) -> None:
        self._on_error = callback

    def on_status_change(self, callback: Callable[[EngineStatus], None]) -> None:
        self._on_status_change = callback

    def _emit_token(self, token: str) -> None:
        if self._on_token:
            self._on_token(token)

    def _emit_message(self, msg: str) -> None:
        if self._on_message:
            self._on_message(msg)

    def _emit_thinking(self, text: str) -> None:
        if self._on_thinking:
            self._on_thinking(text)

    def _emit_tool_call(self, tc: dict) -> None:
        if self._on_tool_call:
            self._on_tool_call(tc)

    def _emit_error(self, err: str) -> None:
        if self._on_error:
            self._on_error(err)

    def _set_status(self, status: EngineStatus) -> None:
        self._status = status
        if self._on_status_change:
            self._on_status_change(status)

    # ==================== 可选覆盖 ====================

    def stream(self, messages: List[Dict], **kwargs) -> Generator[str, None, None]:
        """默认流式 = chat 结果分块（bridge 栈原样；真流式子类自行覆盖）。"""
        result = self.chat(messages, **kwargs)
        chunk_size = max(1, len(result) // 10)
        for i in range(0, len(result), chunk_size):
            if self._cancelled:
                break
            yield result[i:i + chunk_size]

    def list_models(self) -> List[str]:
        """返回可用模型列表（默认空列表，子类按需覆盖）。"""
        return []

    @property
    def supports_tools(self) -> bool:
        """是否支持工具调用（默认看 capabilities；基类默认含 TOOL_CALLING）。"""
        return EngineCapability.TOOL_CALLING in self._capabilities

    def get_model_name(self) -> str:
        return self._config.model or self.name

    def cancel(self) -> None:
        self._cancelled = True

    def reset_cancel(self) -> None:
        self._cancelled = False

    def get_status_info(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "displayName": self.display_name,
            "status": self.status.value,
            "available": self.is_available(),
            "capabilities": [c.value for c in self._capabilities],
            "config": self._config.to_dict(),
        }

    # ==================== 共享助手 ====================

    def _make_http_session(self, pool_connections: int = 5,
                           pool_maxsize: int = 10,
                           max_retries: int = 1,
                           scheme: Optional[str] = None,
                           retry: Optional[int] = None) -> "requests.Session":
        """创建带连接池的 requests.Session（两栈调用风格均保持原行为）：

        - bridge 无参风格 `_make_http_session()`：scheme=None → urllib3 Retry
          (total=retry or 3, backoff_factor=0.5, status_forcelist 5xx)，
          同时挂载 http:// 与 https://（与旧 bridge/engines/base 一致）
        - shared 显式风格 `_make_http_session(pool_connections=…,
          pool_maxsize=…, max_retries=1, scheme="http"/"https")`：整数
          max_retries 直挂指定 scheme（与旧 shared/engines/base 一致）
        """
        if not requests:
            raise ImportError("requests 未安装")

        session = requests.Session()
        if scheme is None:
            from urllib3.util.retry import Retry as UrllibRetry
            retry_strategy = UrllibRetry(
                total=retry if retry is not None else 3,
                backoff_factor=0.5,
                status_forcelist=[500, 502, 503, 504])
            adapter = requests.adapters.HTTPAdapter(
                pool_connections=pool_connections,
                pool_maxsize=pool_maxsize,
                max_retries=retry_strategy)
            session.mount("http://", adapter)
            session.mount("https://", adapter)
        else:
            adapter = requests.adapters.HTTPAdapter(
                pool_connections=pool_connections,
                pool_maxsize=pool_maxsize,
                max_retries=max_retries)
            session.mount(f"{scheme}://", adapter)
        return session
