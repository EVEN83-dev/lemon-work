# -*- coding: utf-8 -*-
"""
Engine Manager（Qt-free 注册表）— ★ 引擎收口（本窗口）canonical 位置
==============================================================================
原 bridge/engines/engine_manager.py（B-002）迁入本文件；bridge/engines/
engine_manager.py 降级为兼容 facade。bridge/agent_loop、bridge/core/
smart_router、bridge/event_adapter、bridge/bridge_server 等消费方统一改
import 本模块。

职责边界（收口铁律）：
  - 注册表（register/unregister/list）在本类实现；
  - 健康单源（失败计数 / 连续失败 DOWN / 成功恢复）只在
    shared.engine_manager 实现 —— 本类仅委托（record_engine_failure /
    record_engine_success / is_engine_down / engine_health_summary）；
  - fallback 顺序单源 shared.engine_manager.FALLBACK_ORDER —— 本类只读取
    过滤，不另算顺序。

无 Qt 依赖（回调式事件）；shared.engine_manager 的 QObject 栈不受影响。
"""
from __future__ import annotations

import json
import logging
import os
import threading
import time
from enum import Enum
from typing import Any, Callable, Dict, Generator, List, Optional

try:
    from shared.engine_manager import (
        FALLBACK_ORDER,
        engine_health_summary,
        is_engine_down,
        log_engine_event,
        record_engine_failure,
        record_engine_success,
        reset_engine_health_module,
    )
except ImportError:  # 兜底：repo 根未入 sys.path 时补齐
    import os
    import sys

    _ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    if _ROOT not in sys.path:
        sys.path.insert(0, _ROOT)
    from shared.engine_manager import (
        FALLBACK_ORDER,
        engine_health_summary,
        is_engine_down,
        log_engine_event,
        record_engine_failure,
        record_engine_success,
        reset_engine_health_module,
    )

from .base import BaseEngineAdapter, EngineConfig, EngineStatus
from .deepseek_adapter import DeepSeekAdapter
from .lmstudio_adapter import LMStudioAdapter
from .ollama_adapter import OllamaAdapter

logger = logging.getLogger(__name__)


class EngineType(str, Enum):
    OLLAMA = "ollama"
    DEEPSEEK = "deepseek"
    LMSTUDIO = "lmstudio"
    OPENAI_COMPAT = "openai_compat"


ENGINE_CLASS_MAP: Dict[str, type] = {
    EngineType.OLLAMA: OllamaAdapter,
    EngineType.DEEPSEEK: DeepSeekAdapter,
    EngineType.LMSTUDIO: LMStudioAdapter,
    EngineType.OPENAI_COMPAT: OllamaAdapter,
}


class EngineManager:
    def __init__(self):
        self._engines: Dict[str, BaseEngineAdapter] = {}
        self._primary: str = ""
        self._lock = threading.Lock()
        # ★ 收口项 9：primary 选择与 shared EngineManager 共用落盘文件（键分离）
        self._state_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
            "data", "config", "engine_state.json")
        self._restore_primary()

    def _restore_primary(self):
        try:
            if os.path.exists(self._state_path):
                import json
                with open(self._state_path, "r", encoding="utf-8") as f:
                    st = json.load(f) or {}
                saved = str(st.get("bridge_primary") or "").strip()
                if saved:
                    self._primary = saved
                    logger.info(f"[EngineManager(qt-free)] 已恢复上次 primary: {saved}")
        except Exception as e:
            logger.debug("[EngineManager(qt-free)] primary 恢复失败（静默）: %s", e)

    def _save_primary(self):
        try:
            import json
            st = {}
            if os.path.exists(self._state_path):
                try:
                    with open(self._state_path, "r", encoding="utf-8") as f:
                        st = json.load(f) or {}
                except Exception:
                    st = {}
            st["bridge_primary"] = self._primary
            st["bridge_primary_saved_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
            os.makedirs(os.path.dirname(self._state_path), exist_ok=True)
            with open(self._state_path, "w", encoding="utf-8") as f:
                json.dump(st, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.debug("[EngineManager(qt-free)] primary 落盘失败（静默）: %s", e)

    def register_engine(self, engine_type: str, config: EngineConfig,
                        name: Optional[str] = None) -> str:
        cls = ENGINE_CLASS_MAP.get(engine_type)
        if cls is None:
            raise ValueError(f"Unknown engine type: {engine_type}")
        engine_name = name or engine_type
        adapter = cls(config)
        with self._lock:
            self._engines[engine_name] = adapter
            if not self._primary:
                self._primary = engine_name
        logger.info(f"Registered engine: {engine_name} ({engine_type})")
        return engine_name

    def unregister_engine(self, name: str) -> bool:
        with self._lock:
            if name in self._engines:
                self._engines[name].cleanup()
                del self._engines[name]
                if self._primary == name:
                    self._primary = next(iter(self._engines), "")
                return True
        return False

    def get_engine(self, name: Optional[str] = None) -> Optional[BaseEngineAdapter]:
        with self._lock:
            if name:
                return self._engines.get(name)
            return self._engines.get(self._primary)

    def set_primary(self, name: str) -> bool:
        with self._lock:
            if name in self._engines:
                self._primary = name
                self._save_primary()   # ★ 收口项 9：落盘
                return True
        return False

    def get_primary_name(self) -> str:
        return self._primary

    def list_engines(self) -> List[Dict[str, Any]]:
        with self._lock:
            result = []
            for name, engine in self._engines.items():
                info = engine.get_status_info()
                info["primary"] = name == self._primary
                result.append(info)
            return result

    def list_available_engines(self) -> List[str]:
        with self._lock:
            return [n for n, e in self._engines.items()
                    if e.is_available() and not is_engine_down(n)]

    def auto_select(self) -> Optional[str]:
        """自动选择主引擎：顺序读取 shared.engine_manager.FALLBACK_ORDER 单源，
        过滤「已注册且可用」，不另算顺序（收口项 6）。"""
        available = self.list_available_engines()
        if not available:
            return None
        for pref in FALLBACK_ORDER:
            if pref in available:
                self.set_primary(pref)
                return pref
        self.set_primary(available[0])
        return available[0]

    def chat(self, messages: List[Dict], engine_name: Optional[str] = None,
             **kwargs) -> str:
        engine, used = self._resolve(engine_name)
        try:
            out = engine.chat(messages, **kwargs)
        except Exception:
            # ★ 健康单源：失败计数 / 连续 DOWN 只在 shared.engine_manager
            record_engine_failure(used)
            raise
        record_engine_success(used)
        return out

    def chat_stream(self, messages: List[Dict], engine_name: Optional[str] = None,
                    **kwargs) -> Generator[str, None, None]:
        engine, used = self._resolve(engine_name)
        try:
            for chunk in engine.stream(messages, **kwargs):
                yield chunk
        except Exception:
            record_engine_failure(used)
            raise
        record_engine_success(used)

    def chat_with_tools(self, messages: List[Dict], tools: List[Dict],
                        engine_name: Optional[str] = None,
                        **kwargs) -> Dict[str, Any]:
        engine, used = self._resolve(engine_name)
        try:
            if not engine.supports_tools:
                content = engine.chat(messages, **kwargs)
                result = {"content": content, "tool_calls": []}
            else:
                result = engine.generate_with_tools(messages, tools, **kwargs)
        except Exception:
            record_engine_failure(used)
            raise
        record_engine_success(used)
        return result

    def _resolve(self, engine_name: Optional[str] = None):
        """解析目标引擎；主引擎 DOWN 时按 FALLBACK_ORDER 单源自动切换（收口项 14）。"""
        engine = self.get_engine(engine_name)
        if engine is None:
            raise RuntimeError(f"No engine available (requested: {engine_name})")
        used = engine_name or self._primary
        if (not engine.is_available()) or is_engine_down(used):
            fallback = self._find_fallback(used)
            if fallback:
                logger.info(f"[EngineManager] 引擎 {used} 不可用 → 备引擎 {fallback.name} 接管")
                engine = fallback
                used = fallback.name
            else:
                raise RuntimeError(f"Engine not available: {engine_name or self._primary}")
        return engine, used

    def _find_fallback(self, exclude: Optional[str] = None) -> Optional[BaseEngineAdapter]:
        """备引擎查找：顺序单源 FALLBACK_ORDER（bridge 侧只读取不另算，收口项 6）。"""
        with self._lock:
            for name in FALLBACK_ORDER:
                if name == exclude:
                    continue
                engine = self._engines.get(name)
                if engine and engine.is_available() and not is_engine_down(name):
                    logger.info(f"Using fallback engine: {name}")
                    return engine
        return None

    def setup_callbacks(self, on_token: Optional[Callable] = None,
                        on_message: Optional[Callable] = None,
                        on_tool_call: Optional[Callable] = None,
                        on_error: Optional[Callable] = None) -> None:
        for engine in self._engines.values():
            if on_token:
                engine.on_token(on_token)
            if on_message:
                engine.on_message(on_message)
            if on_tool_call:
                engine.on_tool_call(on_tool_call)
            if on_error:
                engine.on_error(on_error)

    def health_check(self) -> Dict[str, bool]:
        """可用性快照 = 适配器实时探测 ∧ 单源健康（DOWN 视为不可用）。"""
        with self._lock:
            return {name: (engine.is_available() and not is_engine_down(name))
                    for name, engine in self._engines.items()}

    def health_summary(self) -> Dict[str, Dict[str, Any]]:
        """★ 收口项 13：健康单源快照（UP/DOWN/延迟/失败计数），UI 只读此口径。"""
        return engine_health_summary()

    def reset_health(self, engine_name: str = "") -> None:
        reset_engine_health_module(engine_name)

    def cleanup(self) -> None:
        with self._lock:
            for engine in self._engines.values():
                engine.cleanup()
            self._engines.clear()
