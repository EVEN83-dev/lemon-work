# -*- coding: utf-8 -*-
"""★第408章 web_capture —— 网页抓取与对话内渲染（双模式）

两种呈现模式（按内容质量自动分流）：
  reader  阅读模式：提取正文 → 用 Lemon 自己的排版重排。干净、可读、体积小。
  visual  原貌快照：保留原站 CSS（<style>/<link>）只删脚本 → iframe 内接近原站观感。

设计要点（此前版本"卡片很丑"的技术根因修复）：
  1. 旧版把 <style> 整块删除，却保留 271 个 class → 骨架留下、皮肤扒掉 = 裸 HTML。
     新版 visual 保留样式表，只删 <script>/<noscript>/<iframe>/<form> 与 on* 事件，
     并由 sandbox 禁脚本双保险。
  2. 注入 <base href="原URL">，相对图片/链接不再在 srcdoc 里全部失效。
  3. SPA 空壳不再冒充成功：正文过短且原始 HTML 很大 → reason_code="needs_js"，
     由前端引导用户去内置浏览器，而不是给一张空白卡。
  4. 合规：只走协议/内网/黑名单校验 + 同域名限速 + 审计落库；
     robots.txt 仅作软提示（用户主动"打开这个页面看"等同人工访问，不是批量爬取）。
"""
from __future__ import annotations

import html as _html
import re
import time
from typing import Dict, List, Tuple
from urllib.parse import urljoin, urlparse

_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/126.0 Safari/537.36 LemonAgent/1.0")

_MAX_VISUAL_HTML = 200_000     # 原貌快照上限（srcdoc 可承载）
_MAX_READER_HTML = 60_000      # 阅读模式上限
_MAX_PREVIEW = 600             # 卡片摘要字数
_MIN_ARTICLE_CHARS = 300       # 正文低于此值视为"没提到内容"
_SPA_RAW_THRESHOLD = 100_000   # 原始 HTML 很大但正文很短 → 典型 JS 渲染空壳

# 正文容器里可保留的块级标签
_BLOCK_TAGS = ("h1", "h2", "h3", "h4", "p", "blockquote", "li", "img")
# 提取前先整块删除的噪声标签
_NOISE_TAGS = ("script", "style", "noscript", "iframe", "form", "nav", "footer",
               "header", "aside", "button", "input", "select", "textarea",
               "svg", "canvas", "video", "audio")


# ═══════════════════════════════════════════════════════════════
# 抓取原始 HTML
# ═══════════════════════════════════════════════════════════════
def _check_redirect_hop(url: str) -> Tuple[Dict, str]:
    """A-06: 重定向逐跳复检 —— 每一跳都必须通过 browser_policy.check_url。

    返回 (错误字典或空, 规范化后的 URL)。
    """
    try:
        from urllib.parse import urljoin
        u = urljoin(url, (url or "").strip())
        from shared.browser_policy import check_url
        c = check_url(u)
        if not c.get("allowed"):
            return {"success": False, "reason_code": "policy", "url": u,
                    "error": f"重定向逐跳复检拦截（A-06）: {c['reason']}"}, ""
        return {}, u
    except Exception as e:
        # 策略层不可用 → fail-closed（A-06：禁止静默放行）
        return {"success": False, "reason_code": "policy", "url": url,
                "error": f"重定向复检策略层不可用，已拦截（A-06 fail-closed）: {e}"}, ""


def _fetch_raw(url: str, timeout: int) -> Tuple[Dict, str]:
    """返回 (错误字典或空, raw_html)

    A-06: allow_redirects=False + 手动逐跳跟进，每一跳经 _check_redirect_hop
    复检（首跳已在 capture() 的合规闸门校验）。
    """
    import requests
    current = url
    hops = 0
    resp = None
    while True:
        err, current = _check_redirect_hop(current)
        if err:
            return err, ""
        if hops > 5:
            return {"success": False, "reason_code": "policy", "url": current,
                    "error": "重定向跳数超过 5，已拦截（A-06）"}, ""
        try:
            resp = requests.get(current, headers={"User-Agent": _UA}, timeout=timeout,
                                allow_redirects=False, verify=True)
        except Exception as e:
            return {"success": False, "reason_code": "timeout", "url": current,
                    "error": f"抓取失败: {type(e).__name__}: {e}"}, ""
        if resp.is_redirect or resp.is_permanent_redirect:
            hops += 1
            loc = resp.headers.get("Location") or ""
            if not loc:
                break
            from urllib.parse import urljoin
            current = urljoin(current, loc)
            continue
        break

    if resp.status_code in (401, 403, 412, 429, 503):
        return {"success": False, "reason_code": "blocked", "url": current,
                "error": f"站点拒绝程序访问（HTTP {resp.status_code}），"
                         f"可改用内置浏览器打开"}, ""

    if resp.encoding is None or resp.encoding.lower() in ("iso-8859-1",):
        resp.encoding = resp.apparent_encoding or "utf-8"

    raw = resp.text or ""
    if len(raw.strip()) < 200:
        return {"success": False, "reason_code": "empty", "url": current,
                "error": "页面内容为空"}, ""
    return {}, raw


# ═══════════════════════════════════════════════════════════════
# visual 模式：保留 CSS 的原貌快照
# ═══════════════════════════════════════════════════════════════
_CSS_GUARD = (
    "<style id=\"lw-frame-guard\">"
    "html,body{overflow-x:hidden!important;}"
    "body{word-wrap:break-word;}"
    "/* 只读快照：禁一切可交互元素，避免用户点进 iframe 出不来 */"
    "a{pointer-events:none!important;cursor:default!important;"
    "  text-decoration:none!important;color:inherit!important;}"
    "form,button,input,select,textarea{pointer-events:none!important;opacity:.9;}"
    "/* 图片：可见、可 hover 微放大给出\"这是张图\"的反馈，但不弹层不跳转 */"
    "img{cursor:zoom-in;transition:transform .18s ease,box-shadow .18s ease;"
    "    border-radius:4px;}"
    "img:hover{transform:scale(1.025);box-shadow:0 6px 22px rgba(0,0,0,.22);}"
    "</style>"
)


def _build_visual(raw: str, url: str) -> Dict:
    """生成保留原站样式的快照 HTML（脚本全禁，靠 sandbox 双保险）"""
    from bs4 import BeautifulSoup

    soup = BeautifulSoup(raw, "html.parser")

    # 只删"可执行/可提交"元素；<style>/<link> 一律保留
    for tag in soup(["script", "noscript", "iframe", "object", "embed", "form"]):
        tag.decompose()

    # 清掉 HTML 注释：注释里的 <script> 不执行，但会污染文本检查并白占体积
    from bs4 import Comment
    for node in soup.find_all(string=lambda s: isinstance(s, Comment)):
        node.extract()

    # 事件属性与危险协议清理
    for tag in soup.find_all(True):
        for attr in list(tag.attrs):
            low = attr.lower()
            if low.startswith("on"):
                del tag[attr]
            elif low in ("href", "src", "action"):
                val = str(tag.get(attr) or "")
                if val.strip().lower().startswith(("javascript:", "vbscript:")):
                    tag[attr] = "#"
        # 去掉 target=_blank 之类（iframe 内无意义）
        if tag.has_attr("target"):
            del tag["target"]

    # 确保有 head 并注入 base（相对路径的命门）
    if soup.head is None:
        head = soup.new_tag("head")
        if soup.html is not None:
            soup.html.insert(0, head)
        else:
            soup.insert(0, head)
    for old in soup.head.find_all("base"):
        old.decompose()
    base_tag = soup.new_tag("base", href=url)
    soup.head.insert(0, base_tag)
    guard = BeautifulSoup(_CSS_GUARD, "html.parser")
    soup.head.append(guard.find("style"))

    style_count = len(soup.find_all("style")) + len(
        soup.find_all("link", attrs={"rel": lambda v: v and "stylesheet" in str(v).lower()}))
    img_count = len(soup.find_all("img"))

    html = str(soup)
    if len(html) > _MAX_VISUAL_HTML:
        html = html[:_MAX_VISUAL_HTML] + "</body></html>"

    return {"html": html, "style_count": style_count, "img_count": img_count}


# ═══════════════════════════════════════════════════════════════
# reader 模式：正文提取 + 自排版
# ═══════════════════════════════════════════════════════════════
def _pick_article_container(soup):
    """按"文本多 + 链接少 + 段落多"打分挑选正文容器"""
    nodes = soup.find_all(["article", "main", "section", "div"])
    best, best_score = None, 0.0
    for n in nodes:
        text = n.get_text(" ", strip=True)
        tl = len(text)
        if tl < 120:
            continue
        link_text = sum(len(a.get_text(" ", strip=True)) for a in n.find_all("a"))
        link_ratio = min(link_text / float(tl), 0.9)
        p_count = len(n.find_all("p"))
        score = tl * (1.0 - link_ratio) + p_count * 40.0
        if score > best_score:
            best, best_score = n, score
    return best or soup.body or soup


def _extract_article(raw: str, url: str) -> Dict:
    """返回 {frag_html, text_chars, img_count}"""
    from bs4 import BeautifulSoup

    soup = BeautifulSoup(raw, "html.parser")
    for tag in soup(_NOISE_TAGS):
        tag.decompose()
    for tag in soup.find_all(True):
        for attr in list(tag.attrs):
            if attr.lower().startswith("on"):
                del tag[attr]

    container = _pick_article_container(soup)
    base = url

    blocks, seen = [], set()
    for el in container.find_all(list(_BLOCK_TAGS)):
        if el.name == "img":
            src = str(el.get("src") or "").strip()
            if not src or src.startswith("data:"):
                continue
            src = urljoin(base, src)
            if src in seen:
                continue
            seen.add(src)
            blocks.append('<img src="%s" alt="%s" loading="lazy">'
                          % (_html.escape(src, quote=True),
                             _html.escape(str(el.get("alt") or ""), quote=True)))
            continue
        text = el.get_text(" ", strip=True)
        if len(text) < 12:
            continue
        key = text[:80]
        if key in seen:
            continue
        seen.add(key)
        tag = el.name
        esc = _html.escape(text, quote=False)
        if tag in ("h1", "h2", "h3", "h4"):
            blocks.append("<%s>%s</%s>" % (tag, esc, tag))
        elif tag == "blockquote":
            blocks.append("<blockquote>%s</blockquote>" % esc)
        elif tag == "li":
            blocks.append("<li>%s</li>" % esc)
        else:
            blocks.append("<p>%s</p>" % esc)

    frag = "\n".join(blocks)
    text_chars = sum(len(re.sub(r"<[^>]+>", "", b)) for b in blocks)
    return {"frag_html": frag, "text_chars": text_chars,
            "img_count": sum(1 for b in blocks if b.startswith("<img"))}


_READER_CSS = """
:root{color-scheme:light}
*{box-sizing:border-box}
body{margin:0;padding:26px 30px 40px;background:#ffffff;color:#1f2430;
     font:16px/1.85 -apple-system,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;}
article{max-width:760px;margin:0 auto}
h1{font-size:25px;line-height:1.35;margin:0 0 10px;font-weight:650;letter-spacing:.2px}
h2{font-size:20px;margin:30px 0 12px;font-weight:600;border-left:3px solid #ff8a00;padding-left:10px}
h3,h4{font-size:17px;margin:24px 0 10px;font-weight:600}
p{margin:0 0 17px;text-align:justify}
blockquote{margin:18px 0;padding:12px 16px;background:#f7f8fa;border-left:3px solid #d9dde3;
           color:#4a5160;font-size:15px;border-radius:0 6px 6px 0}
li{margin:0 0 9px;padding-left:2px}
img{max-width:100%;height:auto;display:block;margin:18px auto;border-radius:8px}
.lw-meta{font-size:12.5px;color:#8a92a3;margin:0 0 26px;padding-bottom:14px;
         border-bottom:1px solid #eef0f4;word-break:break-all}
.lw-foot{margin-top:38px;padding-top:14px;border-top:1px solid #eef0f4;
         font-size:12px;color:#9aa1af;text-align:center}
@media (max-width:560px){body{padding:18px 16px 30px;font-size:15px}h1{font-size:21px}}
"""


def _reader_shell(title: str, url: str, frag: str) -> str:
    return (
        '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1">'
        f'<base href="{_html.escape(url, quote=True)}">'
        f'<style>{_READER_CSS}</style></head><body><article>'
        f'<h1>{_html.escape(title or "无标题", quote=False)}</h1>'
        f'<div class="lw-meta">{_html.escape(url, quote=False)} · 阅读模式</div>'
        f'{frag}'
        '<div class="lw-foot">已由 Lemon Work 提取正文并重排 · 原文样式与脚本未执行</div>'
        '</article></body></html>'
    )


# ═══════════════════════════════════════════════════════════════
# 统一入口
# ═══════════════════════════════════════════════════════════════
_IMG_SRC_RE = re.compile(r"<img\b[^>]*?\bsrc\s*=\s*[\"']([^\"']+)[\"']", re.I)
_IMG_SRCSET_RE = re.compile(r"<img\b[^>]*?\bsrcset\s*=\s*[\"']([^\"']+)[\"']", re.I)


def extract_image_urls(clean_html: str, base_url: str, max_n: int = 6) -> List[str]:
    """★ ui-fix Q5: 从 HTML 提取图片直链（<img src> 与 srcset 首项）。

    - urljoin 绝对化（相对路径依赖 <base href>，这里统一用 base_url 兜底）
    - 跳过 data:/javascript:/纯锚点；仅保留 http(s)
    - 去重且保序；最多返回 max_n 条
    """
    urls: List[str] = []
    seen = set()

    def _push(raw: str) -> None:
        u = (raw or "").strip()
        if not u or u.startswith(("data:", "#", "javascript:", "vbscript:")):
            return
        # srcset 取首项（"a.png 1x, b.png 2x" → a.png）
        u = u.split(",")[0].strip().split()[0] if u else ""
        if not u or u.startswith(("data:", "#")):
            return
        try:
            absu = urljoin(base_url, u)
        except Exception:
            return
        if not absu.lower().startswith(("http://", "https://")):
            return
        if absu in seen:
            return
        seen.add(absu)
        urls.append(absu)

    for m in _IMG_SRC_RE.finditer(clean_html or ""):
        _push(m.group(1))
        if len(urls) >= max_n:
            return urls
    for m in _IMG_SRCSET_RE.finditer(clean_html or ""):
        _push(m.group(1))
        if len(urls) >= max_n:
            return urls
    return urls


def fetch_page(url: str, timeout: int = 15, mode: str = "auto",
               apply_policy: bool = True, with_images: bool = False) -> Dict:
    """抓取网页并生成渲染内容。

    Args:
        mode: "auto"（按正文质量分流，默认）| "reader" | "visual"
        apply_policy: 是否走合规闸门（协议/内网/黑名单 + 限速 + 审计）
        with_images: ★ ui-fix Q5 — 为 True 时提取 <img> 直链并由
            shared.image_fetch 逐张下载，dataURL 写进返回结构 images[]
            （默认 False，行为与旧版逐字一致）

    Returns:
        {success, url, title, mode, preview, clean_html, sandbox,
         reason_code, quality, fetched_at, html_size[, images]}
    """
    if not url or not re.match(r"^https?://", url.strip(), re.I):
        return {"success": False, "reason_code": "bad_url",
                "error": "URL 必须以 http(s):// 开头"}
    url = url.strip()

    # ── 合规闸门：只做 URL 校验 + 限速 + 审计；robots 作软提示不拦截 ──
    # A-06: 策略层不可用时 fail-closed（旧版静默放行是 SSRF 漏洞面）
    robots_note = ""
    if apply_policy:
        try:
            from shared.browser_policy import check_url, throttle, audit, check_robots
            c = check_url(url)
            if not c["allowed"]:
                return {"success": False, "reason_code": "policy",
                        "url": url, "error": f"策略拦截: {c['reason']}"}
            throttle(c["domain"])
            r = check_robots(url)
            if not r["allowed"]:
                robots_note = "站点 robots.txt 声明禁止自动抓取，已按用户主动访问处理且限速"
            audit("web_preview", url, mode, verdict="ok", risk="read")
        except Exception as e:
            print(f"[web_capture] 策略层不可用，按 A-06 fail-closed 拦截（证据已记录）")
            from shared.pii_mask import mask_url
            return {"success": False, "reason_code": "policy", "url": mask_url(url),
                    "error": "策略层不可用 —— 已 fail-closed 拦截（A-06）",
                    "policy_error": str(e)}

    err, raw = _fetch_raw(url, timeout)
    if err:
        return err

    m = re.search(r"<title[^>]*>(.*?)</title>", raw, re.I | re.S)
    title = _html.unescape(m.group(1)).strip()[:120] if m else url

    reader = _extract_article(raw, url)
    visual = _build_visual(raw, url)

    want = (mode or "auto").lower()
    if want == "reader":
        chosen = "reader"
    elif want == "visual":
        chosen = "visual"
    else:
        if reader["text_chars"] >= _MIN_ARTICLE_CHARS:
            chosen = "reader"
        elif len(raw) > _SPA_RAW_THRESHOLD and reader["text_chars"] < 120:
            # 原始 HTML 很大、正文几乎没有 = 典型 JS 渲染空壳
            chosen = "needs_js"
        else:
            # 小页面或短内容页：给原貌快照，至少能看到页面本身
            chosen = "visual"

    # ── SPA 空壳：不再冒充成功 ──
    if chosen == "needs_js":
        return {
            "success": False, "reason_code": "needs_js", "url": url, "title": title,
            "error": (f"该页面需要 JavaScript 渲染才能出正文（原始 HTML {len(raw)} 字节，"
                      f"可提取正文仅 {reader['text_chars']} 字），"
                      f"已为你在内置浏览器打开"),
            "reader_chars": reader["text_chars"],
        }

    if chosen == "reader":
        html = _reader_shell(title, url, reader["frag_html"])
        if len(html) > _MAX_READER_HTML:
            html = html[:_MAX_READER_HTML] + "</article></body></html>"
        text_plain = re.sub(r"<[^>]+>", " ", reader["frag_html"])
        text_plain = re.sub(r"\s+", " ", text_plain).strip()
        # ★ 2026-11-22 修复: reader 提取不到正文时降级 visual 原貌快照，不再直接失败。
        #   此前短正文/纯静态页（如 example.com）在 reader 模式下必定返回
        #   「页面无可提取正文」→ 不出卡片，用户看到的就是「抓取页面显示失效」。
        #   现在只要抓到了 HTML，就一定给出一张可看的卡。
        if len(text_plain) < _MIN_ARTICLE_CHARS:
            chosen = "visual"
            html = visual["html"]
            text_plain = re.sub(r"<(script|style)[^>]*>.*?</\1>", " ", raw, flags=re.I | re.S)
            text_plain = re.sub(r"<[^>]+>", " ", text_plain)
            text_plain = re.sub(r"\s+", " ", text_plain).strip()
            preview = text_plain[:_MAX_PREVIEW] + ("…" if len(text_plain) > _MAX_PREVIEW else "")
            sandbox = "allow-same-origin"   # CSS 生效；不给 allow-scripts
            quality = {"text_chars": len(text_plain), "img_count": visual["img_count"],
                       "style_count": visual["style_count"]}
        else:
            preview = text_plain[:_MAX_PREVIEW] + ("…" if len(text_plain) > _MAX_PREVIEW else "")
            sandbox = ""          # 纯自排 HTML，无需任何权限
            quality = {"text_chars": reader["text_chars"], "img_count": reader["img_count"],
                       "style_count": 0}
    else:
        html = visual["html"]
        text_plain = re.sub(r"<(script|style)[^>]*>.*?</\1>", " ", raw, flags=re.I | re.S)
        text_plain = re.sub(r"<[^>]+>", " ", text_plain)
        text_plain = re.sub(r"\s+", " ", text_plain).strip()
        preview = text_plain[:_MAX_PREVIEW] + ("…" if len(text_plain) > _MAX_PREVIEW else "")
        sandbox = "allow-same-origin"   # CSS 生效；不给 allow-scripts
        quality = {"text_chars": len(text_plain), "img_count": visual["img_count"],
                   "style_count": visual["style_count"]}

    # ★ 2026-11-22: 到达此处仍无内容才判定失败（reader 已在上方自动降级 visual）
    if len(text_plain) < 20 and not html:
        return {"success": False, "reason_code": "empty", "url": url, "title": title,
                "error": "页面无可提取正文（可能为纯脚本页或反爬拦截）"}

    return {
        "success": True, "url": url, "title": title,
        "mode": chosen, "preview": preview, "clean_html": html,
        "sandbox": sandbox, "reason_code": "", "quality": quality,
        "robots_note": robots_note,
        "fetched_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "html_size": len(html),
        # ★ ui-fix Q5: with_images=True 时内联图片直链抓取结果（dataURL），
        #   默认 False 时该键不存在 —— 旧调用方行为逐字不变
        **({"images": _fetch_images_inline(html, url, timeout)} if with_images else {}),
    }


def _fetch_images_inline(page_html: str, page_url: str, timeout: int) -> List[Dict]:
    """with_images=True 的落地：提直链 → image_fetch 下载 → 成功项列表。"""
    try:
        from shared.image_fetch import fetch_images
        urls = extract_image_urls(page_html, page_url, max_n=6)
        got = fetch_images(urls, max_n=6, timeout=min(int(timeout), 10))
        return [g for g in got if g.get("ok")]
    except Exception as e:
        print(f"[web_capture] with_images 抓取失败（不阻塞主结果）: {e}")
        return []


# ══════════════════════════════════════════════════════════════════
# ★ A5: parse_html — 抓取与展示解耦的解析入口
#   raw,url,mode="auto" -> {mode,clean_html,preview,quality,sandbox}
#   内部复用 _extract_article / _build_visual / 现有分流阈值；
#   fetch_page 改为调用 parse_html，返回结构逐字不变。
# ══════════════════════════════════════════════════════════════════
def parse_html(raw: str, url: str, mode: str = "auto") -> Dict:
    """把原始 HTML 解析为 {mode, clean_html, preview, quality, sandbox}

    纯函数，不发网络请求、不写库。mode: auto|reader|visual
    """
    import html as _html
    import re as _re

    m = _re.search(r"<title[^>]*>(.*?)</title>", raw, _re.I | _re.S)
    title = _html.unescape(m.group(1)).strip()[:120] if m else url

    reader = _extract_article(raw, url)
    visual = _build_visual(raw, url)

    want = (mode or "auto").lower()
    if want == "reader":
        chosen = "reader"
    elif want == "visual":
        chosen = "visual"
    else:
        if reader["text_chars"] >= _MIN_ARTICLE_CHARS:
            chosen = "reader"
        elif len(raw) > _SPA_RAW_THRESHOLD and reader["text_chars"] < 120:
            chosen = "needs_js"
        else:
            chosen = "visual"

    if chosen == "needs_js":
        return {
            "mode": "needs_js",
            "clean_html": "",
            "preview": "",
            "quality": {"text_chars": reader["text_chars"], "img_count": 0, "style_count": 0},
            "sandbox": "",
            "title": title,
            "reader_chars": reader["text_chars"],
        }

    if chosen == "reader":
        html = _reader_shell(title, url, reader["frag_html"])
        if len(html) > _MAX_READER_HTML:
            html = html[:_MAX_READER_HTML] + "</article></body></html>"
        text_plain = _re.sub(r"<[^>]+>", " ", reader["frag_html"])
        text_plain = _re.sub(r"\s+", " ", text_plain).strip()
        preview = text_plain[:_MAX_PREVIEW] + ("…" if len(text_plain) > _MAX_PREVIEW else "")
        sandbox = ""
        quality = {"text_chars": reader["text_chars"], "img_count": reader["img_count"],
                   "style_count": 0}
    else:
        html = visual["html"]
        text_plain = _re.sub(r"<(script|style)[^>]*>.*?</\1>", " ", raw, flags=_re.I | _re.S)
        text_plain = _re.sub(r"<[^>]+>", " ", text_plain)
        text_plain = _re.sub(r"\s+", " ", text_plain).strip()
        preview = text_plain[:_MAX_PREVIEW] + ("…" if len(text_plain) > _MAX_PREVIEW else "")
        sandbox = "allow-same-origin"
        quality = visual.get("quality") or {"text_chars": len(text_plain), "img_count": 0,
                                           "style_count": 0}

    return {
        "mode": chosen,
        "clean_html": html,
        "preview": preview,
        "quality": quality,
        "sandbox": sandbox,
        "title": title,
    }
