@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0LemonWork"
if not exist "..\requirements.txt" (
  echo [Lemon One] package incomplete: requirements.txt missing
  pause & exit /b 1
)
where python >nul 2>nul
if errorlevel 1 (
  where py >nul 2>nul
  if errorlevel 1 (
    echo [Lemon One] Python not found. Install Python 3.12 first.
    echo Then run: pip install -r ..\requirements.txt
    pause & exit /b 1
  )
  start "" py -3 yh_main.py
) else (
  start "" python yh_main.py
)
exit
