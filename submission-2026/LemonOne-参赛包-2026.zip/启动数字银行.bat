@echo off
chcp 65001 >nul
cd /d "%~dp0LemonWork\DigitalBank"
where python >nul 2>nul
if errorlevel 1 (
  echo [DigitalBank] Python not found. Install Python 3.12 first.
  pause & exit /b 1
)
python server.py
pause
