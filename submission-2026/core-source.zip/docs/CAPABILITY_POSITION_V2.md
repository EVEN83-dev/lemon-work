# CAPABILITY_POSITION_V2 · 能力定位（实证版）

> 版本：超级收口集群 v1 Wave D（D3，P14）· 2026-11-06
> 性质：**工程实证文档，非营销文案**。每条结论挂可复核的报告/代码路径；"未满足"如实标注。
> 版图基线：单机 RTX 4060 Laptop（8GB 显存）+ 16GB 系统内存 + Ollama 本地推理（qwen3.5 系列本地权重）。

---

## 一、三条实证结论

### 结论 1：能力密度远超一般 Agent —— 金融级安全、白盒可审计、自评估闭环均真实存在

**不是"有一个安全提示词"，而是多层可执行组件 + 可复核的测试证据：**

| 能力面 | 组件（可复核路径） | 实证数据 |
|---|---|---|
| 浏览器合规策略 | `shared/browser_policy.py`（协议/内网/黑名单/robots/限速/审计/风险分级） | scripts/test_browser_legal.py **22/22**（含 file:// 拦截、内网拦截、robots Disallow、审计行数递增、write 需确认、拒绝确认即取消）——supercluster_gate0.md §2.3 |
| 权限分级与确认 | `shared/permission_guard.py` / `shared/permission_tiers.py`（read/write/submit 分级 + 审批流） | legal 测试 P8-P10 分类断言 + P19-P22 操控拦截全过 |
| 金融 HITL 网关 | `shared/bank_gateway_server.py`（/api/bank/policy、pending、approve、decisions，HITL 阈值 L53）+ `shared/mock_bank.py` 本地沙盒账本 | 转账类操作强制人工审批路径存在（代码 L241-243） |
| 白盒过程可视 | `standard_mode/ui/whitebox/` + `lw_whitebox_fold.js`（过程卡折叠治理）+ TraceRenderer 全轨迹 | v6.5 白盒折叠真机冒烟随 C0 全场景通过 |
| 自评估闭环 | `bridge/eval/real_e2e_bench.py`（冻结契约跑批器）+ `bridge/eval/failure_attribution.py`（四分类+待人工复核）+ `bridge/autoloop/`（护栏 V1.6）+ `bridge/eval/CASES_MAINTENANCE.md`（季度题集评审机制，meta.review_due 自动标注） | test_autoloop.py **28/28**；failure_attribution 自测 **20/20**；num_predict 契约单测 **18/18**——GateA/GateB |
| 技能层 | 45 技能注册（/api/skills 实测）+ skill_audit / skill_trajectory / skill_promote 治理链 | data/evals/.c3_health.json（skills_count=45） |
| 双阶段工具路由 | `shared/tool_router_2stage.py` | 首轮计划生成→逐工具执行的结构化路由（代码在仓可审） |

**一句话定位：这是"带合规围栏、白盒轨迹、自评估与季度题集治理的本地 Agent 工作台"，同类开源 Agent 框架普遍缺失 robots 合规、HITL 金融网关与冻结契约式评估治理这三块。**

### 结论 1 补充披露（D3 · 2026-11-15）

- **Crawl-delay 支持**：`shared/browser_policy.py` 解析 robots `User-agent: *` 段的 `Crawl-delay`（非法值忽略），与台账 `rate_limit_s` 一起参与生效间隔 `max(MIN_INTERVAL=1.5s, Crawl-delay, 台账)`——**更严允许、更松拒绝**。证据：`tests/test_crawl_delay.py` 4/4（含同域间隔毫秒实测表，见 `data/cluster_evidence/D3/D3-02.json`）。
- **台账限速真实生效**：合规台账 `rate_limit_s` 不再「仅记录」（原为死配置 `pass`），真实作用于按域锁。
- **进程边界限制（诚实披露）**：**多进程同域限速互不可见**——每进程独立 `_LAST_HIT` 与 robots 规则集缓存。跨进程 / 多 daemon 部署时需在网关层统一限速，否则域间隔可能低于单进程口径。

### 结论 2：智能水位受"8GB 显存 + 256K 默认 context"与"4b 模型推理能力"双层约束

**第一层（资源层）——context 治理前后对比（全部实测，非推测）：**

| 配置 | PROCESSOR | SIZE | 系统空闲内存 | 22 题通过率 | 平均耗时 |
|---|---|---|---|---|---|
| qwen3.5:4b @256K 默认 ctx | **62%/38% CPU/GPU** | 14GB | 396MB（高压） | 81.8%（F2） | 52.0s |
| qwen3.5:9b @256K 默认 ctx | **72%/28% CPU/GPU** | 16GB | 崩溃边缘 | 81.8%（I2） | ~60s |
| qwen3.5:4b-ctx8k | **100% GPU** | 3.4GB | 充裕 | **90.9%** | **7.9s** |
| qwen3.5:9b-ctx8k | **100% GPU** | 5.6GB | 充裕 | 86.4% | 9.5s |

路径：data/evals/supercluster_gate0.md（硬件基线）→ data/evals/model_rematch_20261106.md（A1-A4 控制变量实验）→ data/evals/supercluster_gateA.md。
历史误判修正：F2"9b 更快"= 4b CPU 卸载假象；I2"热降频"= 证伪（81°C 时频率仍 2610-2625MHz，data/evals/.a4_temp_analysis.txt）。

**第二层（能力层）——即使资源层修满，hard 题仍有 2 题过不去：**
- 4b-ctx8k 全 GPU 最优条件下 hard_06/hard_07 仍 0/3 通过（归因"模型决策错"，非资源问题）——model_rematch_20261106.md §二
- 9b-ctx8k 的 hard 失败为输出截断（2048 预算），但 num_predict=4096 实测 **0pt 提升**——model_rematch_20261106.md §四
- **结论：8K ctx 治理解除了资源封印（+9.1pt/-85% 耗时），但推理能力上限由 4b/9b 权重本身决定。**

### 结论 3：当前闭环边界 = 模型能力边界

- 完整样本闭环（7 题 × repeat 2 × 2 轮，无 --limit）：R1 57.1% → R2 42.9%，退化 14.2pt 触发护栏 **rolled_back**——data/autoloop/supercluster_gateB.md
- 条款只改变失败形态（hard_02 归因从输出截断迁移为模型决策错，答案仍错），不降低推理错误率——docs/AUTOLOOP.md §4.4"差距四"
- J2 的子集结论在完整样本下复验成立：**卡点在模型能力层，prompt 搜索收益上界 = 不退化**
- 三个被实证排除的纯 prompt 侧出路：① num_predict 4096（0pt）② 输出收口条款（R2 反而退化）③ 更长上下文（256K → CPU 卸载反噬）

---

## 二、"真正超越 Agent 范畴"的三个必要条件（全部未满足，如实标注）

| # | 必要条件 | 现状 | 证据路径 |
|---|---|---|---|
| 1 | **模型侧能力升级**：更强推理模型 / 微调 / 蒸馏落地 | **未满足**。A5 判定不切换（9b-ctx8k 86.4% < 4b-ctx8k 90.9%）；蒸馏仅留配方未执行（data/evals/DISTILL_RECIPE.md、distill_dataset.jsonl 存在但无训练基础设施） | data/evals/model_switch_decision.md §七 |
| 2 | **产品代码自动修复**：闭环能改 Agent 循环/工具/技能代码并验证回写 | **未满足**。autoloop 仅 --system-extra 注入，护栏明令禁止写产品代码（bridge/autoloop/guardrails.py check_write_path 白名单=data/autoloop） | docs/AUTOLOOP.md §4.2 差距一 |
| 3 | **跨会话积累**：有效条款/经验固化为产品默认，跨会话生效 | **未满足**。session 记忆仅进程内（routes_agent 同进程共享实例）；条款不持久化；无跨会话学习 | docs/AUTOLOOP.md §4.2 差距三 |

**总判词**：当前系统 = 单机资源约束下的**能力密度领先**的本地 Agent 工作台，其自评估闭环已能诚实测量自身边界；要越过"Agent 范畴"进入"自我改进系统"，上表三个条件缺一不可，本次集群之后三者仍未满足——这不是失败，而是边界被清晰标注。

---

## 三、数据索引

| 报告 | 覆盖 |
|---|---|
| data/evals/supercluster_gate0.md | Stage0 基线（硬件/测试/副本/CSS 口径） |
| data/evals/supercluster_gateA.md | P01/P02/P03/P06/P07 全链路证据 |
| data/evals/model_rematch_20261106.md | 8K ctx 重横评 + 热降频证伪 + num_predict 实验 |
| data/evals/model_switch_decision.md §七 | A5 切换决策 + 回滚通道 |
| data/autoloop/supercluster_gateB.md | P04 完整样本闭环 + P05 差距四 |
| data/ui_smoke/supercluster_gateC.md | P08/P09/P10/P11/P12 真机证据 |
| docs/REPO_HYGIENE.md §三 | P13 仓库卫生与并行改动标识 |

---

## 四、八项前端能力：修复前/后对照（★ ui-fix-cluster v1 · 2026-11-06）

> 覆盖集群：「图片·界面·内容呈现 超级修复集群 v1」Stage 0-6（单窗口串行）。
> 定级口径：**有 / 部分 / 无**。每项挂 Gate 报告路径（含 QWebEngine 真机截图），
> "部分"项如实标注缺口。总报告：data/evals/ui_capability_final.md。

| # | 能力 | 修复前 | 修复后 | Gate/证据 |
|---|---|---|---|---|
| Q1 | 图片稳定性（手绘图表） | **无**（6 渲染器无冻结、5/6 无 0 宽兜底、900ms 重试被 0 宽 canvas 短路、PerfOpt 清 canvas → 黑屏） | **有**（lw_canvas_freeze.js 固化 6 渲染器 + 0 宽兜底 6/6 + 重试判定含 0 宽 + PerfOpt 四处双守卫；真机 6 类固化、35 条消息滚动后 6 图完好） | data/evals/ui_fix_gate1.md |
| Q2 | 绘制用户想要的界面（构建期固化+契约机检） | **无**（全靠运行时 canvas/iframe，无固化、无机检） | **部分**（lwRenderUiSpec 纯 SVG/CSS 内核 8 块 × 4 主题 + 契约机检 195/195 + 真机 4 主题滚动稳定；**缺口：8 块 vs 微信版 36 模板×4 皮肤，renderChartCard 未收敛只并行挂载**） | data/evals/ui_fix_gate5.md、docs/UI_SPEC_CONTRACT.md |
| Q3 | 代码框（复制/语言标签） | **部分**（复制 hover 才显、委托类名死链、无语言标签、initCodeToolbars 未导出从未创建） | **有**（语言标签 + 复制常驻 + 类名统一 + 导出补齐 + 点击打勾真机 + 剪贴板 Promise 拒绝兜底 + _stToolbar null 守卫） | data/evals/ui_fix_gate4.md §③、data/evals/ui_fix_gate6.md G6e |
| Q4 | 文件生成最后一公里 | **部分**（真落盘但技能产物只回一行路径、卡只在 write/edit 触发、无保存/预览键、exports 目录不存在） | **有**（emit_artifact_card 统一发卡 + 3 技能 artifact_path 接线 + 保存/预览/缩略/徽标 + data/exports 落盘；真实落盘单测 9/9 + 真机 3 类卡；**保存对话框弹出留主控应用内回归（与导出共用同一实现）**） | data/evals/ui_fix_gate3.md |
| Q5 | 网页照片 | **无**（外链 `<img>` 由 iframe 请求原站，无下载/代理/防盗链兜底） | **部分**（image_fetch.py 直链下载 + fetch_page(with_images) + `__WEB_IMAGES__` dataURL 内联 + 防盗链结构化错误；真机本地 HTTP 页 3 张内联；**缺口：仅覆盖已知直链（`<img src>`/srcset），懒加载/动态图/整屏截图未覆盖**） | data/evals/ui_fix_gate2.md |
| Q6 | 图文混排失败占位 | **无**（全链路无 img.onerror，坏图白屏） | **有**（lw_image_guard.js 捕获阶段全局兜底 + .img-fallback 虚线占位；网页图 N 张同卡内联；真机坏图占位验证） | data/evals/ui_fix_gate2.md §③ |
| Q7 | 输出思考化 | **有**（TraceRenderer v3 + 批量折叠已达标），缺 report_only 开关 | **有**（lwSetProcessMode('full'/'report_only') + 输入区切换按钮 + localStorage；真机：report_only 无过程节点且结论在、切回恢复） | data/evals/ui_fix_gate4.md §④ |
| Q8 | 文本渐进（流式收口） | **部分**（18ms 打字机存在，但 120ms 缓冲只接咩咩面板；onStreamEnd/replaceStreamBlockHTML 整块覆盖"打完又闪"；无 TTFT 埋点） | **有**（主流接 120ms 缓冲 + onStreamEnd 先 finish 全量 flush + needsFullRender 纯文本不覆盖 + [ttft] 埋点；真机：DOM 25 采样单调递增、收口移除仅 2 光标、[ttft] 输出） | data/evals/ui_fix_gate4.md §①② |

**汇总：有 6 项（Q1/Q3/Q4/Q6/Q7/Q8）、部分 2 项（Q2/Q5）**。两项"部分"的能力边界：
- Q2：纯 SVG 内核 8 块（kpi/table/timeline/compare/bullets/highlight/para/chart），离微信版 36 模板 × 4 皮肤仍有模板量级差距；契约已冻结（docs/UI_SPEC_CONTRACT.md），扩块走"加块 + 机检用例"路径。
- Q5：网页照片依赖页面 HTML 中的已知直链；防盗链站返回结构化错误不再空白，但不会穷举懒加载占位图（data-src 等）与整屏截图替代。

Gate 链：Gate0（基线）→ Gate1（Q1）→ Gate2（Q5/Q6）→ Gate3（Q4）→ Gate4（Q3/Q8/Q7）→ Gate5（Q2）→ Gate6（总回归），
全部 PASS，报告在 data/evals/ui_fix_gate*.md，真机截图在 data/ui_smoke/gate*_*.png。

## 五、全量体检后的能力校准（★ 2026-11-06 补跑三集群 · **只追加，前四节结论一字未改**）

追加人：补跑集群（窗口1 模型/技能 + 窗口2 框架/纪律 + 窗口3 治理）。
追加理由：前四节写于"Gate 全绿"的时点；随后 12 小时内完成了 8 模型 × 6 能力真调用、
126 个注册技能逐个 invoke、四目录假链接/空实现机检、4 个 P0 修复与 30 条接线断言。
**新证据对若干定级构成下修或上调**，不追加就会留下一份偏乐观的定位文档。

### 5.1 八项前端能力最终定级（对照 §四 的原定级）

| # | 能力 | §四 原判定 | **体检后定级** | 变化依据（可复核） |
|---|---|---|---|---|
| Q1 | 图表冻结 | 有 | **有（成立）** | 6 个渲染器 6/6 调 `lwFreezeChart`（`lw_charts.js:274/373/485/600/702/780`）、0 宽兜底 6/6、重试判定含 `width===0` 2 处、PerfOpt 四守卫 4/4 |
| Q2 | 声明式画界面 | 部分 | **部分 → 下调为"内核可用、链路未接"** | `lwRenderUiSpec` 生产调用点 **0**（全仓 `grep "lwRenderUiSpec(" standard_mode/` 除自身外无命中）；195/195 契约机检全绿 + 真机 4 主题截图全过，**但业务不经过它**；`mimo_app.js:13674` 注释宣称"优先走 lwRenderUiSpec"而其函数体直接建 canvas（注释与代码不符）；活的那条是 `renderChartCard`（`mimo_app.js:20373` + 调用 `:19945`） |
| Q3 | 代码框 | 有 | **有（成立）** | `initCodeToolbars` 导出补齐（`:4557`）+ 生产调用 2 处（`:8070/:8078`）；此前"未导出导致守卫永远静默跳过"确已修好 |
| Q4 | 文件生成最后一公里 | 有 | **原判定不成立 → 本轮修复后才成立（真机仍待验）** | 体检时查明断链：`mimo_panel.py:5141/5167` 调 `EngineManager.execute_skill`，而该方法**不存在**（`in vars()=False`，118 个方法全无）→ 发卡函数 `:7266-7270` 永不执行，异常被 `except` 吞。**窗口1 已补 `execute_skill` 薄封装**（转发到带高危确认门/审计/超时的 `_invoke_tool_with_timeout`，不新开旁路），接线测试 T2.1-2.11 验证 `emit_artifact_card` 真收到 `artifact_path` 与 `kind`。未验部分：QWebEngine 端 `onFileCard` 渲染 + `mimo_app.js:19950` 的 `!card.buttons` 早退守卫 |
| Q5 | 网页照片 | 部分 | **部分（成立，缺口同 §四）** | 链路核到行号：`image_fetch.py:54` ← `web_capture.py:415` ← `mimo_panel.py:9188 with_images=True` → `:9214-9221` 透传 `data_url` → `:8717` 校验前缀后才拼 `<img>`，无另拼 URL；缺口仍是懒加载/动态图 |
| Q6 | 坏图占位 | 有 | **有（成立）** | `lw_image_guard.js:49` 为 `document.addEventListener('error', …, true)` 捕获阶段委托 → 对动态插入 img 生效（非固定容器）；去重 `:35-36` |
| Q7 | 输出思考化 | 有 | **有（语义已核清）** | `report_only` = **不创建过程节点**（`mimo_app.js:19428-19434` 早于 `:19435 switch` 建节点语句 return，无 display/visibility）；校准一处：Web 侧 switch 实为 **7 类**渲染分支（run_start/thinking/round/status/text_delta/tool_start/tool_end），事件类型 9 种（narrative/full_result 无渲染分支），Qt 白盒面板 connect 的信号是 **12 类**而非 9 类 |
| Q8 | 文本渐进 | 有 | **有（含一处实现债）** | 主链路接通（`push:12840` → `onFlush:12749` → `_flushCharQueue:12862` → `insertBefore:12879` 落 `#outputMessages` 内块）；债在 `lw_smooth.js:241-246` 每帧往**永不入 DOM 的占位 span** 追加全量文本 |

**净变化**：Q2 与 Q4 需要下修（Q4 由本轮修复重新转正，但真机端到端仍未验）；
其余 6 项经逐环取证后**判定维持**。原文"有 6 项 / 部分 2 项"在体检时点应为"有 5 / 部分 2 / 断链 1"。

### 5.2 模型分工（公平条件下的新数据）

固定 `options.num_ctx=8192`、8/8 模型实测 **PROCESSOR=100% GPU / CONTEXT=8192**（`ollama ps` 逐格回验）：

| 结论 | 数据 |
|---|---|
| 4b 仍为默认 | chat 驻留 329ms / 冷加载 5.0s；8K 中文 1.9s；content TTFT 141ms；prompt_eval_count 4267（无截断、复读 0.0） |
| 9b 不值得默认 | 冷加载 7.97s、chat 8.28s、8K 中文 12.4s ≈ 4b 的 **6.4×**；通过率结论与凌晨一致（90.9% > 86.4%） |
| **视觉走 4b，不走 qwen3-vl:4b** | qwen3.5 全系红/蓝/绿三图 **3/3 且回答随图变化**，位图数字 OCR `7391` **读对**；`qwen3-vl:4b` 则 **0/3、恒定回答同一色、OCR 正文为空** → 名为视觉模型但未接地 |
| function calling 只有 5/8 可用 | `qwen3.5` 四 tag 与 `deepseek-r1-tool-calling:8b` 产出结构化 `arguments` 对象；`qwen3:4b`、`MIEMIE.V1-test`、`qwen3-vl:4b` **tool_calls=0**（qwen3:4b 只口述"我需要用工具"） |
| 思考开关必须显式关 | qwen3.5 在允许思考时把 token 全写进 `message.thinking`、`content` 为空 → 小 `num_predict` 下**必然拿到空正文**；`qwen3-vl:4b` 甚至不接受 `think:false`（87 字符 thinking 吃满 48 token） |
| 异常降级 | 1s 超时打断 8/8 按时抛错不挂死；非法 payload 4/5 明确 HTTP 400，**静默接受 0 例**；不存在模型稳定 404 |
| 治理口径冲突（未修） | `config_manager.py:87` 的"唯一真源" `ollama.num_ctx=32768` 与本轮治理口径 8192 并存；32768 对 9b/8b **无实测数据**；`bridge/model_policy.py` 自称唯一真源但 **import 数 = 0**；`bridge_server.py:117` 兜底 `qwen2.5-coder:7b` **本机不存在** |

### 5.3 对"能力密度远超一般 Agent"这句定位的诚实修正

§一 结论 1 的原话仍然成立——这些能力**在代码里真实存在**（金融级安全、白盒可审计、自评估闭环都有行号可查）。
但体检给它加了三条必须一起说的限定：

1. **"存在"与"接线"是两件事。** 本轮量化的接线缺口：
   `lwRenderUiSpec` 生产调用 **0**、`lwbKiwi.render` **0**、`base64_full` 生产 3 处消费 **0**、
   `EngineManager.execute_skill` 缺失导致发卡链路断、`SkillMarket.unregister_skill` 无调用方、
   `set_dry_run` 无调用方（dry-run 护栏恒不可达）、`trajectory_recorder` 生产未挂载、
   Web 侧无 `trajectoryStore`/导出、`data/skill_test_report_*.json` **无人写但被 GUI 读**。
   → 这些能力在"能力密度"统计里应记为**未验证**，不能记为已具备。
2. **测试绿灯的强度低于其表面数字。** 22 个可执行单元 16 PASS 里，
   `skills_bench` 30/30 中有 **3 例是依赖不可用仍判过**（LSP "not available"、DAP "not connected"、
   test_runner "0 total | 0 passed"），`agent_bench` 的"10/10 通过"是 **mock 掉被测执行体** 的结果，
   `test_ui_fix_units` 的 U4.1-4.5 是**源码字符串锚点**而非行为断言。
   → "自评估闭环能诚实测量自身边界"这句，只在对**引擎**评测时成立（e2e 的失败归因确为实测）；
   在对**技能/接线**评测时，闭环当时是失明的。这也是本轮为什么专门补 30 条接线断言。
3. **静默失败面远大于报错面。** 全仓 `except …: pass` 实测 **1026 处 / 652 文件**（`bare except: pass` 0），
   其中 `mimo_panel.py` 114、`engine_manager.py` 89——恰好是两个 P 级缺陷（子代理终态丢失、技能发卡丢失）
   的宿主文件。**能力越多、静默点越密**，这是"能力密度领先"的另一面成本。

**校准后的定位表述建议**（供 §一 未来改版参考，本轮不改原文）：

> LemonWork 是"能力密度显著高于一般本地 Agent、且**其接线层刚开始被度量**"的桌面工作台。
> 8 项 UI 能力中 6 项经逐环取证成立、1 项内核完备但业务零调用（Q2）、1 项本轮才修复发卡链路（Q4，真机待验）；
> 模型层在公平条件（8K ctx / 全 GPU）下 4b 全面占优且**已具备真实多模态**（含 OCR），
> 而专用视觉 tag 不可用；能力密度的可信度上限，目前受"1026 处静默吞异常 + 5 个零覆盖域"约束，
> 而不是受模型能力约束。

### 5.4 本节全部证据出口

`data/audit/model_skills_audit.md`（A1-A9）、`data/audit/framework_audit.md`（B1-B9）、
`data/audit/tests_design_audit.md`（C1-C10）、`data/audit/q_discipline_report.md`（Q1-Q8）、
`data/audit/p0_fix_report.md`（P1-P7）、`data/audit/evidence_recheck.md`、
`data/audit/side_effects_manifest.md`、`data/audit/commit_groups_final.md`、
原始数据 `data/audit/model_skills_raw/`（163 文件）、`data/audit/framework_raw/`、`data/audit/tests_raw/`。
