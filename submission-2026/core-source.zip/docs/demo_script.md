# Finance Pack · Demo 脚本

> 版本：W24 · 2026-11-12
> 时长：约 8 分钟
> 环境：`_py312/python.exe`（内置 Python，无需联网）

## 0. 开场（30s）

> "今天演示的是 Lemon Work 的 Finance Pack——一套可以离线跑、结果可复现的 AI 量化研究工具包。
> 我会从数据治理，到因子研究，到模拟盘，完整跑一遍。"

## 1. 数据治理（2min）

### 1.1 多源比对

```bash
./_py312/python.exe -c "
import pandas as pd
from shared.quant.compare import compare
a = pd.DataFrame({'ts_code':['000001'],'trade_date':['20240101'],'close':[10.0],'vol':[1000],'amount':[10000]})
b = pd.DataFrame({'ts_code':['000001'],'trade_date':['20240101'],'close':[10.5],'vol':[1000],'amount':[10000]})
r = compare(a,b)
print('差异行数:', r['summary']['violations'])
"
```

**话术**："两个数据源价格差 5%，`compare` 会标出来，并保留两源原值，方便溯源。"

### 1.2 退市处理

```bash
./_py312/python.exe -c "
from shared.quant.delisted import survivorship_bias_check
import pandas as pd
uni = pd.DataFrame({'ts_code':['000001','000002']})
r = survivorship_bias_check(uni, ['000003','000004'])
print('幸存者偏差比例:', r['bias_ratio'])
"
```

**话术**："如果 universe 里只有活着的股票，回测会虚高。这个检查会告诉你缺了多少退市股。"

### 1.3 PIT（防未来函数）

```bash
./_py312/python.exe -c "
from shared.quant.pit import add_available_at, as_of_view
import pandas as pd
fin = pd.DataFrame({'ann_date':['20240420'],'end_date':['20231231'],'revenue':[100]})
fin = add_available_at(fin)
print('4月22日可见:', len(as_of_view(fin,'20240422')))
"
```

**话术**："财报按公告日入库，不是报告期。查询必须带 as_of，否则报错——这是故意防未来函数的。"

## 2. 因子研究（2min）

```bash
./_py312/python.exe -c "
import pandas as pd, numpy as np
from shared.backtest.factor_lib import compute_factor, compute_ic
dates = pd.bdate_range('2024-01-01', periods=200)
df = pd.DataFrame({'close': 10+np.random.RandomState(42).randn(200).cumsum()*0.1}, index=dates)
f = compute_factor(df, 'momentum')
fwd = df['close'].pct_change(5).shift(-5)
print(compute_ic(f, fwd))
"
```

**话术**："5 个因子，IC 和 RankIC 都算好了。RankIC 用 rank+pearson 实现，不需要 scipy。"

### walk-forward

```bash
./_py312/python.exe -c "
from shared.backtest.factor_lib import walk_forward, compute_factor
# ... 接上
wf = walk_forward(f, fwd)
print('walk-forward 步数:', len(wf))
print('第一步:', wf[0])
"
```

**话术**："walk-forward 每步只用训练期数据选方向，测试期验证。禁止未来函数。"

## 3. 成本模型（1min）

```bash
./_py312/python.exe -c "
from shared.backtest.cost import trade_cost, can_trade
print('买入成本:', trade_cost(10000,'buy',True))
print('卖出成本:', trade_cost(10000,'sell',True))
print('涨停不可买:', can_trade(10.0,11.0,'buy'))
"
```

**话术**："佣金万2.5最低5元、印花税卖出千分之一、过户费沪市、滑点、涨跌停不可成交——全部可配。"

## 4. 模拟盘（2min）

```bash
./_py312/python.exe -c "
import pandas as pd, numpy as np
from shared.quant.paper import run_paper
dates = pd.bdate_range('2024-01-01', periods=20)
prices = pd.DataFrame({'000001':10+np.random.RandomState(42).randn(20).cumsum()*0.1}, index=dates)
weights = pd.DataFrame({'000001':[0.5]*10+[0.3]*10}, index=dates)
acct = run_paper(prices, weights)
print(acct.summary())
"
```

**话术**："目标权重调仓，整百股，资金不足自动减量，涨跌停不成交。净值、回撤、成本都有。"

## 5. 工具选择 + R3 双轨（1min）

```bash
./_py312/python.exe bench/tool_selection.py
```

**话术**："不同领域包的工具选择准确率不一样，A/B 测试量化对比。R3 双轨 = 文本标准 × 权重 + 产出标准 × 权重。"

## 6. 收尾（30s）

> "这就是 Finance Pack 的完整闭环：数据可治理、因子可验证、成本可解释、回测可复现、模拟盘可演示。
> 全部测试离线跑通，断言数超过 150 条。谢谢。"

## 附：一键全量测试

```bash
./_py312/python.exe scripts/test_w24_reliability.py
./_py312/python.exe scripts/test_w24_backup.py
./_py312/python.exe scripts/test_w24_metrics.py
./_py312/python.exe scripts/test_w24_injection.py
./_py312/python.exe scripts/test_w24_factor.py
./_py312/python.exe scripts/test_w24_governance.py
./_py312/python.exe scripts/test_w24_paper.py
./_py312/python.exe scripts/test_w24_tool_selection.py
```
