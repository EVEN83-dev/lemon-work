# 桌面 ↔ 三端（微信 / 鸿蒙 / 桌面）契约台账

> 版本：D3 · 2026-11-15
> 维护纪律：契约**只增不改**——端侧按字段集消费，追加字段自动兼容；删除/改名/改语义须三端评审。
> 本文件是契约变更的销账处（微信 `desktop_requests.md` 需求单在此对齐）。

## 1. `/api/crawl/card` 响应键集

| 键 | 语义 | 引入 |
|---|---|---|
| `type` / `card_id` / `session_id` / `title` / `state` | 卡身份与状态 | A-08 |
| `overview` / `queue` / `recent` / `series` / `annotations` | 五字段契约 | A-08 |
| `tools` / `notes` | 工具条 / 备注 | A-08 |
| `event_names` / `state_names` | 事件与状态常量字典 | A-08 |
| `source` | `live` \| `db_fallback`（跨进程兜底卡显式标注） | D3-07 |
| `war` | 作战室实时数据（见 §2） | D3-09 |

**12 键语义冻结**；`source` / `war` 为追加键，端侧不消费即忽略。

## 2. `war` 键（D3-09 追加）

```
war = {
  domain_health: [{domain, p95_ms, rate_429, extract, requests, fail, circuit, fetching}],
  queue: {pending, done, failed, skipped},
  rate_429: <最差域 429 率>,
  circuit: <open|half_open|closed>,
  plan: {url, title, verdict, quality, depth, pending_total} | null,
  fetching_window_s: 20,
  log: [最近 12 条真实 crawl_page 行]   # 可选
}
```
- 来源：`shared/crawler/war_room_data.py:war_room(session_id)`（只读、session 过滤 + LIMIT）。
- 异常时**省略 `war` 键**（不用 null 冒充）。
- `stage_server /api/board` 同源（已带 war_room，无改动）。

## 3. FETCHING 口径统一（D3-09）

**声明**：桌面 `war_room.fetching`（20s 窗口）为 **真源**；微信 / 鸿蒙的「5s 新页」口径为**降级近似**，端侧下次集群切换为读 `card.war.domain_health[].fetching`。

| 端 | 当前口径 | 目标口径 |
|---|---|---|
| 桌面 | `fetching_window_s=20` 真实抓取新鲜度 | 真源（保持） |
| 微信 / 鸿蒙 | 5s 内新页计数 | 读 `war.domain_health[].fetching` |

## 4. crawl 事件族（D3-08 对齐）

| 事件 | 值 | 端 |
|---|---|---|
| session_start | `crawl.session_start` | 三端同名同值 |
| page_start | `crawl.page_start` | 三端同名同值 |
| page_done | `crawl.page_done` | 三端同名同值 |
| page_fail | `crawl.page_fail` | 三端同名同值 |
| session_done | `crawl.session_done` | 三端同名同值 |
| **control** | `crawl.control` | 微信 C3-06 扩展位；桌面 D3-08 补齐 |

`crawl.control` 载荷：`{session_id, action: "pause"|"resume", state: ST_PAUSED|ST_RUNNING}`。
桥侧只记 annotation，不改状态机。

## 5. 需求销账

| 编号 | 需求 | 状态 |
|---|---|---|
| 微信需求① | `tools/list` 注册 `crawl_*` / `backtest_run` | D3-10 销账（见 §6） |
| 微信 C3-06 | crawl 事件族六类 | D3-08 销账（diff=[]） |

## 6. `tools/list` 扫描面（D3-10）

`bridge/skills/registry.py:auto_discover` 除 `bridge/skills` 外，追加扫描 `shared/skills_builtin`：
- `_CRAWL_SPECS`（crawl_start / crawl_status / crawl_pause / crawl_resume / crawl_stop / crawl_export / crawl_watchdog / crawl_backup …）
- `_QUANT_SPECS`（backtest_run / quant_quality_check …）

幂等：重复注册 skip；`requires_confirm` 对 `crawl.stop` 等危险动作生效；拒绝 placeholder 覆盖语义不变。
