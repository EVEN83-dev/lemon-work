# 并发纪律（CONCURRENCY_RULES）

> 适用范围：`D:\lemon work\LemonWork` 多窗口/多集群并行作业。
> 生效日期：2026-11-06。制定依据：凌晨"超级收口集群 v1 + 图片界面超级修复集群"实测事故复盘。
> 本文件由补跑审计窗口（窗口3）起草，内容全部可追溯到仓库内既有证据。

## 一、四条硬规则

### R1 共享四文件单窗口独占写入

共享热区文件：

| 文件 | 当前规模 | 为什么是热区 |
|---|---|---|
| `standard_mode/ui/mimo_app.js` | 20,596 行（`wc -l` 实测） | 前端主逻辑，凌晨一轮即 +1,096 行回涨 |
| `standard_mode/ui/mimo_panel.py` | 约 9,400+ 行 | PyBridge method 分发表 + 全部后端事件出口 |
| `standard_mode/ui/mimo_style.css` | 14,147 行 | 205 条 transition / 114 个 @keyframes 全在此 |
| `standard_mode/ui/mimo_page.html` | 2,400+ 行 | script/link 挂载点，新模块必须在此注册 |

规则：

1. 同一时刻**只允许一个窗口**对这四个文件写入；其余窗口一律只读。
2. 需要动其中任何一个，先在主控处登记"文件 + 时段"，登记成功才开始写。
3. 写入窗口在每个 Stage 结束时必须显式释放（回报改动行数 + 涉及文件），主控据此放行下一个窗口。
4. 想改这四文件但拿不到写入权的窗口：**改为产出 patch 建议文档**，禁止就地编辑、禁止另建同名副本"绕过锁"。

### R2 截图与 Gate 报告必须同批落盘

门禁结论的可信度取决于"断言文本 / 结果 json / 截图字节"三者同批。规则：

1. `data/ui_smoke/gateN_*.png`、`data/ui_smoke/gateN_result.json`、`data/evals/ui_fix_gateN.md` **必须在同一次运行内写完**；三者 mtime 跨度不得超过 15 分钟。
2. 报告引用截图时，必须写截图的 **SHA256 前 16 位**，不只写文件名——否则同名覆盖无法察觉。
3. **禁止**在补拍/复现时以同名覆盖既有证据截图。复现须另存 `gateN_rerunHHMM.png`，并在报告里新增"复现批次"小节，原始断言与原始截图保持不动。
4. 若确实发生了同名覆盖（事后才发现），必须立刻在对应 Gate md 末尾追加一行补拍注记（只追加、不改写结论），并在 `data/audit/evidence_manifest.md` 登记为时序倒置。

### R3 每 Stage 结束立即同步 UI 副本

1. 每个 Stage 收尾必须跑 `scripts/sync_ui_copies.py`（必要时 `--check` 复核），并保证
   `same=56 differ=0 missing=0 extra=0` 才允许宣告该 Stage 完成。
2. 未完成同步的 Stage 不得进入下一个 Stage：`bin/_internal` 与 `dist/_internal` 的副本一旦被判定"陈旧"，
   审计者就会把副本当现役资产（本次 C1 盘点就不得不专门排除 `bin\_internal\data\ui_verify\` 的 17 个孤儿 `verify_*.py`）。
3. 新增/删除 `standard_mode/ui/` 下文件时，同步脚本的清单必须同批更新，禁止留下只更新一半的三副本状态。

### R4 未提交改动超阈值必须暂停

1. 以 `git status --porcelain | measure` 计数，**超过 50 项**时：所有写入窗口立即暂停产出新文件，通知主控做一次提交或归档分组。
2. 未提交改动**禁止跨集群累积**：凌晨遗留 391 项（实测 `git status --porcelain`：333 未跟踪 / 47 修改 / 11 删除）直接导致本轮无法区分"谁的产物"，审计窗口不得不逐个文件反查归属（见 `data/audit/commit_groups.md`）。
3. 阈值触达后的处置只有两条路：主控提交，或按 `commit_groups.md` 分组提交。**审计窗口不得代为提交。**
4. 运行时数据（`gui_worm_bridge.log`、`data/exports/**`、`data/ui_smoke/**` 截图等）一律进 `.gitignore` 评估清单，不占改动计数分子。

## 二、凌晨"902 行并行差异"事件复盘

事实链（全部可在仓库内复核）：

- `data/evals/supercluster_final.md:31`（P12）记录：JS 第二轮拆分判定为"**无安全区块、保持现状**"，
  理由是"并行窗口活跃写入 902 行差异，强拆禁忌"。
- `data/evals/supercluster_final.md:74` 再次声明同一因果："原因 = 并行窗口活跃写入（902 行未提交差异 + 2 个新文件），非能力不足"。
- `data/evals/supercluster_final.md:76` 列出共存期间的并行写入对象：`mimo_app.js` / `mimo_page.html` / `lw_charts.js` / `mimo_panel.py` + 2 个新 ui 文件。
- 同期遗留：`data/evals/supercluster_final.md:77` 自述"主控未 commit/push/改版本号"，即这 902 行**从未进入版本控制**。

直接后果：

1. **既定重构目标被外部并发因素否决**。P12 的"mimo_app.js 继续瘦身"没有失败在技术上，而是失败在写入权未编排；
   结果 `mimo_app.js` 从 `c9b431e` 记录的 19,500 行回涨到今天的 20,596 行（+1,096 行）。
2. **同一批四文件被两个窗口同时改，任何一次 `git checkout`/`stash` 都可能吞掉对方成果**——这正是本集群"禁止 git 写操作"的原因。
3. **证据时序被打破**。R2 缺失的直接体现：`data/ui_smoke/` 内 **21 张**截图 mtime 落在 2026-11-06 10:54:41–10:55:25，
   而引用它们的 `gate1-5_result.json` 写于 02:25–03:25、`ui_fix_gate1/4/5.md` 写于 02:28–03:27。
   凌晨断言时刻的截图字节已被上午同名重跑覆盖，PNG 无法为凌晨结论提供字节级证据
   （逐文件 SHA256 与时序差见 `data/audit/evidence_manifest.md`，取证脚本 `scripts/audit_tests/c7_evidence_manifest.py`）。

## 三、改进项（可执行，按优先级）

| # | 改进项 | 落点 | 验收口径 |
|---|---|---|---|
| I1 | 共享四文件写入权登记：开工前登记、收工后释放 | 主控会话 + 本文件 R1 | 任意时刻只有一个窗口持有同一文件 |
| I2 | 拆 `mimo_app.js` 时改用 **worktree/分支** 而非同目录并行 | 新窗口作业方式 | 拆分窗口不再以"并行差异"为由否决重构 |
| I3 | Gate 报告生成时内嵌截图 SHA256 与批次号 | `scripts/ui_smoke_gates.py` 的报告写出段（**由具备 R1 权限的窗口实施**） | 新报告每条截图断言带 hash |
| I4 | 复现/补拍一律新文件名，禁止同名覆盖 | 本文件 R2 第 3 条 | `evidence_manifest.json` 中 `INVERSION` 数为 0 |
| I5 | Stage 收尾把 `sync_ui_copies.py --check` 设为门禁 | 各集群 Stage 定义 | `differ=0 missing=0 extra=0` 才计完成 |
| I6 | 未提交改动计数器进主控看板 | 主控 | 达 50 项触发暂停与分组提交 |
| I7 | 清理 `bin/_internal` 内孤儿资产（17 个 `verify_*.py`、指向不存在 `tests/` 的 `pytest.ini`） | `scripts/sync_ui_copies.py` 加 prune（**由 R1 窗口实施**） | 审计无需再排除副本 |

## 四、审计窗口的自约束

补跑审计窗口（窗口1/2/3）在本规则下的定位：

- 对四个共享热区文件**永久只读**；只写各自的 `scripts/audit_*/**` 与 `data/audit/**`。
- 唯一授权的产品目录写入：`data/evals/ui_fix_gate1.md` / `gate4.md` / `gate5.md` 末尾各追加一行截图补拍注记（R2 第 4 条要求的补救动作，追加而非改写）。
- 不 commit、不 push、不改版本号、不删文件、不调用 Ollama（窗口2/3）、不重跑取最好一次、不把 SKIP 写成 PASS。
