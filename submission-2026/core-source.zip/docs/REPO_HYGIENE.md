# REPO_HYGIENE · 仓库卫生报告

> 版本：V1.6-WPD  
> 日期：2026-11-05  
> 目标：梳理未跟踪/被忽略文件，明确同步方式与归档策略

---

## 一、文件状态总览

### 1.1 运行时需要、禁止删除

| 文件 | 状态 | 说明 |
|------|------|------|
| `standard_mode/ui/browser_drawer.py` | 未跟踪 | **运行时需要**，禁止删除/移动。建议纳入版本控制（本轮不 commit，交给主控） |

### 1.2 历史备份（已归档）

| 文件 | 归档位置 | 说明 |
|------|----------|------|
| `mimo_app.js.bak_lemonB` | `archive/` | lemonB 窗口备份，已移入 archive/ |
| `mimo_page.html.bak_lemonB` | `archive/` | 同上 |
| `mimo_style.css.bak_lemonB` | `archive/` | 同上 |

### 1.3 被 .gitignore 忽略的副本

| 路径 | 说明 |
|------|------|
| `bin/_internal/` | 运行时副本，由 `scripts/sync_ui_copies.py` 同步 |
| `dist/_internal/` | 同上 |

**正确同步方式**：
```bash
python scripts/sync_ui_copies.py --check   # 检查差异
python scripts/sync_ui_copies.py            # 执行同步
python scripts/sync_ui_copies.py --check   # 确认零差异
```

### 1.4 仓外文件（不受 git 管理）

| 文件 | 说明 |
|------|------|
| 4 个启动 `.bat` | 在仓外，已挂 `sync_ui_copies.py` 调用 |

---

## 二、未跟踪文件清单（建议处理）

| 文件 | 建议 |
|------|------|
| `standard_mode/ui/browser_drawer.py` | 纳入版本控制（本轮不 commit，交给主控） |
| `standard_mode/ui/lw_charts.js` | 纳入版本控制（本轮新增） |
| `standard_mode/ui/lw_face.js` / `lw_face.css` / `lw_tokens.css` | 纳入版本控制（之前窗口新增） |
| `standard_mode/ui/lw_taskcard.js` | 纳入版本控制（G3 窗口新增） |
| `docs/MODULE_BOUNDARIES.md` | 纳入版本控制（本轮新增） |
| `docs/REPO_HYGIENE.md` | 纳入版本控制（本轮新增） |
| `docs/AUTOLOOP.md` | 纳入版本控制（autoloop 窗口新增） |
| `data/autoloop/**` | 纳入版本控制（autoloop 窗口新增） |
| `bridge/autoloop/**` | 纳入版本控制（autoloop 窗口新增） |
| `scripts/test_autoloop.py` | 纳入版本控制（autoloop 窗口新增） |
| `archive/**` | **已忽略**（.gitignore 新增 `archive/` 规则） |

---

## 三、.gitignore 变更

```
archive/
```

仅追加一行，不影响现有规则。

---

## 四、风险提示

1. **browser_drawer.py 未跟踪**：若误删会导致浏览器抽屉功能失效，建议尽快 commit
2. **副本同步**：`bin/_internal` 与 `dist/_internal` 由脚本同步，**禁止手动编辑副本**
3. **版本串一致性**：`mimo_page.html` 中 `?v=6.5-20261105` 必须与 `bin/_internal`、`dist/_internal` 一致
4. **节日主题色**：CSS 令牌化避开节日专用色（圣诞红/Monokai 高亮等），替换时需持续维护黑名单

---

## 五、维护建议

| 频率 | 操作 |
|------|------|
| 每次发布前 | 跑 `sync_ui_copies.py --check` 确认零差异 |
| 每次窗口交付后 | 检查新增文件是否纳入版本控制 |
| 每月 | 清理 `archive/` 中超过 90 天的备份 |
| 每次 CSS 令牌化 | 更新节日/专用色黑名单 |

---

> 本报告仅记录现状与建议，不执行任何破坏性操作。

---

## 六、运行时产物目录（★ ui-fix-cluster Q4 追加，2026-11-06）

- `data/exports/`：技能产物统一落盘目录（office_generator / image_poster /
  math_plotter 默认输出）。**运行时目录，不入库**（等同 data/charts 处理口径）。
- 旧路径兼容：显式传 `output_path` 的调用方不受影响；`_DEFAULT_CHARTS_DIR` /
  `_DEFAULT_POSTER_DIR` 常量保留仍可引用（仅默认值改走 exports）。
- 技能产物卡：技能在 `SkillResult.data['artifact_path']` 带产物路径，
  `mimo_panel._emit_artifact_from_skill_result` 统一检测后经
  `emit_artifact_card(path, kind)` 发卡（打开/保存/预览/导出）。

---

## 三、超级收口集群 v1 增补（Wave D，2026-11-06）

### 3.1 待主控提交清单（本集群产出 + 遗留补齐）

| 文件 | 状态 | 处置 |
|------|------|------|
| `standard_mode/ui/browser_drawer.py` | 未跟踪 | **运行时必需**（scripts/test_browser_drawer.py:45 `from ui.browser_drawer import BrowserDrawer`，drawer 测试 12 项依赖）→ **主控提交** |
| `bridge/eval/real_e2e_bench.py` | 本集群改动（--num-predict + unknown 治理） | 主控提交 |
| `bridge/eval/failure_attribution.py` | 本集群改动（待人工复核兜底） | 主控提交 |
| `bridge/eval/test_num_predict.py` | 本集群新建 | 主控提交 |
| `bridge/model_policy.py` | 本集群改动（PREFERRED_MODEL=4b 对齐） | 主控提交 |
| `scripts/ui_smoke_qwebengine.py` | 本集群新建 | 主控提交 |
| `scripts/c5_tokenize_hex.py` | 本集群新建 | 主控提交 |
| `standard_mode/ui/lw_bank_card.js` / `lw_kiwi_card.js` | 本集群新建 | 主控提交 |
| `standard_mode/ui/mimo_page.html` / `mimo_style.css` / `lw_tokens.css` | 本集群改动（含并行窗口 Q1/Q2 改动共存） | 主控提交（注意与并行窗口合流） |
| `standard_mode/ui/lw_canvas_freeze.js` / `lw_ui_render.js` | **并行窗口新建（未跟踪）** | 非本集群产出，主控收口时随 Q1/Q2 一并决定 |
| `docs/AUTOLOOP.md` / `docs/MODULE_BOUNDARIES.md` / `docs/REPO_HYGIENE.md` / `docs/CAPABILITY_POSITION_V2.md` | 本集群改动/新建 | 主控提交 |
| `data/evals/supercluster_*.md`、`model_rematch_20261106.md`、`Modelfile.*`、`model_switch_decision.md` | 本集群新建报告 | 主控提交（评估证据链） |
| `data/autoloop/supercluster_gateB.md`、`j_archive_20261105/` | 本集群新建 | 主控提交 |
| `data/ui_smoke/*.png`、`supercluster_gateC.md` | 本集群截图证据 | 主控提交 |
| 版本号 | — | **保持 v6.5-20261105 不变**（本集群未 bump） |

### 3.2 三个 .bak 归档状态复核 ✅

- `archive/mimo_app.js.bak_lemonB`、`archive/mimo_page.html.bak_lemonB`、`archive/mimo_style.css.bak_lemonB`：三份均在 archive/（已被 .gitignore 忽略）→ **无需提交，维持归档**。
- 另发现 `shared/engine_manager.py.bak_before_restore` 与 `bin/_internal/shared/engine_manager.py.bak_before_restore`：非本集群产物（并行窗口遗留），维持现状，主控收口时决定。

### 3.3 data/evals 下 20261104 系列历史未跟踪报告处置建议

未跟踪清单（git status 实测）：
```
data/evals/e2e_report_20261104_210350.{json,md}
data/evals/e2e_report_20261104_210649.{json,md}
data/evals/e2e_report_20261104_214232.md
data/evals/e2e_report_20261104_214425.md
data/evals/e2e_report_20261104_214612.md
data/evals/full_A_std.txt / full_B_hard.txt / full_C_tool.txt / full_D_skills.txt
```
**建议**：全部保留在仓内并纳入版本控制（它们是 v1→v3 评分标准迭代与 hard 题入库的实证链，CASES_MAINTENANCE.md 引用）；若主控希望收敛目录，可移动至 `data/evals/archive/20261104/` 后提交，**禁止删除**（运行时数据/评估证据）。

### 3.4 并行改动标识（D2 · 非本集群范围，主控收口时排除）

以下文件在主控开工前已存在未提交改动，或在本集群执行期间被并行窗口写入；本集群**未修改**其中任何文件：

| 文件 | 证据 |
|------|------|
| `shared/engine_manager.py` | git status M（开工前已存在） |
| `shared/core/task_classifier.py` | git status M（开工前已存在） |
| `shared/skills_builtin/ui_cards_skill.py` | git status M（开工前已存在） |
| `shared/skills_builtin/web_skills.py` | git status M（开工前已存在） |
| `shared/web_capture.py` | git status M（开工前已存在） |
| `standard_mode/core/skills/browser_automation.py` | git status M（开工前已存在） |
| `standard_mode/ui/mimo_app.js` | 02:40:13 被外部写入（本集群零改动，实测 mtime） |
| `standard_mode/ui/lw_charts.js` | git diff 43 行（并行窗口） |
| `standard_mode/ui/mimo_panel.py` | git diff 88 行（并行窗口） |
| `standard_mode/ui/lw_canvas_freeze.js`（新）+ mimo_page.html +2 行 | 并行窗口 Q1 |
| `standard_mode/ui/lw_ui_render.js`（新，265 行） | 并行窗口 Q2 |
| `scripts/gui_patrol_test.py` / `scripts/gui_whitebox_test.py` | git status M（并行窗口） |

**本集群写入范围（白名单自查）**：bridge/eval/**、bridge/model_policy.py、bridge/autoloop/**（仅新增报告/归档）、scripts/test_autoloop.py（未改）、scripts/ui_smoke_qwebengine.py（新）、scripts/c5_tokenize_hex.py（新）、standard_mode/ui/{mimo_page.html, mimo_style.css, lw_tokens.css, lw_bank_card.js, lw_kiwi_card.js}、docs/{AUTOLOOP, MODULE_BOUNDARIES, REPO_HYGIENE, CAPABILITY_POSITION_V2}.md、data/evals/**（报告）、data/autoloop/**、data/ui_smoke/**、data/mock_bank 等运行时数据零写入。shared/** 零写入 ✅。

---

## 四、Gate D 判定（超级收口集群 Wave D · 2026-11-06）

| 项 | 结果 | 证据 |
|---|---|---|
| D1 版本控制补齐（browser_drawer.py 运行时必需确认 + 待主控提交清单 + .bak 复核 + 20261104 报告处置建议） | ✅ | 本文 §3.1-3.3 |
| D2 并行改动标识（12 项并行文件清单 + 本集群白名单自查，shared/** 零写入） | ✅ | 本文 §3.4 |
| D3 能力定位 v2（三实证结论 + 三必要条件全未满足，每条挂路径） | ✅ | docs/CAPABILITY_POSITION_V2.md |
| 14 项逐项处置表 | ✅ | data/evals/supercluster_final.md（Stage 5 S5-4 产出） |

**Gate D = PASS。**（REPO_HYGIENE.md 写后半（本节起），与 Wave C 写前半（MODULE_BOUNDARIES.md）分文件，无同文件并发写。）
