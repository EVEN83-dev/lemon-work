# MODULE_BOUNDARIES · 模块边界分析（第二轮拆分）

> 版本：V1.6-WPD  
> 日期：2026-11-05  
> 目标：扫描 mimo_app.js 顶层函数与内联引用，标出可安全外迁的区块

---

## 一、分析方法

1. **顶层函数提取**：正则匹配 `^function\s+([a-zA-Z_$][a-zA-Z0-9_$]*)\s*\(`，共 658 个顶层函数
2. **函数体范围**：从函数声明行到下一个顶层函数声明行
3. **交叉引用分析**：检查每个函数体内是否引用其它顶层函数名
4. **HTML 内联检查**：grep `mimo_page.html` 中是否以 `onclick/oninput` 调用该函数
5. **全局依赖检查**：检查函数体内引用的全局对象（document/window/Math 等）

---

## 二、分析结果

### 2.1 零引用函数统计

- 顶层函数总数：658
- 零交叉引用函数：188（占 28.6%）
- 其中零 HTML 内联调用：188（全部）

### 2.2 候选区块（按行数排序）

| 函数 | 行数 | 行号 | 内部引用 | 全局依赖 | 安全度 |
|------|------|------|----------|----------|--------|
| renderSimpleGraph | 267 | L13619-13885 | 无 | document/Math | ⭐⭐⭐ 高 |
| renderScatterPlot | 111 | L14089-14199 | 无 | document/Math | ⭐⭐⭐ 高 |
| renderLineChart | 108 | L13981-14088 | 无 | document/Math | ⭐⭐⭐ 高 |
| renderPieChart | 98 | L14200-14297 | 无 | document/Math | ⭐⭐⭐ 高 |
| renderBarChart | 95 | L13886-13980 | 无 | document/Math | ⭐⭐⭐ 高 |
| render3DSurface | 74 | L14298-14370 | 无 | document/Math | ⭐⭐⭐ 高 |
| renderUiSketch | 79 | L13202-13279 | 无 | document/Math | ⭐⭐⭐ 高 |
| cleanupEventListeners | 58 | L1945-2001 | 无 | — | ⭐⭐⭐ 高 |
| _computeDiff | 57 | L8887-8942 | 无 | — | ⭐⭐⭐ 高 |
| initTopbarExtras | 56 | L17711-17765 | 无 | — | ⭐⭐⭐ 高 |

### 2.3 风险区块（强拆有闭包风险）

| 区块 | 行号 | 风险原因 |
|------|------|----------|
| TraceRenderer / 白盒化 | L13000-19360 | 内部互相引用密集（consume/render/flush 等），依赖 IIFE 私有状态 |
| 图表分发 `_renderChartByType` | L13172-13200 | 调用 6 个图表函数，但本身依赖 `detection` 结构，不宜单独外迁 |
| 任务卡/排队/子代理 | 已迁至 lw_taskcard.js | G3 已完成，函数全在新文件、旧文件无残留 |

---

## 三、本轮迁移决策

### 3.1 迁移区块：6 个图表渲染函数

**迁移理由**：
1. ✅ 零交叉引用：6 个函数之间互不调用，与 mimo_app.js 其它函数无引用
2. ✅ 零 HTML 内联调用：mimo_page.html 中无 `onclick="renderSimpleGraph(...)"` 等
3. ✅ 仅依赖全局对象：`document`、`Math`（标准 API，无闭包私有状态）
4. ✅ 调用点唯一：仅在 `_renderChartByType`（L13179-13189）中被调用，该函数留在 mimo_app.js
5. ✅ 行数适中：760 行，自包含且语义完整

**迁移清单**：
- `renderSimpleGraph`（L13619-13885，267 行）
- `renderBarChart`（L13886-13980，95 行）
- `renderLineChart`（L13981-14088，108 行）
- `renderScatterPlot`（L14089-14199，111 行）
- `renderPieChart`（L14200-14297，98 行）
- `render3DSurface`（L14298-14370，74 行）

### 3.2 迁移后效果

| 指标 | 迁移前 | 迁移后 | 变化 |
|------|--------|--------|------|
| mimo_app.js 行数 | 20251 | 19500 | -751 行 |
| lw_charts.js 行数 | — | 760 | 新增 |
| 顶层函数总数 | 658 | 652 | -6 |

### 3.3 加载顺序

```html
<script src="mimo_app.js?v=6.5-20261105"></script>
<script src="lw_charts.js?v=6.5-20261105"></script>   <!-- 新增 -->
<script src="lw_taskcard.js?v=6.5-20261105"></script>
```

**安全性**：`lw_charts.js` 在 `mimo_app.js` 之后加载，`_renderChartByType` 调用时函数已定义。

---

## 四、未迁移区块说明

### 4.1 renderUiSketch（79 行，L13202-13279）

- 零交叉引用，但**语义上与 `_renderChartByType` 同属图表渲染域**
- 本轮不迁：保持 mimo_app.js 内图表逻辑的完整性，避免分散到两个文件
- 下一轮可考虑与 `_renderChartByType` 一起迁入 `lw_charts.js`

### 4.2 cleanupEventListeners / _computeDiff / initTopbarExtras

- 零交叉引用，但**行数较少（56-58 行）**，迁移收益有限
- 本轮不迁：优先迁移大块（760 行图表群），小块留待后续

### 4.3 TraceRenderer 区块（L13000-19360）

- **强拆风险极高**：内部 `consume/render/flush/scrollToBottom` 等互相引用密集，且依赖 IIFE 私有状态
- **本轮不迁**：按任务要求"禁止强拆导致运行崩溃"

---

## 五、结论

✅ **本轮安全迁移 1 个自包含区块**（6 个图表函数，760 行）到 `lw_charts.js`。  
✅ **mimo_app.js 从 20251 行降至 19500 行**（-751 行，-3.7%）。  
✅ **node --check 两个 JS 文件均通过**。  
✅ **HTML 内联调用零风险**（6 个函数无内联调用）。  
✅ **全局函数 typeof 抽查 ≥8 个**（见验收输出）。

> 下一步：可继续分析 `renderUiSketch` + `_renderChartByType` 的组合迁移，或处理 `cleanupEventListeners` 等小块。

---

## 六、第二轮拆分评估（超级收口集群 C5，2026-11-06）

> 背景：P12 要求第二轮令牌化 + 评估是否存在第 2 个零闭包依赖区块可迁出（≤1 个）。

### 6.1 CSS 令牌第二轮（已完成）

- scripts/c5_tokenize_hex.py 严格值保持替换：mimo_style.css 裸 hex M1 口径 802 → 599（降 203 处 ≥ 150 目标）
- 27 个新 :root 令牌入 lw_tokens.css（幂等块）；12 套节日主题区（L41-742/L940-1100）与 var() fallback 一律不碰
- 详见 data/ui_smoke/supercluster_gateC.md C5 节

### 6.2 mimo_app.js 第二区块迁移评估：**无安全区块，保持现状**

本时点（2026-11-06 03:20）mimo_app.js = 19500 行，**本轮决定不迁出任何区块**，依据如下：

| 候选区块 | 位置/规模 | 评估 | 结论 |
|---|---|---|---|
| renderUiSketch | L13202-13279（79 行） | 零交叉引用、可迁，但**语义属图表域**且首轮已记录"与 _renderChartByType 同迁"的方案；此外本文件正被并行窗口活跃修改 | 缓迁 |
| ActionCard 动态操作卡 IIFE（renderWebPageCard/startLivePoll/onActionCard） | L18957-19499（≈543 行） | 自包含度较高（window.onActionCard 单入口、fetch 直连），但引用 mimo_app.js 内部辅助（消息追加/卡片注册表），且**该文件正被并行窗口改动（工作树 902 行未提交差异、新增 lw_ui_render.js Q2 内核）**——在活跃并行改动下迁移必然冲突 | 缓迁 |
| TraceRenderer 区块 | L13000-19360 | 强闭包依赖（consume/render/flush 互引 + IIFE 私有状态），首轮已判定强拆风险极高 | 不迁 |
| cleanupEventListeners / _computeDiff / initTopbarExtras | 各 56-58 行 | 迁移收益低于风险 | 不迁 |

**冲突证据（主控实测）**：本集群执行期间 mimo_app.js 于 02:40:13 被外部进程写入（本集群未改过该文件），standard_mode/ui/ 出现未跟踪新文件 lw_ui_render.js（265 行，ui-fix-cluster Q2）与 mimo_page.html 的 +2 行（lw_canvas_freeze.js Q1 引用）。**在有并行写入者共存的工作树上执行结构性拆分会互相覆盖，属"强拆"禁忌的现实形态。**

**保持现状 ≠ 放弃**：第二轮的价值落在 CSS 令牌化（-203 裸 hex）；JS 拆分第三轮建议在并行窗口合流（工作树回到干净或改动全部入库）后，按首轮"图表函数群"模式迁出 ActionCard IIFE（单一 window.onActionCard 入口使它成为次安全候选）。
