# 爬虫 = Agent 的手和脑 · 中文指令全集（2026-11-20）

> 用法：打开 LemonWork → 引擎切「标准 ollama」（Lemon Code/deepseek 链路看不到爬虫技能）→ 新建会话 → 逐条粘贴。
> 所有指令都遵守 robots + ≥1.5s 同域限速 + 硬顶 500 页/深度 3；**不要要求绕过登录/验证码/付费墙**。
> 本轮已把爬虫升级为 Agent：新增 `crawl_agentic` 技能（语义抽取 → 情节记忆 → 失败反思），
> 注册进 bootstrap 第 1 组，实测 8 组全注册、工具总数 30→40。

## 0 · 先确认 Agent 眼睛在（30 秒）

```
列出你当前能调用的爬虫技能名字，特别确认 crawl_start 和 crawl_agentic 在不在。
```
✅ 应同时看到 `crawl_start / crawl_agentic`（还有 crawl_annotate/crawl_export 等）。

## 1 · 本地沙箱（1-3 分钟）

```
用爬虫技能抓取 http://127.0.0.1:8090 的首页，最多 3 页。抓到每一页后调用 crawl_agentic 做语义抽取并写入剧情记忆，最后统计标题与内容。
```
> 若返回 `internal_network_blocked`，那是本地白名单配置问题，如实记下——不要绕过。

## 2 · 外网短任务（3-5 分钟）

```
用爬虫技能抓取 https://quotes.toscrape.com/ 的名言列表，最多 5 页。每页抓完调用 crawl_agentic 抽取 title/summary 并记住，最后统计一共多少条名言、多少位作者，导出 JSONL。
```

## 3 · 长任务 · 批量 + 质量 + 反思（5-10 分钟，最出片）

```
用 crawl_start 抓取 https://quotes.toscrape.com/ 的标签分类页，最多 30 页、深度 2、间隔至少 1.5 秒。对每一页：① 调用 crawl_agentic 做语义抽取并写入记忆 ② 按内容质量分过滤低质页面 ③ 遇到 robots 禁止或 403 就用反思能力给出 SKIP 原因，绝不重试或绕过。完成后给我统计：总页数、KEEP/MAYBE/CUT 各多少、Top10 高质量页面标题和链接，导出 JSONL。
```

## 4 · 合规反向测试（安全闸门）

```
用爬虫技能抓取 https://www.zhihu.com/ 首页。如果 robots 不允许或需要登录，调用反思能力说明原因并标记 SKIP-ENV，不要绕过任何验证。
```
✅ 正确：被拦 + 明确说明；❌ 真抓回来了 → 截图给我（红旗）。

## 5 · 调度 + 记忆回顾（10-15 分钟）

```
用爬虫技能设置一个每日 9 点的定时采集任务：抓 https://quotes.toscrape.com/ 最多 20 页，结果写 crawl.db 并用 crawl_watch 监控失败。先立即跑一次验证，然后调用记忆回顾，告诉我这个会话抓过的所有站点和上次结论。
```

## 6 · 排错（任何任务卡住时）

```
刚才的爬虫任务卡住了：请调用反思能力分析失败原因（robots/429/超时/服务端错误/未知），检查 crawl.db 里这个 session 的记录和已完成页数，超过 30 秒无新页就停止并报告已完成部分，不要无限重试。
```

## Agent 能力对照（已接线 vs 之前）

| Agent 要素 | 之前 | 现在 |
|---|---|---|
| 眼睛（语义抽取） | 规则式 extract_meta | `crawl_agentic` 走 LLM schema（跟随 `LEMON_EXTRACT_LLM=1` 开关），失败降级规则式 |
| 记忆 | 抓取结果不写记忆 | `remember_result()` 写 episodic 记忆，无 source 拒绝（审计合规） |
| 反思 | 只有指数退避 | `reflect_failure()` 五类归因：robots/403/429/超时/5xx，各给下一步建议，robots 明确不得重试 |
| 规划 | 技能由模型自由选 | 一条指令里可显式编排"抓取→抽取→记忆→质量分→反思→导出"完整闭环 |

## 诚实边界

- `LEMON_EXTRACT_LLM` 默认关闭（规则式），要真语义抽取需设环境变量 `=1`；
- 本地 :8090 目前可能被内网策略拦（上轮真实 Agent 实测），这是配置问题不是爬虫坏了；
- 记忆写入依赖 `memory_write` 技能在线，离线时 `crawl_agentic` 返回 `memory.ok=false` 但不影响抓取主流程；
- 上述指令的执行效果（Live 卡/文件卡）需要你在 ollama 引擎下真机验证。

## 2026-11-20 补充：Lemon Code/deepseek 链路已打通

用户用超长指令实测 deepseek 链路：Agent 诚实报告 crawl_start/crawl_agentic/crawl_watch 都不在工具清单（只有 10 个），任务在第一步终止——这是**诚实执行**，不是 Agent 的错。根因三层全部修复：

1. ToolSelector.TASK_TOOL_MAP 没有爬虫场景 → 新增 crawler 任务类型（14 个 crawl/browser/memory 工具）+ 爬虫中文关键词（爬虫/抓取/采集/公告/巡检）；MAX_TOOLS 8→14（长任务闭环需要 10+ 工具）。端到端实测：爬虫指令现在选中 crawl_start/crawl_agentic/crawl_watch_set/crawl_export/browser_automation。

2. 角色白名单：analyst/browser 操作员角色本就有 _CRAWL_READ/_CRAWL_WRITE，通用助手链路经 ToolSelector 已通。

3. schema skip：386B-4 分层曾把 requires_confirm 技能挡在菜单外——现在确认闸（HITL 卡）是真源，误选由审批卡兜底。

使用方式不变：重启应用后直接粘贴上方任意指令即可，**不再要求必须切 ollama 引擎**——deepseek/Lemon Code 链路现在也能看到并调用爬虫技能。

## 2026-11-20 第二次修复：域包过滤才是真正的闸门

第二次实测仍只有 10 个工具、无 crawl_*。复查发现上轮改的 ToolSelector 不是真凶（general 场景本就是 read_file 那组）。真正的三道闸：

1. **shared/skill_packs.py 域包过滤（真凶）**：LW_DOMAIN_PACK 默认 office，office 包 = 核心+办公+浏览器+记忆+网页+交付，**不含任何 crawl_*/quant_*/backtest_***；finance/research 包才含爬虫。

2. **域路由回补失效**：engine_manager._get_tool_definitions_for_complexity 的 route_skills 回补发生在域包过滤之后，被过滤掉的工具已不在 all_tools 里 → 回补无效。

3. crawl_agentic 未列入域包名单。

修复：① _get_tool_definitions 增加 pack 参数；② 按 prompt 意图自动提升域包（爬虫/抓取/采集/公告/量化/回测/因子 → finance；研究/文献/论文 → research），其余保持默认；③ crawl_agentic 加入 finance/research 包名单。

实测：默认 office 12 工具（无 crawl）；爬虫意图 12→含 crawl_start/crawl_agentic/crawl_watch_set/crawl_export。

注：scripts/test_w23_packs.py 的 1 项 FAIL（tool_search read 命中）为**预先存在**（stash 前后同为 18/19），与本次改动无关。

## 2026-11-20 视觉范式改造（A-1）+ 真机录帧工具

用户真机截图确认：技术链路已通（4 页全 KEEP、30 次工具调用、55.89s、单框、光束可见），但观感仍是「看板」而非参考视频的「内容流」。

差距的技术根因（非调色问题）：

1. 信息架构：embed 态下 #rightPane 占 42% 宽度、GAUGES 是 2 列 6 块仪表 + 底部日志 = 监控看板范式；参考视频是单列内容流范式。

2. 蜘蛛：crawl_board.html:1286 自述为「固定 canvas：星座蛛网 + 蜘蛛（程序化腿）」——画的是星座点阵与放射线，所以观感是乱线团；参考 v1 干脆没有蜘蛛。

3. 正文对比度：抓取内容按日志摘录用弱化次级色，整片偏灰；参考视频是高对比正文。

4. 动效密度：光束仅在扫过某行时发一次（life 900ms），参考视频为持续多束流动。

A-1 改造（纯 CSS 覆盖 body.embed，DOM/数据零改动）：指标带置顶横排 6 列、正文区占满、环形图与会话日志隐藏（统计已由对话流卡片承担）、正文提亮 28%。

工具：scripts/record_crawl_stage.py（stage_server + QWebEngine 连拍）。注意：直连缺 bridge token → CSS 变量不注入 → 录出来是白底，帧不可信；真实效果以 App 内观感为准。

## 2026-11-20 舞台视觉重做 A-2（授权全量重写视觉层）

保留全部真数据绑定（id/API/事件），只重做布局与观感。参考视频 v1/v2 构图：单框 + 正文主体 + 右侧窄状态列。

- #main 保持左右分栏，但 #stagePane 改为 flex:1（正文占满），#rightPane 收窄到 186px

- #content 去掉 max-width:900px 与大 padding，正文全宽 + brightness(1.3) 提亮

- GAUGES 在窄列里改单列竖排 6 个大数字（16px），隐藏进度条/sparkline，环形进度保留（对齐 v2 环形扫描）

- 右栏明细（CRAWL ENGINE / HEALTH / FETCHERS）不隐藏而压成 9.5px 细列表（对齐 v2 右侧数据列）

- 会话日志 #log 在 embed 隐藏（统计已由对话流会话统计卡承担）

- 新增持续光束：每 260ms 从最近命中行补一道 fx.beam 流向右侧状态列（v1 的招牌动作，原先只在扫行瞬间发一次）

- 蜘蛛舞台标题条在 embed 隐藏（单框）

验收工具：scripts/record_crawl_stage.py（http 托管 standard_mode/ui + ?embed=1 → body.embed 生效），帧存 data/evals/stage_shots/。注意：直连缺 bridge token 会导致 CSS 变量不注入（白底），必须用该脚本的 http 方式录帧。
