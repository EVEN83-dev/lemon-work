# 剩余工作总账 · 2026-11-11 全量执行后

> 本文件记录"本轮已做完什么"与"仍剩什么"，供收口与下一轮排期使用。
> 原则：能机检的都机检，不能执行的如实标注，不把 SKIP 写成 PASS。

## 一、本轮（全量执行）已完成

| 项 | 结果 | 证据 |
|---|---|---|
| 1140 项未提交工作区 | 分两批落袋：`4ca893a`（690 代码文件）、`cda58fd`（430 报告/文档） | `git log` |
| 4 个历史 P0 | 全部已修（BOM 清零、`_elapsed` 消失、`execute_skill` 已补、`main_standard` AST 正常） | 本轮字节级复核 |
| 主链路接线 | `LEMON_EXTRACT_LLM` 开关、`LEMON_TOOL_COMPRESS` 可选压缩（默认关）、`backtest_run` 带 `lookahead` 双检、`factor_eval` 评估字段、`investment_review` 注册为 bootstrap 第 8 组 | `scripts/test_upgrade_20261111.py` |
| 新模块 | `quant_loop.py`（研究闭环：假设→前视检查→IC 评估→keep/reject→日志）、`review.py`（投资复盘 + 技能）、`quant_live_smoke.py`（真源 provenance） | 模块自测 ALL_PASS |
| 算法 bug 修复 | `icir()` 对完全恒定 IC 序列返回 0 的误判（完美因子被当不稳定）→ 改饱和值 ±10 | `factor_eval.py` |
| 真机冒烟 | LLM schema 抽取：qwen3.5:4b-ctx8k，13.49s，正确抽出公司/产品/价格，`source=llm` | `data/evals/llm_extract_smoke.json` |
| LW-Bench 完整复跑 | `--agent oracle --all --repeat 2 --resume`：101 条运行记录、8 维度 10/10；**这是框架/评分器上限验证，不是能力分** | `data/evals/lwbench_oracle_full.md`、`bench/runs_full/` |
| 真实能力分口径 | 原 55 运行报告完好恢复（SR 18.2%、加权 14.29%） | `data/evals/lwbench_report.md` |
| 真源状态 | `TUSHARE_TOKEN` 未设、tushare/akshare 未装 → 明确 `SKIP`，provenance=synthetic，不得把合成数据结论当真实市场结论 | `data/evals/quant_live_smoke.json` |
| pytest 遗留 | `test_plugin_loading` 补 `plugins/hello_world/plugin.py` 真修；`test_terminal_arch` 3 个过时架构断言显式 skip（保留断言体） | 见下 |
| 比赛材料 | 报名帖正文、5 分钟演示脚本、TRAE 留痕清单、提交检查表、答辩诚实边界 | `docs/TRAE_SUBMISSION.md` |
| **自动模拟人类操作巡航** | `scripts/auto_human_patrol.py` 复用 QWebEngine 真机框架，用真实 DOM 事件完成 11 场景（启动/打字/任务卡展开收起/刷新保持/tab/排队条/子代理/图表/代码框/查看全量/打开真实数据），**11/11 ALL_PASS**，7 张截图非空白判定（colors/var/bytes）全过 | `data/ui_smoke/patrol_report.json` / `.md` / `patrol_*.png` |
| **巡航抓出的真实缺陷（已修）** | `lwFetchFullText` 在 Python bridge 存在但回调不触发时永久挂住"查看全量"；加 1.5s 超时闸门 + settled 幂等，超时降级本地 LRU；复测浮层出现且原文 3000 字 | `standard_mode/ui/lw_chat_perf.js` |

### 已知过时测试（skip ≠ PASS）

`standard_mode/tests/test_terminal_arch.py` 的 `test_simple_no_server` /
`test_panel_no_server` / `test_server_deprecated` 期望 TerminalServer 已下线，
但 `terminal_panel_simple.py` 当前**仍真实持有 TerminalServer**（独立 ws_port），
`terminal_server.py` 是活跃运行时依赖。删引用会破坏终端、打 DEPRECATED 是误导。
三条断言保留、显式 skip；**恢复条件**：TerminalServer 真正退役并迁移后移除 skip。
这是"测试期望过时"，不是产品缺陷，也不是把失败藏起来。

## 二、仍未完成（按优先级）

### P0（影响可用性与比赛）

1. **LW-Bench 真实能力分未提升**：fintech 0/6、compliance 0、extract 0；
   `--resume` 已修但**没用真实 agent 重跑完整 26 任务×2 轮**（本轮 oracle 只验框架）。
2. **TRAE 会话留痕必须由人在 TRAE 内完成**（我只能代做代码与文案）；报名帖未发布、视频未录、资格细则未确认。
3. **新模块的 A/B 未做**：`LEMON_TOOL_COMPRESS=1` 对 fintech 6 题是否提升、
   `LEMON_EXTRACT_LLM=1` 全站开启的降级率，都只有单点冒烟没有统计。

### P1（基建完成后排队，按约定不提前）

4. 真实 token 配置 + 真源冒烟（`TUSHARE_TOKEN`）；
5. `autoloop → quant_loop` 的完整自动假设生成闭环（当前 quant_loop 需调用方传假设）；
6. 三条小规模实验（轻量检测 vs MemGuard-Alpha 思路对照、连续折扣 vs pass^k、路由压缩 A/B）；
7. ~~GUI 人工验收~~ → **大部分已由自动巡航替代**（11 场景真 DOM 点击/输入/reload + 截图非空白机检）；**仍剩余**：真人主观观感（字体、动画手感、鼠标轨迹）与 B10 清单里需要真实后端/多轮对话的项。脚本边界已在 `patrol_report.md` 明示。

### P2（长尾工程债，按季度推进）

8. **静态债务**：假实现 21 条（P1 14 / P2 7）、1019 个吞异常点、零调用定义（JS 53/726、Python 1094/10027）；
9. **前端规整**：`mimo_app.js` 19500 行、裸 hex 约 550、emoji/SVG 混用、`!important` 密集；
10. **副作用目录 455 文件**：`data/studio` 415 / `templates/_candidates` 11 / `exports` 28 / `artifacts` 1；
    按纪律未删，建议 `.gitignore` 追加：
    ```
    data/studio/
    data/templates/_candidates/
    data/exports/
    data/artifacts/
    data/backups/
    .code_lock_log.jsonl
    ```
11. **证据链**：21 张 Gate 截图时序倒置已生成 `evidence_manifest.md` + 3 行注记；
    凌晨原始字节被上午同名覆盖，**不可恢复**，只能作为已记录事实；
12. **夹带文件归属**（7 个，详见 `data/audit/commit_groups.md`）：`T4_远期优化方案.md`、
    `exec_command_cluster.py`、`c5_tokenize_hex.py`、`make_src_package.py`、
    `gui_ux_experience_test.py` 等，本轮已随代码组提交，需主控最终裁决是否需要保留；
13. **历史遗留**：Web 侧 trajectoryStore/按会话导出、选区样式工具栏死链、两个 login HTML、
    `browser_drawer.py` 未纳入版本控制状态复核；
14. **未测项**：默认 `ollama num_ctx=32768` 对 9b/8b 是否溢出 CPU、`:8090` 银行端点业务正确性断言。

## 三、明确不做

- 不切 9b 默认（8K 公平横评：4b 90.9%/7.9s 优于 9b 86.4%/9.5s）
- 不迁移 Electron/TS、不翻译小程序（31 万行 / 6-12 人月）
- 不再堆新功能；不把 SKIP 写成 PASS；不宣称算法首创（见 `QUANT_AGENT_UPGRADE.md` 第五节文献核查）
- 不为过时的终端架构断言改动活跃运行时代码

## 四、下一轮最小动作

1. 用真实 agent（非 oracle）跑 LW-Bench 完整 26×2，得到新的 fintech 分数；
2. 打开 `LEMON_TOOL_COMPRESS=1` 做 A/B，看候选压缩是否把 fintech 从 0% 拉起；
3. 在 TRAE 内完成一次真实增量并留痕 → 录视频 → 发布报名帖。

## 五、2026-11-11 第二批：JS 重复定义治理（新扫描发现的问题已解决）

问题扫描发现 mimo_app.js 存在 7 组同文件顶层函数重复定义（后定义静默覆盖前定义，与历史假链接同根）。已全部处理：

- switchModel x3：删 2 死版 + 旧协议版改名 _legacySwitchModel，旧模型面板调用点同步改调（行为零变化）；现行三参版保留
- switchSession x2：同上 _legacySwitchSession
- showToast / trashThrowBehavior / stretchBehavior / toggleMiemiePanel：各删旧版死代码（现行后定义版生效）
- replaceIconPlaceholders 跨文件（mimo_app 扩展版 + svg_icons 基础版）：登记不删，svg_icons 可能被其他页面单独使用

复扫结果：同文件重复定义 = 0；mimo_app.js 21095 降为 21050；LemonGaze 状态日志 3 处 console.error 降为 console.warn（巡航观察项修复）。

回归：巡航 11/11 ALL_PASS、契约 5/5、副本 66 零差异、ui_fix 14/14、SVG 195/195、浏览器 22/21/12。复扫机检建议下轮固化为 scripts/check_no_dup.py 并纳入 pre-commit。

## 六、2026-11-11 第三批：机检固化 + 巡航扩展 + fintech 真实复跑

- 重复定义机检固化为 scripts/check_no_dup.py（同文件重复=0 判定，跨文件白名单 replaceIconPlaceholders），并接入 .git/hooks/pre-commit（契约检查后执行）
- 自动巡航从 11 场景扩到 14 场景：+团队 tab 真实点击、+文件卡打开/保存按钮渲染（不真点避免对话框挂死）、+会话自愈钩子；14/14 ALL_PASS
- 新增 bench/agents.py BridgeAgent（bridge :8765 /api/agent/chat 适配器，提交/轮询/工具调用转 steps），bench.run --agent choices 加入 bridge；fintech 6 题真实 agent 复跑后台进行，结果见 data/evals/lwbench_report.md（bridge 轮）

## 七、fintech 真实 agent 复跑结果（2026-11-11 第三批）

BridgeAgent 适配器已固化并实测：fintech 5 题 SR=0/5（Wilson [0%,43.5%]，violations=0）。归因三层：工具选择错（env_checker/finance_assistant）、输出走报告模板（bridge AgentLoop 报告模式，与 E-2 同族）、期望关键词未命中。**适配器链路本身全通**（提交/轮询/评分/落盘，147-200s/题）。
下一手优先级提升：把 bridge AgentLoop 的输出从报告模板切到任务直答（E-2 同族修复）+ 工具选择压缩注入——这两项做完 fintech 才可能从 0% 抬起。
详见 data/evals/fintech_real.md。

## 八、math_solver calculate 补丁 + e2e 第三轮（2026-11-11 第三批续）
巡演抓出 math_solver 缺 calculate 操作（4b 首选操作名直接 FAIL，靠自愈换 simplify），已补 ops/enum/docstring 三处并离线验证 15051。e2e 断言笔误修正（15041→15051，正确答案本就是 15051）。
第三轮 e2e：direct 6.9s / math 9.3s(PASS) / review 21.7s / chart 9.8s / crawl 9.6s(上轮 240s 超时为 4b 波动) / session 3.9s 全 PASS；transfer 连续两轮 90s 无审批卡（4b 不触发转账工具，稳定短板，待 DeepSeek 对照）。6/7 PASS。

**transfer 归因更正（同日）**：第三轮 transfer FAIL 不是模型短板——Agent 行为完全正确：查询全部账户 → 发现 6222 假账号不存在 → 如实报告并建议正确格式（ACC00x）并列出可用账户（陈奕汶 ACC001...）。拒绝向不存在的账户转账正是金融合规行为。用例设计错误（假账号），已改用沙箱真实账户 ACC001→ACC002，重跑后预期看到审批卡拒绝流。

## 九、e2e round4-8：11 用例全技能实测（2026-11-11 第三批完成）

新增 5 条重点用例（爬虫 Live 卡/量化质量/回测/办公/记忆）+ E2E_ONLY 过滤 + 工具名审计。过程中修复：
1. 审批闸断链（P0 级）：_send_via_agent_chat 未传 confirm_callback，面板链路转账直接执行无审批——已接线（ACC001→ACC002 500 元实测弹审批卡+拒绝流 PASS）
2. math_solver 补 calculate 操作（4b 首选名）
3. extra 模块 send/wait/snap 签名对齐 + main 判定规范化（旧版 all(x[1]) 错位）
4. transfer 假账号用例更正（Agent 拒转不存在账户是正确行为）
最终 11 用例：direct 10s / math 9.3s / review 25s / chart 10s / crawl 9.4s / transfer 90.9s(审批闸) / session 6.9s / quant_quality 241s / backtest 37.4s / office 27.3s / memory 10s —— 10/11 PASS。
**关键洞察**：4b 在 3 条用例里绕过专项技能（quant_quality_check/backtest_run/office_generator）改走 execute_code 通用路线——LW-Bench tool_called 失败码的真机实锤；office 文件卡 cards=0 再现 artifact 白名单丢弃问题。下一手：工具路由偏向专项技能 + artifact 卡白名单放行。

## 六、2026-11-20 真机卡顿 + matplotlib 弹窗修复（截图证据驱动）

用户截图证据：界面 FPS 2 / CPU 61.8% / MEM 15.8GB；execute_code 跑 matplotlib 时弹出独立 Figure 窗口且中文全是 □ 方块。

根因与修复：

1. execute_code 走 subprocess 跑临时 .py → matplotlib 用 Windows 默认 TkAgg **弹独立窗口**（子进程窗口还与主进程抢 Qt 事件循环，导致界面卡死）。已在 skills_registry.py 新增 _prepare_code_for_subprocess()：对 python + matplotlib 代码注入前缀——强制 Agg 无头 backend + 注入中文字体（Microsoft YaHei/SimHei/DejaVu Sans，axes.unicode_minus=False）+ 把 plt.show() 改写为落盘 PNG（供卡片渲染）。实测：无弹窗、lw_chart.png 12KB、中文标题正常。

2. 柠檬之瞳每帧 5 次 shadowBlur（bloom 3 层含重复 fill + 描边 + 鼻部）→ 无 GPU 合成下极贵。已把 bloom 降为单层（半径×0.55、一次 fill），描边与鼻部 shadowBlur 置 0。

3. 柠檬之瞳开启时只把 starfield 的 opacity 压到 0，**其 rAF 仍在全速跑**（双 canvas 抢 GPU）。现改为开启时真正 cancelAnimationFrame(_starfieldRAF)，关闭时恢复。

4. 星空安全网每 5 秒检查帧丢失，在低帧率时反复重启星空（雪上加霜）。现改为：页面不可见不重启 + 两次重启至少间隔 30s。

回归：巡航 11/11 ALL_PASS、契约 6/6、副本 106 文件零差异、node --check 通过、py_compile 通过。

仍需人工确认：真实长会话下 FPS 是否回到 30+（需人眼观察 UI 状态栏 FPS 计数）。

## 七、2026-11-20 真机反馈三连修（用户截图驱动）

1. 正文字体黑底黑字不可读：抓取页（数字银行）自带深色内联样式。已在 embed 态强制正文亮色 #e8eef7、标题白+橙辉光、链接青色下划线、加粗金字（!important 覆盖被抓页面样式）。

2. Agent 工作时无法上下翻（自动滑回底部）：22 处 area.scrollTop=area.scrollHeight 强制滚底绕过 StickyBottom.following。已在 lw_smooth.js 的 onScroll 加拦截——非跟随态检测到「单事件 moved>150 直达底部」的程序化滚底特征即恢复用户位置；用户滚轮惯性是多事件渐进不会误伤；点「回到最新」恢复跟随。一处改动覆盖全部 22 处。

3. 蜘蛛四肢不稳定：步态参数表（reach/thr/swT/lift）按 B3 冻结不得改（三端 diff=[]）；解析双骨 IK 本身稳定。怀疑是性能掉帧残留（FPS2 时代 dt 巨大导致腿跳变），本轮性能修复（shadowBlur 降层/starfield 停启/安全网间隔）后待用户复测；若仍不稳，下轮专项做「idle 态冻结腿 + dt 钳制」。
