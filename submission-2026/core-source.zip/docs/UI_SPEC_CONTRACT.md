# UI_SPEC_CONTRACT — lwRenderUiSpec 界面块契约（冻结）

> ui-fix-cluster Stage 5 · Q2 · 版本 v6.5-20261105
> 内核：`standard_mode/ui/lw_ui_render.js` + `lw_ui_render.css`
> 机检：`node scripts/test_ui_render_spec.js`（零依赖，**195/195 ALL_PASS**，
> 覆盖 8 块 × 4 主题 = 32 组 × 6 断言 + chart 三变体 + 3 个 fallback 组）

## 1. 顶层契约（冻结）

```
window.lwRenderUiSpec(spec) → 自包含 HTML 字符串
spec = {
  title?: string,                        // 卡片标题（可省略）
  theme?: 'default'|'light'|'warm'|'cool', // 缺省 default
  blocks: [ Block, ... ]                 // 必填，可为空数组
}
失败语义：任何输入（null/异常字段/未知 kind）都不抛异常；
未知 kind 与内部错误 → .lwc-state 规范空态卡（复用 lw_tokens.css）。
```

## 2. 8 种块的冻结字段

| kind | 字段 | 说明 |
|------|------|------|
| `kpi` | `items: [{label, value, unit?, delta?}]` | 指标格子；value 可为数字/字符串，NaN→0 |
| `table` | `columns: [string]`, `rows: [[cell,...],...]` | 单元格任意标量，全部转义 |
| `timeline` | `items: [{time?, title, desc?}]` | 竖排时间轴 |
| `compare` | `left: {title, items:[string]}`, `right: {同}` | 双栏对比 |
| `bullets` | `items: [string \| {text, tone?: 'ok'\|'danger'}]` | 列表 |
| `highlight` | `title?, text, tone?: 'info'\|'ok'\|'warn'\|'danger'` | 左边框高亮条 |
| `para` | `text: string` | 段落（pre-wrap） |
| `chart` | `chart: 'line'\|'bar'\|'pie'`, `labels: [string]`, `values: [number]`, `unit?` | **内联 SVG**；空数据 → .lwc-state 空态 |

## 3. 安全与稳定性冻结（机检逐条断言）

- 输出**无** `undefined` / `NaN` / `{{` 模板残留（数值 NaN/Infinity 强制清洗为 0）
- 输出**无** `http(s)://` 外链、**无** `<script`（禁止外链/脚本，永久）
- SVG 标签开闭配平（自闭合计入）；全部字符串经 esc() 转义
- 全部块 = 普通 DOM/SVG 节点，**禁止 canvas**（滚动复用不黑屏的根基）
- 主题 = 9 个 `--lwr-*` 令牌（bg/card/border/text/text-dim/accent/accent-soft/ok/danger）
  × 4 主题类 `lw-ui-theme-*`，作用域仅限 .lw-ui-card 子树

## 4. 通道关系（5.3 二选一记录）

- `renderChartCard`（mimo_app.js，inline SVG 通道）**保留原实现**，二者并行互不替代；
- `renderUiSketch`（canvas 概念草图）保留为**降级路径**，函数头已注明"优先 lwRenderUiSpec"；
- 技能/模型画界面一律走 `window.lwRenderUiSpec`。

## 5. 机检方式

```
node scripts/test_ui_render_spec.js
→ "ALL_PASS 195/195"（退出码 0）
```
断言口径变更须同步本文件第 3 节（冻结项不得放宽）。
