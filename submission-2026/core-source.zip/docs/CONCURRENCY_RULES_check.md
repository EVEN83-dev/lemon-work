# 并发纪律机检说明（Q6）

配套脚本：`scripts/audit_tests/check_concurrency_rules.py`
配套规则原文：`docs/CONCURRENCY_RULES.md`（本文件**不重写规则**，只把 R1-R4 变成可执行检查与处置指引）

## 一、四项检查

```
python -X utf8 scripts/audit_tests/check_concurrency_rules.py                      # 全量跑
python -X utf8 scripts/audit_tests/check_concurrency_rules.py --window 60          # 放宽 C1 观察窗
python -X utf8 scripts/audit_tests/check_concurrency_rules.py --json out.json      # 留档
python -X utf8 scripts/audit_tests/check_concurrency_rules.py --self-test          # 4 条纯函数自测
```
退出码：**0 = 无 FAIL（允许 WARN）**；**1 = 至少一项 FAIL**。WARN 不改退出码，但必须上报。
（注意：`| tail` 之后 `$?` 是管道末端的状态，判断退出码请直接跑或先重定向。）

| 项 | 检查什么 | 阈值/触发条件 | 判据实现 | FAIL 时找谁 |
|---|---|---|---|---|
| **C1 共享四文件写入批次** | `mimo_app.js` / `mimo_panel.py` / `mimo_style.css` / `mimo_page.html` 在 `--window`（默认 30 分钟）内是否被多批写入，以及**检查期间是否正被写入** | 窗口内出现 ≥2 个 mtime 批次（相邻间隔 >120s 视为另一批）→ WARN；检查过程中任一 fresh 文件 SHA256 变化 → **FAIL**；任一热区文件缺失 → FAIL | mtime 聚集度近似（不装依赖、不读 git）；`--hash-watch`（默认 3s）期间对比 hash | 出现 FAIL：**立刻停手并通知主控**，由主控裁决哪个窗口持有写入权（R1）。检查期间 hash 变化时，任何写入动作都可能吞掉对方成果 |
| **C2 UI 副本一致性** | `standard_mode/ui` 的运行时资产（html/js/css，实测 28 个）与 `bin/_internal`、`dist/lemon_agent/_internal` 两份副本 hash | 任一不一致/缺失 → **FAIL** | 逐文件 SHA256 比对（等价于 `sync_ui_copies.py --check` 的 same/differ，但给出 hash 值） | 有写权的窗口跑 `python -X utf8 scripts/sync_ui_copies.py`（**只做源码→副本**）。若刚同步过又出现差异 → 说明并行写入未停止，回到 C1 的处理路径 |
| **C3 截图与 Gate 同批落盘** | `data/ui_smoke/*.png` 的 mtime 是否晚于引用它的 `gate*_result.json` | 时差 > `--tolerance`（默认 900s）即倒置；倒置数 >5 → **FAIL**，1-5 → WARN | 解析 result json 里的 `([A-Za-z0-9_]+\.png)` 引用（含 json 内文字性 `截图已存:` 路径），取最早 json mtime 作基准 | 主控。处置办法见 R2 补正方案：不可改写既有结论，只能在 Gate 报告**追加一行**注记并登记 `evidence_manifest.md`；今后复现必须用新文件名（`gateN_rerunHHMM.png`），禁止同名覆盖 |
| **C4 未提交改动规模** | `git status --porcelain` 行数 | > `--max-untracked`（默认 50）→ **FAIL**；> 阈值的 60% → WARN | 只数行数并按首列状态分桶（?? / M / D），不做任何 git 写操作 | 主控。按 `data/audit/commit_groups_final.md` 分组提交；**先摘掉运行时数据**（`data/checkpoints` 371 项里的大头、`data/evals`、`data/ui_smoke`、`data/studio` 等）就能把分子降下来 |

## 二、实测结果（2026-11-06 13:0x，本集群）

```
[PASS] C1 共享四文件写入批次: 窗口内无写入
[PASS] C2 UI 副本一致性: same=56 differ=0
[FAIL] C3 截图与 Gate 同批落盘: 21 张截图晚于引用它的 result json >15 分钟（R2 违规）
[FAIL] C4 未提交改动规模: 未提交改动 432 项 > 阈值 50（R4：须暂停并通知主控）
汇总: FAIL=['C3', 'C4'] WARN=无 退出码=1
自测: 4/4 PASS（ST1 同批聚合 / ST2 分批拆分 / ST3 倒置-同批-无引用分类 / ST4 阈值判定）
```
证据文件：`data/audit/tests_raw/q5_concurrency_check.json`

## 三、两次事件的复盘时间线

### 事件 A：凌晨"902 行并行差异"（R1 缺失）

| 时刻 | 事实 | 证据 |
|---|---|---|
| 01:32 | 主控最后一次提交 `9d3d1ef` | `git log` |
| 01:56–03:28 | 超级收口集群 v1 与图片界面修复集群**并行活跃**，双方都在写 `mimo_app.js` / `mimo_page.html` / `lw_charts.js` / `mimo_panel.py` + 2 个新 ui 文件 | `data/evals/supercluster_final.md:76` |
| ~02:40 | P12 判定"JS 第二轮拆分 = **无安全区块、保持现状**"，理由不是技术不行，而是"并行窗口活跃写入 **902 行差异**，强拆禁忌" | `supercluster_final.md:31`、`:74` |
| 结果 | 既定重构目标被外部并发因素否决；`mimo_app.js` 从 `c9b431e` 记录的 19,500 行回涨到今天的 **20,596 行（+1,096）** | `wc -l` 实测 |
| 至今状态 | 那 902 行从未进入版本控制（432 项未提交里就含它） | `git status --porcelain` |

**机检能怎么拦住它**：当时的 C1 会报 `batches>=2`（WARN）→ 按流程必须通知主控编排写入权，
拆分窗口就不会在"对方正在写"的状态下评估安全性，结论也就不会被并发因素否决。

### 事件 B：本轮"differ 4 → 8 扩大"（R3 缺失）

| 时刻 | 事实 |
|---|---|
| 凌晨 03:30 前 | 集群自述 `sync_ui_copies --check → same=56 differ=0`（`supercluster_final.md:43`） |
| 11:19–11:20 | 另一窗口跑浏览器测试，写 `data/evals/audit_test_*.txt` |
| 11:52（补跑窗口3） | 我实测 **same=52 differ=4**：`mimo_app.js`、`mimo_style.css` × bin/dist 两份副本 |
| 11:36–12:32 | 并行窗口继续改 `mimo_app.js`(11:36)、`mimo_style.css`(11:47)、`mimo_page.html`(12:26:46)、`lw_taskcard.js`、`engine_manager.py`(12:09 与 12:32 两次) |
| 12:54 | 我实测扩大为 **same=48 differ=8**（多了 `lw_taskcard.js`、`mimo_page.html` 两对） |
| 12:54:54 | Q4 执行**单向同步**（源码→副本） |
| 12:55 | `--check` → **same=56 differ=0 missing=0 extra=0** |
| 13:00 前后（+5 分钟复查） | `--check` → **same=56 differ=0**；我的 hash 比对：跟踪资产 28 个、仍不一致 **0** 个 → 判定 **STABLE**（`tests_raw/q4_recheck.json`） |

结论：differ 从 4 扩到 8 不是同步脚本坏了，而是**"源改了不立刻同步"**这个习惯缺失。
现在 C2 每次跑都能抓到，且 Q4 已把三副本对齐并复验稳定。

### 事件 C：证据时序倒置（R2 缺失，C3 的由来）

凌晨 02:25–03:30 写成的 Gate 断言引用的截图，被上午 10:54–10:55 的复现**同名覆盖**，
21 张 PNG 无法再为凌晨断言提供字节级证据（最极端 `boot.png` 晚 26,647.5 秒 ≈ 7.4 小时）。
逐张 SHA256 与分类见 `data/audit/evidence_recheck.md`。

## 四、日常用法建议

1. **开工前**跑一次（`--window 30`）：C1 若 FAIL，说明别人正在写，先找主控，不要动共享四文件。
2. **每个 Stage 收尾**跑 C2（或 `sync_ui_copies.py` + `--check`），零差异才算完成（R3）。
3. **出 Gate 报告时**跑 C3：新增截图与 json 必须同批；复现一律换文件名。
4. **每天收工**跑 C4：超阈值就提交或分组，别让工作区停在 400+ 项（当前 432）。
5. 建议把 `check_concurrency_rules.py --json` 的输出留在各集群自己的审计目录里，作为 Stage 门禁证据。

## 五、机检自身的局限（不要高估）

- C1 用 mtime 聚集**近似**"多窗口写入"，无法区分"两个窗口"与"一个窗口改两次"；
  `--hash-watch` 的 3 秒窗口只能抓"正好在写"的时刻，抓不到"写完刚好停了 4 分钟"这种边界（本轮 t0 就是这种情况，所以我额外做了 5.5 分钟静默复测才动手）。
- C2 只比 hash，不判断"哪边更新"；方向性由 `sync_ui_copies.py` 保证（源→副本），我也没有给同步脚本加 `--guard`（见 Q8 未完成项）。
- C3 依赖 json 里真的写了文件名；若某报告只写"截图已存"但 json 没引用，就会被归入"无引用"而漏检。
- C4 只看总数，不看风险：432 项里 371 项其实是运行时数据。
