# -*- coding: utf-8 -*-
"""
Lemon Code Agent — 混合模式Web面板
加载hybrid_mode_wireframe.html并通过QWebChannel连接后端
★ v3.10 修复：使用 HybridDebugWebPage 拦截 __PYBRIDGE__ 消息，
   让前端 _callPython('agentChatWithEngine', ...) 桥接到 Python 后端 Ollama 调用
"""

import logging
logger = logging.getLogger(__name__)
import os
import re
import sys
import json
import threading
import traceback
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout
from PyQt5.QtCore import Qt, QUrl, QTimer, pyqtSignal, QObject, pyqtSlot, QMetaObject
from PyQt5.QtWebEngineWidgets import (
    QWebEngineView, QWebEngineSettings, QWebEnginePage, QWebEngineProfile,
)
from PyQt5.QtWebChannel import QWebChannel

# Windows 控制台 UTF-8（避免 print 中文崩溃）
try:
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    if hasattr(sys.stderr, 'reconfigure'):
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass


# ★ v4.5 前端 H2~M5 调用 → HybridBridge 真实方法的转发清单
_BRIDGE_FORWARD_METHODS = (
    'getAgentsInfo',          # 获取 Agent 列表 (arg: filter)
    'getAgentDetail',        # 获取 Agent 详情 (arg: agent_id)
    'getWorkflowStatus',     # 工作流状态
    'getMonitorData',        # 运行监控数据
    'getOrchestratorStatus', # orchestrator 状态
    'getMultiInstanceStatus',# 多实例集群状态
    'configureAgent',        # 配置 Agent (args: agent_id, config_json)
    'addAgent',              # 新增 Agent (arg: role_key)
    'removeAgent',           # 删除 Agent (arg: agent_id)
    'pauseWorkflow',         # 暂停工作流
    'openRoleConfigDialog',  # H2 角色配置对话框 (arg: agent_id)
    'getRoleSkillMap',       # ★ v4.6.1 角色→可用 Skill 白名单映射
    'dispatchCrossWindowTask',     # ★ v5.P0 跨窗派发（标准/咩咩/几维鸟）
    'getCompanyArchitecture',      # ★ v5.P0 公司架构三窗状态
    'dispatchOrchestratorCrossWindow',  # ★ v5.P0 总指挥编排派发
    'getAgentRoster',              # ★ v5.P0 花名册统一数据源
    'hireAgent',                   # ★ v5.P0 入职开席
    'fireAgent',                   # ★ v5.P0 解雇关席
    'assignTask',                  # ★ v5.P0 分配任务
    'setAgentModel',               # ★ v5.P0 切换模型
    'commanderPlan',               # ★ v5.P2 策划书结构化分解
    'startCompany',                # ★ v5.P3 启动公司
    'saveRunData',                 # ★ v5.P3 保存 run 记录
    'getRunHistory',               # ★ v5.P3 run 历史
    'getAgentHealth',              # ★ v5.P3 Agent 心跳检测
    'restartAgent',                # ★ v5.P3 一键重启
    'getPoolStats',                # ★ v5.37.T1 GPU 池统计
    'getFormationConfig',          # ★ v5.37.T1 编制配置
    'getArtifacts',                # v5.37.T2 产物索引
    # ★ 2026-10 接线修复批：补齐前端真实调用的桥方法
    'getAgentOutputs',             # Agent 输出聚合（查看输出按钮）
    'sendChat',                    # 聊天广播别名
    'stopCompany', 'stopRealInstances',  # 停转公司 / 停实例
    'fileTreeList', 'fileTreeCreate',    # 文件树真实 FS 操作
    'commanderPlanAndDispatch',    # 策划书分解+立即派发（公司主线）
    'invokeSkill', 'invokeSkillChain',   # Skill 真调用/链执行
    'listAllSkills', 'getSkillDetails',  # Skill 真清单/详情
    'getSkillCallStats', 'getSkillRouteStats',  # Skill 真统计
    'listSkillChains', 'getSkillChainDetails',  # Skill Chain 真数据
    'companyApi',                     # ★ A9 公司 OS 统一动作位（上传/审批/信件/配置）
    # ★ 2026-11-23 第二波接线：wireframe 直调、桥侧已有真实实现的名字
    'sendChatMessage', 'listAvailableSkills',  # 聊天别名 / 技能清单别名
    'getSessionHistory', 'getHandoffDoc', 'getProjectLog',  # 会话历史/交接单/事件流水
    # ★ 2026-11-23 第三波：员工暂停/恢复、统筹启动、会话交接（wireframe 真实调用点）
    'pauseAgent', 'resumeAgent', 'startWorkflow', 'triggerHandoff',
    # 注：setVerifyMode / isVerifyMode / openModeSwitchDialog 已移除 ——
    #     前端零引用且代码中不存在"查验模式/模式切换对话框"能力，
    #     保留只会制造永远失败的转发（宁可审计报缺，也不放假绿灯）。
)

# ★ 2026-10：重 IO 方法（起进程/LLM/文件扫描/跨窗派发）一律后台线程执行，防卡 Qt 主线程
_BRIDGE_ASYNC_METHODS = (
    'hireAgent', 'startCompany', 'stopCompany', 'stopRealInstances',
    'commanderPlanAndDispatch', 'assignTask', 'dispatchCrossWindowTask',
    'dispatchOrchestratorCrossWindow', 'invokeSkill', 'invokeSkillChain',
    'fileTreeList', 'fileTreeCreate', 'getAgentOutputs', 'setAgentModel',
    'importConfig', 'getArtifacts', 'getCompanyArchitecture',
    'companyApi',   # ★ A9：上传/审批/完成/信件均可能触发引擎链，一律后台执行
)


# ============================================================
# ★ v3.10 HybridDebugWebPage — 拦截 JS 控制台 __PYBRIDGE__ 消息
# ============================================================
class HybridDebugWebPage(QWebEnginePage):
    """捕获 JS 控制台日志 + Console Message Bridge（agentChatWithEngine 等）"""

    def __init__(self, parent, panel):
        super().__init__(parent)
        self._panel = panel  # HybridModeWebPanel 引用

    def javaScriptConsoleMessage(self, level, message, lineNumber, sourceID):
        # ★ 修复：禁止同步 print 到 stdout（交互式终端下会阻塞主线程导致卡顿）
        # 仅在 LEMON_JS_CONSOLE=1 时输出，用于开发调试
        if os.environ.get("LEMON_JS_CONSOLE") == "1":
            level_str = {0: 'INFO', 1: 'WARN', 2: 'ERROR', 3: 'DEBUG'}.get(level, str(level))
            msg = message.strip() if message else ''
            if msg and not msg.startswith('__PYBRIDGE__:'):
                print(f"[JS {level_str}] {msg}")

        msg = (message or '').strip()
        # ★ 拦截 __PYBRIDGE__ 消息并分发（核心桥接逻辑，不受日志开关影响）
        if msg and msg.startswith('__PYBRIDGE__:'):
            try:
                data = json.loads(msg[len('__PYBRIDGE__:'):])
                method = data.get('method', '')
                args = data.get('args', [])
                callback_id = data.get('callbackId')
                self._handle_pybridge(method, args, callback_id)
            except Exception as e:
                print(f"[PYBRIDGE] 解析错误: {e}")
                traceback.print_exc()

    # ------------------------------------------------------------
    # 桥接方法分发
    # ------------------------------------------------------------
    def _handle_pybridge(self, method, args, callback_id):
        """调度 JS→Python 的桥接调用"""
        try:
            if method == 'agentChatWithEngine' and len(args) >= 3:
                # 前端 sendAgentMessage 调用：args = [engine, model, fullPrompt]
                self._panel.handle_agent_chat_with_engine(args[0], args[1], args[2], callback_id)
            elif method == 'agentChat' and len(args) >= 2:
                # 兼容旧接口：args = [model, prompt]
                self._panel.handle_agent_chat(args[0], args[1], callback_id)
            elif method == 'switchMode' and len(args) >= 1:
                # 切换模式：args = [mode_id]
                self._panel.handle_switch_mode(args[0], callback_id)
            elif method == 'checkBridge':
                # 桥接自检
                self._reply(callback_id, {
                    "success": True,
                    "status": "hybrid_pybridge_ok_v3.10",
                    "panel": "HybridModeWebPanel"
                })
            elif method == 'echo' and len(args) >= 1:
                self._reply(callback_id, {"success": True, "echo": args[0]})
            elif method == 'getOllamaStatus':
                # 同步检查 Ollama 状态
                self._panel.handle_get_ollama_status(callback_id)
            elif method == 'getOllamaModels':
                self._panel.handle_get_ollama_models(callback_id)
            elif method == 'getMimoStatus':
                # ★ v3.11 检查 MIMO Code 服务状态（端口 4097）
                self._panel.handle_get_mimo_status(callback_id)
            elif method == 'checkAllAIStatus':
                # ★ v3.18 一次性检查所有 AI 服务状态
                self._panel.handle_check_all_ai_status(callback_id)
            elif method == 'hireAgent':
                # ★ 第456章：hireAgent→start_instance 可能秒级耗时，放后台线程防卡 UI 主线程
                threading.Thread(target=self._forward_to_bridge, args=(method, args, callback_id), daemon=True).start()
            elif method == 'saveUiOverrides' and len(args) >= 1:
                # ★ 2026-10：界面设置（粗调+专业微调）持久化到 config/ui_overrides.json
                result = self._panel.save_ui_overrides(args[0])
                try:
                    self._reply(callback_id, {"success": True, "data": json.loads(result)})
                except Exception:
                    self._reply(callback_id, {"success": True, "data": result})
            elif method == 'loadUiOverrides':
                result = self._panel.load_ui_overrides()
                try:
                    self._reply(callback_id, {"success": True, "data": json.loads(result).get("data", {})})
                except Exception:
                    self._reply(callback_id, {"success": True, "data": {}})
            elif method in _BRIDGE_FORWARD_METHODS:
                # ★ v4.5 把前端 H2~M5 调用转发到 HybridBridge 的真实方法
                # ★ 2026-10：重 IO 方法放后台线程执行（与 hireAgent 同策略），防卡 Qt 主线程
                if method in _BRIDGE_ASYNC_METHODS:
                    threading.Thread(target=self._forward_to_bridge,
                                     args=(method, args, callback_id), daemon=True).start()
                else:
                    self._forward_to_bridge(method, args, callback_id)
            else:
                # 未知方法：返回失败，让前端 fallback
                self._reply(callback_id, {
                    "success": False,
                    "error": f"未知方法: {method}"
                })
        except Exception as e:
            print(f"[PYBRIDGE] 调度异常: {e}")
            traceback.print_exc()
            self._reply(callback_id, {"success": False, "error": str(e)})

    def _forward_to_bridge(self, method, args, callback_id):
        """★ v4.5 把前端 H2~M5 调用转发到 HybridBridge 的真实方法。

        HybridBridge 的 @pyqtSlot(result=str) 方法返回 JSON 字符串；
        无 result 的 @pyqtSlot 方法返回 None（动作类，成功即回复）。
        """
        try:
            from shared.jsonl_log import log_event
            log_event("bridge.call", method=str(method or ""),
                      args_len=len(args or []))
        except Exception:
            logger.debug("bridge call log failed", exc_info=True)
        bridge = getattr(self._panel, '_bridge', None)
        if bridge is None or not hasattr(bridge, method):
            self._reply(callback_id, {"success": False, "error": f"Bridge 不支持方法: {method}"})
            return
        try:
            fn = getattr(bridge, method)
            result = fn(*args) if args else fn()
            if isinstance(result, str):
                try:
                    parsed = json.loads(result)
                    self._reply(callback_id, {"success": True, "data": parsed})
                except Exception:
                    self._reply(callback_id, {"success": True, "data": result})
            else:
                self._reply(callback_id, {"success": True, "result": result})
        except Exception as e:
            print(f"[PYBRIDGE] 转发 {method} 失败: {e}")
            try:
                from shared.jsonl_log import log_event
                log_event("bridge.error", method=str(method or ""),
                          error=str(e)[:200])
            except Exception:
                logger.debug("bridge error log failed", exc_info=True)
            traceback.print_exc()
            self._reply(callback_id, {"success": False, "error": str(e)})

    def _reply(self, callback_id, result):
        """通过 runJavaScript 回调前端"""
        if callback_id is None:
            return
        try:
            js = f"window._pybridgeCallback && window._pybridgeCallback({callback_id}, {json.dumps(result, ensure_ascii=False)})"
            self.runJavaScript(js)
        except Exception as e:
            print(f"[PYBRIDGE] 回调失败: {e}")


class HybridModeWebPanel(QWidget):
    """混合模式Web面板 — 加载HTML并通过QWebChannel连接Python后端"""

    # 信号
    command_sent = pyqtSignal(str)
    nav_action = pyqtSignal(str)
    workflow_step = pyqtSignal(str)
    mode_switch_requested = pyqtSignal(str)  # ★ v3.10 切换到标准模式
    # ★ v3.13 线程安全回调信号（子线程→主线程）
    _reply_signal = pyqtSignal(int, object)  # (callback_id, result)

    def __init__(self, engine_manager=None, parent=None):
        super().__init__(parent)
        # ★ 第21批（真机可见修复）: 给面板一个真实最小尺寸，
        #   否则 QStackedWidget 按 sizeHint 压缩，公司页只占半屏。
        self.setMinimumSize(900, 560)
        self._engine_manager = engine_manager
        self._bridge = None
        self._backend_initialized = False
        self._page_loaded = False
        # ★ v3.34: 销毁标志 — 防止后台线程访问已删除对象
        self._destroyed = False
        # ★ 第21批: 公司页加载失败重试计数（图4「有时候运行不出来」兜底）
        self._company_reload_tries = 0
        # ★ v3.10 Ollama 配置（确保有 http:// 前缀）
        # ★ 第456章补：OLLAMA_HOST=0.0.0.0 是 Ollama 服务端"监听所有网卡"的绑定配置，
        #   不能当客户端地址用（实测 WinError 10049 地址无效 → 引擎灯误报离线，
        #   而桥本体检测 11434 在线）。客户端侧归一为 127.0.0.1，无端口补 11434。
        _ollama_raw = os.environ.get('OLLAMA_HOST', 'http://127.0.0.1:11434').rstrip('/')
        if not _ollama_raw.startswith('http://') and not _ollama_raw.startswith('https://'):
            _ollama_raw = 'http://' + _ollama_raw
        if '0.0.0.0' in _ollama_raw:
            _ollama_raw = _ollama_raw.replace('0.0.0.0', '127.0.0.1')
        if ':' not in _ollama_raw.split('://', 1)[-1]:
            _ollama_raw = _ollama_raw + ':11434'
        self._ollama_host = _ollama_raw
        # 已知有效的 Ollama 模型
        self._valid_ollama_models = [
            'qwen3.5:4b', 'qwen3.5:9b',
            'qwen3-vl:4b', 'aleshribar3/deepseek-r1-tool-calling:8b'
        ]
        # ★ 第458章：本机可用模型缓存（/api/tags，60s TTL）——员工配置模型可能未拉取
        self._ollama_models_cache = None
        self._ollama_models_ts = 0.0
        self._init_ui()
        self._setup_bridge()
        # ★ v3.13 连接线程安全回调信号
        self._reply_signal.connect(self._handle_reply_signal)

    def _init_ui(self):
        """初始化UI"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # ★ 窗口3·公司模式：页签条（A9 公司OS 默认；固定框架看板次之；经典 wireframe 兜底）
        tabbar = QWidget()
        tb = QHBoxLayout(tabbar)
        tb.setContentsMargins(6, 3, 6, 3)
        tb.setSpacing(6)
        from PyQt5.QtWidgets import QPushButton
        self._btnCompanyOsPage = QPushButton("公司OS")
        self._btnCompanyPage = QPushButton("固定框架看板")
        self._btnWireframePage = QPushButton("经典面板(兜底)")
        for btn in (self._btnCompanyOsPage, self._btnCompanyPage, self._btnWireframePage):
            btn.setCheckable(True)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setStyleSheet(
                "QPushButton{font-size:11px;padding:3px 12px;border-radius:7px;"
                "border:1px solid rgba(255,255,255,.12);background:transparent;color:#8a90a0;}"
                "QPushButton:checked{border-color:#ff9a4a;color:#ff9a4a;}")
            tb.addWidget(btn)
        # ★ 第23批: 旧「固定框架看板 / 经典面板」已并入公司 OS —— 仅保留公司 OS 页签
        self._btnCompanyPage.hide()
        self._btnWireframePage.hide()
        tb.addStretch(1)
        self._btnCompanyOsPage.setChecked(True)
        self._btnCompanyOsPage.clicked.connect(self.load_company_os)
        self._btnCompanyPage.clicked.connect(self.load_company_board)
        self._btnWireframePage.clicked.connect(self.load_wireframe)
        layout.addWidget(tabbar)

        # ★ 2026-10 持久化修复：file:// 页面的 localStorage「重启即丢」的根因是
        #   默认 profile 的存储路径不可写/临时。按 Qt 官方建议指向 AppLocalDataLocation，
        #   页面内全部 localStorage（聊天记录/人格/界面设置）即自动跨会话持久化。
        try:
            from PyQt5.QtCore import QStandardPaths
            base = QStandardPaths.writableLocation(QStandardPaths.AppLocalDataLocation)
            storage = os.path.join(base, "hybrid_web_profile")
            os.makedirs(storage, exist_ok=True)
            profile = QWebEngineProfile.defaultProfile()
            profile.setPersistentStoragePath(storage)
            profile.setPersistentCookiesPolicy(QWebEngineProfile.ForcePersistentCookies)
            print(f"[HybridPanel] WebEngine 持久化存储: {storage}")
        except Exception as e:
            print(f"[HybridPanel] 持久化路径设置失败（localStorage 退化为会话级）: {e}")

        # 创建WebEngine视图
        self.web_view = QWebEngineView()
        # ★ 2026-11-22: 公司模式页面缩放（Ctrl+滚轮 / Ctrl+± / Ctrl+0 复位）
        try:
            try:
                from ui.lw_zoom import install_zoom
            except ImportError:
                from lw_zoom import install_zoom
            install_zoom(self.web_view)
        except Exception as _ze:
            print(f"[HybridModeWebPanel] 缩放接线跳过: {_ze}")
        # ★ 第21批: 必须随父容器拉伸，否则被 tabbar 挤成半屏
        from PyQt5.QtWidgets import QSizePolicy
        self.web_view.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        # ★ v3.10 关键修复：使用 HybridDebugWebPage 拦截 __PYBRIDGE__ 消息
        self.web_view.setPage(HybridDebugWebPage(self.web_view, self))
        # ★ 窗口3·公司模式：进程内公司服务句柄（SSE 8801-8805；启动失败如实回落轮询）
        self._company_server = None

        # 启用必要设置
        settings = self.web_view.page().settings()
        settings.setAttribute(QWebEngineSettings.JavascriptEnabled, True)
        settings.setAttribute(QWebEngineSettings.LocalContentCanAccessRemoteUrls, True)
        settings.setAttribute(QWebEngineSettings.AllowRunningInsecureContent, True)

        # ★ 2026-10：页面每次加载完成后注入「界面设置覆盖」（粗调/微调 token）
        self.web_view.loadFinished.connect(self._on_load_finished_apply_overrides)

        # ★ 2026-10：拉起混合模式旁路服务（7790 桥 / 7791 指挥官）
        self._service_processes = []
        self._ensure_bridge_services()

        layout.addWidget(self.web_view, 1)

    # ------------------------------------------------------------
    # ★ 2026-10 旁路服务自启动（7790/7791）
    # ------------------------------------------------------------
    def _ensure_bridge_services(self):
        """探活 7790/7791，未启动则用自身解释器后台拉起（worker 再入模式）。

        最佳实践依据：PyInstaller onefile 场景用 `sys.executable + 参数` 自身再入；
        开发场景 sys.executable 即 python.exe。进程句柄保留，cleanup() 时 terminate。
        探活失败不阻断面板加载，仅在终端如实提示（绝不假装在线）。
        """
        import socket
        import subprocess
        import threading
        import time as _time

        def _port_open(port, timeout=0.6):
            try:
                with socket.create_connection(("127.0.0.1", port), timeout=timeout):
                    return True
            except OSError:
                return False

        targets = [
            (7790, ["-m", "hybrid_mode.server"], "混合模式桥"),
            (7791, ["-m", "hybrid_mode.core.commander_server"] if True else [], "指挥官服务"),
        ]
        for port, extra_args, label in targets:
            if _port_open(port):
                print(f"[HybridPanel] {label}({port}) 已在运行，复用")
                continue
            try:
                kwargs = {}
                if os.name == "nt":
                    kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
                proc = subprocess.Popen(
                    [sys.executable] + extra_args,
                    cwd=self._repo_root(),
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                    **kwargs,
                )
                self._service_processes.append(proc)
                print(f"[HybridPanel] 已拉起 {label}(port {port}) pid={proc.pid}")

                def _wait_alive(p=proc, pt=port, lb=label):
                    for _ in range(10):
                        if _port_open(pt):
                            print(f"[HybridPanel] {lb}({pt}) 探活成功")
                            return
                        _time.sleep(0.5)
                    print(f"[HybridPanel] [WARN] {lb}({pt}) 10s 内未探活——相关按钮将如实报错")
                threading.Thread(target=_wait_alive, daemon=True).start()
            except Exception as e:
                print(f"[HybridPanel] [WARN] 拉起 {label}({port}) 失败: {e}（按钮将如实报错）")

    @staticmethod
    def _repo_root():
        return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    # ------------------------------------------------------------
    # ★ 2026-10 界面设置覆盖（token 微调）注入
    # ------------------------------------------------------------
    def _on_load_finished_apply_overrides(self, ok):
        """页面加载完成后：1) 注入持久化界面设置；2) 注入 SSOT token 常量兜底；
        3) ★ 集群B(项2): 公司 OS 页主动取一次 CompanyService.state() 并注入
        window.onCompanyState —— 首屏即真实数据，不等第一轮状态推送。"""
        if not ok:
            # ★ 第21批: 加载失败不再静默留黑屏 —— 自动重载（最多 2 次），仍败显示错误页
            if not self._destroyed:
                self._retry_company_page("loadFinished(ok=False)")
            return
        if self._destroyed:
            return
        try:
            overrides = self._load_ui_overrides()
            js_vars = []
            for k, v in (overrides.get("vars") or {}).items():
                safe_key = re.sub(r"[^a-z0-9-]", "", str(k).lower())
                safe_val = str(v).replace("\\", "").replace("'", "")
                if safe_key and safe_val:
                    js_vars.append(f"'--{safe_key}':'{safe_val}'")
            effects = bool(overrides.get("effects", False))
            starfield = bool(overrides.get("starfield", False))
            js = (
                "window.__UI_OVERRIDES__ = {vars:{" + ",".join(js_vars) + "},"
                f"effects:{'true' if effects else 'false'},starfield:{'true' if starfield else 'false'}}};"
                "if (typeof window.__applyUiOverrides === 'function') window.__applyUiOverrides();"
            )
            self.web_view.page().runJavaScript(js)
        except Exception as e:
            print(f"[HybridPanel] 界面设置注入失败: {e}")
        # ★ 集群B(项2): 首屏真实状态主动注入（getState → svc.state() 原样）
        try:
            bridge = getattr(self, '_bridge', None)
            if bridge is not None and hasattr(bridge, 'companyApi'):
                raw = bridge.companyApi('getState', '{}')
                parsed = json.loads(raw) if isinstance(raw, str) else raw
                if parsed and parsed.get('ok') and parsed.get('data'):
                    state_json = json.dumps(parsed['data'], ensure_ascii=False,
                                            default=str)
                    self.web_view.page().runJavaScript(
                        "window.onCompanyState && window.onCompanyState(%s);" % state_json)
                    print("[HybridPanel] 公司OS首屏真实 state 已注入（项2）")
        except Exception as e:
            print(f"[HybridPanel] 公司OS首屏 state 注入失败（页面回落轮询/SSE）: {e}")
        # ★ 集群B: company_os 页缺 qwebchannel.js —— loadFinished 后注入
        #   qwebchannel.js + QWebChannel 引导（幂等），让页面 __bridge 真正连上。
        try:
            if 'company_os.html' in self.web_view.url().toString():
                _qwc = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                    'qwebchannel.js')
                if os.path.exists(_qwc):
                    with open(_qwc, 'r', encoding='utf-8') as _f:
                        qweb_src = _f.read()
                    bootstrap = (
                        qweb_src +
                        "\n;(function(){"
                        "if(window.__bridgeInjected)return;"
                        "if(!(window.qt&&qt.webChannelTransport&&typeof QWebChannel!=='undefined'))return;"
                        "window.__bridgeInjected=true;"
                        "new QWebChannel(qt.webChannelTransport,function(channel){"
                        "window.__bridge=channel.objects.hybridBridge||null;"
                        "if(window.__bridge&&window.__bridge.companyApi){"
                        "if(typeof window.refreshState==='function')window.refreshState();"
                        "}});})();")
                    self.web_view.page().runJavaScript(bootstrap)
                    print("[HybridPanel] company_os QWebChannel 引导注入完成")
        except Exception as e:
            print(f"[HybridPanel] QWebChannel 注入失败: {e}")
        # ★ 第21批: 加载成功也要验一次真高 —— 空白页（#app 高度 0）自动重载
        if "company_os.html" in self.web_view.url().toString():
            QTimer.singleShot(1800, self._verify_company_page)

    # ── ★ 第21批: 公司页加载兜底（黑屏自愈）────────────────────
    def _retry_company_page(self, reason: str):
        if self._destroyed:
            return
        if self._company_reload_tries >= 2:
            print(f"[HybridPanel] 公司页连续失败（{reason}），显示错误页")
            self.web_view.setHtml(
                "<html><body style='background:#0b0d12;color:#e8ecf5;"
                "font:14px/1.7 Microsoft YaHei;padding:40px'>"
                "<h2 style='color:#ff9a4a'>公司模式加载失败</h2>"
                f"<p>原因：{reason}</p>"
                "<p>已自动重试 2 次。请点上方「公司OS」页签重试，或切到标准模式后重开。</p>"
                "</body></html>")
            return
        self._company_reload_tries += 1
        print(f"[HybridPanel] 公司页异常（{reason}），第 "
              f"{self._company_reload_tries} 次重载")
        QTimer.singleShot(600, self.load_company_os)

    def _verify_company_page(self):
        if self._destroyed:
            return
        js = ("(function(){var a=document.getElementById('app');"
              "if(!a)return -1;var r=a.getBoundingClientRect();"
              "return Math.round(r.height)})()")
        self.web_view.page().runJavaScript(js, 0, self._on_company_height)

    def _on_company_height(self, h):
        try:
            h = int(h)
        except Exception:
            h = -1
        if h > 40:
            self._company_reload_tries = 0
            return
        self._retry_company_page(f"blank(#app.height={h})")

    _UI_OVERRIDES_PATH = os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
        "config", "ui_overrides.json",
    )

    def _load_ui_overrides(self):
        try:
            with open(self._UI_OVERRIDES_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}

    def save_ui_overrides(self, overrides_json):
        """供 __PYBRIDGE__ 分发：持久化界面设置（粗调+专业微调）。"""
        try:
            data = json.loads(overrides_json) if isinstance(overrides_json, str) else (overrides_json or {})
            os.makedirs(os.path.dirname(self._UI_OVERRIDES_PATH), exist_ok=True)
            with open(self._UI_OVERRIDES_PATH, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            # 立即生效
            self._on_load_finished_apply_overrides(True)
            return json.dumps({"success": True, "path": self._UI_OVERRIDES_PATH}, ensure_ascii=False)
        except Exception as e:
            return json.dumps({"success": False, "error": str(e)}, ensure_ascii=False)

    def load_ui_overrides(self):
        return json.dumps({"success": True, "data": self._load_ui_overrides()}, ensure_ascii=False)

    # ============================================================
    # ★ v3.13 线程安全回调 — 子线程通过信号触发主线程执行 runJavaScript
    # ============================================================
    def _handle_reply_signal(self, callback_id, result):
        """主线程执行：通过 runJavaScript 回调前端"""
        try:
            js = f"window._pybridgeCallback && window._pybridgeCallback({callback_id}, {json.dumps(result, ensure_ascii=False)})"
            print(f"[PYBRIDGE] => JS回调: callback_id={callback_id}, success={result.get('success')}, online={result.get('online', 'N/A')}")
            self.web_view.page().runJavaScript(js)
        except Exception as e:
            print(f"[PYBRIDGE] 主线程回调失败: {e}")
            traceback.print_exc()
    
    def _reply_thread_safe(self, callback_id, result):
        """子线程安全回调（v3.34: 使用 _destroyed 标志防止崩溃）"""
        if self._destroyed:
            return  # 面板已销毁，静默跳过
        try:
            self._reply_signal.emit(callback_id, result)
        except RuntimeError:
            pass  # C/C++ 对象已删除，静默忽略

    # ============================================================
    # ★ v3.10 Python 后端处理 — Agent 对话桥接
    # ============================================================
    def handle_agent_chat_with_engine(self, engine, model, prompt, callback_id):
        """
        处理前端 _callPython('agentChatWithEngine', engine, model, prompt, callback)
        engine: 'ollama' / 'mimo'
        model: Ollama 模型名（如 qwen3.5:4b）
        prompt: 完整提示词（已包含角色设定）
        callback_id: JS 回调 ID
        """
        # 强制使用子线程，避免阻塞 UI
        t = threading.Thread(
            target=self._do_agent_chat,
            args=(engine, model, prompt, callback_id),
            daemon=True
        )
        t.start()

    def handle_agent_chat(self, model, prompt, callback_id):
        """兼容旧接口：默认使用 ollama 引擎"""
        self.handle_agent_chat_with_engine('ollama', model, prompt, callback_id)

    def set_engine_manager(self, engine_manager):
        """★ 第458章：延迟注入引擎管理器（构造期窗口尚未持有 _engine_manager）。
        注入后 agentChatWithEngine 走 unified_chat 正路，不再降级直连。
        ★ 窗口3·公司模式：同步传播给 HybridBridge（公司模式取数/派发同源）。"""
        self._engine_manager = engine_manager
        if getattr(self, '_bridge', None) is not None and hasattr(self._bridge, 'set_engine_manager'):
            try:
                self._bridge.set_engine_manager(engine_manager)
            except Exception as e:
                print(f"[HybridModeWebPanel] Bridge 引擎管理器注入失败: {e}")
        if engine_manager is not None:
            print("[HybridModeWebPanel] 引擎管理器已延迟注入（unified_chat 正路生效）")

    def _resolve_chat_model(self, want):
        """★ 第458章：按本机 /api/tags 实况解析聊天模型（缓存 60s）。
        want 可用 → 原样返回；不可用 → 按速度偏好选最小可用模型；
        查询失败 → 沿用旧硬编码规则（诚实暴露原错误）。"""
        try:
            import requests as _rq
            import time as _t
            now = _t.time()
            if self._ollama_models_cache is not None and now - self._ollama_models_ts < 60:
                names = self._ollama_models_cache
            else:
                r = _rq.get(self._ollama_host + "/api/tags", timeout=3)
                names = [m.get("name", "") for m in r.json().get("models", [])]
                self._ollama_models_cache = names
                self._ollama_models_ts = now
            for n in names:
                if n == want or n.startswith(want):
                    return want
            for pref in ("qwen2.5:1.5b", "qwen3:4b", "qwen3.5:4b", "qwen3.5:9b"):
                for n in names:
                    if n == pref or n.startswith(pref):
                        return n
            base = (want or "").split(":")[0]
            if base:
                for n in names:
                    if n.startswith(base):
                        return n
            return want
        except Exception:
            return want if want in self._valid_ollama_models else 'qwen3.5:4b'

    def _do_agent_chat(self, engine, model, prompt, callback_id):
        """子线程执行：调用 AI 引擎（★ v3.17 优先使用 EngineManager.unified_chat）"""
        import time as _time
        start_time = _time.time()
        print(f"[PYBRIDGE] ★ 开始调用引擎: {engine}, 模型: {model}, callback_id: {callback_id}")

        # ★ v5.1 P0修复：空 prompt 守卫（此前前端发 null 导致空调用，引擎必报错）
        if not prompt or not str(prompt).strip():
            self._reply_thread_safe(callback_id, {
                "success": False, "reply": "", "error": "空消息：请输入内容后再发送",
                "engine": engine or "unknown", "model": model,
            })
            return
        try:
            # ★ v3.17 优先使用统一的 AI 调用接口
            if self._engine_manager is not None:
                print(f"[PYBRIDGE] 使用 EngineManager.unified_chat()")
                # ★ 第458章续：unified_chat 路径同样按本机 /api/tags 实况解析模型。
                #   截图实锤：员工配置 qwen2.5:1.5b 未拉取 → /api/chat 404 →
                #   错误文本被 unified_chat 包装成 success 回复（气泡显示报错）。
                model = self._resolve_chat_model(model)
                print(f"[PYBRIDGE] unified_chat 模型解析: {model}")
                result = self._engine_manager.unified_chat(
                    prompt=prompt,
                    model=model,
                    engine_id=engine,
                )
                elapsed = _time.time() - start_time
                result['elapsed_ms'] = int(elapsed * 1000)
                print(f"[PYBRIDGE] unified_chat 结果: success={result.get('success')}, engine={result.get('engine')}, {len(result.get('reply',''))}字")
                self._reply_thread_safe(callback_id, result)
                return
            else:
                print(f"[PYBRIDGE] ⚠ EngineManager 不可用，使用直接调用")
        except Exception as e:
            print(f"[PYBRIDGE] ⚠ unified_chat 失败: {e}，使用直接调用")
        
        # ★ 降级：直接调用（保留原有逻辑作为 fallback）
        try:
            import requests as _req
            
            # 1. 如果是 mimo 引擎，尝试调用 mimo serve
            if engine == 'mimo':
                print(f"[PYBRIDGE] 尝试调用 MIMO Code...")
                mimo_result = self._call_mimo_serve(prompt)
                if mimo_result.get('success'):
                    elapsed = _time.time() - start_time
                    mimo_result['elapsed_ms'] = int(elapsed * 1000)
                    mimo_result['engine'] = 'mimo'
                    self._reply_thread_safe(callback_id, mimo_result)
                    return
                print(f"[PYBRIDGE] ⚠ mimo 引擎调用失败: {mimo_result.get('error')}, 降级 ollama")

            # 2. 调用 Ollama（★ 第458章：模型按本机实况动态解析，员工配置模型未拉取时自动选最快可用）
            use_model = self._resolve_chat_model(model)
            print(f"[PYBRIDGE] 直接调用 Ollama: {self._ollama_host}, 模型: {use_model}")
            _is_thinking = any(t in use_model.lower() for t in ['4b', '7b', '14b', 'qwen3'])
            _num_predict = 1500 if _is_thinking else 300
            payload = {
                "model": use_model,
                "prompt": prompt,
                "stream": False,
                "options": {
                    "temperature": 0.7,
                    "num_predict": _num_predict,
                    "top_p": 0.85,
                    "top_k": 20,
                    "repeat_penalty": 1.1
                }
            }
            resp = _req.post(f"{self._ollama_host}/api/generate", json=payload, timeout=180)
            print(f"[PYBRIDGE] Ollama HTTP 状态: {resp.status_code}")
            if resp.status_code == 200:
                data = resp.json()
                reply_text = data.get('response', '').strip()
                if not reply_text:
                    raw_thinking = data.get('thinking', '').strip()
                    if raw_thinking:
                        parts = [p.strip() for p in raw_thinking.split('\n\n') if p.strip()]
                        for p in reversed(parts):
                            if not any(m in p.lower() for m in ['thinking process', 'analyze', 'step ', '1.', '2.', 'let me', '**']):
                                reply_text = p
                                break
                        if not reply_text and parts:
                            reply_text = parts[-1]
                elapsed = _time.time() - start_time
                result = {
                    "success": True,
                    "reply": reply_text or '(空回复)',
                    "tokens": data.get('eval_count', 0),
                    "elapsed_ms": int(elapsed * 1000),
                    "engine": "ollama",
                    "model": use_model
                }
                self._reply_thread_safe(callback_id, result)
            else:
                err = f"Ollama HTTP {resp.status_code}: {resp.text[:200]}"
                self._reply_thread_safe(callback_id, {"success": False, "error": err, "engine": "ollama"})

        except Exception as e:
            print(f"[PYBRIDGE] ✗ Agent 对话异常: {e}")
            traceback.print_exc()
            self._reply_thread_safe(callback_id, {"success": False, "error": str(e), "engine": engine})

    def _call_mimo_serve(self, prompt):
        """★ v3.12 尝试调用本地 mimo serve（兼容端口 4096 和 4097）
        - 4096: MIMO Code GUI 默认端口（D:\\mimo_ai\\mimo-gui\\start-server.js）
        - 4097: 项目 multi_instance_manager 默认端口
        """
        try:
            import requests as _req
            # ★ 依次尝试 4096 和 4097 端口（短超时，避免阻塞）
            online_port = None
            for port in [4096, 4097]:
                try:
                    health = _req.get(f'http://127.0.0.1:{port}/global/health', timeout=1)
                    if health.status_code == 200:
                        online_port = port
                        break
                except Exception:
                    continue

            if online_port is None:
                return {"success": False, "error": "mimo serve 未运行 (端口 4096/4097 均不可达，请先启动 D:\\mimo_ai\\mimo-gui\\start-desktop.bat 或运行 mimo serve --port 4097)"}

            # 调用 mimo serve
            payload = {"prompt": prompt, "stream": False}
            resp = _req.post(f'http://127.0.0.1:{online_port}/v1/chat', json=payload, timeout=120)
            if resp.status_code == 200:
                data = resp.json()
                reply_text = data.get('response', '') or data.get('content', '') or ''
                return {
                    "success": True,
                    "reply": reply_text,
                    "tokens": data.get('usage', {}).get('total_tokens', 0),
                    "model": "mimo",
                    "port": online_port
                }
            return {"success": False, "error": f"mimo serve HTTP {resp.status_code} (port {online_port})"}
        except Exception as e:
            return {"success": False, "error": f"mimo serve 调用异常: {e}"}

    # ============================================================
    # 其他桥接方法
    # ============================================================
    def handle_switch_mode(self, mode, callback_id):
        """切换模式：发送信号到主窗口"""
        print(f"[PYBRIDGE] 切换模式: {mode}")
        self.mode_switch_requested.emit(mode)
        self._reply(callback_id, {"success": True, "mode": mode})

    def handle_get_ollama_status(self, callback_id):
        """获取 Ollama 服务状态"""
        print(f"[PYBRIDGE] handle_get_ollama_status: callback_id={callback_id}, host={self._ollama_host}")
        def _check():
            if self._destroyed:
                return  # ★ v3.34: 面板已销毁，跳过
            try:
                import requests as _req
                print(f"[PYBRIDGE] 正在检测 Ollama: {self._ollama_host}/api/tags")
                resp = _req.get(f"{self._ollama_host}/api/tags", timeout=3)
                print(f"[PYBRIDGE] Ollama 响应: HTTP {resp.status_code}")
                if resp.status_code == 200:
                    models = resp.json().get("models", [])
                    print(f"[PYBRIDGE] Ollama 在线，{len(models)} 个模型")
                    self._reply_thread_safe(callback_id, {"success": True, "online": True, "host": self._ollama_host, "models": len(models)})
                else:
                    print(f"[PYBRIDGE] Ollama 异常: HTTP {resp.status_code}")
                    self._reply_thread_safe(callback_id, {"success": True, "online": False, "error": f"HTTP {resp.status_code}"})
            except Exception as e:
                print(f"[PYBRIDGE] Ollama 检测失败: {e}")
                self._reply_thread_safe(callback_id, {"success": True, "online": False, "error": str(e)})

        threading.Thread(target=_check, daemon=True).start()

    def handle_get_ollama_models(self, callback_id):
        """获取 Ollama 模型列表"""
        def _fetch():
            if self._destroyed:
                return  # ★ v3.34: 面板已销毁，跳过
            try:
                import requests as _req
                resp = _req.get(f"{self._ollama_host}/api/tags", timeout=5)
                if resp.status_code == 200:
                    data = resp.json()
                    models = [m.get('name', '') for m in data.get('models', [])]
                    self._reply_thread_safe(callback_id, {"success": True, "models": models})
                else:
                    self._reply_thread_safe(callback_id, {"success": False, "error": f"HTTP {resp.status_code}"})
            except Exception as e:
                self._reply_thread_safe(callback_id, {"success": False, "error": str(e)})

        threading.Thread(target=_fetch, daemon=True).start()

    def handle_get_mimo_status(self, callback_id):
        """★ v3.12 获取 MIMO Code 服务状态（兼容端口 4096 和 4097）
        - 4096: MIMO Code GUI 默认端口
        - 4097: 项目 multi_instance_manager 默认端口
        """
        print(f"[PYBRIDGE] handle_get_mimo_status: callback_id={callback_id}")
        def _check():
            if self._destroyed:
                return  # ★ v3.34: 面板已销毁，跳过
            try:
                import requests as _req
                online_port = None
                # ★ 依次尝试 4096 和 4097
                for port in [4096, 4097]:
                    try:
                        print(f"[PYBRIDGE] 检测 MIMO 端口 {port}...")
                        resp = _req.get(f'http://127.0.0.1:{port}/global/health', timeout=2)
                        if resp.status_code == 200:
                            online_port = port
                            print(f"[PYBRIDGE] MIMO 在线: 端口 {port}")
                            break
                    except Exception:
                        # fallback: 尝试根路径
                        try:
                            resp = _req.get(f'http://127.0.0.1:{port}/', timeout=2)
                            if resp.status_code in (200, 401, 404):
                                online_port = port
                                print(f"[PYBRIDGE] MIMO 在线(根路径): 端口 {port}")
                                break
                        except Exception:
                            continue

                if online_port is None:
                    print(f"[PYBRIDGE] MIMO 离线 (端口 4096/4097 均不可达)")
                
                self._reply_thread_safe(callback_id, {
                    "success": True,
                    "online": online_port is not None,
                    "port": online_port,
                    "checked_ports": [4096, 4097]
                })
            except Exception as e:
                print(f"[PYBRIDGE] MIMO 检测失败: {e}")
                self._reply_thread_safe(callback_id, {"success": True, "online": False, "error": str(e)})

        threading.Thread(target=_check, daemon=True).start()

    def handle_check_all_ai_status(self, callback_id):
        """★ v3.18 一次性检查所有 AI 服务状态（Ollama + MIMO）"""
        print(f"[PYBRIDGE] handle_check_all_ai_status: callback_id={callback_id}")
        def _check_all():
            if self._destroyed:
                return  # ★ v3.34: 面板已销毁，跳过
            import requests as _req
            import time as _time
            start = _time.time()
            result = {
                "success": True,
                "ollama": {"online": False, "error": ""},
                "mimo": {"online": False, "port": None, "error": ""},
                "elapsed_ms": 0
            }
            
            # 1. 检查 Ollama
            try:
                resp = _req.get(f"{self._ollama_host}/api/tags", timeout=3)
                if resp.status_code == 200:
                    result["ollama"]["online"] = True
                    result["ollama"]["models"] = len(resp.json().get("models", []))
                else:
                    result["ollama"]["error"] = f"HTTP {resp.status_code}"
            except Exception as e:
                result["ollama"]["error"] = str(e)[:100]
            
            # 2. 检查 MIMO Code（★ v3.60: 使用 /global/health 而非 /health）
            for port in [4096, 4097]:
                try:
                    resp = _req.get(f'http://127.0.0.1:{port}/global/health', timeout=2)
                    if resp.status_code == 200:
                        result["mimo"]["online"] = True
                        result["mimo"]["port"] = port
                        break
                except Exception:
                    continue
            
            if not result["mimo"]["online"]:
                result["mimo"]["error"] = "端口 4096/4097 均不可达"
            
            result["elapsed_ms"] = int((_time.time() - start) * 1000)
            print(f"[PYBRIDGE] checkAllAIStatus 完成: ollama={result['ollama']['online']}, mimo={result['mimo']['online']}, {result['elapsed_ms']}ms")
            self._reply_thread_safe(callback_id, result)
        
        threading.Thread(target=_check_all, daemon=True).start()

    def _reply(self, callback_id, result):
        """通过 runJavaScript 回调前端（主线程安全）"""
        if callback_id is None:
            return
        try:
            js = f"window._pybridgeCallback && window._pybridgeCallback({callback_id}, {json.dumps(result, ensure_ascii=False)})"
            # QWebEnginePage.runJavaScript 是线程安全的（会自动切到 WebEngine 线程）
            self.web_view.page().runJavaScript(js)
        except Exception as e:
            print(f"[PYBRIDGE] 回调失败: {e}")
    
    def _setup_bridge(self):
        """设置前后端桥接"""
        # 创建QWebChannel
        self._channel = QWebChannel()

        # 导入并创建HybridBridge
        try:
            # ★ 第453章修复：弹性行内路径引导 + 残缺命名空间清缓存
            # GUI 实测出现 ModuleNotFoundError: No module named 'hybrid_mode.core'
            # （启动早期虽有多处 sys.path 引导，但 hybrid_page 创建时仍可能因
            #   引导次序/模块缓存命中残缺命名空间而失败）。
            # 此处按 __file__ 三级 dirname 直算仓库根（与下方 HTML 路径解析器同款
            # 算法，已被验证可靠），强制入 path 并清掉 hybrid_mode 模块缓存。
            _repo_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            if _repo_root not in sys.path:
                sys.path.insert(0, _repo_root)
            for _m in [m for m in list(sys.modules) if m == 'hybrid_mode' or m.startswith('hybrid_mode.')]:
                del sys.modules[_m]
            from hybrid_mode.core.hybrid_mode_bridge import HybridBridge
            self._bridge = HybridBridge(self._engine_manager, self)

            # 注册bridge对象到channel（必须与 HTML 中的 hybridBridge 一致）
            self._channel.registerObject('hybridBridge', self._bridge)

            # 设置channel到web页面
            self.web_view.page().setWebChannel(self._channel)

            # 连接后端信号到前端 JS 全局回调（pyqtSignal 不会通过 QWebChannel 暴露 connect）
            self._connect_signals_to_frontend()

            print("[HybridModeWebPanel] Bridge初始化成功")

        except Exception as e:
            print(f"[HybridModeWebPanel] Bridge初始化失败: {e}")
            import traceback
            traceback.print_exc()
            # ★ 第453章：失败诊断（下次复发可直读根因）
            try:
                _hm_dir = os.path.join(_repo_root, 'hybrid_mode')
                _core_dir = os.path.join(_hm_dir, 'core')
                print(f"[HybridModeWebPanel][诊断] repo_root={_repo_root} 存在={os.path.isdir(_repo_root)}")
                print(f"[HybridModeWebPanel][诊断] hybrid_mode/ 存在={os.path.isdir(_hm_dir)} core/ 存在={os.path.isdir(_core_dir)}")
                print(f"[HybridModeWebPanel][诊断] sys.path 前6项={sys.path[:6]}")
            except Exception:
                logger.debug("suppressed exception")

        # ★ 修复：混合模式 HTML 路径解算（v6 公司模式增强）
        # __file__ = standard_mode/ui/hybrid_mode_web_panel.py
        #   dirname 3 → 仓库根；PyInstaller 打包后 __file__ 落到 bin/_internal/...
        # ★ 窗口3·公司模式：优先加载 company_board.html（固定框架看板），
        #   文件缺失时回落旧 wireframe（保留兜底，绝不白屏）。
        def _resolve_board_html(filename):
            here = os.path.abspath(__file__)
            repo_root = os.path.dirname(os.path.dirname(os.path.dirname(here)))
            candidates = [
                os.path.join(os.path.dirname(here), filename),               # standard_mode/ui/
                os.path.join(repo_root, filename),                            # 仓库根
                os.path.join(os.path.dirname(repo_root), filename),           # 仓库父级（兜底）
                os.path.join(getattr(sys, '_MEIPASS', repo_root),
                             'standard_mode', 'ui', filename),                # PyInstaller 解包目录
                os.path.join(getattr(sys, '_MEIPASS', repo_root), filename),
                os.path.join(os.path.dirname(here), '..', filename),
            ]
            seen = set()
            for c in candidates:
                c_abs = os.path.normpath(c)
                if c_abs in seen:
                    continue
                seen.add(c_abs)
                if os.path.exists(c_abs):
                    return c_abs
            # 兜底：候选未命中，递归向上找，最多 4 层
            cur = here
            for _ in range(5):
                cur = os.path.dirname(cur)
                guess = os.path.join(cur, filename)
                if os.path.exists(guess):
                    return guess
            return None

        # ★ 集群B(公司OS): A9 工作台以仓库根 company_os.html 为准（本窗口改造版），
        #   standard_mode/ui 版（三栏管理台）作次选，company_board/wireframe 兜底。
        html_path = None
        # ★ 第21批（真机入口修复）: repo_root 此前只在内部函数里定义，
        #   外层直接用会 NameError → 公司页整页创建失败（后台 e2e 看不见）。
        repo_root = os.path.dirname(os.path.dirname(os.path.dirname(
            os.path.abspath(__file__))))
        _root_os = os.path.join(repo_root, 'company_os.html')
        if os.path.exists(_root_os):
            html_path = _root_os
        else:
            html_path = _resolve_board_html('company_os.html')      # ★ A9 公司OS 优先
        if html_path is None:
            html_path = _resolve_board_html('company_board.html')  # 固定框架看板次选
        if html_path is None:
            html_path = _resolve_board_html('hybrid_mode_wireframe.html')  # 旧 wireframe 兜底

        if html_path:
            self.web_view.setUrl(QUrl.fromLocalFile(html_path))
            print(f"[HybridModeWebPanel] 加载HTML: {html_path}")
        else:
            # 全候选都没命中 — 显示错误信息（给开发期排查用，绝不会"静默失败"）
            tried = 'company_os.html | company_board.html | hybrid_mode_wireframe.html（均未命中候选路径）'
            error_html = f"""
            <html>
            <body style="background:#0d0d0d;color:#ff6900;font-family:Segoe UI;padding:20px;">
                <h1>混合模式加载失败</h1>
                <p>HTML文件不存在（已尝试：公司模式 company_board.html → 兜底 wireframe）：</p>
                <pre style="background:#1a1a1a;padding:12px;color:#ddd;white-space:pre-wrap;">{tried}</pre>
            </body>
            </html>
            """
            self.web_view.setHtml(error_html)
            print(f"[HybridModeWebPanel] HTML文件不存在（公司模式与兜底 wireframe 均未命中）", flush=True)

        # ★ 窗口3·公司模式：进程内拉起公司服务（SSE 8801-8805）
        #   失败不阻断面板：页面会回落桥轮询（可见时 3s），并在页签如实显示 POLL 状态。
        self._start_company_service()

    def _start_company_service(self):
        """进程内启动 CompanyServer（SSE）。失败如实打印，绝不假装在线。"""
        try:
            from shared.company.server import start_company_server
            svc = self._bridge._company_service() if self._bridge else None
            if svc is None:
                print("[HybridPanel] [WARN] CompanyService 不可用，SSE 未启动（页面回落桥轮询）")
                return
            self._company_server = start_company_server(svc)
            if self._company_server is None:
                print("[HybridPanel] [WARN] 公司服务 8801-8805 全部绑定失败，SSE 未启动（页面回落桥轮询）")
        except Exception as e:
            print(f"[HybridPanel] [WARN] 公司服务启动失败: {e}（页面回落桥轮询）")

    def load_company_os(self):
        """切换到公司 OS 页（★ 集群B: 仓库根 A9 工作台优先，缺失回落 ui 版/固定框架）。"""
        here = os.path.abspath(__file__)
        repo_root = os.path.dirname(os.path.dirname(os.path.dirname(here)))
        path = os.path.join(repo_root, 'company_os.html')
        if not os.path.exists(path):
            path = os.path.join(os.path.dirname(here), 'company_os.html')
        if os.path.exists(path):
            self._btnCompanyOsPage.setChecked(True)
            self._btnCompanyPage.setChecked(False)
            self._btnWireframePage.setChecked(False)
            self.web_view.load(QUrl.fromLocalFile(path))
            print(f"[HybridModeWebPanel] 切换公司OS页: {path}")
        else:
            print("[HybridModeWebPanel] [WARN] company_os.html 不存在，回落固定框架看板")
            self.load_company_board()

    def load_company_board(self):
        """切换到公司模式页（company_board.html；缺失回落 wireframe）。"""
        here = os.path.abspath(__file__)
        repo_root = os.path.dirname(os.path.dirname(os.path.dirname(here)))
        path = os.path.join(os.path.dirname(here), 'company_board.html')
        if not os.path.exists(path):
            path = os.path.join(repo_root, 'company_board.html')
        if os.path.exists(path):
            self._btnCompanyPage.setChecked(True)
            self._btnWireframePage.setChecked(False)
            self.web_view.load(QUrl.fromLocalFile(path))
            print(f"[HybridModeWebPanel] 切换公司模式页: {path}")
        else:
            print("[HybridModeWebPanel] [WARN] company_board.html 不存在，保留旧 wireframe")
            self.load_wireframe()

    def load_wireframe(self):
        """切换回经典 wireframe 页（兜底）。"""
        here = os.path.abspath(__file__)
        repo_root = os.path.dirname(os.path.dirname(os.path.dirname(here)))
        for cand in (os.path.join(repo_root, 'hybrid_mode_wireframe.html'),
                     os.path.join(os.path.dirname(here), '..', 'hybrid_mode_wireframe.html')):
            if os.path.exists(cand):
                self._btnWireframePage.setChecked(True)
                self._btnCompanyPage.setChecked(False)
                self.web_view.load(QUrl.fromLocalFile(os.path.normpath(cand)))
                print(f"[HybridModeWebPanel] 切换经典 wireframe: {cand}")
                return
        print("[HybridModeWebPanel] [WARN] hybrid_mode_wireframe.html 不存在")

    def _connect_signals_to_frontend(self):
        """将 HybridBridge 的 pyqtSignal 通过 runJavaScript 转发到前端全局函数"""
        if not self._bridge:
            return

        import json as _json

        page = self.web_view.page()

        def _js(expr):
            """安全执行 JS，忽略页面未加载时的错误"""
            try:
                page.runJavaScript(expr)
            except Exception as e:
                print(f"[HybridModeWebPanel] runJavaScript 失败: {e}")

        self._bridge.agentStatusChanged.connect(
            lambda agent_id, status, progress:
            _js(f"window.onAgentStatusChanged && window.onAgentStatusChanged({_json.dumps(agent_id)}, {_json.dumps(status)}, {_json.dumps(progress)})")
        )
        self._bridge.chatMessageReceived.connect(
            lambda sender, content, timestamp:
            _js(f"window.onChatMessageReceived && window.onChatMessageReceived({_json.dumps(sender)}, {_json.dumps(content)}, {_json.dumps(timestamp)})")
        )
        self._bridge.monitorDataUpdated.connect(
            lambda json_data:
            _js(f"window.onMonitorDataUpdated && window.onMonitorDataUpdated({_json.dumps(json_data)})")
        )
        self._bridge.workflowStepChanged.connect(
            lambda step_id, status:
            _js(f"window.onWorkflowStepChanged && window.onWorkflowStepChanged({_json.dumps(step_id)}, {_json.dumps(status)})")
        )
        self._bridge.errorOccurred.connect(
            lambda err:
            _js(f"window.onErrorOccurred && window.onErrorOccurred({_json.dumps(err)})")
        )
        self._bridge.agentOutputReceived.connect(
            lambda agent_id, text:
            _js(f"window.onAgentOutputReceived && window.onAgentOutputReceived({_json.dumps(agent_id)}, {_json.dumps(text)})")
        )
        self._bridge.agentThinkingReceived.connect(
            lambda agent_id, thinking:
            _js(f"window.onAgentThinkingReceived && window.onAgentThinkingReceived({_json.dumps(agent_id)}, {_json.dumps(thinking)})")
        )
        # ★ 窗口3·公司模式：注入契约 window.onCompanyState / window.onCompanyEvent
        #   （CompanyService 真实状态/事件 → 页面渲染；页面自身零造数）
        self._bridge.companyStateChanged.connect(
            lambda state_json:
            _js(f"window.onCompanyState && window.onCompanyState({state_json})")
        )
        self._bridge.companyEventReceived.connect(
            lambda event_json:
            _js(f"window.onCompanyEvent && window.onCompanyEvent({event_json})")
        )

        print("[HybridModeWebPanel] 后端信号已连接到前端 JS 回调")

    def get_bridge(self):
        """获取Bridge对象"""
        return self._bridge

    def get_view(self):
        """获取WebEngine视图（供诊断脚本使用）"""
        return self.web_view

    # ============================================================
    # ★ v3.34: 生命周期管理 — 防止后台线程访问已删除对象
    # ============================================================
    def closeEvent(self, event):
        print("[HybridModeWebPanel] 关闭事件，清理资源...")
        self._destroyed = True  # ★ v3.34: 立即标记销毁，阻止后台线程访问
        self._cleanup_resources()
        event.accept()

    def hideEvent(self, event):
        """面板被隐藏时（切换模式），标记为不可用"""
        self._destroyed = True  # ★ v3.34: 隐藏也标记，防止后台线程访问
        super().hideEvent(event)

    def showEvent(self, event):
        """面板再次显示时，重置销毁标志"""
        self._destroyed = False  # ★ v3.34: 重新可用
        super().showEvent(event)

    def _cleanup_resources(self):
        """清理所有资源"""
        # ★ 2026-10：停掉本面板拉起的旁路服务（7790/7791 worker 进程）
        try:
            for proc in getattr(self, "_service_processes", []):
                if proc.poll() is None:
                    proc.terminate()
            self._service_processes = []
        except Exception as e:
            print(f"[HybridModeWebPanel] 停止旁路服务时出错: {e}")
        # ★ 窗口3·公司模式：停公司服务与桥订阅（防回调进已删除对象）
        try:
            if getattr(self, "_company_server", None) is not None:
                self._company_server.stop()
                self._company_server = None
        except Exception as e:
            print(f"[HybridModeWebPanel] 停止公司服务时出错: {e}")
        if self._bridge:
            try:
                if hasattr(self._bridge, 'shutdown'):
                    self._bridge.shutdown()
            except Exception as e:
                print(f"[HybridModeWebPanel] Bridge shutdown 出错: {e}")
            try:
                self._bridge.agentStatusChanged.disconnect()
                self._bridge.chatMessageReceived.disconnect()
                self._bridge.monitorDataUpdated.disconnect()
                self._bridge.workflowStepChanged.disconnect()
                self._bridge.errorOccurred.disconnect()
                self._bridge.agentOutputReceived.disconnect()
                self._bridge.agentThinkingReceived.disconnect()
            except Exception as e:
                print(f"[HybridModeWebPanel] 断开信号时出错: {e}")
            try:
                self._channel.deregisterObject('hybridBridge')
            except Exception as e:
                print(f"[HybridModeWebPanel] 注销对象时出错: {e}")
            self._bridge = None
        if self._channel:
            self._channel = None
        if self.web_view:
            try:
                self.web_view.load(QUrl("about:blank"))
                self.web_view.stop()
                self.web_view.page().setWebChannel(None)
                self.web_view.deleteLater()
            except Exception as e:
                print(f"[HybridModeWebPanel] 清理 WebView 时出错: {e}")
            self.web_view = None
        self._backend_initialized = False
        self._page_loaded = False
        print("[HybridModeWebPanel] 资源清理完成")

    def cleanup(self, soft: bool = False):
        """外部调用清理

        ★ 2026-11-23 修复公司模式黑屏：
          切到标准模式时主窗口曾调用 cleanup() 硬清理 → WebView 被 deleteLater、
          self.web_view=None；再点「公司」只剩页签条（整屏黑）。
          模式切换只是“暂时离开”，必须保留 WebView，只有真正关闭窗口才硬清理。
        """
        self._destroyed = True
        if soft:
            print("[HybridModeWebPanel] 软清理：保留 WebView（切模式可秒回）")
            return
        self._cleanup_resources()