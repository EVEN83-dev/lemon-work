# -*- coding: utf-8 -*-
"""★ 2026-11-22 页面缩放（标准模式 / 公司模式共用）

Ctrl + 滚轮 / Ctrl + 加号减号 缩放页面，Ctrl + 0 复位。
两种模式的 WebView 都调 install_zoom(view) 即可，不改任何 HTML。

实现要点：QWebEngineView 的滚轮/按键会先落到内部 focusProxy
（RenderWidgetHostViewQtDelegateWidget），只装在 view 上收不到事件，
因此 view 与 focusProxy 都要装同一个过滤器。
"""
import logging
logger = logging.getLogger(__name__)
from PyQt5.QtCore import QEvent, QObject, Qt

_MIN_F = 0.5
_MAX_F = 2.5
_STEP = 1.1


class LwZoomFilter(QObject):
    """捕获 Ctrl+滚轮 / Ctrl+± / Ctrl+0，改写 QWebEngineView 的 zoomFactor。"""

    def __init__(self, view, parent=None):
        # 真机传 QWebEngineView（QObject）；防御非 QObject 入参（测试替身）
        _p = parent if isinstance(parent, QObject) else (
            view if isinstance(view, QObject) else None)
        super().__init__(_p)
        self._view = view
        self._factor = 1.0

    def _apply(self):
        try:
            self._view.page().setZoomFactor(self._factor)
        except Exception:
            logger.debug("suppressed exception")

    def _scale(self, up: bool):
        self._factor = (self._factor * _STEP) if up else (self._factor / _STEP)
        self._factor = max(_MIN_F, min(_MAX_F, self._factor))
        self._apply()

    def eventFilter(self, obj, ev):
        try:
            et = ev.type()
            if et == QEvent.Wheel and (ev.modifiers() & Qt.ControlModifier):
                dy = ev.angleDelta().y()
                if dy:
                    self._scale(dy > 0)
                    return True
            if et == QEvent.KeyPress and (ev.modifiers() & Qt.ControlModifier):
                k = ev.key()
                if k in (Qt.Key_Plus, Qt.Key_Equal):
                    self._scale(True)
                    return True
                if k == Qt.Key_Minus:
                    self._scale(False)
                    return True
                if k == Qt.Key_0:
                    self._factor = 1.0
                    self._apply()
                    return True
        except Exception:
            logger.debug("suppressed exception")
        return False


def install_zoom(view):
    """给 QWebEngineView 装 Ctrl+滚轮缩放；返回过滤器实例（已挂到 view 防 GC）。"""
    try:
        f = LwZoomFilter(view)
        view.installEventFilter(f)
        try:
            fp = view.focusProxy()
            if fp is not None:
                fp.installEventFilter(f)
        except Exception:
            logger.debug("suppressed exception")
        view._lw_zoom_filter = f
        return f
    except Exception:
        return None
