@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo [Lemon Work] 调试模式：控制台保留，报错可见。
echo [Lemon Work] 工作目录: %CD%
"%~dp0_py312\python.exe" "%~dp0yh_main.py"
echo.
echo [Lemon Work] 进程已退出，按任意键关闭。
pause >nul
