# -*- coding: utf-8 -*-
"""★ 会话级主从权限引擎（session ACL）—— 全系统唯一权限判定入口。

铁律：
  1. 所有主从读写判定只走本文件四个函数，UI 层 / 路由层 / worker 一律不得自行判断。
  2. 越权（deny）必须同时给出 ①明确错误码 ②审计记录（复用 shared/skill_audit 流）。
  3. 判定依据只有两处真源：data/chat.db 的 session_acl 行 + chat_session.parent_id
     归属关系；任何一层不一致都 fail-closed（宁可拒绝，不放行）。

四个核心判定（任务规格原文语义）：
  can_master_read_child(master, child)          主读子（看板/信件）
  can_master_write_child(master, child)         主写子（下发任务）
  can_child_read_master(child)                  子读主
  can_child_write_master(child, kind)           子写主 —— 默认只放行 kind='result'
                                                （child_can_write_master=1 才放开其他 kind）

错误码（HTTP 层据此映射 403 响应体，UI 层据此展示拦截提示）：
  ACL_ROW_MISSING                 无授权行（从未 link，或已被删除）
  ACL_LINK_BROKEN                 有授权行但 chat_session.parent_id 与之不符（降级/脏数据）
  ACL_READ_DENIED                 授权行存在但 can_read=0
  ACL_WRITE_DENIED                授权行存在但 can_write=0
  ACL_CHILD_READ_MASTER_DENIED    子读主被 child_can_read_master=0 关闭
  ACL_CHILD_WRITE_MASTER_NON_RESULT  子向主发非 result 消息（默认铁律拒绝）
  ACL_PEER_MESSAGE_DENIED         工位互传位 can_peer_message=0（公司默认；
                                  提示语含"消息不等于授权"）
  ACL_COMMAND_DENIED              指令位 can_command=0（工位默认禁下达指令）
  ACL_APPROVE_DENIED              审批位 can_approve=0
  ACL_HANDOFF_DENIED              交接位 can_handoff=0
  SESSION_SELF_LOOP               master 与 child 相同
  SESSION_INVALID_ID              空参/非法参
  SESSION_NOT_FOUND               会话档案不存在

★ 集群B·A9 扩展（公司工位能力位，全部默认 0，fail-closed）：
  session_acl 新列 can_peer_message / can_command / can_approve / can_handoff；
  新动作 check("peer_message"|"command"|"approve"|"handoff", viewer, target)：
    · peer_message / approve / handoff 看主体自身授权行（child_id=viewer）；
    · command 看主→从授权行（master_id=viewer, child_id=target）。
  授权一律经 set_acl() 显式写入；本文件不产生任何隐式授权。

零第三方依赖（stdlib + shared.skill_audit）。
"""
from __future__ import annotations

import os
import sqlite3
import threading
from typing import Any, Dict, Optional, Tuple

from shared.skill_audit import record_skill_audit

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# 错误码（与本文件 docstring 一一对应；HTTP 层不得自造码）
ACL_ROW_MISSING = "ACL_ROW_MISSING"
ACL_LINK_BROKEN = "ACL_LINK_BROKEN"
ACL_READ_DENIED = "ACL_READ_DENIED"
ACL_WRITE_DENIED = "ACL_WRITE_DENIED"
ACL_CHILD_READ_MASTER_DENIED = "ACL_CHILD_READ_MASTER_DENIED"
ACL_CHILD_WRITE_MASTER_NON_RESULT = "ACL_CHILD_WRITE_MASTER_NON_RESULT"
ACL_PEER_MESSAGE_DENIED = "ACL_PEER_MESSAGE_DENIED"
ACL_COMMAND_DENIED = "ACL_COMMAND_DENIED"
ACL_APPROVE_DENIED = "ACL_APPROVE_DENIED"
ACL_HANDOFF_DENIED = "ACL_HANDOFF_DENIED"
SESSION_SELF_LOOP = "SESSION_SELF_LOOP"
SESSION_INVALID_ID = "SESSION_INVALID_ID"
SESSION_NOT_FOUND = "SESSION_NOT_FOUND"
OK = "OK"

# 各动作 → 展示文案（UI 拦截提示直接取这里，不在 UI 层硬编码权限文案）
DENY_MESSAGES = {
    ACL_ROW_MISSING: "该会话尚未建立主从授权（session_acl 无记录）",
    ACL_LINK_BROKEN: "主从关系已失效（会话已取消从属或归属不一致）",
    ACL_READ_DENIED: "主会话读取该子会话的权限已被关闭",
    ACL_WRITE_DENIED: "主会话向该子会话下发的权限已被关闭",
    ACL_CHILD_READ_MASTER_DENIED: "子会话读取主会话的权限已被关闭",
    ACL_CHILD_WRITE_MASTER_NON_RESULT: "子会话只能向主会话回传 result 结果消息",
    ACL_PEER_MESSAGE_DENIED: "工位互传未授权（can_peer_message=0）——消息不等于授权，指令请走主管派发",
    ACL_COMMAND_DENIED: "指令权未授权（can_command=0）——消息不等于授权，不得越级下令",
    ACL_APPROVE_DENIED: "审批权未授权（can_approve=0）——只有 owner/主管可批",
    ACL_HANDOFF_DENIED: "交接权未授权（can_handoff=0）",
    SESSION_SELF_LOOP: "会话不能与自身建立主从关系",
    SESSION_INVALID_ID: "会话标识为空或非法",
    SESSION_NOT_FOUND: "会话不存在",
}

_LOCAL = threading.local()   # 最近一次 deny 判定（HTTP 层取错误码用，线程隔离）

_RESULT_KIND = "result"      # 子→主回传唯一放行的 kind（规格铁律）


# ─────────────────────────── 底层读取（唯一数据入口） ───────────────────────────

def _db_path() -> str:
    """chat.db 路径：env LW_CHAT_DB 是全仓统一覆盖开关（session_mesh/store.py 同源）。"""
    env = os.environ.get("LW_CHAT_DB", "").strip()
    if env:
        return env
    return os.path.join(_PROJECT_ROOT, "data", "chat.db")


def _connect() -> sqlite3.Connection:
    path = _db_path()
    d = os.path.dirname(path)
    if d and not os.path.isdir(d):
        os.makedirs(d, exist_ok=True)
    conn = sqlite3.connect(path, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


_CAP_COLUMNS = ("can_peer_message", "can_command", "can_approve", "can_handoff")


def ensure_acl_schema(conn: Optional[sqlite3.Connection] = None) -> None:
    c = conn or _connect()
    own = conn is None
    try:
        c.executescript("""
CREATE TABLE IF NOT EXISTS session_acl(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  master_id TEXT,
  child_id TEXT,
  can_read INTEGER DEFAULT 1,
  can_write INTEGER DEFAULT 1,
  child_can_read_master INTEGER DEFAULT 1,
  child_can_write_master INTEGER DEFAULT 0,
  can_peer_message INTEGER DEFAULT 0,
  can_command INTEGER DEFAULT 0,
  can_approve INTEGER DEFAULT 0,
  can_handoff INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_session_acl_child ON session_acl(child_id);
CREATE INDEX IF NOT EXISTS idx_session_acl_master ON session_acl(master_id);
""")
        # ★ 迁移：既有库（旧 6 列表）补齐 A9 能力位（全部默认 0，fail-closed）
        existing = {r["name"] for r in c.execute("PRAGMA table_info(session_acl)")}
        for col in _CAP_COLUMNS:
            if col not in existing:
                c.execute(f"ALTER TABLE session_acl ADD COLUMN {col} INTEGER DEFAULT 0")
        c.commit()
    finally:
        if own:
            c.close()


def get_acl(master_id: str, child_id: str,
            conn: Optional[sqlite3.Connection] = None) -> Optional[Dict[str, Any]]:
    own = conn is None
    c = conn or _connect()
    try:
        row = c.execute("SELECT * FROM session_acl WHERE master_id=? AND child_id=?",
                        (master_id, child_id)).fetchone()
        return dict(row) if row else None
    finally:
        if own:
            c.close()


def set_acl(master_id: str, child_id: str, can_read: int = 1, can_write: int = 1,
            child_can_read_master: int = 1, child_can_write_master: int = 0,
            can_peer_message: int = 0, can_command: int = 0,
            can_approve: int = 0, can_handoff: int = 0,
            conn: Optional[sqlite3.Connection] = None) -> Dict[str, Any]:
    """建立/整行覆写授权（link 的唯一写入口；参数缺省即任务规格默认位）。

    ★ A9 公司能力位（can_peer_message/can_command/can_approve/can_handoff）
      默认全 0，fail-closed —— 只有主管经 set_acl 显式授予才放开。
    """
    own = conn is None
    c = conn or _connect()
    try:
        ensure_acl_schema(c)
        c.execute("DELETE FROM session_acl WHERE master_id=? AND child_id=?",
                  (master_id, child_id))
        c.execute("INSERT INTO session_acl(master_id, child_id, can_read, can_write,"
                  " child_can_read_master, child_can_write_master,"
                  " can_peer_message, can_command, can_approve, can_handoff)"
                  " VALUES(?,?,?,?,?,?,?,?,?,?)",
                  (master_id, child_id, int(bool(can_read)), int(bool(can_write)),
                   int(bool(child_can_read_master)), int(bool(child_can_write_master)),
                   int(bool(can_peer_message)), int(bool(can_command)),
                   int(bool(can_approve)), int(bool(can_handoff))))
        c.commit()
        return get_acl(master_id, child_id, conn=c) or {}
    finally:
        if own:
            c.close()


def remove_acl(master_id: str, child_id: str = "",
               conn: Optional[sqlite3.Connection] = None) -> int:
    """解除授权。child_id 为空时解除该主会话的全部授权（删除主会话时用）。"""
    own = conn is None
    c = conn or _connect()
    try:
        ensure_acl_schema(c)
        if child_id:
            cur = c.execute("DELETE FROM session_acl WHERE master_id=? AND child_id=?",
                            (master_id, child_id))
        else:
            cur = c.execute("DELETE FROM session_acl WHERE master_id=?", (master_id,))
        c.commit()
        return cur.rowcount
    finally:
        if own:
            c.close()


def _session_row(session_id: str,
                 conn: Optional[sqlite3.Connection]) -> Optional[Dict[str, Any]]:
    row = conn.execute("SELECT * FROM chat_session WHERE session_id=?",
                       (session_id,)).fetchone()
    return dict(row) if row else None


# ─────────────────────────── 判定漏斗（审计 + 错误码收口） ───────────────────────────

def _audit(action: str, viewer: str, target: str, code: str,
           allowed: bool, kind: str = "") -> None:
    """审计收口：deny 必记；allow 只在显式开启时记（避免流水噪声）。"""
    try:
        record_skill_audit(
            tool_name="session_acl",
            args={"action": action, "viewer": viewer, "target": target,
                  "kind": kind, "code": code},
            success=allowed,
            error=("" if allowed else code),
            source="session_acl",
            session_id=viewer,
        )
    except Exception:
        # 审计失败绝不能改变判定结果本身（skill_audit 内部同样吞掉写失败）；
        # 但这里不能静默 —— 抛给调用方会让权限判定链多一条失败路径，故按
        # skill_audit 的既有口径记入标准错误流而非中断判定。
        import sys
        print("[session_acl] audit write failed", file=sys.stderr)


def check(action: str, viewer: str, target: str = "", kind: str = "",
          audit_all: bool = False) -> Tuple[bool, str]:
    """判定漏斗。返回 (allowed, code)；deny 时错误码与审计必达。

    action ∈ master_read_child / master_write_child / child_read_master /
             child_write_master / peer_message / command / approve / handoff
    （后四者为 A9 公司工位能力位判定，语义见模块 docstring）
    """
    allowed, code = _judge(action, viewer, target, kind)
    if (not allowed) or audit_all:
        _audit(action, viewer, target, code, allowed, kind=kind)
    if not allowed:
        _LOCAL.last_denial = {"action": action, "viewer": viewer,
                              "target": target, "kind": kind, "code": code}
    return allowed, code


def _judge(action: str, viewer: str, target: str, kind: str) -> Tuple[bool, str]:
    if not viewer or not isinstance(viewer, str):
        return False, SESSION_INVALID_ID
    # master→child 方向 target 即子会话，必填；child→master 方向主会话由
    # chat_session.parent_id 推导，target 可为空（填了则用于防指认错主）。
    # A9: command / peer_message 亦需明确 target（指令与互传都要知道对方是谁）。
    needs_target = action in ("master_read_child", "master_write_child",
                              "command", "peer_message")
    if needs_target and (not target or not isinstance(target, str)):
        return False, SESSION_INVALID_ID
    if viewer == target:
        return False, SESSION_SELF_LOOP

    conn = _connect()
    try:
        ensure_acl_schema(conn)
        if action in ("master_read_child", "master_write_child"):
            master, child = viewer, target
            row = get_acl(master, child, conn=conn)
            if row is None:
                return False, ACL_ROW_MISSING
            kid = _session_row(child, conn)
            if kid is None:
                return False, SESSION_NOT_FOUND
            if kid.get("parent_id") != master:
                return False, ACL_LINK_BROKEN
            if action == "master_read_child":
                if int(row["can_read"] or 0) != 1:
                    return False, ACL_READ_DENIED
                return True, OK
            if int(row["can_write"] or 0) != 1:
                return False, ACL_WRITE_DENIED
            return True, OK

        if action in ("child_read_master", "child_write_master"):
            child = viewer
            kid = _session_row(child, conn)
            if kid is None:
                return False, SESSION_NOT_FOUND
            master = kid.get("parent_id") or ""
            if not master:
                return False, ACL_LINK_BROKEN      # 独立会话没有主会话可读写
            if action == "child_write_master" and target and target != master:
                # 子会话只允许回传给自己的主会话，指认其他会话一律按兄弟越权处理
                return False, ACL_ROW_MISSING
            row = get_acl(master, child, conn=conn)
            if row is None:
                return False, ACL_ROW_MISSING
            if action == "child_read_master":
                if int(row["child_can_read_master"] or 0) != 1:
                    return False, ACL_CHILD_READ_MASTER_DENIED
                return True, OK
            # child_write_master：kind 铁律 —— 非 result 一律拒（规格：只允许回传结果）
            if kind != _RESULT_KIND:
                return False, ACL_CHILD_WRITE_MASTER_NON_RESULT
            return True, OK

        # ── A9 公司工位能力位 ──
        if action in ("peer_message", "approve", "handoff"):
            # 主体能力位：看 viewer 自身的授权行（公司工位以 child 身份被授予）
            grant = _grant_row_for(viewer, conn)
            if grant is None:
                return False, ACL_ROW_MISSING
            code_map = {"peer_message": ACL_PEER_MESSAGE_DENIED,
                        "approve": ACL_APPROVE_DENIED,
                        "handoff": ACL_HANDOFF_DENIED}
            if int(grant.get(_CAP_ACTION_BIT[action]) or 0) != 1:
                return False, code_map[action]
            return True, OK

        if action == "command":
            # 指令位：看主→从授权行（viewer 必须是对 target 的授权方）
            row = get_acl(viewer, target, conn=conn)
            if row is None:
                return False, ACL_ROW_MISSING
            if int(row["can_command"] or 0) != 1:
                return False, ACL_COMMAND_DENIED
            return True, OK

        return False, SESSION_INVALID_ID
    finally:
        conn.close()


# A9 能力位映射：动作 → 授权行列名
_CAP_ACTION_BIT = {"peer_message": "can_peer_message", "approve": "can_approve",
                   "handoff": "can_handoff"}


def _grant_row_for(viewer: str,
                   conn: Optional[sqlite3.Connection]) -> Optional[Dict[str, Any]]:
    """主体自身的授权行（child_id=viewer 的最新一条；无则 fail-closed）。"""
    row = conn.execute(
        "SELECT * FROM session_acl WHERE child_id=? ORDER BY id DESC LIMIT 1",
        (viewer,)).fetchone()
    return dict(row) if row else None


def get_caps(viewer: str) -> Dict[str, Any]:
    """读取主体的能力位（无授权行时全部 0 —— fail-closed 口径）。"""
    conn = _connect()
    try:
        ensure_acl_schema(conn)
        grant = _grant_row_for(viewer, conn)
        if grant is None:
            return {col: 0 for col in _CAP_COLUMNS}
        return {col: int(grant.get(col) or 0) for col in _CAP_COLUMNS}
    finally:
        conn.close()


# ─────────────────────────── 四个核心判定（对外的唯一入口） ───────────────────────────

def can_master_read_child(master: str, child: str) -> bool:
    return check("master_read_child", master, child)[0]


def can_master_write_child(master: str, child: str) -> bool:
    return check("master_write_child", master, child)[0]


def can_child_read_master(child: str) -> bool:
    return check("child_read_master", child, "")[0]


def can_child_write_master(child: str, kind: str = "") -> bool:
    return check("child_write_master", child, "", kind=kind)[0]


# ── A9 公司工位能力位判定（对外入口；授权仍只经 set_acl 显式写入） ──

def can_peer_message(actor: str, peer: str) -> bool:
    """工位互传（默认 0 —— 消息不等于授权）。"""
    return check("peer_message", actor, peer)[0]


def can_command(sender: str, target: str) -> bool:
    """下达指令（默认 0 —— 指令必须走主管派发链）。"""
    return check("command", sender, target)[0]


def can_approve(actor: str) -> bool:
    """审批能力位（scope 级判定在公司层由 shared.company.org.can_approve 收口）。"""
    return check("approve", actor)[0]


def can_handoff(actor: str) -> bool:
    """文件/任务交接能力位。"""
    return check("handoff", actor)[0]


# ─────────────────────────── 供 HTTP 层取详细信息 ───────────────────────────

def last_denial() -> Dict[str, Any]:
    """当前线程最近一次 deny 的详情（code + 各方 id）；无则返回空 dict。"""
    return dict(getattr(_LOCAL, "last_denial", None) or {})


def deny_message(code: str) -> str:
    return DENY_MESSAGES.get(code, code)
