# -*- coding: utf-8 -*-
"""★ A6: 抽取与质量分

quality 0-1 公式（写进注释）：
  正文长度分档 0.4 + 段落数 0.2 + 有标题 0.2 + 元数据完整度 0.2
  - 链接占比惩罚（上限 0.2）
禁止：随机数/时间参与质量分；把 quality 当成功率
"""
from __future__ import annotations

import re
from typing import Dict
from urllib.parse import urlparse


def extract_meta(raw: str, url: str) -> Dict:
    """title/author/published_at/summary/og:*"""
    out = {"title": "", "author": "", "published_at": "", "summary": "", "og": {}}
    if not raw:
        return out
    m = re.search(r"<title[^>]*>(.*?)</title>", raw, re.I | re.S)
    out["title"] = _unescape(m.group(1)).strip()[:120] if m else ""

    # og:title
    for m in re.finditer(r'<meta[^>]+property=["\']og:title["\'][^>]+content=["\']([^"\']*)["\']', raw, re.I):
        out["og"]["title"] = _unescape(m.group(1))[:120]
    # og:description
    for m in re.finditer(r'<meta[^>]+property=["\']og:description["\'][^>]+content=["\']([^"\']*)["\']', raw, re.I):
        out["og"]["description"] = _unescape(m.group(1))[:300]
    # author
    for m in re.finditer(r'<meta[^>]+name=["\']author["\'][^>]+content=["\']([^"\']*)["\']', raw, re.I):
        out["author"] = _unescape(m.group(1)).strip()[:80]
    # published_at
    for pat in (r'<meta[^>]+property=["\']article:published_time["\'][^>]+content=["\']([^"\']*)["\']',
                r'<meta[^>]+name=["\']publishdate["\'][^>]+content=["\']([^"\']*)["\']',
                r'<time[^>]+datetime=["\']([^"\']+)["\']'):
        m = re.search(pat, raw, re.I)
        if m:
            out["published_at"] = _unescape(m.group(1)).strip()[:40]
            break
    out["summary"] = (out["og"].get("description") or "")[:300]
    return out


def _unescape(s: str) -> str:
    import html as _h
    return _h.unescape(s or "")


def count_features(raw: str, text: str) -> Dict:
    """计数：text_len / img_count / link_count / 段落数"""
    img_count = len(re.findall(r"<img\b", raw or "", re.I))
    link_count = len(re.findall(r"<a\b[^>]+href=", raw or "", re.I))
    # 段落：<p> 标签数（去重空段）
    paragraphs = len([p for p in re.findall(r"<p\b[^>]*>(.*?)</p>", raw or "", re.I | re.S)
                      if len(re.sub(r"<[^>]+>", "", p).strip()) > 10])
    return {
        "text_len": len(text or ""),
        "img_count": img_count,
        "link_count": link_count,
        "paragraphs": paragraphs,
    }


def quality_score(text: str, has_title: bool, meta_complete: float,
                  link_ratio: float) -> float:
    """quality 0-1

    正文长度分档 0.4：
      <200 字 → 0.0
      200-800 → 0.15
      800-2000 → 0.3
      >=2000 → 0.4
    段落数 0.2：>=3 段 → 0.2；1-2 段 → 0.1；0 → 0
    有标题 0.2：True → 0.2
    元数据完整度 0.2：meta_complete (0-1) * 0.2
    链接占比惩罚（上限 0.2）：min(0.2, max(0, link_ratio - 0.3))
    """
    n = len(text or "")
    if n < 200:
        len_score = 0.0
    elif n < 800:
        len_score = 0.15
    elif n < 2000:
        len_score = 0.3
    else:
        len_score = 0.4
    # 段落数从调用方传入更准确；这里用文本行数近似
    para_score = 0.0  # 由调用方覆盖
    title_score = 0.2 if has_title else 0.0
    meta_score = float(meta_complete or 0.0) * 0.2
    penalty = min(0.2, max(0.0, float(link_ratio or 0.0) - 0.3))
    q = len_score + para_score + title_score + meta_score - penalty
    return max(0.0, min(1.0, round(q, 3)))


def compute_quality(text: str, has_title: bool, meta: Dict,
                    link_count: int, paragraphs: int) -> float:
    """完整质量分（含段落与元数据完整度）"""
    n = len(text or "")
    if n < 200:
        len_score = 0.0
    elif n < 800:
        len_score = 0.15
    elif n < 2000:
        len_score = 0.3
    else:
        len_score = 0.4
    if paragraphs >= 3:
        para_score = 0.2
    elif paragraphs >= 1:
        para_score = 0.1
    else:
        para_score = 0.0
    title_score = 0.2 if has_title else 0.0
    meta_fields = [meta.get("author"), meta.get("published_at"), meta.get("summary")]
    meta_complete = sum(1 for x in meta_fields if x) / 3.0
    meta_score = meta_complete * 0.2
    link_ratio = (link_count / max(1, paragraphs))
    penalty = min(0.2, max(0.0, link_ratio - 0.3))
    q = len_score + para_score + title_score + meta_score - penalty
    return max(0.0, min(1.0, round(q, 3)))


def extract_structured(raw_html: str, text: str, url: str, schema: Dict,
                       *, use_llm: bool = False, **kw) -> Dict:
    """★ 2026-11-11 升级 A 接线点：结构化抽取统一入口。

    use_llm=False（默认）→ 与旧版 extract_meta 逐字等价，零行为变化；
    use_llm=True → 走 extract_llm 的 LLM schema 抽取，失败自动降级规则式。
    调用方：fetch.py / 爬虫技能；详见 docs/QUANT_AGENT_UPGRADE.md。
    """
    from .extract_llm import extract_structured as _llm_extract
    return _llm_extract(raw_html, text, url, schema, use_llm=use_llm, **kw)


# ── 自检 ──
if __name__ == "__main__":
    short = "x" * 100
    mid = ("<p>" + "内容" * 300 + "</p>") * 4
    long_p = ("<p>" + "段落" * 500 + "</p>") * 5
    q0 = compute_quality(short, False, {}, 10, 0)
    q1 = compute_quality(mid, True, {"author": "a"}, 5, 4)
    q2 = compute_quality(long_p, True, {"author": "a", "published_at": "2026"}, 2, 5)
    print(f"短: {q0} / 中: {q1} / 长: {q2}")
    print("排序正确:", q2 > q1 > q0)
    print("空页:", compute_quality("", False, {}, 0, 0))
