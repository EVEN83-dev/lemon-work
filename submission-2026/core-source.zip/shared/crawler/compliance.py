# -*- coding: utf-8 -*-
"""★ W22-5: 域名合规台账（ToS/授权/限速）

- 新表 crawl_domain_policy(domain PK, allowed, rate_limit_s, license,
  tos_url, contact, note, updated_at)
- is_allowed(domain) / rate_limit(domain)
- gate 前置检查：allowed=0 → 拒绝 reason=domain_policy_denied
- 未配置域名不受影响
- 禁止：把台账当法律意见；自动抓取 ToS 页面代替人工确认
"""
from __future__ import annotations

import os
import time
from typing import Optional

try:
    from .store import conn, ensure_schema
except ImportError:
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from shared.crawler.store import conn, ensure_schema

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_DB = os.path.join(_ROOT, "data", "crawl.db")


def _ddl(db_path=None):
    """建 crawl_domain_policy 表（幂等）"""
    ensure_schema(db_path)
    c = conn(db_path)
    c.execute("""
        CREATE TABLE IF NOT EXISTS crawl_domain_policy(
            domain TEXT PRIMARY KEY,
            allowed INTEGER DEFAULT 1,
            rate_limit_s REAL DEFAULT 1.5,
            license TEXT,
            tos_url TEXT,
            contact TEXT,
            note TEXT,
            updated_at TEXT
        )
    """)
    c.commit()


def set_policy(domain: str, allowed: bool = True, rate_limit_s: float = 1.5,
               license: str = "", tos_url: str = "", contact: str = "",
               note: str = "", db_path: Optional[str] = None) -> dict:
    """设置域名合规策略"""
    _ddl(db_path)
    c = conn(db_path)
    c.execute(
        """INSERT INTO crawl_domain_policy(domain,allowed,rate_limit_s,license,
           tos_url,contact,note,updated_at)
           VALUES(?,?,?,?,?,?,?,?)
           ON CONFLICT(domain) DO UPDATE SET allowed=excluded.allowed,
           rate_limit_s=excluded.rate_limit_s, license=excluded.license,
           tos_url=excluded.tos_url, contact=excluded.contact,
           note=excluded.note, updated_at=excluded.updated_at""",
        (domain, 1 if allowed else 0, float(rate_limit_s), license,
         tos_url, contact, note, time.strftime("%Y-%m-%d %H:%M:%S")))
    c.commit()
    return {"ok": True, "domain": domain}


def get_policy(domain: str, db_path: Optional[str] = None) -> Optional[dict]:
    _ddl(db_path)
    c = conn(db_path)
    r = c.execute("SELECT * FROM crawl_domain_policy WHERE domain=?",
                  (domain,)).fetchone()
    return dict(r) if r else None


def list_policies(db_path: Optional[str] = None) -> list:
    _ddl(db_path)
    c = conn(db_path)
    return [dict(r) for r in c.execute(
        "SELECT * FROM crawl_domain_policy ORDER BY domain").fetchall()]


def is_allowed(domain: str, db_path: Optional[str] = None) -> bool:
    """未配置 → True（不受影响）；配置且 allowed=0 → False"""
    p = get_policy(domain, db_path=db_path)
    if p is None:
        return True
    return bool(p.get("allowed", 1))


def rate_limit(domain: str, default: float = 1.5,
               db_path: Optional[str] = None) -> float:
    p = get_policy(domain, db_path=db_path)
    if p is None:
        return float(default)
    return float(p.get("rate_limit_s", default))


def gate_check(url: str, db_path: Optional[str] = None) -> dict:
    """gate 前置检查：域名策略"""
    from urllib.parse import urlparse
    domain = (urlparse(url).hostname or "").lower()
    if not is_allowed(domain, db_path=db_path):
        return {"ok": False, "reason": "domain_policy_denied",
                "domain": domain,
                "message": f"域名 {domain} 已被合规台账标记为不允许抓取"}
    return {"ok": True, "domain": domain,
            "rate_limit_s": rate_limit(domain, db_path=db_path)}


if __name__ == "__main__":
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        db = os.path.join(td, "t.db")
        print("未配置:", is_allowed("example.com", db_path=db))
        set_policy("bad.com", allowed=False, db_path=db)
        print("denied 后:", is_allowed("bad.com", db_path=db))
        print("gate:", gate_check("https://bad.com/x", db_path=db))
        set_policy("slow.com", rate_limit_s=3.0, db_path=db)
        print("限速:", rate_limit("slow.com", db_path=db))
