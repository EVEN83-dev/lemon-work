# -*- coding: utf-8 -*-
"""★ A4: 队列与线程池

- queue.Queue + worker（默认 2，上限 4），daemon=True
- frontier 持久化在 crawl_edge：入队 pending，完成 done/failed
- resume 从 crawl_edge 重建 pending，已 done 不重抓
- 背压：pending>1000 暂停入队；单会话 30 分钟硬超时
- max_pages/max_depth 双硬顶
- stop() 置 stopping，等 inflight 完成再收尾
- 禁止：网络请求放 GUI 线程；无限入队
"""
from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

import json
import os
import queue
import threading
import time
from typing import Optional


# A-07: 活动引擎注册表（session_id → CrawlEngine）—— pause/resume/status 的
# 控制面由此寻址；会话结束自动注销。
_LIVE_ENGINES: dict = {}

try:
    from . import (ST_QUEUED, ST_RUNNING, ST_PAUSED, ST_STOPPING,
                   ST_COMPLETED, ST_FAILED, ST_CANCELLED, MAX_PAGES, MAX_DEPTH,
                   MAX_WORKERS, SESSION_TIMEOUT_MIN, EV_SESSION_START,
                   EV_PAGE_START, EV_PAGE_DONE, EV_PAGE_FAIL, EV_SESSION_DONE,
                   EV_CONTROL)
    from .store import conn, ensure_schema
    from . import session as _session
except ImportError:
    import sys, os
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from shared.crawler import (ST_QUEUED, ST_RUNNING, ST_PAUSED, ST_STOPPING,
                                ST_COMPLETED, ST_FAILED, ST_CANCELLED, MAX_PAGES,
                                MAX_DEPTH, MAX_WORKERS, SESSION_TIMEOUT_MIN,
                                EV_SESSION_START, EV_PAGE_START, EV_PAGE_DONE,
                                EV_PAGE_FAIL, EV_SESSION_DONE, EV_CONTROL)
    from shared.crawler.store import conn, ensure_schema
    from shared.crawler import session as _session

_PENDING_CAP = 1000


class CrawlEngine:
    """单会话爬取引擎"""

    def __init__(self, session_id: str, fetch_fn, parse_fn=None,
                 workers: int = 2, db_path: Optional[str] = None,
                 event_cb=None, delay_ms: int = 0):
        ensure_schema(db_path)
        self.session_id = session_id
        self.fetch_fn = fetch_fn
        self.parse_fn = parse_fn
        self.workers = max(1, min(int(workers), MAX_WORKERS))
        self.db_path = db_path
        self.event_cb = event_cb
        self.q = queue.Queue()
        self.stop_flag = threading.Event()
        self.pause_flag = threading.Event()   # A-07: 控制面 —— 置位后 worker 挂起取件
        self.timeout_at = None
        self.inflight = 0
        self.inflight_lock = threading.Lock()
        # ★ crawl_audit P1-3: 域限速执行 —— delay_ms 此前只在 config 里存值，
        #   全链路无消费点（UI 却显示 rate 1.5s/req）。0 = 不限速（既有测试行为不变）。
        self._delay_ms = max(0, int(delay_ms or 0))
        self._throttle_lock = threading.Lock()
        self._last_req = {}   # domain -> 已预占的下一请求起点 (time.time())
        # ★ 本窗口（项49）: 单域并发 1 —— 每域一把真实锁，同域同时只有一页在抓
        self._domain_slots = {}
        self._domain_slots_guard = threading.Lock()
        self.pages_done = 0
        self.pages_started = 0
        self.pages_ok = 0
        self.pages_fail = 0
        self.pages_dup = 0   # ★ D3-04: 真实去重命中计数（dedup_hit）
        # ★ 本窗口（项1-7）: 判定管线计数（真实来源，供自测/验收断言）
        self.judged_rule = 0
        self.judged_model = 0
        self.judged_human = 0
        self._threads = []
        self._max_pages = MAX_PAGES
        self._max_depth = MAX_DEPTH

    def _domain_slot(self, domain: str) -> threading.Lock:
        """单域并发 1（项49）：每域一把锁；同域第二线程会阻塞等第一页收尾。"""
        if not domain:
            domain = "(unknown)"
        with self._domain_slots_guard:
            lock = self._domain_slots.get(domain)
            if lock is None:
                lock = threading.Lock()
                self._domain_slots[domain] = lock
            return lock

    def _throttle(self, domain: str) -> float:
        """★ P1-3: 每域请求起点间隔 >= delay_ms（锁内预占槽位、锁外睡眠，
        不同域互不阻塞；返回实际等待秒数）。"""
        interval = self._delay_ms / 1000.0
        if interval <= 0 or not domain:
            return 0.0
        with self._throttle_lock:
            start = max(time.time(), self._last_req.get(domain, 0.0) + interval)
            self._last_req[domain] = start   # 预占：同域后续请求在此之后串行排队
        remain = start - time.time()
        if remain > 0:
            time.sleep(remain)
        return remain

    def _emit(self, ev_type, payload):
        # ★ A-08 修复：payload 统一注入 session_id —— live_bridge._on_event 等消费方
        #   靠 session_id 路由卡片；W3 直通回调此前因缺 sid 全部早退（卡片零数据）
        payload = {"session_id": self.session_id, **(payload or {})}
        if self.event_cb:
            try:
                self.event_cb(ev_type, payload)
            except Exception as _exc:
                logger.debug("[A-15] engine.py:80 _emit 异常已结构化记录: %s", _exc)

    def enqueue(self, url: str, depth: int = 0, from_page_id=None) -> bool:
        """入队；pending>1000 返回 False（背压）"""
        c = conn(self.db_path)
        cnt = c.execute("SELECT COUNT(*) n FROM crawl_edge WHERE session_id=? AND state='pending'",
                        (self.session_id,)).fetchone()["n"]
        if cnt >= _PENDING_CAP:
            return False
        try:
            from .urls import url_key as _uk
            key = _uk(url)
        except ImportError:
            from shared.crawler.urls import url_key as _uk
            key = _uk(url)
        # ★ 合法爬行：同一会话同一 url_key 只入队一次。
        #   原实现仅靠落库唯一索引去重，但重复请求已经发出，会给目标站点重复施压
        #   （实测 13 次请求中 7 次为重复页）。此处在入队前拦截。
        exists = c.execute(
            "SELECT 1 FROM crawl_edge WHERE session_id=? AND to_url_key=? LIMIT 1",
            (self.session_id, key)).fetchone()
        if exists:
            return False
        c.execute(
            "INSERT INTO crawl_edge(session_id,from_page_id,to_url,to_url_key,depth,state) "
            "VALUES(?,?,?,?,?,?)",
            (self.session_id, from_page_id, url, key, depth, "pending"))
        c.commit()
        self.q.put((url, depth, from_page_id))
        return True

    def _worker(self):
        while not self.stop_flag.is_set():
            if self.pause_flag.is_set():   # A-07: 暂停时不取新件，在途任务照常收尾
                time.sleep(0.2)
                continue
            try:
                url, depth, from_id = self.q.get(timeout=1.0)
            except queue.Empty:
                continue
            with self.inflight_lock:
                self.inflight += 1
            try:
                self._process(url, depth, from_id)
            finally:
                with self.inflight_lock:
                    self.inflight -= 1
                self.q.task_done()

    def _process(self, url, depth, from_id):
        if self.timeout_at and time.time() > self.timeout_at:
            self._save_failure(url, depth, "session_timeout", "timeout")
            self._mark_edge(url, "failed", from_id)
            self.pages_done += 1
            self.pages_fail += 1
            self._emit(EV_PAGE_FAIL, {"url": url, "error": "session_timeout"})
            return
        # ★ W25-H: fetch 前预留 slot，失败页也计入 max_pages，保证总行数 <= max_pages
        with self.inflight_lock:
            if self.pages_started >= self._max_pages:
                self._mark_edge(url, "skipped", from_id)
                return
            self.pages_started += 1
        self._emit(EV_PAGE_START, {"url": url, "depth": depth})
        # ★ P1-3: 域限速 —— 同域请求起点间隔 >= delay_ms（在发请求前等待）
        try:
            from urllib.parse import urlparse as _up
            self._throttle((_up(url).hostname or "").lower())
        except Exception as _exc:
            logger.debug("[A-15] engine.py:_throttle 异常已结构化记录: %s", _exc)
        # ★ 本窗口（项49）: 单域并发 1 —— 同域 fetch+解析+落库全程串行
        #   （锁覆盖真实网络请求；不同域互不阻塞）
        try:
            from urllib.parse import urlparse as _up2
            _dom = (_up2(url).hostname or "").lower() or "(unknown)"
        except Exception:
            _dom = "(unknown)"
        with self._domain_slot(_dom):
            try:
                result = self.fetch_fn(url, depth)
            except Exception as e:
                self._save_failure(url, depth, str(e)[:200], "engine")
                self._mark_edge(url, "failed", from_id)
                self.pages_done += 1
                self.pages_fail += 1
                self._emit(EV_PAGE_FAIL, {"url": url, "error": str(e)[:200]})
                return
            # ★ W25-H: 跨域/过滤页不落库、不占 max_pages（释放预留）
            if result.get("no_save"):
                with self.inflight_lock:
                    self.pages_started = max(0, self.pages_started - 1)
                self._mark_edge(url, "skipped", from_id)
                return
            try:
                from .store import save_page, save_content
            except ImportError:
                from shared.crawler.store import save_page, save_content
            row = {
                "session_id": self.session_id,
                "url": url,
                "url_key": result.get("url_key"),
                "content_hash": result.get("content_hash"),
                "domain": result.get("domain"),
                "depth": depth,
                "status": result.get("status", "ok"),
                "http_status": result.get("http_status"),
                "mode": result.get("mode"),
                "title": result.get("title"),
                "author": result.get("author"),
                "published_at": result.get("published_at"),
                "summary": result.get("summary"),
                "text_len": result.get("text_len", 0),
                "img_count": result.get("img_count", 0),
                "link_count": result.get("link_count", 0),
                "quality": result.get("quality", 0.0),
                "elapsed_ms": result.get("elapsed_ms", 0),
                "size_bytes": result.get("size_bytes", 0),
                "error": result.get("error"),
                "fetched_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                # ★ W24-1: 条件请求 + 失败分类
                "etag": result.get("etag", ""),
                "last_modified": result.get("last_modified", ""),
                "not_modified": 1 if result.get("status") == "not_modified" else 0,
                "failure_type": result.get("failure_type", ""),
            }
            saved = save_page(row, db_path=self.db_path)
            # ★ W25-H: 每页完成后写域指标（此前 record_page 从未被调用）
            try:
                from .metrics import record_page as _record_metric
                _record_metric(
                    result.get("domain") or "",
                    float(result.get("elapsed_ms", 0) or 0),
                    result.get("status", ""),
                    bool(result.get("text_len", 0)),
                    result.get("failure_type", ""),
                    db_path=self.db_path,
                )
            except Exception as _exc:
                logger.debug("[A-15] engine.py:196 _process 异常已结构化记录: %s", _exc)
            if result.get("clean_html") is not None:
                try:
                    save_content(saved["id"], result.get("clean_html", ""),
                                 result.get("text", ""), result.get("meta", {}),
                                 db_path=self.db_path)
                except Exception as _exc:
                    logger.debug("[A-15] engine.py:203 _process 异常已结构化记录: %s", _exc)
            # ★ 本窗口（项1-7）: 判定管线（在域槽内 —— 与 fetch 同域串行）
            self._finish_page(url, depth, from_id, result, saved)
        # 域槽外：链接入队（不占用抓取并发）
        if depth < self._max_depth and result.get("links"):
            for link in result["links"]:
                if self._within_limits():
                    self.enqueue(link, depth + 1, saved["id"])

    def _finish_page(self, url, depth, from_id, result, saved):
        """★ 本窗口（项1-7）: 判定管线 —— 抓取成功并解析后真实判定并回写。

        规则判定（board_data.judge 单一真源）：
          KEEP/CUT（明确档）→ judge_route='rule'，p=quality；
        灰区（MAYBE）→ 二级分流：
          模型判定开启（LEMON_CRAWL_MODEL_JUDGE=1 或 LEMON_EXTRACT_LLM=1）
            → extract_llm.judge_with_model → route='model'，p=模型置信度；
          模型不可用/失败 → route='human'，needs_review=1（等人确认）。
        每次判定写 crawl_judge_event（question/p/route/source；同页同问只留
        最终判定，项7）。规则与模型两路分别埋点（项6）。"""
        from .board_data import judge as _rule_judge
        from .store import set_judge_route, record_judge_event
        doc = {"status": result.get("status"), "quality": result.get("quality"),
               "text_len": result.get("text_len", 0)}
        verdict = _rule_judge(doc)
        self.pages_done += 1   # ★ 本页已处理（判定管线与状态分支共用入口）
        p_rule = round(float(result.get("quality") or 0), 4)
        question = "该页是否值得保留（KEEP/MAYBE/CUT）"
        route, p, source, needs_review = "rule", p_rule, "rule_engine", False

        if verdict == "MAYBE":
            model_on = (os.environ.get("LEMON_CRAWL_MODEL_JUDGE", "") == "1"
                        or os.environ.get("LEMON_EXTRACT_LLM", "") == "1")
            if model_on:
                try:
                    from .extract_llm import judge_with_model
                    mj = judge_with_model(
                        str(result.get("text") or result.get("summary") or "")[:6000],
                        session_id=self.session_id, db_path=self.db_path)
                    if mj.get("ok") and mj.get("p") is not None:
                        verdict = mj["verdict"]       # 模型可改判（MAYBE→KEEP/CUT）
                        route, p, source = "model", round(float(mj["p"]), 4), mj["source"]
                        self.judged_model += 1
                    else:
                        route, p, source = "human", None, "model_failed"
                        needs_review = True
                        self.judged_human += 1
                except Exception as _exc:
                    logger.debug("[A-15] engine 判定管线模型分支异常: %s", _exc)
                    route, p, source = "human", None, "model_error"
                    needs_review = True
                    self.judged_human += 1
            else:
                route, p, source = "human", None, "gray_zone"
                needs_review = True
                self.judged_human += 1
        else:
            self.judged_rule += 1

        try:
            set_judge_route(saved["id"], route, needs_review=needs_review,
                            db_path=self.db_path)
            record_judge_event(self.session_id, saved["id"], question, p,
                               route, source, db_path=self.db_path)
        except Exception as _exc:
            logger.debug("[A-15] engine 判定回写异常: %s", _exc)
        # ★ W24-1: not_modified 不计入 fail
        if result.get("status") == "not_modified":
            self.pages_ok += 1
            self._emit(EV_PAGE_DONE, {
                "url": url, "title": result.get("title"),
                "domain": result.get("domain"), "text_len": 0,
                "elapsed_ms": result.get("elapsed_ms", 0),
                "quality": 0.0, "page_id": saved["id"],
                "mode": "", "size_bytes": result.get("size_bytes", 0),
                "dup": False, "not_modified": True,
            })
            self._mark_edge(url, "done", from_id)
        elif result.get("status") == "ok" and saved["dup"]:
            # ★ W25-H: 同 URL 重复抓取是 dedup，不是 fail
            # ★ D3-04: 补发 PAGE_DONE（dup=True）+ dedup_hit 计数，
            #   否则 live_bridge dedup_hit 恒 0、进度环不透传。
            self.pages_ok += 1
            self.pages_dup += 1
            self._emit(EV_PAGE_DONE, {
                "url": url, "title": result.get("title"),
                "domain": result.get("domain"), "text_len": 0,
                "elapsed_ms": result.get("elapsed_ms", 0),
                "quality": 0.0, "page_id": saved["id"],
                "mode": "", "size_bytes": 0, "dup": True,
            })
            self._mark_edge(url, "done", from_id)
        elif result.get("status") == "ok" and not saved["dup"]:
            self.pages_ok += 1
            self._emit(EV_PAGE_DONE, {
                "url": url, "title": result.get("title"),
                "domain": result.get("domain"), "text_len": result.get("text_len", 0),
                "elapsed_ms": result.get("elapsed_ms", 0),
                "quality": result.get("quality", 0.0), "page_id": saved["id"],
                # ★ W3: 补 mode / size_bytes / dup（Live 卡桥需要）
                "mode": result.get("mode", ""),
                "size_bytes": result.get("size_bytes", 0),
                "dup": saved.get("dup", False),
            })
        else:
            self.pages_fail += 1
            self._emit(EV_PAGE_FAIL, {"url": url, "error": result.get("error", "dup")})
        self._mark_edge(url, "done" if result.get("status") == "ok" else "failed", from_id)

    def _within_limits(self) -> bool:
        return self.pages_started < self._max_pages

    def _save_failure(self, url, depth, error, failure_type="engine"):
        """★ W25-H: 引擎级异常也落一行 fail，避免 total/ok/fail 对不上。"""
        from urllib.parse import urlparse
        from .store import save_page
        from .urls import url_key
        row = {
            "session_id": self.session_id,
            "url": url,
            "url_key": url_key(url),
            "domain": (urlparse(url).hostname or "").lower(),
            "depth": depth,
            "status": "fail",
            "error": str(error)[:200],
            "failure_type": failure_type,
            "text_len": 0,
            "elapsed_ms": 0,
            "size_bytes": 0,
            "fetched_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        last = None
        for _ in range(3):
            try:
                save_page(row, db_path=self.db_path)
                return
            except Exception as e:
                last = e
                time.sleep(0.2)
        print(f"[engine] save_failure failed: {last}")

    def _mark_edge(self, url, state, from_id):
        try:
            from .urls import url_key as _uk
            key = _uk(url)
        except ImportError:
            from shared.crawler.urls import url_key as _uk
            key = _uk(url)
        c = conn(self.db_path)
        c.execute("UPDATE crawl_edge SET state=? WHERE session_id=? AND to_url_key=?",
                  (state, self.session_id, key))
        c.commit()

    def run(self, max_pages: int = MAX_PAGES, max_depth: int = MAX_DEPTH,
            seed_urls=None, timeout_min: int = SESSION_TIMEOUT_MIN):
        self._max_pages = max_pages
        self._max_depth = max_depth
        self.timeout_at = time.time() + timeout_min * 60
        _session.transition(self.session_id, ST_RUNNING, db_path=self.db_path)
        self.pause_flag.clear()
        _LIVE_ENGINES[self.session_id] = self   # A-07: 控制面可寻址
        try:
            return self._run_inner(max_pages, seed_urls)
        finally:
            _LIVE_ENGINES.pop(self.session_id, None)

    def _run_inner(self, max_pages: int, seed_urls):
        self._emit(EV_SESSION_START, {"session_id": self.session_id})
        try:
            from shared.jsonl_log import log_event
            log_event("crawl.session_start", session=self.session_id,
                      workers=self.workers)
        except Exception:
            logger.debug("crawl start log failed", exc_info=True)
        for u in (seed_urls or []):
            if self._within_limits():
                self.enqueue(u, 0)
        for _ in range(self.workers):
            t = threading.Thread(target=self._worker, daemon=True)
            t.start()
            self._threads.append(t)
        self.q.join()
        self.stop_flag.set()
        for t in self._threads:
            t.join(timeout=2.0)
        _session.transition(self.session_id, ST_STOPPING, db_path=self.db_path)
        _session.update_progress(self.session_id, total=self.pages_done,
                                 ok=self.pages_ok, fail=self.pages_fail,
                                 dedup_hit=self.pages_dup,
                                 db_path=self.db_path)
        # ★ 本窗口（项10）: 会话结束写 crawl_session 真实汇总
        #   （pages/bytes/keep/maybe/cut —— 全部来自 crawl_page 真实行聚合）
        try:
            from .store import write_session_summary
            summary = write_session_summary(self.session_id, db_path=self.db_path)
        except Exception as _exc:
            logger.debug("[A-15] engine 会话汇总写库异常: %s", _exc)
            summary = {}
        # ★ 本窗口（项14）: 库超 100MB 自动按 session 归档（幂等；越界才动库）
        try:
            from .store import archive_if_large
            archive_if_large(db_path=self.db_path)
        except Exception as _exc:
            logger.debug("[A-15] engine 归档检查异常: %s", _exc)
        # ★ W25-H: 允许少量页面失败（<=20%），避免一次超时把整批判死
        fail_tolerant = max(1, self.pages_done // 5)
        final = ST_COMPLETED if (self.pages_done > 0 and
                                 self.pages_fail <= fail_tolerant) else ST_FAILED
        _session.transition(self.session_id, final, db_path=self.db_path)
        self._emit(EV_SESSION_DONE, {
            "session_id": self.session_id, "total": self.pages_done,
            "ok": self.pages_ok, "fail": self.pages_fail,
            "state": final,  # ★ 终态透传：Live 卡不再硬编码 COMPLETED
            "judged": {"rule": self.judged_rule, "model": self.judged_model,
                       "human": self.judged_human},   # ★ 判定管线真实计数
            "summary": summary,
        })
        try:
            from shared.jsonl_log import log_event
            log_event("crawl.session_done", session=self.session_id,
                      total=self.pages_done, ok=self.pages_ok,
                      fail=self.pages_fail, state=final)
        except Exception:
            logger.debug("crawl done log failed", exc_info=True)
        return {"total": self.pages_done, "ok": self.pages_ok,
                "fail": self.pages_fail}

    def stop(self):
        """置 stopping，等 inflight 完成再收尾

        A-07: 先清暂停位并排空未取件（修复暂停/积压时 q.join() 卡死）；
        未取件边标记 cancelled，不计失败。
        """
        _session.transition(self.session_id, ST_STOPPING, db_path=self.db_path)
        self.stop_flag.set()
        self.pause_flag.clear()
        c = conn(self.db_path)
        while True:
            try:
                url, depth, from_id = self.q.get_nowait()
            except queue.Empty:
                break
            try:
                self._mark_edge(url, "cancelled", from_id)
            except Exception as _exc:
                logger.debug("[A-15] engine.py:346 stop 异常已结构化记录: %s", _exc)
            self.q.task_done()
        self.q.join()
        for t in self._threads:
            t.join(timeout=2.0)
        _session.transition(self.session_id, ST_COMPLETED, db_path=self.db_path)

    # ═══════════════════════════════════════════════════════════════
    # A-07: 控制面 —— pause / resume / status（落库 + 真实线程暂停）
    # ═══════════════════════════════════════════════════════════════
    def pause(self) -> dict:
        """暂停会话：DB 状态落 PAUSED，worker 停止取件（在途任务收尾）。"""
        r = _session.transition(self.session_id, ST_PAUSED, db_path=self.db_path)
        if not r.get("success"):
            return {"ok": False, "error": r.get("error"),
                    "session_id": self.session_id}
        self.pause_flag.set()
        # ★ D3-08: 控制面扩展事件（与微信 C3-06 六类对齐）
        self._emit(EV_CONTROL, {"action": "pause", "state": ST_PAUSED})
        return {"ok": True, "session_id": self.session_id, "state": ST_PAUSED,
                "pages_done": self.pages_done, "pending_in_queue": self.q.qsize()}

    def resume(self) -> dict:
        """恢复会话：DB 状态回 RUNNING，worker 继续取件。"""
        r = _session.transition(self.session_id, ST_RUNNING, db_path=self.db_path)
        if not r.get("success"):
            return {"ok": False, "error": r.get("error"),
                    "session_id": self.session_id}
        self.pause_flag.clear()
        # ★ D3-08: 控制面扩展事件
        self._emit(EV_CONTROL, {"action": "resume", "state": ST_RUNNING})
        return {"ok": True, "session_id": self.session_id, "state": ST_RUNNING,
                "pages_done": self.pages_done, "pending_in_queue": self.q.qsize()}

    def status(self) -> dict:
        """只读状态：DB 会话行 + 引擎实时队列/计数（委托 ops.ops_status 汇总）。"""
        s = _session.get(self.session_id, db_path=self.db_path)
        with self.inflight_lock:
            inflight = self.inflight
        out = {"ok": bool(s.get("success", True)) and s.get("session") is not None,
               "session_id": self.session_id,
               "live": self.session_id in _LIVE_ENGINES,
               "paused": self.pause_flag.is_set(),
               "queue_pending": self.q.qsize(), "inflight": inflight,
               "pages_done": self.pages_done, "pages_ok": self.pages_ok,
               "pages_fail": self.pages_fail, "pages_started": self.pages_started}
        if s.get("session"):
            out["state"] = s["session"].get("state")
            out["session"] = s["session"]
        else:
            out["state"] = None
            out["error"] = s.get("error")
        return out

# ═══════════════════════════════════════════════════════════════
# A-07: 模块级控制面入口 —— 技能层/HTTP 端点统一走这里。
# 活动引擎在场 → 真实线程级暂停/恢复；不在场（重启后遗留会话）→ 仅落库迁移。
# ═══════════════════════════════════════════════════════════════
def stop_session(session_id: str, db_path: Optional[str] = None,
                 wait_s: float = 15.0) -> dict:
    """★ crawl_audit P1-4: 模块级叫停（600s 单轮超时后干净退出用）。

    活动引擎在场：排空未取件（标记 cancelled）+ 等在途任务收尾 + join
    worker 线程，直到线程退出或 wait_s 超时；随后会话落终态。
    不在场（重启遗留）：仅做 queued/running/paused → cancelled 落库迁移。
    """
    eng = _LIVE_ENGINES.get(session_id)
    if eng is not None:
        try:
            eng.stop()   # 排空 + q.join()（等在途 fetch 完成）+ join 线程 + 终态
        except Exception as e:
            return {"ok": False, "session_id": session_id,
                    "error": f"stop_failed:{str(e)[:100]}"}
        deadline = time.time() + wait_s
        while time.time() < deadline:
            alive = [t for t in getattr(eng, "_threads", []) if t.is_alive()]
            if not alive and session_id not in _LIVE_ENGINES:
                break
            time.sleep(0.1)
        residual = [t.name for t in getattr(eng, "_threads", []) if t.is_alive()]
        return {"ok": not residual, "session_id": session_id,
                "stopped": "live", "residual_threads": residual,
                "pages_done": eng.pages_done}
    r = _session.transition(session_id, ST_CANCELLED, db_path=db_path)
    if not r.get("success"):
        # 已是终态 / 未知会话：如实返回（幂等叫停不算失败）
        cur = str(r.get("error") or "")
        if "terminal" in cur or "unknown_session" in cur:
            return {"ok": True, "session_id": session_id, "stopped": "db",
                    "note": cur}
        return {"ok": False, "session_id": session_id, "error": cur}
    return {"ok": True, "session_id": session_id, "stopped": "db",
            "state": ST_CANCELLED}


def pause_session(session_id: str, db_path: Optional[str] = None) -> dict:
    eng = _LIVE_ENGINES.get(session_id)
    if eng is not None:
        return eng.pause()
    r = _session.transition(session_id, ST_PAUSED, db_path=db_path)
    if not r.get("success"):
        return {"ok": False, "error": r.get("error"), "session_id": session_id}
    return {"ok": True, "session_id": session_id, "state": ST_PAUSED, "live": False}


def resume_session(session_id: str, db_path: Optional[str] = None) -> dict:
    eng = _LIVE_ENGINES.get(session_id)
    if eng is not None:
        return eng.resume()
    r = _session.transition(session_id, ST_RUNNING, db_path=db_path)
    if not r.get("success"):
        return {"ok": False, "error": r.get("error"), "session_id": session_id}
    return {"ok": True, "session_id": session_id, "state": ST_RUNNING, "live": False}


def status_session(session_id: str, db_path: Optional[str] = None) -> dict:
    eng = _LIVE_ENGINES.get(session_id)
    if eng is not None:
        return eng.status()
    s = _session.get(session_id, db_path=db_path)
    if not s.get("session"):
        return {"ok": False, "error": s.get("error") or "unknown_session",
                "session_id": session_id}
    return {"ok": True, "session_id": session_id, "live": False,
            "state": s["session"].get("state"), "session": s["session"],
            "queue_pending": s.get("queue_pending", 0)}
