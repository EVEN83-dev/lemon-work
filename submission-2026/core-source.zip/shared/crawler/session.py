# -*- coding: utf-8 -*-
"""★ A3: 会话状态机

合法跃迁：
  queued    -> running / cancelled
  running   -> paused / stopping / failed
  paused    -> running / stopping / cancelled
  stopping  -> completed / failed
终态不再跃迁。
"""
from __future__ import annotations

import json
import os
import random
import sqlite3
import time
from typing import Optional

try:
    from . import (ST_QUEUED, ST_RUNNING, ST_PAUSED, ST_STOPPING,
                   ST_COMPLETED, ST_FAILED, ST_CANCELLED, TERMINAL_STATES)
    from .store import conn, ensure_schema
except ImportError:  # 直接运行脚本时
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from shared.crawler import (ST_QUEUED, ST_RUNNING, ST_PAUSED, ST_STOPPING,
                                ST_COMPLETED, ST_FAILED, ST_CANCELLED, TERMINAL_STATES)
    from shared.crawler.store import conn, ensure_schema

# 合法跃迁矩阵
_TRANSITIONS = {
    ST_QUEUED:   {ST_RUNNING, ST_CANCELLED},
    ST_RUNNING:  {ST_PAUSED, ST_STOPPING, ST_FAILED},
    ST_PAUSED:   {ST_RUNNING, ST_STOPPING, ST_CANCELLED},
    ST_STOPPING: {ST_COMPLETED, ST_FAILED},
    ST_COMPLETED: set(),
    ST_FAILED:    set(),
    ST_CANCELLED: set(),
}


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def create_session(name: str, seed_url: str, config: Optional[dict] = None,
                   db_path: Optional[str] = None) -> str:
    """创建会话，返回 cs_YYYYmmdd_HHMMSS_xxxx"""
    ensure_schema(db_path)
    sid = "cs_" + time.strftime("%Y%m%d_%H%M%S") + "_%04d" % random.randint(0, 9999)
    c = conn(db_path)
    c.execute(
        """INSERT INTO crawl_session(session_id,name,seed_url,config_json,state,created_at)
           VALUES(?,?,?,?,?,?)""",
        (sid, name, seed_url, json.dumps(config or {}, ensure_ascii=False),
         ST_QUEUED, _now()))
    c.commit()
    return sid


def transition(session_id: str, to_state: str,
               db_path: Optional[str] = None, note: str = "") -> dict:
    """状态跃迁；非法跃迁返回 {success:false,error:'illegal_transition:...'}"""
    ensure_schema(db_path)
    c = conn(db_path)
    row = c.execute("SELECT state FROM crawl_session WHERE session_id=?",
                    (session_id,)).fetchone()
    if row is None:
        return {"success": False, "error": f"unknown_session:{session_id}"}
    cur = row["state"]
    if cur in TERMINAL_STATES:
        return {"success": False,
                "error": f"illegal_transition:{cur}->{to_state}(terminal)"}
    allowed = _TRANSITIONS.get(cur, set())
    if to_state not in allowed:
        return {"success": False,
                "error": f"illegal_transition:{cur}->{to_state}"}
    ended = _now() if to_state in TERMINAL_STATES else None
    c.execute("UPDATE crawl_session SET state=?, ended_at=?, note=? WHERE session_id=?",
              (to_state, ended, note, session_id))
    # ★ 演出层修复: 进入 running 时落 started_at —— 旧实现从不写该列（恒 NULL），
    #   看门狗的 IFNULL(started_at, created_at) 年龄判定与会话块 started 展示
    #   全部失效（运行会话被误判停滞的根因之一）。
    if to_state == ST_RUNNING:
        c.execute("UPDATE crawl_session SET started_at=? WHERE session_id=? "
                  "AND IFNULL(started_at,'')=''",
                  (_now(), session_id))
    c.commit()
    return {"success": True, "from": cur, "to": to_state}


def recover(db_path: Optional[str] = None) -> dict:
    """重启把残留 running 改判 paused 并写 note"""
    ensure_schema(db_path)
    c = conn(db_path)
    rows = c.execute("SELECT session_id FROM crawl_session WHERE state=?",
                     (ST_RUNNING,)).fetchall()
    n = 0
    for r in rows:
        c.execute("UPDATE crawl_session SET state=?, note=? WHERE session_id=?",
                  (ST_PAUSED, "recovered_after_restart", r["session_id"]))
        n += 1
    c.commit()
    return {"recovered": n}


def get(session_id: str, db_path: Optional[str] = None) -> dict:
    """返回整行 + 队列剩余数"""
    ensure_schema(db_path)
    c = conn(db_path)
    row = c.execute("SELECT * FROM crawl_session WHERE session_id=?",
                    (session_id,)).fetchone()
    if row is None:
        return {"success": False, "error": f"unknown_session:{session_id}"}
    d = dict(row)
    pending = c.execute(
        "SELECT COUNT(*) n FROM crawl_edge WHERE session_id=? AND state='pending'",
        (session_id,)).fetchone()["n"]
    d["queue_pending"] = pending
    return {"success": True, "session": d}


def list_sessions(limit: int = 10, db_path: Optional[str] = None) -> list:
    ensure_schema(db_path)
    c = conn(db_path)
    rows = c.execute("SELECT * FROM crawl_session ORDER BY id DESC LIMIT ?",
                     (limit,)).fetchall()
    return [dict(r) for r in rows]


def update_progress(session_id: str, total: int = None, ok: int = None,
                    fail: int = None, dedup_hit: int = None,
                    size_bytes: int = None, db_path: Optional[str] = None) -> None:
    ensure_schema(db_path)
    c = conn(db_path)
    sets, args = [], []
    for col, val in (("total", total), ("ok", ok), ("fail", fail),
                     ("dedup_hit", dedup_hit), ("size_bytes", size_bytes)):
        if val is not None:
            sets.append(f"{col}=?")
            args.append(val)
    if sets:
        args.append(session_id)
        c.execute(f"UPDATE crawl_session SET {','.join(sets)} WHERE session_id=?", args)
        c.commit()


if __name__ == "__main__":
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        db = os.path.join(td, "t.db")
        sid = create_session("t", "http://example.com", {}, db_path=db)
        print("create:", sid[:20])
        # 6 条跃迁矩阵
        tests = [
            (sid, ST_RUNNING, True),
            (sid, ST_PAUSED, True),
            (sid, ST_RUNNING, True),
            (sid, ST_STOPPING, True),
            (sid, ST_COMPLETED, True),
            (sid, ST_RUNNING, False),   # 终态后
        ]
        for s, to, expect in tests:
            r = transition(s, to, db_path=db)
            got = bool(r.get("success"))
            mark = "✅" if got == expect else "❌"
            print(f"{mark} ->{to}: {r}")
        # 非法跃迁
        r = transition(sid, ST_PAUSED, db_path=db)
        print("非法:", r)
        print("get:", get(sid, db_path=db).get("success"))
