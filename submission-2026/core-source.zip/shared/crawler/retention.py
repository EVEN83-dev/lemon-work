# -*- coding: utf-8 -*-
"""★ W22-2: 保留策略 + 磁盘配额

- prune(db_path, keep_days=30, max_pages=200000, vacuum=True, dry_run=True)
- check_quota(db_path, min_free_gb=2.0)
- 铁律 R2：删除类操作默认 dry-run，默认不删除
"""
from __future__ import annotations

import os
import sqlite3
import time
from typing import Optional


def _db_size(path: str) -> int:
    try:
        return os.path.getsize(path)
    except OSError:
        return 0


def check_quota(db_path: str, min_free_gb: float = 2.0) -> dict:
    """磁盘剩余 < 阈值 → {"ok": False, "reason": "disk_low"}"""
    try:
        import shutil
        usage = shutil.disk_usage(os.path.dirname(os.path.abspath(db_path)))
        free_gb = usage.free / (1024 ** 3)
        return {"ok": free_gb >= float(min_free_gb), "free_gb": round(free_gb, 2),
                "min_free_gb": float(min_free_gb)}
    except Exception as e:
        return {"ok": False, "reason": f"quota_check_error: {e}"}


def prune(db_path: str, keep_days: int = 30, max_pages: int = 200000,
          vacuum: bool = True, dry_run: bool = True) -> dict:
    """保留策略：删旧会话 + 超页上限 + VACUUM

    铁律：dry_run=True 时不执行任何删除/VACUUM。
    """
    if not os.path.exists(db_path):
        return {"ok": False, "error": f"db 不存在: {db_path}"}
    before_bytes = _db_size(db_path)
    result = {"dry_run": bool(dry_run), "keep_days": keep_days,
              "max_pages": max_pages, "deleted_sessions": 0,
              "deleted_pages": 0, "before_bytes": before_bytes,
              "after_bytes": before_bytes, "vacuum": bool(vacuum) and not dry_run}

    conn = sqlite3.connect(db_path, timeout=5)
    conn.row_factory = sqlite3.Row
    try:
        cutoff = time.strftime("%Y-%m-%d %H:%M:%S",
                               time.localtime(time.time() - keep_days * 86400))
        # ── 1. 删旧会话 ──
        old = conn.execute(
            "SELECT session_id FROM crawl_session WHERE created_at<?",
            (cutoff,)).fetchall()
        old_ids = [r["session_id"] for r in old]
        # ── 2. 超页上限：从最旧页删 ──
        total_pages = conn.execute("SELECT COUNT(*) n FROM crawl_page").fetchone()["n"]
        overflow = max(0, total_pages - int(max_pages))
        oldest_pages = []
        if overflow > 0:
            oldest_pages = [r["id"] for r in conn.execute(
                "SELECT id FROM crawl_page ORDER BY id LIMIT ?", (overflow,)).fetchall()]

        result["deleted_sessions"] = len(old_ids)
        result["deleted_pages"] = len(oldest_pages) + sum(
            conn.execute("SELECT COUNT(*) n FROM crawl_page WHERE session_id=?",
                         (sid,)).fetchone()["n"] for sid in old_ids) if old_ids else len(oldest_pages)

        if dry_run:
            conn.rollback()
            return result

        # ── 执行删除 ──
        for sid in old_ids:
            conn.execute("DELETE FROM crawl_annotation WHERE page_id IN "
                         "(SELECT id FROM crawl_page WHERE session_id=?)", (sid,))
            conn.execute("DELETE FROM crawl_content WHERE page_id IN "
                         "(SELECT id FROM crawl_page WHERE session_id=?)", (sid,))
            conn.execute("DELETE FROM crawl_edge WHERE session_id=?", (sid,))
            conn.execute("DELETE FROM crawl_page WHERE session_id=?", (sid,))
            conn.execute("DELETE FROM crawl_session WHERE session_id=?", (sid,))
        if oldest_pages:
            conn.execute(f"DELETE FROM crawl_content WHERE page_id IN "
                         f"({','.join('?' * len(oldest_pages))})", oldest_pages)
            conn.execute(f"DELETE FROM crawl_page WHERE id IN "
                         f"({','.join('?' * len(oldest_pages))})", oldest_pages)
        conn.commit()

        if vacuum:
            conn.execute("VACUUM")
            conn.commit()
        result["after_bytes"] = _db_size(db_path)
        return result
    finally:
        conn.close()


if __name__ == "__main__":
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        db = os.path.join(td, "t.db")
        from shared.crawler.store import ensure_schema
        ensure_schema(db)
        print("dry-run:", prune(db, dry_run=True))
        print("real:", prune(db, dry_run=False))
        print("quota:", check_quota(db))
