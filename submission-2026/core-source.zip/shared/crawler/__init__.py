# -*- coding: utf-8 -*-
"""★ A0: shared/crawler 契约冻结

事件/状态/硬顶常量唯一真源 —— 禁止散落到其他文件。
"""
# ── 版本 ──
CRAWL_VERSION = "1.0"

# ── 事件常量 ──
# ★ D3-08: crawl.control 为控制面扩展位，与微信 C3-06 CrawlEventType 六类对齐
EV_SESSION_START = "crawl.session_start"
EV_PAGE_START = "crawl.page_start"
EV_PAGE_DONE = "crawl.page_done"
EV_PAGE_FAIL = "crawl.page_fail"
EV_SESSION_DONE = "crawl.session_done"
EV_CONTROL = "crawl.control"   # pause/resume 控制事件（只增不改）

# ── 状态常量 ──
ST_QUEUED = "queued"
ST_RUNNING = "running"
ST_PAUSED = "paused"
ST_STOPPING = "stopping"
ST_COMPLETED = "completed"
ST_FAILED = "failed"
ST_CANCELLED = "cancelled"

# 终态集合
TERMINAL_STATES = {ST_COMPLETED, ST_FAILED, ST_CANCELLED}

# ── 硬顶 ──
MAX_PAGES = 500          # 单会话最大抓取页数
MAX_DEPTH = 3            # 最大链接深度
MAX_WORKERS = 4          # 线程池上限
SESSION_TIMEOUT_MIN = 30  # 单会话硬超时（分钟）
MAX_CONTENT_HTML = 524288   # 正文 HTML 上限 512KB
MAX_CONTENT_TEXT = 204800   # 正文纯文本上限 200KB
