# -*- coding: utf-8 -*-
"""★ C10: 站点规则

- selectors_json：list_item/title/link/price/date/content
- 未配置走通用提取；非法选择器捕获并回退
- 按 domain 精确匹配
- 禁止：规则写死代码
"""
from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

import json
import os
import time
from typing import Optional

try:
    from .store import conn, ensure_schema
except ImportError:
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from shared.crawler.store import conn, ensure_schema

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_DB = os.path.join(_ROOT, "data", "crawl.db")

_SELECTOR_KEYS = ("list_item", "title", "link", "price", "date", "content")


def rule_set(domain: str, name: str, selectors: dict,
             enabled: bool = True, db_path: Optional[str] = None) -> dict:
    """设置站点规则"""
    ensure_schema(db_path)
    c = conn(db_path)
    # 校验：只保留合法 key
    clean = {k: str(selectors.get(k, "") or "") for k in _SELECTOR_KEYS}
    cur = c.execute(
        "INSERT INTO crawl_rule(domain,name,selectors_json,enabled,created_at) VALUES(?,?,?,?,?)",
        (domain, name, json.dumps(clean, ensure_ascii=False), 1 if enabled else 0,
         time.strftime("%Y-%m-%d %H:%M:%S")))
    c.commit()
    return {"id": cur.lastrowid, "domain": domain}


def rule_get(domain: str, db_path: Optional[str] = None) -> Optional[dict]:
    """按 domain 精确匹配"""
    ensure_schema(db_path)
    c = conn(db_path)
    row = c.execute("SELECT * FROM crawl_rule WHERE domain=? AND enabled=1 ORDER BY id DESC",
                    (domain,)).fetchone()
    if row is None:
        return None
    d = dict(row)
    try:
        d["selectors"] = json.loads(d.get("selectors_json") or "{}")
    except Exception:
        d["selectors"] = {}
    return d


def apply_rules(raw_html: str, url: str, db_path: Optional[str] = None) -> dict:
    """应用规则提取；非法选择器回退通用提取"""
    from urllib.parse import urlparse
    domain = (urlparse(url).hostname or "").lower()
    rule = rule_get(domain, db_path=db_path)
    if not rule or not rule.get("selectors"):
        return {"applied": False, "reason": "no_rule"}
    sels = rule["selectors"]
    try:
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(raw_html, "html.parser")
        out = {"applied": True, "rule_id": rule["id"]}
        # 列表项
        li_sel = sels.get("list_item")
        if li_sel:
            items = soup.select(li_sel)
            out["list_count"] = len(items)
            out["items"] = []
            for it in items[:20]:
                item = {}
                for key, sel in (("title", sels.get("title")),
                                 ("link", sels.get("link")),
                                 ("price", sels.get("price")),
                                 ("date", sels.get("date")),
                                 ("content", sels.get("content"))):
                    if sel:
                        try:
                            el = it.select_one(sel)
                            if el:
                                if key == "link":
                                    item[key] = el.get("href", "")
                                else:
                                    item[key] = el.get_text(strip=True)[:200]
                        except Exception:
                            # 非法选择器 → 该字段跳过（回退）
                            continue
                if item:
                    out["items"].append(item)
        return out
    except Exception as e:
        return {"applied": False, "reason": f"error:{str(e)[:80]}"}


if __name__ == "__main__":
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        db = os.path.join(td, "t.db")
        ensure_schema(db)
        rule_set("example.com", "测试", {"list_item": ".item", "title": "h2",
                                         "price": ".price"}, db_path=db)
        r = rule_get("example.com", db_path=db)
        print("规则:", r["selectors"] if r else None)
        html = '<div class="item"><h2>A</h2><span class="price">¥100</span></div>'
        out = apply_rules(html, "http://example.com/x", db_path=db)
        print("应用:", out.get("applied"), "items:", len(out.get("items", [])))


# ══════════════════════════════════════════════════════════════════
# ★ W22-4: 改版健康检测（crawl_rule_health）
# ══════════════════════════════════════════════════════════════════

def rule_health(domain: str, html: str = "",
                db_path: Optional[str] = None) -> dict:
    """用最新规则跑选择器，算 hit_rate；<0.5 → emit crawl_alert_card

    铁律：不把 health 写进 crawl_rule 主表；独立表 crawl_rule_health。
    """
    import time
    ensure_schema(db_path)
    c = conn(db_path)
    rule = rule_get(domain, db_path=db_path)
    if not rule or not rule.get("selectors"):
        # 无规则域名：回退通用提取，不报错
        return {"ok": True, "reason": "no_rule", "hit_rate": None}
    sels = rule["selectors"]
    li_sel = sels.get("list_item", "")
    hits, total = 0, 0
    if html and li_sel:
        try:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(html, "html.parser")
            total = len(soup.select(li_sel))
            hits = total
        except Exception as _exc:
            logger.debug("[A-15] rules.py:143 rule_health 异常已结构化记录: %s", _exc)
    # hit_rate：有 html 时按命中数；无 html 时用 1.0（无法判定）
    hit_rate = (hits / max(1, total)) if total > 0 else (1.0 if not html else 0.0)
    status = "ok" if hit_rate >= 0.5 else "degraded"
    c.execute(
        "INSERT INTO crawl_rule_health(domain,checked_at,selector,hits,total,hit_rate,status) "
        "VALUES(?,?,?,?,?,?,?)",
        (domain, time.strftime("%Y-%m-%d %H:%M:%S"), li_sel, hits, total,
         round(hit_rate, 3), status))
    c.commit()
    if status == "degraded":
        try:
            from shared.action_cards import get_action_card_registry
            get_action_card_registry().emit_card({
                "type": "crawl_alert_card",
                "card_id": f"cal_rule_{domain}_{int(time.time())}",
                "title": f"⚠ 规则降级: {domain}",
                "name": domain,
                "reason": f"hit_rate={hit_rate:.1%} < 50%（疑似改版）",
                "session_id": "",
                "state": "degraded",
                "tools": [{"action": "crawl.rule_set", "label": "更新规则"}],
            })
        except Exception as _exc:
            logger.debug("[A-15] rules.py:167 rule_health 异常已结构化记录: %s", _exc)
    return {"ok": status == "ok", "hit_rate": round(hit_rate, 3),
            "status": status, "hits": hits, "total": total}
