# -*- coding: utf-8 -*-
"""★ D5-02: LTTB 降采样（纯 Python，无第三方依赖）。

算法：Largest-Triangle-Three-Buckets（Sveinn Steinarsson, 2013）。
思路：把序列切成 n-1 个桶，每个桶选「与前一采样点、下一桶均值点」构成
三角形面积最大的点——在锐降/尖峰处保留更多细节。

保形底线（本实现附加）：原序列最大值点必保留——若 LTTB 未选中，
则替换与其索引最接近的中间采样点（保持 n 点、首尾不动）。

禁止在前端重复实现（D5 §0 职责划分：降采样属后端）。
"""
from __future__ import annotations

from typing import Dict, List, Sequence, Union

Point = Dict[str, Union[int, float]]


def lttb(points: Sequence[Point], n: int) -> List[Point]:
    """把 points 降采样到 n 点。

    Args:
        points: [{"t": <单调递增>, "v": <数值>}, ...]
        n: 目标点数

    Returns:
        n 个点（n >= len(points) 时原样返回）；首尾点与全局最大值点必保留；
        t 单调递增；相同输入输出确定一致（无随机）。
    """
    m = len(points)
    if n >= m or n < 2:
        return list(points)
    if m < 2:
        return list(points)

    def _t(i):
        return points[i]["t"]

    def _v(i):
        return points[i]["v"]

    idx = [0]
    a = 0
    for i in range(1, n - 1):
        avg_start = int((m - 2) * i / (n - 1)) + 1
        avg_end = int((m - 2) * (i + 1) / (n - 1)) + 1
        avg_slice = points[avg_start:avg_end]
        if not avg_slice:
            continue
        avg_t = sum(_t(j) for j in range(avg_start, avg_end)) / len(avg_slice)
        avg_v = sum(_v(j) for j in range(avg_start, avg_end)) / len(avg_slice)
        offs = int((m - 2) * (i - 1) / (n - 1)) + 1
        to = int((m - 2) * i / (n - 1)) + 1
        pa_t, pa_v = _t(a), _v(a)
        best_j, best_area = offs, -1.0
        for j in range(offs, to):
            area = abs((pa_t - avg_t) * (_v(j) - pa_v)
                       - (pa_t - _t(j)) * (avg_v - pa_v)) * 0.5
            if area > best_area:
                best_area, best_j = area, j
        idx.append(best_j)
        a = best_j
    idx.append(m - 1)

    # ── 保形底线：全局最大值点必保留 ──
    max_i = max(range(m), key=lambda k: _v(k))
    if max_i not in idx:
        # 替换与最大值点索引最接近的「中间」采样点（首尾不动，保持 n 点）
        k = min(range(1, n - 1), key=lambda kk: abs(idx[kk] - max_i))
        idx[k] = max_i
    idx.sort()
    return [points[i] for i in idx]


__all__ = ["lttb"]
