# -*- coding: utf-8 -*-
"""★ W22-8: 运维看板 crawl_ops_card

ops_status() 返回：
  db_size_mb / free_gb / sessions_by_state / pages /
  annotations / rules / watch / last_prune / last_watchdog /
  scheduler_jobs / domain_policies

只读；禁止在看板里执行 prune/抓取。
"""
from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

import os
import time
from typing import Optional

try:
    from .store import ro_conn, ensure_schema
    from . import retention as _retention
except ImportError:
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from shared.crawler.store import ro_conn, ensure_schema
    from shared.crawler import retention as _retention

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_DB = os.path.join(_ROOT, "data", "crawl.db")

# 运行态记录（内存，重启清零；不落库）
_LAST_PRUNE = None
_LAST_WATCHDOG = None


def note_prune():
    global _LAST_PRUNE
    _LAST_PRUNE = time.strftime("%Y-%m-%d %H:%M:%S")


def note_watchdog():
    global _LAST_WATCHDOG
    _LAST_WATCHDOG = time.strftime("%Y-%m-%d %H:%M:%S")


def ops_status(db_path: Optional[str] = None) -> dict:
    """只读运维状态"""
    path = db_path or _DB
    ensure_schema(path)
    out = {"ok": True, "db_size_mb": 0.0, "free_gb": 0.0,
           "sessions_by_state": {}, "pages": 0, "annotations": 0,
           "rules": 0, "watch": 0, "last_prune": _LAST_PRUNE,
           "last_watchdog": _LAST_WATCHDOG, "scheduler_jobs": 0,
           "domain_policies": 0}
    try:
        out["db_size_mb"] = round(os.path.getsize(path) / 1024 / 1024, 2)
    except OSError as _exc:
        logger.debug("[A-15] ops.py:55 ops_status 异常已结构化记录: %s", _exc)
    q = _retention.check_quota(path)
    out["free_gb"] = q.get("free_gb", 0.0)

    c = ro_conn(path)
    if c is None:
        return out
    try:
        rows = c.execute("SELECT state, COUNT(*) n FROM crawl_session "
                         "GROUP BY state").fetchall()
        out["sessions_by_state"] = {r["state"]: r["n"] for r in rows}
        out["pages"] = c.execute("SELECT COUNT(*) n FROM crawl_page").fetchone()["n"]
        out["annotations"] = c.execute(
            "SELECT COUNT(*) n FROM crawl_annotation WHERE deleted=0").fetchone()["n"]
        out["rules"] = c.execute("SELECT COUNT(*) n FROM crawl_rule WHERE enabled=1").fetchone()["n"]
        out["watch"] = c.execute("SELECT COUNT(*) n FROM crawl_watch WHERE enabled=1").fetchone()["n"]
        try:
            out["domain_policies"] = c.execute(
                "SELECT COUNT(*) n FROM crawl_domain_policy").fetchone()["n"]
        except Exception:
            out["domain_policies"] = 0
    finally:
        c.close()
    # ★ W24-3: 域健康（Top5 失败域）
    try:
        from . import metrics as _metrics
        out["domain_health"] = {"top_failing_domains": _metrics.top_failing_domains(5)}
    except Exception as e:
        out["domain_health"] = {"error": str(e)[:120]}

    # ★ W25-H: 直接从 jobs.json 统计启用任务（不依赖 SchedulerEngine 是否启动）
    try:
        import json
        sp = os.path.join(_ROOT, "data", "scheduler", "jobs.json")
        with open(sp, encoding="utf-8") as f:
            jobs = json.load(f).get("jobs", [])
        out["scheduler_jobs"] = len([j for j in jobs if j.get("enabled")])
    except Exception as _exc:
        logger.debug("[A-15] ops.py:93 ops_status 异常已结构化记录: %s", _exc)
    return out


if __name__ == "__main__":
    import json
    print(json.dumps(ops_status(), ensure_ascii=False, indent=2))
