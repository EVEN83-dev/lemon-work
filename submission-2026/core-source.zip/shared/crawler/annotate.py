# -*- coding: utf-8 -*-
"""★ C1: 标注后端

标注对象：
  id,page_id,field,quote,note,tags[],color,
  status(pending|confirmed|rejected),author,created_at,updated_at,deleted
铁律：
  - 同页同 quote 同 tags 合并，返回已有 id
  - 软删（deleted=1），list 不返回
  - note 落库前过 pii_mask.mask_pii
  - 禁止：物理删除；跨会话串数据
"""
from __future__ import annotations

import json
import os
import time
from typing import Optional

try:
    from .store import conn, ensure_schema
except ImportError:
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from shared.crawler.store import conn, ensure_schema

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_DB = os.path.join(_ROOT, "data", "crawl.db")


def _mask(text: str) -> str:
    try:
        from shared.pii_mask import mask_pii
        return mask_pii(text)
    except Exception:
        return text


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def create(page_id: int, field: str = "", quote: str = "", note: str = "",
           tags=None, color: str = "#f5a623", author: str = "",
           status: str = "confirmed", db_path: Optional[str] = None) -> dict:
    """创建标注；同页同 quote 同 tags 合并，返回已有 id"""
    ensure_schema(db_path)
    c = conn(db_path)
    tags = tags or []
    tag_key = json.dumps(tags, ensure_ascii=False)
    # 重复合并
    existing = c.execute(
        "SELECT id FROM crawl_annotation WHERE page_id=? AND quote=? AND tags=? AND deleted=0",
        (page_id, quote, tag_key)).fetchone()
    if existing:
        return {"id": existing["id"], "merged": True}
    note = _mask(note)
    cur = c.execute(
        """INSERT INTO crawl_annotation(page_id,field,quote,note,tags,color,status,author,
           created_at,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
        (page_id, field, quote, note, json.dumps(tags, ensure_ascii=False), color,
         status, author, _now(), _now(), 0))
    c.commit()
    return {"id": cur.lastrowid, "merged": False}


def list_annotations(page_id: int = None, session_id: str = "",
                     status: str = "", db_path: Optional[str] = None) -> list:
    """列出标注（软删不返回）"""
    ensure_schema(db_path)
    c = conn(db_path)
    sql = "SELECT * FROM crawl_annotation WHERE deleted=0"
    args = []
    if page_id is not None:
        sql += " AND page_id=?"
        args.append(page_id)
    if session_id:
        sql += " AND page_id IN (SELECT id FROM crawl_page WHERE session_id=?)"
        args.append(session_id)
    if status:
        sql += " AND status=?"
        args.append(status)
    sql += " ORDER BY id DESC"
    rows = c.execute(sql, args).fetchall()
    return [dict(r) for r in rows]


def update(ann_id: int, note: str = None, tags=None, color: str = None,
           status: str = None, db_path: Optional[str] = None) -> dict:
    ensure_schema(db_path)
    c = conn(db_path)
    row = c.execute("SELECT id FROM crawl_annotation WHERE id=? AND deleted=0",
                    (ann_id,)).fetchone()
    if row is None:
        return {"success": False, "error": f"annotation {ann_id} 不存在"}
    sets, args = [], []
    if note is not None:
        sets.append("note=?")
        args.append(_mask(note))
    if tags is not None:
        sets.append("tags=?")
        args.append(json.dumps(tags, ensure_ascii=False))
    if color is not None:
        sets.append("color=?")
        args.append(color)
    if status is not None:
        sets.append("status=?")
        args.append(status)
    if sets:
        sets.append("updated_at=?")
        args.append(_now())
        args.append(ann_id)
        c.execute(f"UPDATE crawl_annotation SET {','.join(sets)} WHERE id=?", args)
        c.commit()
    return {"success": True, "id": ann_id}


def delete(ann_id: int, db_path: Optional[str] = None) -> dict:
    """软删"""
    ensure_schema(db_path)
    c = conn(db_path)
    row = c.execute("SELECT id FROM crawl_annotation WHERE id=? AND deleted=0",
                    (ann_id,)).fetchone()
    if row is None:
        return {"success": False, "error": f"annotation {ann_id} 不存在"}
    c.execute("UPDATE crawl_annotation SET deleted=1, updated_at=? WHERE id=?",
              (_now(), ann_id))
    c.commit()
    return {"success": True, "id": ann_id, "deleted": True}


if __name__ == "__main__":
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        db = os.path.join(td, "t.db")
        ensure_schema(db)
        # 增
        r1 = create(1, quote="金额 100", note="含手机号 13800138000",
                    tags=["金额"], db_path=db)
        print("创建:", r1)
        # 合并
        r2 = create(1, quote="金额 100", tags=["金额"], db_path=db)
        print("合并:", r2)
        # 查
        rows = list_annotations(page_id=1, db_path=db)
        print("列出:", len(rows), "条")
        if rows:
            print("掩码:", "13800138000" not in rows[0]["note"])
            # 改
            update(rows[0]["id"], note="更新备注", db_path=db)
            # 软删
            delete(rows[0]["id"], db_path=db)
            rows2 = list_annotations(page_id=1, db_path=db)
            print("软删后:", len(rows2), "条")
        store_close = conn(db)
        store_close.close()
