# -*- coding: utf-8 -*-
"""★ W22-3: 抓取 watchdog

- tick(threshold_min=5)：running 会话超时 → failed + emit alert + notify
- 全局 watchdog 线程（register_crawl_skills 时启动，daemon=True，interval=60s）
- 禁止：watchdog 里做网络抓取；无界重试
"""
from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

import os
import threading
import time
from typing import Optional

try:
    from .store import conn, ensure_schema
    from . import notify
except ImportError:
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from shared.crawler.store import conn, ensure_schema
    from shared.crawler import notify

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_DB = os.path.join(_ROOT, "data", "crawl.db")
_audit_path = os.path.join(_ROOT, "data", "crawler", "watchdog_audit.log")


def set_audit_path(p: str):
    """★ D3-11: 审计落盘路径（测试可注入临时路径）"""
    global _audit_path
    _audit_path = p


def _audit(rec: str):
    """★ D3-11: tick 审计落盘（供机检验证看门狗真跑）"""
    try:
        os.makedirs(os.path.dirname(_audit_path), exist_ok=True)
        with open(_audit_path, "a", encoding="utf-8") as f:
            f.write(f"{_now()} {rec}\n")
    except Exception as _exc:
        logger.debug("[A-15] watchdog.py:45 tick 审计落盘异常已结构化记录: %s", _exc)


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def tick(db_path: Optional[str] = None, threshold_min: int = 5) -> dict:
    """检查 running 会话是否停滞；停滞 → failed + 告警

    ★ 演出层修复: 停滞判定从「started_at 早于阈值」改为「进展判定」——
      旧实现杀的是『跑得久』的会话（长时健康抓取必被误杀），且 started_at
      恒 NULL 的会话首拍即死（实测 45/45 全 ok 的抓取被标 watchdog_stall）。
      新口径：running + 会话年龄超阈值 + 阈值窗口内 crawl_page 零新增，
      三条同时满足才算真停滞（以库内真实进展为准，无硬编码窗口）。"""
    ensure_schema(db_path)
    c = conn(db_path)
    now_ts = time.time()
    cutoff = time.strftime("%Y-%m-%d %H:%M:%S",
                           time.localtime(now_ts - threshold_min * 60))
    stalled = c.execute(
        "SELECT s.session_id, s.name FROM crawl_session s "
        "WHERE s.state='running' "
        "AND IFNULL(s.started_at, s.created_at) < ? "
        "AND NOT EXISTS (SELECT 1 FROM crawl_page p "
        "                WHERE p.session_id=s.session_id AND p.fetched_at >= ?)",
        (cutoff, cutoff)).fetchall()
    fixed = []
    for r in stalled:
        sid = r["session_id"]
        c.execute("UPDATE crawl_session SET state='failed', note=? WHERE session_id=?",
                  ("watchdog_stall", sid))
        c.commit()
        payload = {"type": "crawl_stall", "session_id": sid,
                   "name": r["name"], "threshold_min": threshold_min,
                   "ts": _now()}
        # emit alert card（走 ActionCardRegistry）
        try:
            from shared.action_cards import get_action_card_registry
            get_action_card_registry().emit_card({
                "type": "crawl_alert_card",
                "card_id": f"cal_wd_{sid}_{int(now_ts)}",
                "title": f"⚠ 抓取停滞: {r['name'] or sid[:20]}",
                "name": r["name"] or "",
                "reason": f"超过 {threshold_min} 分钟无进展",
                "session_id": sid,
                "state": "stalled",
                "tools": [{"action": "crawl.status", "label": "查看会话"}],
            })
        except Exception as _exc:
            logger.debug("[A-15] watchdog.py:65 tick 异常已结构化记录: %s", _exc)
        notify.send(payload)
        fixed.append(sid)
    # ★ D3-11: tick 审计（无论是否命中停滞都记一条，供机检验证常驻真跑）
    _audit(f"tick db={db_path or _DB} stalled={len(stalled)} fixed={len(fixed)}")
    return {"checked": True, "stalled": len(stalled), "fixed": fixed}


class _WatchdogThread(threading.Thread):
    def __init__(self, db_path=None, interval=60, threshold_min=5):
        super().__init__(daemon=True, name="crawl-watchdog")
        self._db = db_path
        self._interval = interval
        self._threshold = threshold_min
        self._stop = threading.Event()

    def run(self):
        while not self._stop.is_set():
            try:
                tick(self._db, self._threshold)
            except Exception as e:
                print(f"[watchdog] tick 异常: {e}")
            self._stop.wait(self._interval)

    def stop(self):
        self._stop.set()


_started = False
_thread: Optional[_WatchdogThread] = None
_start_lock = threading.Lock()


def start_watchdog(db_path=None, interval=60, threshold_min=5,
                   interval_s=None, daemon=True) -> bool:
    """全局 watchdog 线程（只启动一次）。

    ★ D3-11: interval_s 为 interval 的别名（规格口径）；daemon 保持 True。
    """
    if interval_s is not None:
        interval = interval_s
    global _started, _thread
    with _start_lock:
        if _started:
            return False
        _thread = _WatchdogThread(db_path, interval, threshold_min)
        _thread.start()
        _started = True
        _audit(f"start interval={interval}s threshold={threshold_min}min")
        print(f"[watchdog] 已启动（interval={interval}s, threshold={threshold_min}min）")
        return True


def stop_watchdog():
    global _started, _thread
    with _start_lock:
        if _thread:
            _thread.stop()
            _thread = None
        _started = False


if __name__ == "__main__":
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        db = os.path.join(td, "t.db")
        ensure_schema(db)
        c = conn(db)
        old = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time() - 600))
        c.execute("INSERT INTO crawl_session(session_id,name,seed_url,state,started_at) "
                  "VALUES('cs_stall','停滞测试','http://e.com','running',?)", (old,))
        c.commit()
        c.close()
        r = tick(db, threshold_min=5)
        print("tick:", r)
        c = conn(db)
        st = c.execute("SELECT state FROM crawl_session WHERE session_id='cs_stall'").fetchone()["state"]
        c.close()
        print("状态:", st)
