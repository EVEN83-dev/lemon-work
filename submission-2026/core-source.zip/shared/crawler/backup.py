# -*- coding: utf-8 -*-
"""★ W24-2: 数据备份 / 恢复 / 迁移

- backup(db_path, out_dir)：sqlite3 backup API 在线备份 + manifest
- restore(backup_path, db_path)：integrity_check → 恢复
- schema_version：crawl_meta 记录版本；migrate() 幂等
- 禁止：直接 copy 正在写的 SQLite 文件
"""
from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

import hashlib
import json
import os
import shutil
import sqlite3
import time
from typing import Dict, Optional

SCHEMA_VERSION = 2  # ★ W24-1 后版本


def _file_hash(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def backup(db_path: str, out_dir: Optional[str] = None) -> Dict:
    """在线备份（sqlite3 backup API）+ manifest

    Returns:
        {"ok": True, "path": ..., "size": ..., "sha256": ..., "manifest": ...}
    """
    if not os.path.exists(db_path):
        return {"ok": False, "error": f"db 不存在: {db_path}"}
    out_dir = out_dir or os.path.join(os.path.dirname(db_path), "backups")
    os.makedirs(out_dir, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    dest = os.path.join(out_dir, f"crawl_backup_{stamp}.db")

    try:
        src = sqlite3.connect(db_path, timeout=10)
        dst = sqlite3.connect(dest)
        with dst:
            src.backup(dst)
        # 验证备份完整性
        cur = dst.execute("PRAGMA integrity_check")
        check = cur.fetchone()
        dst.close()
        src.close()
        if not check or check[0] != "ok":
            os.remove(dest)
            return {"ok": False, "error": "备份完整性检查失败"}

        manifest = {
            "version": SCHEMA_VERSION,
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "source": os.path.abspath(db_path),
            "size_bytes": os.path.getsize(dest),
            "sha256": _file_hash(dest),
            "integrity": check[0] if check else "unknown",
        }
        with open(dest + ".manifest.json", "w", encoding="utf-8") as f:
            json.dump(manifest, f, ensure_ascii=False, indent=2)
        return {"ok": True, "path": dest, "manifest": manifest}
    except Exception as e:
        if os.path.exists(dest):
            try:
                os.remove(dest)
            except OSError as _exc:
                logger.debug("[A-15] backup.py:72 backup 异常已结构化记录: %s", _exc)
        return {"ok": False, "error": f"backup failed: {str(e)[:160]}"}


def restore(backup_path: str, db_path: str) -> Dict:
    """恢复备份（先 integrity_check，再恢复）"""
    if not os.path.exists(backup_path):
        return {"ok": False, "error": f"备份不存在: {backup_path}"}
    try:
        src = sqlite3.connect(backup_path, timeout=10)
        cur = src.execute("PRAGMA integrity_check")
        check = cur.fetchone()
        src.close()
        if not check or check[0] != "ok":
            return {"ok": False, "error": "备份完整性检查失败（拒绝恢复损坏库）"}
        # 目标目录
        os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)
        # 先备份现有库（如存在）
        if os.path.exists(db_path):
            bak = db_path + f".before_restore_{int(time.time())}"
            shutil.copy2(db_path, bak)
        # 恢复
        shutil.copy2(backup_path, db_path)
        # 验证恢复后库
        dst = sqlite3.connect(db_path, timeout=10)
        cur = dst.execute("PRAGMA integrity_check")
        check2 = cur.fetchone()
        dst.close()
        if not check2 or check2[0] != "ok":
            return {"ok": False, "error": "恢复后完整性检查失败"}
        return {"ok": True, "path": db_path, "integrity": check2[0]}
    except Exception as e:
        return {"ok": False, "error": f"restore failed: {str(e)[:160]}"}


def get_schema_version(db_path: str) -> int:
    """读取库中 schema_version（缺省 1）"""
    try:
        c = sqlite3.connect(db_path, timeout=5)
        c.row_factory = sqlite3.Row
        try:
            row = c.execute("SELECT v FROM crawl_meta WHERE k='schema_version'").fetchone()
            ver = int(row["v"]) if row else 1
        except Exception:
            ver = 1
        c.close()
        return ver
    except Exception:
        return 0


def migrate(db_path: str) -> Dict:
    """幂等迁移：crawl_meta 记录 schema_version

    Returns:
        {"ok": True, "from": ..., "to": ...}
    """
    try:
        c = sqlite3.connect(db_path, timeout=10)
        c.row_factory = sqlite3.Row
        try:
            c.execute("CREATE TABLE IF NOT EXISTS crawl_meta(k TEXT PRIMARY KEY, v TEXT)")
            row = c.execute("SELECT v FROM crawl_meta WHERE k='schema_version'").fetchone()
            old = int(row["v"]) if row else 1
        except Exception:
            old = 1
        c.execute("INSERT OR REPLACE INTO crawl_meta(k,v) VALUES('schema_version',?)",
                  (str(SCHEMA_VERSION),))
        c.commit()
        c.close()
        return {"ok": True, "from": old, "to": SCHEMA_VERSION}
    except Exception as e:
        return {"ok": False, "error": f"migrate failed: {str(e)[:160]}"}


if __name__ == "__main__":
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        db = os.path.join(td, "t.db")
        from shared.crawler.store import ensure_schema
        ensure_schema(db)
        print("backup:", backup(db))
        print("migrate:", migrate(db))
        print("restore:", restore(backup(db)["path"], db))
