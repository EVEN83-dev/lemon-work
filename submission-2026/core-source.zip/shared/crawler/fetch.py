# -*- coding: utf-8 -*-
"""★ A5: 抓取链与 JS 回退

- gate(url,"open") -> requests.get(UA,timeout=15) -> parse_html
- 401/403/412/429/503 记 blocked
- needs_js 判定：原始 HTML>100KB 且正文<120 字
- JsFetcher：QMetaObject.invokeMethod 回 GUI 线程执行 browser_tool._js_sync，
  BlockingQueuedConnection + 20s 超时；无面板直接标 needs_js 不重试
- 每次抓取记录 elapsed_ms/size_bytes/http_status/mode
- 禁止：绕过 gate；GUI 线程 sleep 轮询；无限重试
"""
from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

import re
import time
from typing import Optional
from urllib.parse import urlparse

import requests

_UA = {"User-Agent": "LemonWork-Crawl/1.0 (+https://github.com/EVEN83-dev/lemon-work)"}
_BLOCKED_HTTP = {401, 403, 412, 429, 503}


def _gate(url: str, action: str = "open"):
    """合规闸门（唯一出入口）"""
    try:
        from shared.browser_policy import gate
    except ImportError:
        from browser_policy import gate
    return gate(url, action)


def needs_js(raw_html: str, text_chars: int) -> bool:
    """原始 HTML>100KB 且正文<120 字 → 需要 JS 渲染"""
    return len(raw_html or "") > 100 * 1024 and int(text_chars or 0) < 120


class JsFetcher:
    """JS 回退：把 page.runJavaScript 调用投递到 GUI 线程执行"""

    def __init__(self, panel=None, timeout_ms: int = 20000):
        self.panel = panel
        self.timeout_ms = timeout_ms

    def available(self) -> bool:
        return self.panel is not None and hasattr(self.panel, "_webview")

    def fetch(self, url: str) -> Optional[dict]:
        """有 UI 面板时回 GUI 线程取渲染后 HTML；无面板返回 None"""
        if not self.available():
            return None
        try:
            from PyQt5.QtCore import QMetaObject, Qt, Q_ARG
            view = self.panel._webview
            page = view.page()
            holder = {}

            def _cb(result):
                holder["html"] = result

            # 先导航
            view.setUrl(__import__("PyQt5.QtCore", fromlist=["QUrl"]).QUrl(url))
            # 等待 loadFinished（带超时）
            from PyQt5.QtCore import QEventLoop, QTimer
            loop = QEventLoop()
            t = QTimer()
            t.setSingleShot(True)
            t.timeout.connect(loop.quit)
            view.loadFinished.connect(lambda ok: loop.quit())
            t.start(self.timeout_ms)
            loop.exec_()
            t.stop()

            # 回 GUI 线程执行 JS
            QMetaObject.invokeMethod(
                page, "runJavaScript",
                Qt.BlockingQueuedConnection,
                Q_ARG(str, "document.documentElement.outerHTML"),
                Q_ARG(object, _cb),
            )
            html = holder.get("html")
            return {"html": html} if html else None
        except Exception as e:
            print(f"[JsFetcher] 失败: {e}")
            return None


from .domain_state import get_registry, classify_failure, compute_backoff, MAX_RETRIES


def _get_cached_conditional(url: str, db_path: Optional[str] = None) -> dict:
    """从库中取 etag/last_modified 用于条件请求。

    ★ crawl_audit P1-2 修复：主查询必须用 url_key（sha1 十六进制）匹配 ——
      旧实现拿 urlparse(url).path 当键查 sha1 列，永不命中，恒走 url 全库回退；
      且此前无视 db_path 直读全局生产库。现在 db_path 可透传（会话库隔离）。"""
    try:
        from .store import ro_conn
        from .urls import url_key as _url_key
        c = ro_conn(db_path)
        if c is None:
            return {}
        try:
            row = c.execute("SELECT etag, last_modified FROM crawl_page WHERE url_key=?",
                            (_url_key(url),)).fetchone()
            # url_key 未命中时回退用 url 精确匹配（历史行 url_key 可能为空）
            if not row:
                row = c.execute("SELECT etag, last_modified FROM crawl_page WHERE url=?",
                                (url,)).fetchone()
        finally:
            c.close()
        if row and (row[0] or row[1]):
            return {"etag": row[0] or "", "last_modified": row[1] or ""}
    except Exception as _exc:
        logger.debug("[A-15] fetch.py:_get_cached_conditional 异常已结构化记录: %s", _exc)
    return {}


def fetch_url(url: str, depth: int = 0, js_fetcher: Optional[JsFetcher] = None,
              use_js: bool = True, timeout: int = 15,
              db_path: Optional[str] = None) -> dict:
    """抓取单页（★ W24-1: 条件请求 + 指数退避 + 熔断 + 失败分类）

    ★ elapsed_ms 口径 = 纯抓取耗时：t0 从合规闸门之后起算，1.5s 域限速的
      等待不计入页面耗时（此前 t0 在 gate 之前，avg_ms 被限速等待撑到 ~2.5s，
      看板/端侧读到的是"每页总耗时"而非抓取性能）。"""
    # ── 合规闸门 ──
    g = _gate(url, "open")
    if not g.get("ok"):
        return {"status": "blocked", "url": url, "error": g.get("reason", "policy_blocked"),
                "http_status": 0, "mode": "", "elapsed_ms": 0, "size_bytes": 0,
                "failure_type": "robots"}

    domain = (urlparse(url).hostname or "").lower()
    reg = get_registry()
    st = reg.get(domain)
    if st.is_open and not st.can_probe():
        return {"status": "blocked", "url": url,
                "error": f"circuit_open:{st.last_failure_type}",
                "http_status": 0, "mode": "", "elapsed_ms": 0, "size_bytes": 0,
                "failure_type": st.last_failure_type or "circuit_open"}

    # ★ elapsed_ms 起点：闸门/熔断已放行、限速等待已结束 → 纯抓取耗时
    t0 = time.time()

    # ── 条件请求头 ──
    headers = dict(_UA)
    cond = _get_cached_conditional(url, db_path=db_path)
    if cond.get("etag"):
        headers["If-None-Match"] = cond["etag"]
    if cond.get("last_modified"):
        headers["If-Modified-Since"] = cond["last_modified"]

    last_exc = None
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            r = requests.get(url, headers=headers, timeout=timeout)
            break
        except Exception as e:
            last_exc = e
            ft = classify_failure(e)
            if attempt < MAX_RETRIES:
                delay = compute_backoff(attempt,
                                        float(getattr(e, "retry_after", 0) or 0))
                time.sleep(delay)
            else:
                # 记录失败 + 熔断
                st.record_failure(ft)
                return {"status": "fail", "url": url,
                        "error": str(e)[:200], "http_status": 0, "mode": "",
                        "elapsed_ms": int((time.time() - t0) * 1000),
                        "size_bytes": 0, "failure_type": ft}
    else:
        # 所有重试耗尽
        ft = classify_failure(last_exc) if last_exc else "unknown"
        st.record_failure(ft)
        return {"status": "fail", "url": url,
                "error": str(last_exc)[:200] if last_exc else "max_retries",
                "http_status": 0, "mode": "",
                "elapsed_ms": int((time.time() - t0) * 1000),
                "size_bytes": 0, "failure_type": ft}

    elapsed = int((time.time() - t0) * 1000)
    size_bytes = len(r.content or b"")

    # ★ W24-1: 304 Not Modified → 跳过解析，标记 not_modified
    if r.status_code == 304:
        st.record_success()
        # ★ crawl_audit P1-1 修复：304 分支必须带 url_key/domain ——
        #   旧实现两字段缺失，save_page 落 NULL 键行（历史库 333 条），
        #   域聚合/计划查找/会话内去重对这批行全部失效。
        from .urls import url_key as _uk_304
        return {"status": "not_modified", "url": url, "error": "",
                "url_key": _uk_304(url), "domain": domain,
                "http_status": 304, "mode": "", "elapsed_ms": elapsed,
                "size_bytes": size_bytes, "failure_type": "",
                "etag": r.headers.get("ETag", ""),
                "last_modified": r.headers.get("Last-Modified", "")}

    if r.status_code in _BLOCKED_HTTP:
        ft = "http_4xx" if r.status_code < 500 else "http_5xx"
        st.record_failure(ft)
        return {
            "status": "blocked", "url": url, "error": f"http_{r.status_code}",
            "http_status": r.status_code, "mode": "", "elapsed_ms": elapsed,
            "size_bytes": size_bytes, "failure_type": ft,
        }

    # ★ 成功 → 记录
    st.record_success()

    # ★ W25-H2: PDF 附件分支（公告正文大多在 PDF 里，先于 HTML 解析）
    _ct = (r.headers.get("Content-Type") or "")
    try:
        from .extract_pdf import needs_pdf as _needs_pdf
    except ImportError:
        from shared.crawler.extract_pdf import needs_pdf as _needs_pdf
    if _needs_pdf(_ct, url):
        try:
            from .extract_pdf import extract_pdf_text as _pdf_text, \
                extract_pdf_meta as _pdf_meta
        except ImportError:
            from shared.crawler.extract_pdf import extract_pdf_text as _pdf_text, \
                extract_pdf_meta as _pdf_meta
        pdf_text = _pdf_text(r.content or b"")
        if pdf_text:
            from .urls import url_key as _uk, content_hash as _ch
            from .extract import compute_quality as _cq
            pdf_meta = _pdf_meta(r.content or b"")
            return {
                "status": "ok",
                "url": url,
                "url_key": _uk(url),
                "content_hash": _ch(pdf_text),
                "domain": domain,
                "depth": depth,
                "http_status": r.status_code,
                "mode": "pdf",
                "title": pdf_meta.get("pdf_title") or url.rsplit("/", 1)[-1][:120],
                "author": pdf_meta.get("pdf_author", ""),
                "published_at": "",
                "summary": pdf_text[:300],
                "clean_html": "",
                "text": pdf_text,
                "text_len": len(pdf_text),
                "img_count": 0,
                "link_count": 0,
                "quality": _cq(pdf_text, bool(pdf_meta.get("pdf_title")), {}, 0, 0),
                "elapsed_ms": elapsed,
                "size_bytes": size_bytes,
                "links": [],
                "meta": pdf_meta,
                "etag": r.headers.get("ETag", ""),
                "last_modified": r.headers.get("Last-Modified", ""),
            }
        # PDF 解析失败 → 落到 HTML 分支，会得到低质量行（可观测）

    raw = r.text or ""
    # ── 解析 ──
    try:
        from shared.web_capture import parse_html
    except ImportError:
        from web_capture import parse_html

    parsed = parse_html(raw, url, "auto")
    mode = parsed.get("mode", "visual")
    text_chars = (parsed.get("quality") or {}).get("text_chars", 0)

    # ── JS 回退 ──
    if mode == "needs_js" and use_js and js_fetcher is not None:
        js_result = js_fetcher.fetch(url)
        if js_result and js_result.get("html"):
            parsed = parse_html(js_result["html"], url, "auto")
            mode = parsed.get("mode", "visual")

    if mode == "needs_js":
        return {
            "status": "needs_js", "url": url, "error": "needs_js",
            "http_status": r.status_code, "mode": "needs_js",
            "elapsed_ms": elapsed, "size_bytes": size_bytes,
        }

    # ── 元数据 ──
    try:
        from .extract import extract_meta
        meta = extract_meta(raw, url)
    except ImportError:
        from shared.crawler.extract import extract_meta
        meta = extract_meta(raw, url)

    # ── 链接提取 ──
    # ★ D3-03: 相对链接支持。以「重定向后最终地址 r.url」为 base 做 urljoin，
    #   再过滤 scheme ∈ {http, https}（mailto/javascript/data/tel 天然排除），
    #   丢弃纯片段（#…），去重并维持每页 50 条上限。
    links = []
    try:
        from bs4 import BeautifulSoup
        from urllib.parse import urljoin, urlparse as _urlparse
        base = getattr(r, "url", None) or url
        soup = BeautifulSoup(raw, "html.parser")
        seen = set()
        for a in soup.find_all("a", href=True):
            href = (a["href"] or "").strip()
            if not href or href.startswith("#"):
                continue
            absolute = urljoin(base, href)
            if _urlparse(absolute).scheme not in ("http", "https"):
                continue
            if absolute in seen:
                continue
            seen.add(absolute)
            links.append(absolute)
            if len(links) >= 50:
                break
    except Exception as _exc:
        logger.debug("[A-15] fetch.py:283 fetch_url 链接提取异常已结构化记录: %s", _exc)

    from .urls import url_key, content_hash, normalize_url
    from .extract import compute_quality, count_features
    text_plain = re.sub(r"<[^>]+>", " ", parsed.get("clean_html") or "")
    text_plain = re.sub(r"\s+", " ", text_plain).strip()
    feat = count_features(raw, text_plain)
    q = compute_quality(text_plain, bool(parsed.get("title")), meta,
                        feat["link_count"], feat["paragraphs"])

    return {
        "status": "ok",
        "url": url,
        "url_key": url_key(url),
        "content_hash": content_hash(text_plain),
        "domain": (urlparse(url).hostname or "").lower(),
        "depth": depth,
        "http_status": r.status_code,
        "mode": mode,
        "title": parsed.get("title") or meta.get("title") or "",
        "author": meta.get("author", ""),
        "published_at": meta.get("published_at", ""),
        "summary": text_plain[:300],
        "clean_html": parsed.get("clean_html", ""),
        "text": text_plain,
        "text_len": len(text_plain),
        "img_count": (parsed.get("quality") or {}).get("img_count", 0),
        "link_count": len(links),
        "quality": q,
        "elapsed_ms": elapsed,
        "size_bytes": size_bytes,
        "links": links[:50],
        "meta": meta,
        "etag": r.headers.get("ETag", ""),
        "last_modified": r.headers.get("Last-Modified", ""),
    }
