# -*- coding: utf-8 -*-
"""★ W24-3: 域级指标（crawl_domain_metric）

- 新表 crawl_domain_metric(domain, window_start, requests, ok, fail,
  p50_ms, p95_ms, http_429, extract_hit_rate)
- 每页完成后更新；按小时聚合
"""
from __future__ import annotations

import os
import sqlite3
import time
from typing import Dict, Optional

try:
    from .store import conn, ensure_schema
except ImportError:
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from shared.crawler.store import conn, ensure_schema

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_DB = os.path.join(_ROOT, "data", "crawl.db")

DDL = """CREATE TABLE IF NOT EXISTS crawl_domain_metric(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    domain TEXT,
    window_start TEXT,
    requests INTEGER DEFAULT 0,
    ok INTEGER DEFAULT 0,
    fail INTEGER DEFAULT 0,
    p50_ms REAL,
    p95_ms REAL,
    http_429 INTEGER DEFAULT 0,
    extract_hit_rate REAL
)"""


def ensure_metric_table(db_path: Optional[str] = None):
    ensure_schema(db_path)
    c = conn(db_path)
    c.execute(DDL)
    c.commit()


def _percentile(values: list, p: float) -> Optional[float]:
    if not values:
        return None
    s = sorted(values)
    idx = int(len(s) * p / 100.0)
    if idx >= len(s):
        idx = len(s) - 1
    return round(s[idx], 2)


def record_page(domain: str, elapsed_ms: float, status: str,
                extract_ok: bool, failure_type: str = "",
                db_path: Optional[str] = None) -> None:
    """每页完成后更新域指标（按小时窗口聚合）"""
    ensure_metric_table(db_path)
    window = time.strftime("%Y-%m-%d %H:00:00")
    c = conn(db_path)
    try:
        row = c.execute(
            "SELECT id, requests, ok, fail, p50_ms, p95_ms, http_429, extract_hit_rate "
            "FROM crawl_domain_metric WHERE domain=? AND window_start=?",
            (domain, window)).fetchone()
        is_ok = 1 if status == "ok" else 0
        is_fail = 0 if is_ok else 1
        is_429 = 1 if failure_type == "http_429" else 0
        # 简化：p50/p95 用滑动近似（取当前值与历史均值的均值）
        if row:
            rid = row["id"]
            req = row["requests"] + 1
            ok = row["ok"] + is_ok
            fail = row["fail"] + is_fail
            h429 = row["http_429"] + is_429
            p50 = round((row["p50_ms"] + elapsed_ms) / 2, 2) if row["p50_ms"] else elapsed_ms
            p95 = round(max(row["p95_ms"] or 0, elapsed_ms), 2)
            hit = round((row["extract_hit_rate"] * row["requests"] + (1.0 if extract_ok else 0.0)) / req, 4) if req else 0.0
            c.execute(
                "UPDATE crawl_domain_metric SET requests=?, ok=?, fail=?, p50_ms=?, p95_ms=?, "
                "http_429=?, extract_hit_rate=? WHERE id=?",
                (req, ok, fail, p50, p95, h429, hit, rid))
        else:
            req = 1
            ok = is_ok
            fail = is_fail
            h429 = is_429
            p50 = elapsed_ms
            p95 = elapsed_ms
            hit = 1.0 if extract_ok else 0.0
            c.execute(
                "INSERT INTO crawl_domain_metric(domain,window_start,requests,ok,fail,"
                "p50_ms,p95_ms,http_429,extract_hit_rate) VALUES(?,?,?,?,?,?,?,?,?)",
                (domain, window, req, ok, fail, p50, p95, h429, hit))
        c.commit()
    except Exception as e:
        print(f"[metrics] record_page error: {e}")


def get_domain_health(domain: str, hours: int = 24,
                      db_path: Optional[str] = None) -> Dict:
    """查询域健康（最近 N 小时聚合）"""
    ensure_metric_table(db_path)
    c = conn(db_path)
    try:
        rows = c.execute(
            "SELECT window_start, requests, ok, fail, p50_ms, p95_ms, http_429, extract_hit_rate "
            "FROM crawl_domain_metric WHERE domain=? ORDER BY window_start DESC LIMIT ?",
            (domain, hours)).fetchall()
    except Exception:
        rows = []
    if not rows:
        return {"domain": domain, "found": False}
    total_req = sum(r["requests"] for r in rows)
    total_ok = sum(r["ok"] for r in rows)
    total_fail = sum(r["fail"] for r in rows)
    total_429 = sum(r["http_429"] for r in rows)
    p95_vals = [r["p95_ms"] for r in rows if r["p95_ms"]]
    avg_hit = round(sum(r["extract_hit_rate"] * r["requests"] for r in rows) / max(1, total_req), 4)
    return {
        "domain": domain,
        "found": True,
        "hours": len(rows),
        "requests": total_req,
        "ok": total_ok,
        "fail": total_fail,
        "fail_rate": round(total_fail / max(1, total_req), 4),
        "http_429": total_429,
        "rate_429": round(total_429 / max(1, total_req), 4),
        "p95_ms": max(p95_vals) if p95_vals else None,
        "extract_hit_rate": avg_hit,
        "windows": [dict(r) for r in rows[:5]],
    }


def top_failing_domains(limit: int = 5, db_path: Optional[str] = None) -> list:
    """Top N 失败域"""
    ensure_metric_table(db_path)
    c = conn(db_path)
    try:
        rows = c.execute(
            "SELECT domain, SUM(requests) req, SUM(fail) fail, SUM(http_429) h429 "
            "FROM crawl_domain_metric GROUP BY domain HAVING fail>0 ORDER BY fail DESC LIMIT ?",
            (limit,)).fetchall()
    except Exception:
        rows = []
    return [dict(r) for r in rows]


if __name__ == "__main__":
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        db = os.path.join(td, "t.db")
        ensure_metric_table(db)
        record_page("example.com", 100, "ok", True)
        record_page("example.com", 200, "ok", True)
        record_page("example.com", 150, "fail", False, "timeout")
        print("health:", get_domain_health("example.com", db_path=db))
        print("top_failing:", top_failing_domains(db_path=db))
