# -*- coding: utf-8 -*-
"""★ A10: 导出 v1

- JSONL：一页一行，metadata 必含，include_content 可选
- CSV：utf-8-sig，列顺序固定
- Markdown：会话摘要 + 失败 Top10 + 域名分布
- 分块写盘，内存不与表规模挂钩
- 禁止：整表读内存；覆盖已有文件（文件名带时间戳）
"""
from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

import csv
import io
import json
import os
import time
from typing import Optional

try:
    from .store import ro_conn, ensure_schema
except ImportError:
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from shared.crawler.store import ro_conn, ensure_schema

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_CSV_COLS = ["page_id", "url", "domain", "depth", "status", "http_status", "mode",
             "title", "author", "published_at", "text_len", "img_count", "link_count",
             "quality", "elapsed_ms", "size_bytes", "fetched_at"]


def _chunked_pages(session_id: str, db_path: Optional[str] = None, chunk: int = 500):
    """分块产出 crawl_page 行（内存不与表规模挂钩）"""
    c = ro_conn(db_path)
    if c is None:
        return
    try:
        cur = c.execute(
            "SELECT id,url,domain,depth,status,http_status,mode,title,author,"
            "published_at,text_len,img_count,link_count,quality,elapsed_ms,size_bytes,"
            "fetched_at FROM crawl_page WHERE session_id=? ORDER BY id",
            (session_id,))
        while True:
            rows = cur.fetchmany(chunk)
            if not rows:
                break
            for r in rows:
                yield [r[i] for i in range(len(r))]
    finally:
        c.close()


def export_html(session_id: str, out_dir: Optional[str] = None,
                db_path: Optional[str] = None) -> dict:
    """★ C9: 单页离线存档（内联 CSS + mark 高亮 + 侧栏列表，全转义）"""
    import html as _html
    ensure_schema(db_path)
    out = out_dir or os.path.join(_ROOT, "data", "reports")
    os.makedirs(out, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    path = os.path.join(out, f"crawl_{session_id[:24]}_{stamp}.html")
    c = ro_conn(db_path)
    if c is None:
        return {"success": False, "error": "数据库不可读"}
    try:
        pages = c.execute(
            "SELECT id,url,title,text_len,status FROM crawl_page WHERE session_id=? "
            "ORDER BY id", (session_id,)).fetchall()
        if not pages:
            return {"success": False, "error": f"session {session_id} 无页面数据"}
        anns = c.execute(
            "SELECT a.id,a.page_id,a.quote,a.note,a.tags,a.color FROM crawl_annotation a "
            "JOIN crawl_page p ON a.page_id=p.id WHERE p.session_id=? AND a.deleted=0",
            (session_id,)).fetchall()
        # 内容
        contents = {}
        for p in pages:
            cc = c.execute("SELECT text FROM crawl_content WHERE page_id=?",
                           (p["id"],)).fetchone()
            contents[p["id"]] = (cc["text"] if cc else "")[:8000]
    finally:
        c.close()
    # 构造 HTML
    side = "".join(
        f'<div class="side-item" data-pid="{p["id"]}">[{p["status"]}] {_html.escape(p["title"] or p["url"])}</div>'
        for p in pages)
    body_parts = []
    for p in pages:
        text = _html.escape(contents.get(p["id"], ""))
        # 标注高亮
        for a in anns:
            if a["page_id"] == p["id"] and a["quote"]:
                q = _html.escape(a["quote"])
                text = text.replace(q, f'<mark style="background:{_html.escape(a["color"])}">{q}</mark>')
        body_parts.append(
            f'<div class="page" id="pg{p["id"]}">'
            f'<h2>{_html.escape(p["title"] or p["url"])}</h2>'
            f'<div class="url">{_html.escape(p["url"])}</div>'
            f'<div class="content">{text}</div></div>')
    ann_list = "".join(
        f'<li><span style="color:{_html.escape(a["color"])}">●</span> '
        f'{_html.escape(a["quote"])} — {_html.escape(a["note"])}</li>'
        for a in anns)
    html_doc = (
        '<!DOCTYPE html><html><head><meta charset="utf-8"><title>爬取存档</title>'
        '<style>'
        'body{font-family:sans-serif;margin:0;display:flex;min-height:100vh}'
        '.side{width:260px;background:#f7f8fa;padding:12px;overflow-y:auto;flex-shrink:0}'
        '.side-item{padding:4px 8px;font-size:12px;cursor:pointer;border-bottom:1px solid #eee}'
        '.main{flex:1;padding:16px;overflow-y:auto}'
        '.page{margin-bottom:24px;padding-bottom:16px;border-bottom:1px solid #ddd}'
        '.page h2{font-size:15px;margin:0 0 4px}'
        '.url{font-size:11px;color:#888;margin-bottom:8px;word-break:break-all}'
        '.content{font-size:13px;line-height:1.7;white-space:pre-wrap}'
        'mark{padding:0 2px}'
        '.annos{margin-top:16px;padding:12px;background:#fafafa}'
        '.annos li{font-size:12px;margin:4px 0;list-style:none}'
        '</style></head><body>'
        f'<div class="side">{side}</div>'
        f'<div class="main"><h1>爬取离线存档</h1>'
        f'<div class="annos"><h3>标注（{len(anns)} 条）</h3><ul>{ann_list}</ul></div>'
        + "".join(body_parts) +
        '</div></body></html>')
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(html_doc)
    return {"success": True, "path": path, "rows": len(pages),
            "annotations": len(anns)}


def export_jsonl(session_id: str, out_dir: Optional[str] = None,
                 include_content: bool = False,
                 db_path: Optional[str] = None) -> dict:
    ensure_schema(db_path)
    out = out_dir or os.path.join(_ROOT, "data", "reports")
    os.makedirs(out, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    path = os.path.join(out, f"crawl_{session_id[:24]}_{stamp}.jsonl")
    n = 0
    with open(path, "w", encoding="utf-8") as fh:
        for row in _chunked_pages(session_id, db_path):
            rec = dict(zip(_CSV_COLS, row))
            rec["metadata"] = {"session_id": session_id, "exported_at": stamp}
            if include_content:
                try:
                    c = ro_conn(db_path)
                    if c:
                        cc = c.execute("SELECT text FROM crawl_content WHERE page_id=?",
                                       (rec["page_id"],)).fetchone()
                        rec["text"] = (cc["text"] if cc else "")[:2000]
                        c.close()
                except Exception:
                    rec["text"] = ""
            # ★ C9: 含 annotations
            try:
                c = ro_conn(db_path)
                if c:
                    anns = c.execute(
                        "SELECT quote,note,tags,color,status FROM crawl_annotation "
                        "WHERE page_id=? AND deleted=0", (rec["page_id"],)).fetchall()
                    rec["annotations"] = [dict(a) for a in anns]
                    c.close()
            except Exception:
                rec["annotations"] = []
            fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
            n += 1
    if n == 0:
        try:
            os.remove(path)
        except OSError as _exc:
            logger.debug("[A-15] export.py:169 export_jsonl 异常已结构化记录: %s", _exc)
        return {"success": False, "error": f"session {session_id} 无页面数据"}
    return {"success": True, "path": path, "rows": n}


def export_csv(session_id: str, out_dir: Optional[str] = None,
               db_path: Optional[str] = None) -> dict:
    ensure_schema(db_path)
    out = out_dir or os.path.join(_ROOT, "data", "reports")
    os.makedirs(out, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    path = os.path.join(out, f"crawl_{session_id[:24]}_{stamp}.csv")
    n = 0
    with open(path, "w", encoding="utf-8-sig", newline="") as fh:
        w = csv.writer(fh, lineterminator="\n")
        w.writerow(_CSV_COLS)
        for row in _chunked_pages(session_id, db_path):
            w.writerow(row)
            n += 1
    if n == 0:
        try:
            os.remove(path)
        except OSError as _exc:
            logger.debug("[A-15] export.py:192 export_csv 异常已结构化记录: %s", _exc)
        return {"success": False, "error": f"session {session_id} 无页面数据"}
    return {"success": True, "path": path, "rows": n}


def export_markdown(session_id: str, out_dir: Optional[str] = None,
                    db_path: Optional[str] = None) -> dict:
    ensure_schema(db_path)
    out = out_dir or os.path.join(_ROOT, "data", "reports")
    os.makedirs(out, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    path = os.path.join(out, f"crawl_{session_id[:24]}_{stamp}.md")
    c = ro_conn(db_path)
    if c is None:
        return {"success": False, "error": "数据库不可读"}
    try:
        s = c.execute("SELECT * FROM crawl_session WHERE session_id=?", (session_id,)).fetchone()
        if s is None:
            return {"success": False, "error": f"session {session_id} 不存在"}
        s = dict(s)
        rows = c.execute(
            "SELECT domain,COUNT(*) n FROM crawl_page WHERE session_id=? "
            "GROUP BY domain ORDER BY n DESC", (session_id,)).fetchall()
        fails = c.execute(
            "SELECT url,error FROM crawl_page WHERE session_id=? AND status!='ok' "
            "ORDER BY id DESC LIMIT 10", (session_id,)).fetchall()
    finally:
        c.close()
    L = [f"# 会话导出：{s.get('name') or session_id}", "",
         f"- 会话号：{session_id}",
         f"- 种子：{s.get('seed_url')}",
         f"- 状态：{s.get('state')}",
         f"- 总页：{s.get('total', 0)} / 成功：{s.get('ok', 0)} / 失败：{s.get('fail', 0)}",
         f"- 去重命中：{s.get('dedup_hit', 0)}",
         f"- 体积：{s.get('size_bytes', 0)} 字节", "",
         "## 域名分布", "", "| 域名 | 页数 |", "| --- | --- |"]
    for r in rows:
        L.append(f"| {r['domain'] or '—'} | {r['n']} |")
    L += ["", "## 失败 Top10", "", "| URL | 原因 |", "| --- | --- |"]
    for r in fails:
        L.append(f"| {r['url'] or '—'} | {(r['error'] or '')[:60]} |")
    if not fails:
        L.append("| （无失败） | — |")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(L) + "\n")
    return {"success": True, "path": path, "rows": len(rows), "fails": len(fails)}
