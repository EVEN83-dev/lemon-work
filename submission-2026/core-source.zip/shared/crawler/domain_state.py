# -*- coding: utf-8 -*-
"""★ W24-1: 域级状态机（熔断 + 退避 + 条件请求支持）

- 同域连续 5 次失败 → open 10 分钟
- half-open 只放 1 个探测请求
- 退避：429/503/timeout 指数退避 + jitter，最多 3 次
- 尊重 Retry-After
- 失败分类：timeout / dns / tls / http_4xx / http_5xx / robots / parse / js_required
"""
from __future__ import annotations

import random
import threading
import time
from typing import Dict, Optional

OPEN_THRESHOLD = 5        # 连续失败阈值
OPEN_DURATION = 600       # open 持续时间（秒）
MAX_RETRIES = 3           # 最大重试
BASE_BACKOFF = 1.0        # 基础退避（秒）

FAILURE_TYPES = {
    "timeout", "dns", "tls", "http_4xx", "http_5xx",
    "robots", "parse", "js_required", "unknown",
}


class DomainState:
    """单域状态"""

    def __init__(self, domain: str):
        self.domain = domain
        self.consecutive_failures = 0
        self.open_until = 0.0
        self.half_open_sent = False
        self.last_failure_type: Optional[str] = None
        self.total_ok = 0
        self.total_fail = 0
        self.last_ok_at: Optional[float] = None
        self.last_fail_at: Optional[float] = None

    @property
    def is_open(self) -> bool:
        return time.time() < self.open_until

    def record_success(self):
        self.consecutive_failures = 0
        self.half_open_sent = False
        self.total_ok += 1
        self.last_ok_at = time.time()

    def record_failure(self, failure_type: str = "unknown"):
        if failure_type not in FAILURE_TYPES:
            failure_type = "unknown"
        self.consecutive_failures += 1
        self.last_failure_type = failure_type
        self.total_fail += 1
        self.last_fail_at = time.time()
        if self.consecutive_failures >= OPEN_THRESHOLD:
            self.open_until = time.time() + OPEN_DURATION
            self.half_open_sent = False

    def can_probe(self) -> bool:
        """open 期间不允许常规抓取（half-open 由 try_half_open 单独处理）"""
        return not self.is_open

    def try_half_open(self) -> bool:
        """half-open：仅允许 1 个探测请求通过"""
        if not self.is_open:
            return False
        if not self.half_open_sent:
            self.half_open_sent = True
            return True
        return False

    def to_dict(self) -> dict:
        return {
            "domain": self.domain,
            "consecutive_failures": self.consecutive_failures,
            "is_open": self.is_open,
            "open_until": self.open_until,
            "last_failure_type": self.last_failure_type,
            "total_ok": self.total_ok,
            "total_fail": self.total_fail,
        }


class DomainRegistry:
    """全局域状态注册表（线程安全）"""

    def __init__(self):
        self._lock = threading.Lock()
        self._states: Dict[str, DomainState] = {}

    def get(self, domain: str) -> DomainState:
        with self._lock:
            if domain not in self._states:
                self._states[domain] = DomainState(domain)
            return self._states[domain]

    def snapshot(self) -> list:
        with self._lock:
            return [s.to_dict() for s in self._states.values()]


_registry: Optional[DomainRegistry] = None
_reg_lock = threading.Lock()


def get_registry() -> DomainRegistry:
    global _registry
    if _registry is None:
        with _reg_lock:
            if _registry is None:
                _registry = DomainRegistry()
    return _registry


def classify_failure(exc: Exception, status: Optional[int] = None) -> str:
    """失败分类"""
    if status is not None:
        if 400 <= status < 500:
            return "http_4xx"
        if 500 <= status < 600:
            return "http_5xx"
    name = type(exc).__name__.lower()
    msg = str(exc).lower()
    if "timeout" in name or "timeout" in msg:
        return "timeout"
    if "dns" in msg or "name or service not known" in msg or "getaddrinfo" in msg:
        return "dns"
    if "ssl" in msg or "tls" in msg or "certificate" in msg:
        return "tls"
    return "unknown"


def compute_backoff(attempt: int, retry_after: Optional[float] = None) -> float:
    """指数退避 + jitter；尊重 Retry-After"""
    if retry_after and retry_after > 0:
        return min(retry_after, 60.0)
    base = BASE_BACKOFF * (2 ** max(0, attempt - 1))
    jitter = random.uniform(0, 0.5) * base
    return min(base + jitter, 30.0)


if __name__ == "__main__":
    r = get_registry()
    s = r.get("example.com")
    print("initial:", s.to_dict())
    for i in range(6):
        s.record_failure("timeout")
    print("after 6 failures:", s.to_dict())
    print("can_probe:", s.can_probe())
    print("can_probe again:", s.can_probe())
