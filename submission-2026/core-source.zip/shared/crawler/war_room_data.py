# -*- coding: utf-8 -*-
"""★ W25-H10-T3: 作战室实时数据层（纯函数，无 Qt 依赖，只读 ro 连接）

war_room(session_id) 返回注入 window.updateWarRoom(json) 的载荷：
  session_id, state          会话标识与状态
  plan                       下一站 = 最早一条 pending edge
                             {url, title, verdict, quality, depth, pending_total}
                             （title/verdict/quality 尽量取同 URL 已抓页的真实值，
                              未抓过则为 None —— frontier 空时 plan=None）
  verdicts                   {keep, maybe, cut}（SQL 端聚合，判定阈值同 board_data.judge）
  domain_health              [{domain, p95_ms, rate_429, extract, requests, fail,
                              circuit, fetching}]
                             p95/429/extract 读 crawl_domain_metric 最近窗口，
                             circuit 读进程内 DomainRegistry 状态机快照，
                             fetching = 会话运行中且该域 20s 内有真实抓取
  queue                      crawl_edge 按 state 计数 {pending, done, failed, skipped}
  rate_429 / circuit         顶层聚合（最差域口径），供 gauges 直读
  log                        最近 12 条真实 crawl_page 行（含 fetched_at 真实时间戳）

铁律：只读 ro 连接；所有查询 session_id 过滤或显式 LIMIT，禁止全表读入。
"""
from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

import os
import sqlite3
import time
from typing import Optional

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_DB = os.path.join(_ROOT, "data", "crawl.db")

FETCH_RECENT_S = 20     # 域 fetching 判定的真实抓取新鲜度窗口
LOG_ROWS = 12           # 会话记录流行数


def _num(v, default: float = 0.0) -> float:
    """★ crawl_audit P1-9: 数值兜底 —— metric 行任何列缺失/脏值都落成数值，
    保证 war_room 载荷里 p95/429/extract/requests/fail 永不为 None/undefined。"""
    try:
        return float(v if v is not None else 0) or default
    except (TypeError, ValueError):
        return default


def _fix_mojibake(s: str) -> str:
    """修复 utf-8 被按 latin-1 落库的乱码标题（与看板窗口层同款）"""
    s = str(s or "")
    try:
        if any(ch in s for ch in ("æ", "å", "ç", "è", "ä", "Ã", "Â")):
            fixed = s.encode("latin-1", errors="ignore").decode("utf-8", errors="ignore")
            if fixed and not any(ch in fixed for ch in ("æ", "å", "Ã", "Â")):
                return fixed
    except Exception as _exc:
        logger.debug("[A-15] war_room_data.py:44 _fix_mojibake 修复失败保持原文: %s", _exc)
    return s


def _connect(db_path: Optional[str]) -> Optional[sqlite3.Connection]:
    p = db_path or _DB
    if not os.path.exists(p):
        return None
    c = sqlite3.connect(f"file:{p}?mode=ro", uri=True)
    c.row_factory = sqlite3.Row
    return c


def _session_state(c: sqlite3.Connection, session_id: str) -> str:
    r = c.execute("SELECT state FROM crawl_session WHERE session_id=?",
                  (session_id,)).fetchone()
    return str(r["state"] or "") if r else ""


def _verdicts(c: sqlite3.Connection, session_id: str) -> dict:
    """判定计数（SQL 聚合，阈值与 board_data.judge 一致）"""
    r = c.execute(
        "SELECT "
        " SUM(CASE WHEN status IN ('ok','not_modified') AND quality>=0.5 "
        "     AND IFNULL(text_len,0)>=400 THEN 1 ELSE 0 END) keep,"
        " SUM(CASE WHEN status IN ('ok','not_modified') AND NOT (quality>=0.5 "
        "     AND IFNULL(text_len,0)>=400) AND (quality>=0.25 "
        "     OR IFNULL(text_len,0)>=150) THEN 1 ELSE 0 END) maybe,"
        " SUM(CASE WHEN NOT (status IN ('ok','not_modified')) "
        "     OR (NOT (quality>=0.25 OR IFNULL(text_len,0)>=150) "
        "     AND NOT (quality>=0.5 AND IFNULL(text_len,0)>=400)) THEN 1 ELSE 0 END) cut "
        "FROM crawl_page WHERE session_id=?", (session_id,)).fetchone()
    return {"keep": int(r["keep"] or 0), "maybe": int(r["maybe"] or 0),
            "cut": int(r["cut"] or 0)}


def _queue(c: sqlite3.Connection, session_id: str) -> dict:
    q = {"pending": 0, "done": 0, "failed": 0, "skipped": 0}
    for r in c.execute("SELECT state, COUNT(*) n FROM crawl_edge "
                       "WHERE session_id=? GROUP BY state", (session_id,)):
        st = str(r["state"] or "")
        if st in q:
            q[st] = int(r["n"])
        else:
            q[st] = int(r["n"])
    return q


def _plan(c: sqlite3.Connection, session_id: str, queue: dict) -> Optional[dict]:
    """下一站 = 最早一条 pending edge；title/verdict/quality 优先取同 URL 已抓页"""
    edge = c.execute(
        "SELECT id, to_url, to_url_key, depth FROM crawl_edge "
        "WHERE session_id=? AND state='pending' ORDER BY id LIMIT 1",
        (session_id,)).fetchone()
    if not edge:
        return None
    title, verdict, quality = None, None, None
    hit = c.execute(
        "SELECT title, quality, status, text_len FROM crawl_page "
        "WHERE session_id=? AND url_key=? ORDER BY id DESC LIMIT 1",
        (session_id, edge["to_url_key"])).fetchone()
    if hit:
        title = _fix_mojibake(hit["title"])[:40] or None
        quality = round(float(hit["quality"] or 0), 2)
        st = str(hit["status"] or "")
        q = float(hit["quality"] or 0)
        n = int(hit["text_len"] or 0)
        if st in ("ok", "not_modified"):
            if q >= 0.5 and n >= 400:
                verdict = "KEEP"
            elif q >= 0.25 or n >= 150:
                verdict = "MAYBE"
            else:
                verdict = "CUT"
        else:
            verdict = "CUT"
    from urllib.parse import urlparse
    host = urlparse(edge["to_url"] or "").hostname or ""
    return {
        "url": (edge["to_url"] or "")[:120],
        "domain": host,
        "title": title or (host or (edge["to_url"] or "")[:40]),
        "verdict": verdict,
        "quality": quality,
        "depth": int(edge["depth"] or 0),
        "pending_total": int(queue.get("pending", 0)),
    }


def _domain_health(c: sqlite3.Connection, session_id: str,
                   state: str) -> tuple:
    """最近窗口域指标 + circuit 状态机 + 真实 fetching 信号"""
    # 最近 6 个窗口（小时粒度），Python 端按域取最新聚合
    rows = c.execute(
        "SELECT domain, window_start, requests, fail, p95_ms, http_429, "
        "extract_hit_rate FROM crawl_domain_metric "
        "ORDER BY window_start DESC, domain LIMIT 64").fetchall()
    latest = {}
    for r in rows:
        d = str(r["domain"] or "")
        if not d or d in latest:
            continue
        latest[d] = r
    # 真实 fetching：会话运行中 && 该域最近 FETCH_RECENT_S 有抓取
    recent = set()
    if state in ("running", "queued"):
        cut = time.strftime("%Y-%m-%d %H:%M:%S",
                            time.localtime(time.time() - FETCH_RECENT_S))
        for r in c.execute(
                "SELECT domain, MAX(fetched_at) m FROM crawl_page "
                "WHERE session_id=? AND fetched_at>=? GROUP BY domain",
                (session_id, cut)):
            recent.add(str(r["domain"] or ""))
    # circuit：进程内状态机（本进程真实状态；跨进程重启后为 closed）
    try:
        from shared.crawler.domain_state import get_registry
        reg = {s["domain"]: s for s in get_registry().snapshot()}
    except Exception:
        reg = {}

    out = []
    worst_429, circuits = 0.0, []
    for d, r in latest.items():
        req = int(_num(r["requests"]))
        h429 = int(_num(r["http_429"]))
        rate = (h429 / req) if req > 0 else 0.0
        st = reg.get(d)
        if st is not None:
            circuit = "open" if st.get("is_open") else (
                "half_open" if st.get("half_open_sent") else "closed")
        else:
            circuit = "closed"
        fetching = d in recent
        out.append({
            "domain": str(d or ""),
            "p95_ms": round(_num(r["p95_ms"]), 0),
            "rate_429": round(rate, 4),
            "extract": round(_num(r["extract_hit_rate"]), 4),
            "requests": req,
            "fail": int(_num(r["fail"])),
            "circuit": circuit,
            "fetching": bool(fetching),
        })
        worst_429 = max(worst_429, rate)
        circuits.append(circuit)
    # 排序：正在抓的域在前，其余按请求量降序
    out.sort(key=lambda x: (-int(x["fetching"]), -x["requests"]))
    agg = "open" if "open" in circuits else (
        "half_open" if "half_open" in circuits else "closed")
    return out, round(worst_429, 4), agg


def _log_rows(c: sqlite3.Connection, session_id: str) -> list:
    rows = c.execute(
        "SELECT id, domain, title, quality, status, text_len, fetched_at "
        "FROM crawl_page WHERE session_id=? ORDER BY id DESC LIMIT ?",
        (session_id, LOG_ROWS)).fetchall()
    out = []
    for r in reversed(rows):   # 时间正序，便于流式追加
        st = str(r["status"] or "")
        q = float(r["quality"] or 0)
        n = int(r["text_len"] or 0)
        if st in ("ok", "not_modified"):
            verdict = "KEEP" if (q >= 0.5 and n >= 400) else (
                "MAYBE" if (q >= 0.25 or n >= 150) else "CUT")
        else:
            verdict = "CUT"
        out.append({
            "page_id": int(r["id"]),
            "domain": str(r["domain"] or ""),
            "title": _fix_mojibake(r["title"])[:36],
            "verdict": verdict,
            "quality": round(q, 2),
            "fetched_at": str(r["fetched_at"] or ""),
            "status": st,
        })
    return out


_ALERT_RANK = {"ok": 0, "warn": 1, "err": 2}


def _alert(c: sqlite3.Connection, session_id: str,
           health: list, worst_429, circuit) -> dict:
    """★ D5-03: 告警级判定（口径唯一真源在引擎侧，前端只消费枚举）。

    判定：
      fail_rate = fail / max(1,total)：>0.05 → warn，>0.15 → err
      最差域 429 率        ：>0.05 → warn，>0.15 → err
      任一域 circuit open   → err
      robots 拦截 > 0       → warn（合规拦截是引擎正常工作，标提示非错误）
    多项取最严。
    """
    r = c.execute(
        "SELECT COUNT(*) total, "
        "SUM(CASE WHEN status NOT IN ('ok','not_modified','skipped','dup') "
        "THEN 1 ELSE 0 END) fail, "
        "SUM(CASE WHEN IFNULL(error,'') LIKE 'robots%' THEN 1 ELSE 0 END) robots "
        "FROM crawl_page WHERE session_id=?", (session_id,)).fetchone()
    total = int(r["total"] or 0)
    fail = int(r["fail"] or 0)
    robots = int(r["robots"] or 0)
    items = []

    fail_rate = fail / max(1, total)
    if fail_rate > 0.15:
        items.append({"kind": "fail_rate", "level": "err",
                      "detail": f"{fail} 页 fail / {total} 页 · fail_rate={fail_rate:.1%}"})
    elif fail_rate > 0.05:
        items.append({"kind": "fail_rate", "level": "warn",
                      "detail": f"{fail} 页 fail / {total} 页 · fail_rate={fail_rate:.1%}"})

    r429 = float(worst_429 or 0.0)
    if r429 > 0.15:
        items.append({"kind": "rate_429", "level": "err",
                      "detail": f"最差域 429 率 {r429:.1%}"})
    elif r429 > 0.05:
        items.append({"kind": "rate_429", "level": "warn",
                      "detail": f"最差域 429 率 {r429:.1%}"})

    for d in (health or []):
        if str(d.get("circuit", "")).lower() == "open":
            items.append({"kind": "circuit", "level": "err",
                          "detail": f"{d.get('domain', '?')} circuit open"})

    if robots > 0:
        items.append({"kind": "robots_block", "level": "warn",
                      "detail": f"{robots} 页 robots 拦截（合规正常）"})

    level = "ok"
    for it in items:
        if _ALERT_RANK.get(it["level"], 0) > _ALERT_RANK.get(level, 0):
            level = it["level"]
    return {"level": level, "items": items}


def war_room(session_id: str, db_path: Optional[str] = None) -> Optional[dict]:
    """作战室实时数据（只读；session 过滤 + LIMIT，禁止全表读入）"""
    c = _connect(db_path)
    if c is None:
        return None
    try:
        state = _session_state(c, session_id)
        if not state and not session_id:
            return None
        verdicts = _verdicts(c, session_id)
        queue = _queue(c, session_id)
        plan = _plan(c, session_id, queue)
        health, worst_429, circuit = _domain_health(c, session_id, state)
        return {
            "session_id": session_id,
            "state": state,
            "plan": plan,
            "verdicts": verdicts,
            "domain_health": health,
            "queue": queue,
            "rate_429": worst_429,
            "circuit": circuit,
            "alert": _alert(c, session_id, health, worst_429, circuit),
            "log": _log_rows(c, session_id),
        }
    finally:
        c.close()


def latest_session(db_path: Optional[str] = None) -> Optional[str]:
    """最近一个非 failed 会话（与 board_data.latest_session 口径一致）"""
    c = _connect(db_path)
    if c is None:
        return None
    try:
        r = c.execute(
            "SELECT session_id FROM crawl_session WHERE IFNULL(state,'') != 'failed' "
            "ORDER BY created_at DESC LIMIT 1").fetchone()
        return r[0] if r else None
    finally:
        c.close()


if __name__ == "__main__":
    sid = latest_session() or ""
    w = war_room(sid)
    import json
    print(json.dumps(w, ensure_ascii=False, indent=2)[:1500])
