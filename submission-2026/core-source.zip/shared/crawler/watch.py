# -*- coding: utf-8 -*-
"""★ C7: 告警规则

- crawl_watch_set(name,domain,keywords,threshold)
- crawl_watch_eval(session_id)：关键词命中>=threshold 或连续失败>=3
- 命中写 last_fired 并 emit crawl_alert_card（仅 UI 可用）
- 按 page_id 去抖
- 禁止：重复推；告警写进审计库污染统计
"""
from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

import json
import os
import time
from typing import Optional

try:
    from .store import conn, ensure_schema, ro_conn
    from . import events
    from . import ST_COMPLETED, ST_FAILED
except ImportError:
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from shared.crawler.store import conn, ensure_schema, ro_conn
    from shared.crawler import events
    from shared.crawler import ST_COMPLETED, ST_FAILED

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_DB = os.path.join(_ROOT, "data", "crawl.db")


def watch_set(name: str, domain: str, keywords, threshold: int = 1,
              action: dict = None, db_path: Optional[str] = None) -> dict:
    ensure_schema(db_path)
    c = conn(db_path)
    if isinstance(keywords, list):
        keywords = ",".join(keywords)
    cur = c.execute(
        """INSERT INTO crawl_watch(name,domain,keywords,threshold,action_json,enabled)
           VALUES(?,?,?,?,?,1)""",
        (name, domain, keywords, int(threshold),
         json.dumps(action or {}, ensure_ascii=False)))
    c.commit()
    return {"id": cur.lastrowid}


def watch_list(db_path: Optional[str] = None) -> list:
    ensure_schema(db_path)
    c = conn(db_path)
    rows = c.execute("SELECT * FROM crawl_watch WHERE enabled=1").fetchall()
    return [dict(r) for r in rows]


def watch_eval(session_id: str, db_path: Optional[str] = None,
               ui_callback=None) -> dict:
    """评估告警规则；命中写 last_fired 并 emit crawl_alert_card"""
    ensure_schema(db_path)
    c = conn(db_path)
    # 连续失败 >=3
    recent = c.execute(
        "SELECT status FROM crawl_page WHERE session_id=? ORDER BY id DESC LIMIT 3",
        (session_id,)).fetchall()
    consec_fail = 0
    for r in recent:
        if r["status"] != "ok":
            consec_fail += 1
        else:
            break

    watches = c.execute("SELECT * FROM crawl_watch WHERE enabled=1").fetchall()
    fired = []
    for w in watches:
        # 按 page_id 去抖：last_fired 在 60s 内不重复
        if w["last_fired"]:
            try:
                last = time.mktime(time.strptime(w["last_fired"], "%Y-%m-%d %H:%M:%S"))
                if time.time() - last < 60:
                    continue
            except Exception as _exc:
                logger.debug("[A-15] watch.py:79 watch_eval 异常已结构化记录: %s", _exc)
        kws = [k for k in (w["keywords"] or "").split(",") if k]
        if kws:
            # ★ D3-11: 关键词告警按已抓页 title 真实匹配。
            #   旧版此处有一个查 crawl_content.text（该列不存在）+ 恒空 for 循环的
            #   死代码分支，已清除——告警不再「注释宣称」而实际不触发。
            titles = c.execute(
                "SELECT title FROM crawl_page WHERE session_id=?", (session_id,)).fetchall()
            hits = 0
            for t in titles:
                for k in kws:
                    if k in (t["title"] or ""):
                        hits += 1
                        break
            if hits >= int(w["threshold"] or 1):
                c.execute("UPDATE crawl_watch SET last_fired=? WHERE id=?",
                          (time.strftime("%Y-%m-%d %H:%M:%S"), w["id"]))
                c.commit()
                fired.append({"watch_id": w["id"], "name": w["name"],
                              "reason": f"关键词命中 {hits}", "page_id": None})
        # 连续失败
        if consec_fail >= 3:
            c.execute("UPDATE crawl_watch SET last_fired=? WHERE id=?",
                      (time.strftime("%Y-%m-%d %H:%M:%S"), w["id"]))
            c.commit()
            fired.append({"watch_id": w["id"], "name": w["name"],
                          "reason": f"连续失败 {consec_fail}", "page_id": None})
            break

    # ★ W5: emit crawl_alert_card（走 ActionCardRegistry，禁止把 dict 传给 _safe_run_js）
    if fired:
        for f in fired:
            card = {
                "type": "crawl_alert_card",
                "card_id": f"cal_{int(time.time() * 1000)}",
                "title": f"⚠ 告警: {f['name']}",
                "watch_id": f["watch_id"],
                "name": f["name"],
                "reason": f["reason"],
                "session_id": session_id,
                "state": "fired",
                "tools": [{"action": "crawl.status", "label": "查看会话"}],
            }
            try:
                from shared.action_cards import get_action_card_registry
                get_action_card_registry().emit_card(card)
            except Exception:
                # 回退：ui_callback（若提供）
                if ui_callback:
                    try:
                        import json as _json
                        ui_callback("if(window.renderCrawlAlert)window.renderCrawlAlert(%s);"
                                    % _json.dumps(card, ensure_ascii=False))
                    except Exception as _exc:
                        logger.debug("[A-15] watch.py:137 watch_eval 异常已结构化记录: %s", _exc)
    return {"success": True, "fired": fired, "consecutive_fail": consec_fail}


if __name__ == "__main__":
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        db = os.path.join(td, "t.db")
        ensure_schema(db)
        r = watch_set("测试", "example.com", ["风险"], threshold=1, db_path=db)
        print("设置:", r)
        print("评估:", watch_eval("none", db_path=db))
