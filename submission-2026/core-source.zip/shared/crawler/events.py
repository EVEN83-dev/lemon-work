# -*- coding: utf-8 -*-
"""★ A8: 事件总线

- subscribe(cb)/emit(type,payload)，回调在引擎线程同步调用
- 回调异常吞掉并计数 errors，不中断抓取
- 可选桥接 shared/event_bus.py：只在 EventType 末尾加 4 个常量，不改函数
- 禁止：回调里做阻塞 IO；异常冒泡到 worker
"""
from __future__ import annotations

import threading
from typing import Callable, List

_lock = threading.Lock()
_subs: List[Callable] = []
_errors = 0
_error_lock = threading.Lock()


def subscribe(cb: Callable) -> None:
    with _lock:
        _subs.append(cb)


def unsubscribe(cb: Callable) -> None:
    with _lock:
        if cb in _subs:
            _subs.remove(cb)


def emit(ev_type: str, payload: dict) -> None:
    """回调在引擎线程同步调用；异常吞掉并计数"""
    global _errors
    with _lock:
        subs = list(_subs)
    for cb in subs:
        try:
            cb(ev_type, payload)
        except Exception:
            with _error_lock:
                _errors += 1


def error_count() -> int:
    with _error_lock:
        return _errors


def reset_errors() -> None:
    global _errors
    with _error_lock:
        _errors = 0


def subscriber_count() -> int:
    with _lock:
        return len(_subs)


# ── 可选桥接 shared/event_bus.py ──
def bridge_to_event_bus() -> bool:
    """把爬虫事件桥接到 shared/event_bus.py（只加常量，不改函数）"""
    try:
        from shared import event_bus as _eb
    except ImportError:
        return False
    try:
        # 只在 EventType 末尾加 4 个常量
        if not hasattr(_eb.EventType, "CRAWL_SESSION_START"):
            _eb.EventType.CRAWL_SESSION_START = "crawl.session_start"
            _eb.EventType.CRAWL_PAGE_DONE = "crawl.page_done"
            _eb.EventType.CRAWL_PAGE_FAIL = "crawl.page_fail"
            _eb.EventType.CRAWL_SESSION_DONE = "crawl.session_done"
        return True
    except Exception:
        return False


if __name__ == "__main__":
    received = []

    def cb1(t, p):
        received.append((t, p))

    def cb_bad(t, p):
        raise RuntimeError("boom")

    subscribe(cb1)
    subscribe(cb_bad)
    emit("x", {"a": 1})
    emit("y", {"b": 2})
    print("收到:", len(received))
    print("异常计数:", error_count())
    print("事件数 == 页面数:", len(received) == 2)
