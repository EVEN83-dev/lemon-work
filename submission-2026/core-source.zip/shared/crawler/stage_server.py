# -*- coding: utf-8 -*-
"""★ W25-H11: 爬虫作战室舞台服（本机 HTTP，供对话内 iframe 直连）

用途：对话流里自动弹出的作战室卡片是一个 `<iframe src="http://127.0.0.1:PORT/?embed=1">`，
页面自己每 1.5s 拉 `/api/board` 刷新（真实 crawl.db，无硬编码），因此：

  · 与对话栏同滚动（iframe 在消息流里）
  · 不依赖 Qt runJavaScript 注入（断开/重连都能自恢复）
  · 单独用浏览器打开也能看（调试友好）

路由：
  GET /                → standard_mode/ui/crawl_board.html
  GET /api/board?sid=  → {board: session_board(...), war_room: war_room(...),
                          stats: build_stats(...), stats_seq: N}   ★ 窗口2追加键
  GET /api/sessions    → [{session_id, name, state, created_at}]
  GET /api/stats?sid=  → build_stats(...)（★ 窗口2，require_auth 鉴权）
  GET /stats           → standard_mode/ui/crawl_stats.html（★ 窗口2宿主页）
  GET /health          → {ok:true, db:..., sessions:n}

铁律：只读；单进程单例；端口占用自动顺延；任何异常都返回 JSON 不 500 崩栈。
"""
from __future__ import annotations

import hmac
import json
import logging
import os
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

logger = logging.getLogger(__name__)

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_BOARD_HTML = os.path.join(_ROOT, "standard_mode", "ui", "crawl_board.html")
# ★ crawl_audit: 回放降级宿主页（新增文件；作战室视觉定稿 crawl_board.html 不动）
_REPLAY_HOST_HTML = os.path.join(_ROOT, "standard_mode", "ui", "crawl_replay_host.html")
# ★ 窗口2·真实统计层宿主页（新增文件；窗口1蜘蛛段不动）
_STATS_HOST_HTML = os.path.join(_ROOT, "standard_mode", "ui", "crawl_stats.html")

_PREFERRED_PORTS = (8791, 8792, 8793, 8794, 8795)
_server = None
_lock = threading.Lock()

# ★ 本窗口（项48）: 静态资源版本串 —— /stage3 与卡片引用统一带 ?v=，
#   资源改动后前端强刷可见；版本真源由此常量输出（/api/health 透出）。
STAGE_VERSION = "v3-20261121-1"

# ★ 本窗口（项33）: Origin 白名单 —— file:// 宿主（Origin: null）与回环地址放行，
#   其余来源一律 403（防跨站读取本地爬虫统计）。
_ALLOWED_ORIGIN_PREFIXES = ("http://127.0.0.1", "http://localhost",
                            "https://127.0.0.1", "https://localhost")


def _origin_allowed(origin: str) -> bool:
    o = str(origin or "").strip()
    if not o:
        return True          # 非浏览器客户端（Qt fetch/curl）无 Origin → 放行
    if o == "null":
        return True          # file:// 宿主 → 放行（回环语义）
    low = o.lower()
    return any(low.startswith(p) for p in _ALLOWED_ORIGIN_PREFIXES)


def _envelope(ok: bool, data=None, error: str = "", code: str = "") -> dict:
    """★ 本窗口（项32/35）: 统一 {ok,data,error} 信封；错误必带 code 与可读 reason。"""
    return {"ok": bool(ok), "data": data if ok else None,
            "error": "" if ok else str(error or "unknown"),
            "code": "" if ok else (code or "STAGE_ERROR")}


def _require_auth():
    """★ crawl_audit: 新增路由统一走 bridge/api/require_auth.py 鉴权（A-05 单一收口）。

    桥模块不可用时返回 None（路由侧 fail-closed 401，不放行）。"""
    try:
        from bridge.api import require_auth
        return require_auth
    except ImportError:
        if _ROOT not in sys.path:
            sys.path.insert(0, _ROOT)
        try:
            from bridge.api import require_auth
            return require_auth
        except Exception:
            return None


def _bridge_token() -> str:
    """令牌真源 = require_auth.auth_token()；env 缺失时回读启动器持久化令牌。

    ★ 本窗口（项11）: 两者都缺失时自动生成并持久化到
      data/config/bridge_token.json，消除 /stage3 的 401（回环自持）。
    """
    ra = _require_auth()
    if ra is None:
        return ""
    tok = ra.auth_token()
    if tok:
        return tok
    try:
        p = os.path.join(_ROOT, "data", "config", "bridge_token.json")
        if os.path.exists(p):
            with open(p, encoding="utf-8") as f:
                tok = str((json.load(f) or {}).get("token") or "").strip()
            if tok:
                os.environ["LEMON_BRIDGE_TOKEN"] = tok   # check_headers 同源可用
                return tok
    except Exception as _exc:
        logger.debug("[A-15] stage_server.py:72 bridge_token 回读失败用 env: %s", _exc)
    # ★ 自动生成并持久化（回环自持；下次启动直接回读）
    try:
        import secrets
        tok = secrets.token_urlsafe(24)
        p = os.path.join(_ROOT, "data", "config", "bridge_token.json")
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w", encoding="utf-8") as f:
            json.dump({"token": tok, "generated_at":
                       __import__("time").strftime("%Y-%m-%dT%H:%M:%S")}, f)
        os.environ["LEMON_BRIDGE_TOKEN"] = tok
        logger.info("[A-15] bridge_token 已自动生成并持久化: %s", p)
    except Exception as _exc:
        logger.debug("[A-15] bridge_token 自动生成失败: %s", _exc)
    return tok


def _replay_events(sid: str) -> dict:
    """★ crawl_audit: 从 crawl.db 组装回放事件流（只读 ro 连接）。

    事件 = crawl_page 按 id 序（真实抓取顺序），dt = 相邻 fetched_at 真实间隔；
    verdict 复用 board_data.judge 单一真源；gap_cap 取会话自身 p90 间隔
    （数据推导，无硬编码）。任何异常降级为 {"ok": False}，不 500。"""
    try:
        from shared.crawler import MAX_PAGES
        from shared.crawler.board_data import judge
        from shared.crawler.war_room_data import _connect, _fix_mojibake
        from datetime import datetime

        c = _connect(None)
        if c is None:
            return {"ok": False, "error": "crawl_db_missing"}
        try:
            sess = c.execute(
                "SELECT session_id, name, seed_url, state, created_at, started_at, ended_at "
                "FROM crawl_session WHERE session_id=?", (sid,)).fetchone()
            if not sess:
                return {"ok": False, "error": "unknown_session"}
            rows = c.execute(
                "SELECT id, fetched_at, domain, title, status, quality, text_len, "
                "elapsed_ms, size_bytes, mode, depth FROM crawl_page "
                "WHERE session_id=? ORDER BY id ASC LIMIT ?",
                (sid, MAX_PAGES)).fetchall()

            def _ts(s: str):
                try:
                    return datetime.strptime(str(s), "%Y-%m-%d %H:%M:%S").timestamp()
                except Exception:
                    return None

            events, prev = [], None
            for r in rows:
                t = _ts(r["fetched_at"])
                dt = 0.0 if (prev is None or t is None) else max(0.0, t - prev)
                if t is not None:
                    prev = t
                doc = {"status": r["status"], "quality": r["quality"],
                       "text_len": r["text_len"]}
                events.append({
                    "page_id": int(r["id"]), "t": str(r["fetched_at"] or ""),
                    "dt": round(dt, 3),
                    "domain": str(r["domain"] or ""),
                    "title": _fix_mojibake(r["title"]),
                    "verdict": judge(doc),
                    "quality": round(float(r["quality"] or 0), 2),
                    "text_len": int(r["text_len"] or 0),
                    "status": str(r["status"] or ""),
                    "elapsed_ms": int(r["elapsed_ms"] or 0),
                    "size_bytes": int(r["size_bytes"] or 0),
                    "mode": str(r["mode"] or ""), "depth": int(r["depth"] or 0),
                })
            dts = sorted(e["dt"] for e in events if e["dt"] > 0)
            p90 = dts[min(len(dts) - 1, int(round(len(dts) * 0.9)))] if dts else 0.0
            return {
                "ok": True,
                "session": {
                    "session_id": sess["session_id"], "name": sess["name"] or "",
                    "seed": (sess["seed_url"] or "")[:120],
                    "state": sess["state"] or "",
                    "created_at": sess["created_at"] or "",
                    "started": sess["started_at"] or "", "ended": sess["ended_at"] or "",
                },
                "events": events,
                "gap_cap_s": round(p90, 3),
                "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
        finally:
            c.close()
    except Exception as e:
        return {"ok": False, "error": str(e)[:200]}


def _latest_sid() -> str:
    try:
        from shared.crawler.board_data import latest_session
        return latest_session() or ""
    except Exception:
        return ""


def _sessions() -> list:
    try:
        from shared.crawler.war_room_data import _connect
        c = _connect(None)
        if c is None:
            return []
        try:
            rows = c.execute(
                "SELECT session_id, name, state, created_at FROM crawl_session "
                "ORDER BY created_at DESC LIMIT 30").fetchall()
            return [{"session_id": r["session_id"], "name": r["name"] or "",
                     "state": r["state"] or "", "created_at": r["created_at"] or ""}
                    for r in rows]
        finally:
            c.close()
    except Exception:
        return []


def _stats_payload(sid: str, bypass: bool = False) -> dict:
    """★ 窗口2：GET /api/stats 载荷（build_stats 只读聚合；异常降级空形状不 500）

    ★ 本窗口（项26/27）: 与 bridge/api/routes_crawl.stats 同调 shared.crawler.
      build_stats 单一真源（禁止各算一套）；bypass=True 跳 1s 缓存直读库。"""
    try:
        from shared.crawler.stats import build_stats
        return build_stats(sid, bypass=bypass)
    except Exception as e:
        return {"success": False, "error": str(e)[:200], "sid": sid,
                "counters": {}, "by_verdict": {}, "by_domain": [],
                "quality_hist": [], "size_hist": [], "ms_hist": [],
                "timeline": [], "words": [], "arcs": [], "dots": [],
                "edges": [], "tags": {}}


def _timeline_events(sid: str, after_id: int = 0, limit: int = 120) -> list:
    """★ 本窗口（项28）: 判定流增量事件（crawl_judge_event.id 单调递增）。

    每条 {id, ts, page_id, question, p, route, source, verdict}；
    verdict 由 join crawl_page 经 board_data.judge 真实计算（单一真源）。"""
    try:
        from shared.crawler.war_room_data import _connect, _fix_mojibake
        from shared.crawler.board_data import judge as _judge
        c = _connect(None)
        if c is None:
            return []
        try:
            rows = c.execute(
                "SELECT e.id AS id, e.ts AS ts, e.page_id AS page_id, "
                "e.question AS question, e.p AS p, e.route AS route, "
                "e.source AS source, p.quality AS quality, "
                "p.text_len AS text_len, p.status AS status "
                "FROM crawl_judge_event e LEFT JOIN crawl_page p ON p.id=e.page_id "
                "WHERE e.session_id=? AND e.id>? ORDER BY e.id ASC LIMIT ?",
                (sid, int(after_id), int(limit))).fetchall()
            out = []
            for r in rows:
                try:
                    v = _judge({"status": r["status"], "quality": r["quality"],
                                "text_len": r["text_len"]})
                except Exception:
                    v = "MAYBE"
                out.append({"id": int(r["id"]), "ts": str(r["ts"] or ""),
                            "page_id": r["page_id"],
                            "question": _fix_mojibake(r["question"]) if r["question"] else "",
                            "p": (round(float(r["p"]), 3)
                                  if r["p"] is not None else None),
                            "route": str(r["route"] or ""),
                            "source": str(r["source"] or ""),
                            "verdict": v})
            return out
        finally:
            c.close()
    except Exception:
        return []


def _unread_count(sid: str, last_id: int = 0) -> int:
    """★ 本窗口（项29）: 未读判定事件数（id > last_id 的真实行数）。"""
    try:
        from shared.crawler.war_room_data import _connect
        c = _connect(None)
        if c is None:
            return 0
        try:
            return int(c.execute(
                "SELECT COUNT(*) AS n FROM crawl_judge_event "
                "WHERE session_id=? AND id>?", (sid, int(last_id))).fetchone()["n"])
        finally:
            c.close()
    except Exception:
        return 0


def _direction_payload(direction=None) -> dict:
    """★ 本窗口（项30）: GET/POST /api/direction —— 与前端 DIR 状态一致（crawl_meta 真源）。"""
    try:
        from shared.crawler import store as _store
        if direction is None:
            return {"direction": _store.get_direction()}
        r = _store.set_direction(int(direction))
        return r
    except Exception as e:
        return {"ok": False, "error": str(e)[:160], "code": "DIRECTION_FAILED"}


def _board_payload(sid: str) -> dict:
    """看板快照 + 作战室实时聚合（任一失败都降级为空，不让页面炸）

    ★ 窗口2：追加 stats / stats_seq 键（只增不改；既有键结构与消费方不动）。"""
    out = {"board": None, "war_room": None}
    try:
        from shared.crawler.board_data import session_board
        board = session_board(sid) if sid else None
        # 落地库里有 utf-8→latin-1 的历史乱码标题，出口统一修复
        if board and board.get("nodes"):
            try:
                from shared.crawler.war_room_data import _fix_mojibake
                for n in board["nodes"]:
                    n["title"] = _fix_mojibake(n.get("title") or "")[:40]
            except Exception as _exc:
                logger.debug("[A-15] stage_server.py:191 节点标题修复异常已结构化记录: %s", _exc)
        out["board"] = board
    except Exception as e:
        out["board_error"] = str(e)[:200]
    try:
        from shared.crawler.war_room_data import war_room
        out["war_room"] = war_room(sid) if sid else None
    except Exception as e:
        out["war_room_error"] = str(e)[:200]
    # ★ 窗口2：stats 只增不改 —— 失败降级为空统计，不影响 board/war_room
    try:
        from shared.crawler.stats import build_stats
        st = build_stats(sid) if sid else None
        out["stats"] = st
        out["stats_seq"] = int(st.get("seq") or 0) if st else 0
    except Exception as e:
        out["stats_error"] = str(e)[:200]
        out["stats_seq"] = 0
    return out


class _Handler(BaseHTTPRequestHandler):
    server_version = "LemonCrawlStage/1.0"

    def log_message(self, fmt, *args):   # 静默：不刷终端
        pass

    def _send(self, code: int, body: bytes, ctype: str):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        # ★ 允许 file:// 宿主页面（origin: null）跨域读取 —— QWebEngine 里
        #   作战室 iframe 是 file:// 的 crawl_board.html，数据要 fetch 到这里。
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "*")
        self.end_headers()
        try:
            self.wfile.write(body)
        except Exception as _exc:
            logger.debug("[A-15] stage_server.py:223 客户端断开写回失败: %s", _exc)

    def do_OPTIONS(self):
        self._send(204, b"", "text/plain")

    def _json(self, obj, code: int = 200):
        self._send(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"),
                   "application/json; charset=utf-8")

    def _authed(self, qs: dict) -> bool:
        """★ crawl_audit: 新增路由统一鉴权口 —— require_auth.check_headers 为主，
        浏览器直连（EventSource/fetch 无法带自定义头）以 ?token= 兜底比对同一令牌。
        未配置令牌 → fail-closed（LEMON_BRIDGE_INSECURE=1 为 require_auth 自带豁免位）。"""
        ra = _require_auth()
        if ra is not None and ra.check_headers(self.headers):
            return True
        if os.environ.get("LEMON_BRIDGE_INSECURE", "") == "1":
            return True
        tok = (qs.get("token") or [""])[0] or ""
        real = _bridge_token()
        if not real or not tok:
            return False
        try:
            return hmac.compare_digest(tok, real)
        except Exception:
            return False

    def _origin_ok(self) -> bool:
        """★ 本窗口（项33）: Origin 白名单 —— file://(null)/回环放行，其余 403。"""
        return _origin_allowed(self.headers.get("Origin") or "")

    def do_POST(self):
        """★ 本窗口（项30/34）: v3 控制面 POST（direction；统一信封 + 鉴权）。"""
        u = urlparse(self.path)
        path, qs = u.path, parse_qs(u.query)
        n = 0
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except Exception:
            n = 0
        body = {}
        if n > 0:
            try:
                body = json.loads(self.rfile.read(n).decode("utf-8") or "{}")
            except Exception:
                body = {}
        if path == "/api/direction":
            if not self._authed(qs) or not self._origin_ok():
                self._json(_envelope(False, None, "unauthorized", "AUTH"), 401)
                return
            try:
                d = int(body.get("direction", 1))
            except Exception:
                d = 1
            self._json(_envelope(True, _direction_payload(d)))
            return
        self._json(_envelope(False, None, f"not found: {path}", "NOT_FOUND"), 404)

    def do_GET(self):
        u = urlparse(self.path)
        path = u.path
        qs = parse_qs(u.query)

        # ── ★ 本窗口（项48）: favicon 静默（此前 stage3 每次 404 刷日志）──
        if path == "/favicon.ico":
            self._send(204, b"", "image/x-icon")
            return

        if path in ("/", "/index.html", "/board", "/stage"):
            try:
                with open(_BOARD_HTML, "rb") as f:
                    html = f.read()
            except Exception as e:
                self._send(500, ("board html missing: %s" % e).encode("utf-8"),
                           "text/plain; charset=utf-8")
                return
            self._send(200, html, "text/html; charset=utf-8")
            return

        # ── ★ 集群A: 对话内 v3 宽卡宿主（lw_crawl_stage_v3.html；新增路由不改既有）──
        if path == "/stage3":
            try:
                with open(os.path.join(_ROOT, "standard_mode", "ui",
                                       "lw_crawl_stage_v3.html"), "rb") as f:
                    html = f.read()
                # ★ 本窗口（项33）: 托管时注入真实令牌（回环/file:// 宿主语义）；
                #   只替换带引号的字面量（避免误改左值标识符产生非法赋值）；
                #   令牌缺失保持占位串 → 页面新接口 401，自动回落 /api/board。
                tok = _bridge_token()
                if tok:
                    html = html.replace(b'"__STAGE_TOKEN__"',
                                        b'"' + tok.encode("utf-8") + b'"')
                self._send(200, html, "text/html; charset=utf-8")
            except Exception as e:
                self._send(500, ("stage3 html missing: %s" % e).encode("utf-8"),
                           "text/plain; charset=utf-8")
            return

        if path == "/tokens.css":
            try:
                with open(os.path.join(_ROOT, "standard_mode", "ui", "tokens.css"),
                          "rb") as f:
                    self._send(200, f.read(), "text/css; charset=utf-8")
            except Exception as e:
                self._send(404, str(e).encode("utf-8"), "text/plain; charset=utf-8")
            return

        if path == "/health":
            self._json({"ok": True, "db": os.path.exists(
                os.path.join(_ROOT, "data", "crawl.db")),
                "sessions": len(_sessions())})
            return

        if path == "/api/sessions":
            self._json({"sessions": _sessions()})
            return

        if path == "/api/board":
            sid = (qs.get("sid") or [""])[0] or _latest_sid()
            self._json(_board_payload(sid))
            return

        # ── ★ B1/B2: 演出基建静态资源通道（只读白名单；新增路由不改既有返回结构）──
        if path.startswith("/ui/"):
            name = path[len("/ui/"):].split("?")[0]
            if name in ("fx_core.js", "script_engine.js", "fx_demo.html", "tokens.css",
                        "lw_crawl_stats.js", "lw_crawl_stats.css", "lw_visual_spec.js",
                        "lw_crawl_stage_v3.html", "lw_crawl_stage_card.js"):
                try:
                    with open(os.path.join(_ROOT, "standard_mode", "ui", name),
                              "rb") as f:
                        self._send(200, f.read(),
                                   ("text/css; charset=utf-8"
                                    if name.endswith(".css") else
                                    ("application/javascript; charset=utf-8"
                                     if name.endswith(".js")
                                     else "text/html; charset=utf-8")))
                except Exception as e:
                    self._send(500, ("ui file missing: %s" % e).encode("utf-8"),
                               "text/plain; charset=utf-8")
            elif (name.startswith("script/")
                  and name.split("/", 1)[1] in ("crawl_real.json", "agent_real.json")):
                try:
                    with open(os.path.join(_ROOT, "data", "scripts",
                                           name.split("/", 1)[1]), "rb") as f:
                        self._send(200, f.read(), "application/json; charset=utf-8")
                except Exception as e:
                    self._send(500, ("script missing: %s" % e).encode("utf-8"),
                               "text/plain; charset=utf-8")
            else:
                self._json({"error": "not whitelisted", "name": name}, 404)
            return

        # ── ★ 窗口2·真实统计层：宿主页 + 数据端点（新增；蜘蛛段路由不动）──
        if path == "/stats":
            try:
                with open(_STATS_HOST_HTML, "rb") as f:
                    html = f.read()
            except Exception as e:
                self._send(500, ("stats host html missing: %s" % e).encode("utf-8"),
                           "text/plain; charset=utf-8")
                return
            self._send(200, html, "text/html; charset=utf-8")
            return

        # ── ★ crawl_audit 新增路由（走 require_auth 鉴权；既有路由不动）──
        if path == "/api/stats":
            if not self._authed(qs):
                ra = _require_auth()
                self._json(ra.unauthorized_payload() if ra
                           else {"ok": False, "error": "auth module unavailable"}, 401)
                return
            sid = (qs.get("sid") or [""])[0] or _latest_sid()
            self._json(_stats_payload(sid))
            return

        if path == "/api/replay":
            if not self._authed(qs):
                ra = _require_auth()
                self._json(ra.unauthorized_payload() if ra
                           else {"ok": False, "error": "auth module unavailable"}, 401)
                return
            sid = (qs.get("sid") or [""])[0] or _latest_sid()
            self._json(_replay_events(sid))
            return

        if path == "/replay":
            if not self._authed(qs):
                ra = _require_auth()
                self._json(ra.unauthorized_payload() if ra
                           else {"ok": False, "error": "auth module unavailable"}, 401)
                return
            try:
                with open(_REPLAY_HOST_HTML, "rb") as f:
                    html = f.read()
            except Exception as e:
                self._send(500, ("replay host html missing: %s" % e).encode("utf-8"),
                           "text/plain; charset=utf-8")
                return
            self._send(200, html, "text/html; charset=utf-8")
            return

        # ── ★ 本窗口（项28-33）: v3 接口面（统一 {ok,data,error} 信封 + 鉴权 + Origin 白名单）──
        if path == "/api/timeline":
            if not self._origin_ok():
                self._json(_envelope(False, None, "origin_forbidden", "ORIGIN"), 403)
                return
            if not self._authed(qs):
                self._json(_envelope(False, None, "unauthorized", "AUTH"), 401)
                return
            sid = (qs.get("sid") or [""])[0] or _latest_sid()
            try:
                after = int((qs.get("last_id") or ["0"])[0] or 0)
            except Exception:
                after = 0
            evs = _timeline_events(sid, after_id=after)
            self._json(_envelope(True, {"sid": sid, "events": evs,
                                        "last_id": evs[-1]["id"] if evs else after}))
            return

        if path == "/api/timeline/stream":
            # ★ 项28: SSE 增量流 —— last_id 断线补发（EventSource 专用）
            if not self._origin_ok():
                self._json(_envelope(False, None, "origin_forbidden", "ORIGIN"), 403)
                return
            if not self._authed(qs):
                self._json(_envelope(False, None, "unauthorized", "AUTH"), 401)
                return
            sid = (qs.get("sid") or [""])[0] or _latest_sid()
            try:
                last_id = int((qs.get("last_id") or ["0"])[0] or 0)
            except Exception:
                last_id = 0
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            try:
                self.wfile.write(("data: %s\n\n" % json.dumps(
                    _envelope(True, {"type": "hello", "sid": sid}),
                    ensure_ascii=False)).encode("utf-8"))
                self.wfile.flush()
                sent = 0
                idle = 0.0
                while sent < 400:
                    evs = _timeline_events(sid, after_id=last_id, limit=60)
                    for e in evs:
                        last_id = e["id"]
                        self.wfile.write(("data: %s\n\n" % json.dumps(
                            _envelope(True, {"type": "judge", "event": e}),
                            ensure_ascii=False)).encode("utf-8"))
                        sent += 1
                    self.wfile.flush()
                    if not evs:
                        idle += 1.0
                        if idle >= 15.0:      # 15s 心跳注释行
                            self.wfile.write(b": heartbeat\n\n")
                            self.wfile.flush()
                            idle = 0.0
                        time.sleep(1.0)
                    else:
                        idle = 0.0
                        time.sleep(0.4)
            except Exception:
                logger.debug("[A-15] shared/crawler/stage_server.py: 路径降级静默")  # 客户端断开（EventSource 重连带 last_id 自动补发）
            return

        if path == "/api/unread":
            if not self._origin_ok():
                self._json(_envelope(False, None, "origin_forbidden", "ORIGIN"), 403)
                return
            if not self._authed(qs):
                self._json(_envelope(False, None, "unauthorized", "AUTH"), 401)
                return
            sid = (qs.get("sid") or [""])[0] or _latest_sid()
            try:
                last_id = int((qs.get("last_id") or ["0"])[0] or 0)
            except Exception:
                last_id = 0
            self._json(_envelope(True, {"sid": sid, "unread": _unread_count(sid, last_id),
                                        "last_id": last_id}))
            return

        if path == "/api/direction":
            if not self._origin_ok():
                self._json(_envelope(False, None, "origin_forbidden", "ORIGIN"), 403)
                return
            if not self._authed(qs):
                self._json(_envelope(False, None, "unauthorized", "AUTH"), 401)
                return
            self._json(_envelope(True, _direction_payload()))
            return

        if path == "/api/health":
            # ★ 项31: db 路径 / 会话数 / 端口 / 版本（统一信封）
            self._json(_envelope(True, {
                "db": os.path.join(_ROOT, "data", "crawl.db"),
                "db_exists": os.path.exists(os.path.join(_ROOT, "data", "crawl.db")),
                "sessions": len(_sessions()),
                "port": port() or (self.server.server_address[1]
                                   if getattr(self, "server", None) else 0),
                "version": STAGE_VERSION}))
            return

        if path == "/api/v3/stats":
            # ★ 项26/27/32: v3 页面统计口 —— 同一 build_stats 真源 + bypass + 信封
            if not self._origin_ok():
                self._json(_envelope(False, None, "origin_forbidden", "ORIGIN"), 403)
                return
            if not self._authed(qs):
                self._json(_envelope(False, None, "unauthorized", "AUTH"), 401)
                return
            sid = (qs.get("sid") or [""])[0] or _latest_sid()
            bypass = (qs.get("bypass") or ["0"])[0] in ("1", "true")
            self._json(_envelope(True, _stats_payload(sid, bypass=bypass)))
            return

        self._json(_envelope(False, None, f"not found: {path}", "NOT_FOUND"), 404)


class _StageHTTPServer(ThreadingHTTPServer):
    # ★ P2(crawl_audit): ThreadingHTTPServer 默认 allow_reuse_address=1（SO_REUSEADDR），
    #   Windows 上会与残留的旧 stage_server 进程静默同绑同一端口 —— 实测两个进程
    #   同时 LISTEN 8791，请求被陈旧进程接走、数据停更（鉴权 401 乱窜）。
    #   禁用同绑让「端口占用自动顺延」真正生效；路由/返回结构不变。
    allow_reuse_address = False


def start(preferred_ports=None) -> int:
    """起服务（幂等）；返回真实端口，失败返回 0"""
    global _server
    with _lock:
        if _server is not None:
            return _server.server_address[1]
        ports = tuple(preferred_ports or _PREFERRED_PORTS)
        for port in ports:
            try:
                srv = _StageHTTPServer(("127.0.0.1", port), _Handler)
            except OSError:
                continue
            srv.daemon_threads = True
            _server = srv
            t = threading.Thread(target=srv.serve_forever,
                                 name="crawl-stage-http", daemon=True)
            t.start()
            # ★ 收口 29: 返回实际绑定端口（preferred=0 时 OS 随机分配，
            #   旧代码返回请求值 0 导致调用方拿到假端口）
            return srv.server_address[1]
        return 0


def port() -> int:
    return _server.server_address[1] if _server is not None else 0


def url(embed: bool = True, sid: str = "") -> str:
    p = port()
    if not p:
        return ""
    q = []
    if embed:
        q.append("embed=1")
    if sid:
        q.append("sid=" + sid)
    return "http://127.0.0.1:%d/%s" % (p, ("?" + "&".join(q)) if q else "")


def stop():
    global _server
    with _lock:
        if _server is not None:
            try:
                _server.shutdown()
                _server.server_close()
            except Exception as _exc:
                logger.debug("[A-15] stage_server.py:356 服务停止异常已结构化记录: %s", _exc)
            _server = None


if __name__ == "__main__":
    p = start()
    print("crawl stage server:", url(embed=False) if p else "FAILED")
    if p:
        import time
        try:
            while True:
                time.sleep(3600)
        except KeyboardInterrupt:
            stop()
