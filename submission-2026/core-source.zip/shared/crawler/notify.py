# -*- coding: utf-8 -*-
"""★ W22-3 / D6-05: 通知（桌面 + webhook 双通道）

- 桌面：QSystemTrayIcon（shared.notify.desktop），无托盘时显式降级
- Webhook：读 LW_CRAWL_WEBHOOK 环境变量；为空则只写日志
- 任一通道成功即视为送达；两通道都失败返回明细（不抛异常）
"""
from __future__ import annotations

import os


def send(payload: dict) -> dict:
    """双通道发送通知。payload 约定含 type/title/message/session_id。"""
    title = str(payload.get("title") or payload.get("type") or "Lemon Work")
    message = str(payload.get("message") or payload.get("detail") or "")
    sid = payload.get("session_id")

    results = {}

    # ── 通道 1：桌面 ──
    try:
        from shared.notify.desktop import send_desktop
        results["desktop"] = send_desktop(title, message, session_id=sid)
    except Exception as e:  # noqa: BLE001
        results["desktop"] = {"ok": False, "reason": f"{type(e).__name__}: {e}"}

    # ── 通道 2：webhook ──
    url = os.environ.get("LW_CRAWL_WEBHOOK", "").strip()
    if not url:
        results["webhook"] = {"ok": False, "reason": "no_webhook"}
    else:
        try:
            import requests
            r = requests.post(url, json=payload, timeout=5)
            results["webhook"] = {"ok": 200 <= r.status_code < 300,
                                  "status": r.status_code}
        except Exception as e:  # noqa: BLE001
            results["webhook"] = {"ok": False, "reason": str(e)[:120]}

    ok = any(v.get("ok") for v in results.values())
    if not ok:
        print(f"[notify] 双通道均未送达：{title} · {message} → {results}")
    return {"ok": ok, "channels": results,
            "reason": None if ok else "all_channels_failed"}
