# -*- coding: utf-8 -*-
"""★ C4/C5: 统计接口

- crawl_stats(session_id,group_by,since,until)
- group_by ∈ domain|hour|day|status|mode
- 只读 ro_conn；空会话返回空数组
- quality 5 桶；dedup_rate；失败原因 Top10
- 禁止：渲染路径建表/写库

★ 窗口2·真实统计层（本文件追加，只增不改）：
- build_stats(sid, db_path=None) —— 单次行扫描聚合看板统计层全部字段：
  counters / by_domain / by_verdict / quality_hist / size_hist / ms_hist /
  timeline / words / arcs / dots / edges / tags / session
- 判定唯一真源 = board_data.judge（禁止另写一套阈值）
- 所有 SQL 带 session_id 过滤 + LIMIT；1s 内存缓存；stats_seq 内容变更自增
- 无数据返回空数组与 0（禁占位数字）；circuit 用 domain_state 真实状态机，
  跨进程读不到时回退 crawl_page.failure_type='circuit_open' 真实证据
"""
from __future__ import annotations

import hashlib
import logging
import json
import math
import os
import re
import time
from typing import Optional

try:
    from .store import ro_conn, ensure_schema
except ImportError:
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from shared.crawler.store import ro_conn, ensure_schema

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_DB = os.path.join(_ROOT, "data", "crawl.db")

logger = logging.getLogger(__name__)

_GROUP_FIELDS = {
    "domain": "domain",
    "hour": "substr(fetched_at,1,13)",
    "day": "substr(fetched_at,1,10)",
    "status": "status",
    "mode": "mode",
}


def crawl_stats(session_id: str, group_by: str = "domain",
                since: str = "", until: str = "",
                db_path: Optional[str] = None) -> dict:
    """分组统计；只读"""
    ensure_schema(db_path)
    c = ro_conn(db_path)
    if c is None:
        return {"success": False, "error": "数据库不可读"}
    try:
        if group_by not in _GROUP_FIELDS:
            return {"success": False, "error": f"group_by 非法: {group_by}"}
        field = _GROUP_FIELDS[group_by]
        sql = (f"SELECT {field} AS key, COUNT(*) AS count, "
               "SUM(CASE WHEN status IN ('ok','not_modified') THEN 1 ELSE 0 END) AS ok, "
               "SUM(CASE WHEN status NOT IN ('ok','not_modified') THEN 1 ELSE 0 END) AS fail, "
               "ROUND(AVG(elapsed_ms),1) AS avg_ms, "
               "SUM(size_bytes) AS size_bytes "
               "FROM crawl_page WHERE session_id=?")
        args = [session_id]
        if since:
            sql += " AND fetched_at>=?"
            args.append(since)
        if until:
            sql += " AND fetched_at<=?"
            args.append(until)
        sql += f" GROUP BY {field} ORDER BY count DESC LIMIT 200"
        rows = c.execute(sql, args).fetchall()
        groups = [dict(r) for r in rows]
        # totals
        t = c.execute("SELECT COUNT(*) n, "
                      "SUM(CASE WHEN status IN ('ok','not_modified') THEN 1 ELSE 0 END) ok, "
                      "SUM(CASE WHEN status NOT IN ('ok','not_modified') THEN 1 ELSE 0 END) fail "
                      "FROM crawl_page WHERE session_id=?",
                      (session_id,)).fetchone()
        totals = dict(t) if t else {}
        # dedup_hit 从 session 表读
        s = c.execute("SELECT dedup_hit FROM crawl_session WHERE session_id=?",
                      (session_id,)).fetchone()
        totals["dedup_hit"] = s["dedup_hit"] if s else 0
        return {"success": True, "groups": groups, "totals": totals}
    finally:
        c.close()


def quality_buckets(session_id: str, db_path: Optional[str] = None) -> dict:
    """quality 5 桶"""
    ensure_schema(db_path)
    c = ro_conn(db_path)
    if c is None:
        return {"success": False, "error": "数据库不可读"}
    try:
        rows = c.execute(
            "SELECT quality FROM crawl_page WHERE session_id=?", (session_id,)).fetchall()
        buckets = {"<0.3": 0, "0.3-0.5": 0, "0.5-0.7": 0, "0.7-0.9": 0, ">=0.9": 0}
        for r in rows:
            q = float(r["quality"] or 0)
            if q < 0.3:
                buckets["<0.3"] += 1
            elif q < 0.5:
                buckets["0.3-0.5"] += 1
            elif q < 0.7:
                buckets["0.5-0.7"] += 1
            elif q < 0.9:
                buckets["0.7-0.9"] += 1
            else:
                buckets[">=0.9"] += 1
        return {"success": True, "buckets": buckets, "total": len(rows)}
    finally:
        c.close()


def dedup_rate(session_id: str, db_path: Optional[str] = None) -> dict:
    """dedup_rate = dedup_hit/total（dedup_hit 在 crawl_session 表）"""
    ensure_schema(db_path)
    c = ro_conn(db_path)
    if c is None:
        return {"success": False, "error": "数据库不可读"}
    try:
        t = c.execute("SELECT COUNT(*) n FROM crawl_page WHERE session_id=?",
                      (session_id,)).fetchone()
        n = t["n"] or 0
        s = c.execute("SELECT dedup_hit FROM crawl_session WHERE session_id=?",
                      (session_id,)).fetchone()
        d = (s["dedup_hit"] if s else 0) or 0
        return {"success": True, "total": n, "dedup_hit": d,
                "dedup_rate": round(d / n, 4) if n else 0.0}
    finally:
        c.close()


def failure_top10(session_id: str, db_path: Optional[str] = None) -> list:
    """失败原因 Top10（error 前缀归类）"""
    ensure_schema(db_path)
    c = ro_conn(db_path)
    if c is None:
        return []
    try:
        rows = c.execute(
            "SELECT error FROM crawl_page WHERE session_id=? "
            "AND status NOT IN ('ok','not_modified') AND error IS NOT NULL",
            (session_id,)).fetchall()
        buckets = {}
        for r in rows:
            err = (r["error"] or "").strip()
            # 前缀归类：取前 20 字符
            key = err[:20] if err else "(空)"
            buckets[key] = buckets.get(key, 0) + 1
        return sorted([{"reason": k, "count": v} for k, v in buckets.items()],
                      key=lambda x: -x["count"])[:10]
    finally:
        c.close()


# ═══════════════════════════════════════════════════════════════════════════
# ★ 窗口2·真实统计层：build_stats 只读聚合（只增不改；既有函数原样保留）
# ═══════════════════════════════════════════════════════════════════════════

_BUILD_TTL_S = 1.0        # 内存缓存 TTL（需求 10：1s 缓存）
_BUILD_ROW_CAP = 20000    # 单会话行扫描上限（session_id 过滤 + LIMIT）
_ARC_CAP = 2000           # arcs 每页一条的上限（防异常大库撑爆载荷）
_DOT_CAP = 400            # 点阵图保留最近 400 页（需求 17）
_WORD_TOP = 50            # 标题词 top50（需求 8）
_EDGE_TOP = 30            # from_page→域名 top30（需求 9）
_TIMELINE_BUCKETS = 60    # 分钟桶保留末 60 分钟（★ 本窗口项23：按分钟分桶）
_TIMELINE_WINDOW_S = 60   # ★ 本窗口（项23）: 桶宽 60s —— 页面实时曲线按分钟
_FETCH_RECENT_S = 20      # 域 fetching 判定窗口（与 war_room_data 对齐）

# quality 五桶（与既有 quality_buckets 桶界一致）
_QUALITY_BUCKETS = (("<0.3", 0.0, 0.3), ("0.3-0.5", 0.3, 0.5),
                    ("0.5-0.7", 0.5, 0.7), ("0.7-0.9", 0.7, 0.9),
                    (">=0.9", 0.9, float("inf")))
# size 六桶（字节）
_SIZE_BUCKETS = (("<1KB", 0, 1024), ("1-4KB", 1024, 4096), ("4-16KB", 4096, 16384),
                 ("16-64KB", 16384, 65536), ("64-256KB", 65536, 262144),
                 (">=256KB", 262144, float("inf")))
# ms 六桶
_MS_BUCKETS = (("<100", 0, 100), ("100-300", 100, 300), ("300-800", 300, 800),
               ("800-1500", 800, 1500), ("1500-3000", 1500, 3000),
               (">=3000", 3000, float("inf")))

# 停用词：中文单字/双字 + 英文虚词 + 爬虫噪音（需求 8：带停用词）
_ZH_STOP_CHARS = set("的了和是在与及或等为中对从上下内外里也都很就被把让向往之其此这那"
                     "么呢吧啊呀哦嘛么什不明无未已又再还才只更最挺太非常")
_ZH_STOP_WORDS = {"我们", "你们", "他们", "自己", "什么", "怎么", "这个", "那个",
                  "一个", "没有", "不是", "或者", "并且", "但是", "如果", "因为",
                  "所以", "可以", "应该", "需要", "关于", "通过", "进行", "已经",
                  "以及", "同时", "之后", "以后", "以上", "以下", "相关", "内容",
                  "页面", "网页", "链接", "点击", "查看", "更多", "请", "欢迎"}
_EN_STOP_WORDS = {"the", "a", "an", "and", "or", "of", "to", "in", "on", "for",
                  "with", "is", "are", "was", "were", "be", "been", "at", "by",
                  "from", "as", "that", "this", "it", "its", "not", "you", "your",
                  "we", "our", "they", "their", "he", "she", "his", "her", "will",
                  "can", "may", "has", "have", "had", "do", "does", "did", "but",
                  "if", "then", "so", "no", "yes", "all", "any", "more", "new"}
_NOISE_WORDS = {"http", "https", "www", "com", "cn", "net", "org", "html", "htm",
                "php", "asp", "aspx", "jsp", "index", "main", "page", "pages"}

_CJK_RE = re.compile(r"[\u4e00-\u9fff]+")
_LATIN_RE = re.compile(r"[A-Za-z][A-Za-z\-]{1,}")

# 1s 内存缓存 + 内容变更序列号（只读聚合不改库；跨 (sid,db_path) 各自缓存）
_BUILD_CACHE: dict = {}
_BUILD_SEQ = {"n": 0}


def stats_seq() -> int:
    """统计内容变更序列号（SSE 帧携带；内容 hash 变化才自增）"""
    return _BUILD_SEQ["n"]


def _percentile(sorted_vals: list, p: float) -> float:
    """线性插值百分位（空列表返回 0，不伪造）"""
    n = len(sorted_vals)
    if not n:
        return 0
    if n == 1:
        return float(sorted_vals[0])
    k = (n - 1) * p
    f = math.floor(k)
    c = min(f + 1, n - 1)
    if f == c:
        return float(sorted_vals[int(k)])
    return float(sorted_vals[f]) + (k - f) * (float(sorted_vals[c]) - float(sorted_vals[f]))


def _fix_title(s: str) -> str:
    """标题修复（utf-8 被 latin-1 落库的历史乱码）——复用 war_room_data 同款"""
    try:
        from shared.crawler.war_room_data import _fix_mojibake
        return _fix_mojibake(s)
    except Exception:
        return str(s or "")


def _host(url: str) -> str:
    try:
        from urllib.parse import urlparse
        return urlparse(url or "").hostname or ""
    except Exception:
        return ""


def _title_tokens(title: str) -> list:
    """标题分词：中文 2-gram + 英文词；带停用词过滤（需求 8）"""
    out = []
    t = _fix_title(title)
    for run in _CJK_RE.findall(t):
        if len(run) == 1:
            if run not in _ZH_STOP_CHARS:
                out.append(run)
            continue
        for i in range(len(run) - 1):
            g = run[i:i + 2]
            if g[0] in _ZH_STOP_CHARS or g[1] in _ZH_STOP_CHARS:
                continue
            if g in _ZH_STOP_WORDS:
                continue
            out.append(g)
    for w in _LATIN_RE.findall(t):
        w = w.lower().strip("-")
        if len(w) < 2 or w in _EN_STOP_WORDS or w in _NOISE_WORDS:
            continue
        out.append(w)
    return out


def _empty_payload(session_id: str) -> dict:
    """无数据 → 空数组与 0，禁占位数字（需求 11）"""
    return {
        "success": True, "sid": session_id, "session": None,
        "counters": {"pages": 0, "ok": 0, "fail": 0, "skipped": 0, "dedup": 0,
                     "bytes": 0, "avg_ms": 0, "rate": 0.0, "http_429": 0,
                     "circuit": "closed"},
        "by_verdict": {"KEEP": 0, "MAYBE": 0, "CUT": 0},
        "by_domain": [], "quality_hist": [], "size_hist": [], "ms_hist": [],
        "timeline": [], "words": [], "arcs": [], "dots": [], "edges": [],
        "tags": {"verdict": [], "domain": [], "failure_type": []},
        # ★ 集群A 追加键（只增不改）：pipeline/recent/judge/load/route/coverage/work
        "pipeline": {"discovered": 0, "fetched": 0, "parsed": 0,
                     "judged": 0, "annotated": 0},
        "recent": [], "judge": {"last60": [], "avg_p": 0.0},
        "load": {"calls": 0, "tokens": 0, "avg_latency": 0, "ok_rate": 0.0,
                 "models": [], "recent": []},
        "route": {"rule": 0, "model": 0, "human": 0, "total": 0},
        "coverage": {"parsed": 0, "fetched": 0, "ratio": 0.0},
        "work": {"domain": "", "page": "", "page_id": 0, "workers": 0,
                 "queue": 0},
        # ★ 本窗口（项36）: 顶部 KPI 五格真源（口径固定见 build_stats docstring）
        "kpi": {"words": 0, "runs": 0, "keep": 0, "novel": 0, "total": 0},
        "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }


def _build_extras(c, sid: str, pages: list, sess, words: Optional[dict] = None) -> dict:
    """★ 集群A 追加统计（项12/18/20/23；只增不改既有键）。

    pipeline  {discovered,fetched,parsed,judged,annotated} —— 全部真实行证据：
      discovered=页行数 / fetched=fetched_at 非空 / parsed=text_len>0 /
      judged=crawl_judge_event 计数（无事件回退 quality 非空行）/ annotated=标注行
    recent    末 24 页 [{pid,title,domain,verdict,quality,len,status,ts,route,
               needs_review,ann}]（正文列真源；ann=crawl_annotation 真实标注）
    judge     {last60,avg_p} ← crawl_judge_event 末 60（决策流/置信度真源）
    load      {calls,tokens,avg_latency,ok_rate,models,recent} ← crawl_ai_call
    route     {rule,model,human,total} ← crawl_page.judge_route
    coverage  {parsed,fetched,ratio} ← parsed/fetched 真实比值
    work      {domain,page,page_id,workers,queue} ← 末页/config_json/crawl_edge pending
    kpi       {words,runs,keep,novel,total} ← 五格真源（口径见 build_stats）
    旧库缺表时对应键回退 0/[]（空态诚实，禁占位数字）。
    """
    out = {
        "pipeline": {"discovered": 0, "fetched": 0, "parsed": 0,
                     "judged": 0, "annotated": 0},
        "recent": [],
        "judge": {"last60": [], "avg_p": 0.0},
        "load": {"calls": 0, "tokens": 0, "avg_latency": 0, "ok_rate": 0.0,
                 "models": [], "recent": []},
        "route": {"rule": 0, "model": 0, "human": 0, "total": 0},
        "coverage": {"parsed": 0, "fetched": 0, "ratio": 0.0},
        "work": {"domain": "", "page": "", "page_id": 0, "workers": 0,
                 "queue": 0},
    }
    pages = pages or []
    fetched_n = sum(1 for d in pages if str(d.get("fetched_at") or ""))
    parsed_n = sum(1 for d in pages if int(d.get("text_len") or 0) > 0)
    out["pipeline"]["discovered"] = len(pages)
    out["pipeline"]["fetched"] = fetched_n
    out["pipeline"]["parsed"] = parsed_n
    out["coverage"]["parsed"] = parsed_n
    out["coverage"]["fetched"] = fetched_n
    out["coverage"]["ratio"] = round(parsed_n / fetched_n, 4) if fetched_n else 0.0

    # judged：判定事件为真源；事件缺失回退 quality 非空行数（不伪造）
    try:
        judged_n = int(c.execute(
            "SELECT COUNT(*) AS n FROM crawl_judge_event WHERE session_id=?",
            (sid,)).fetchone()["n"])
    except Exception:
        judged_n = 0
    if judged_n <= 0:
        try:
            judged_n = int(c.execute(
                "SELECT COUNT(*) AS n FROM crawl_page "
                "WHERE session_id=? AND quality IS NOT NULL", (sid,)).fetchone()["n"])
        except Exception:
            judged_n = 0
    out["pipeline"]["judged"] = judged_n

    # annotated：真实标注行（deleted=0）按页去重
    try:
        out["pipeline"]["annotated"] = int(c.execute(
            "SELECT COUNT(DISTINCT a.page_id) AS n FROM crawl_annotation a "
            "JOIN crawl_page p ON p.id=a.page_id AND p.session_id=? "
            "WHERE a.deleted=0", (sid,)).fetchone()["n"])
    except Exception:
        logger.debug("[A-15] stats.py 降级静默", exc_info=True)

    ann = {}   # ★ 本窗口（项7）: 同一 ann 映射供 recent.ann 与 annstack 同源
    try:
        from shared.crawler.board_data import judge as _judge
        rows = c.execute(
            "SELECT id, url, domain, status, http_status, title, text_len, "
            "quality, size_bytes, fetched_at, judge_route, needs_review "
            "FROM crawl_page WHERE session_id=? ORDER BY id DESC LIMIT 24",
            (sid,)).fetchall()
        pid_list = [int(r["id"]) for r in rows]
        # ★ 本窗口（项7）: ann 映射 = 全会话标注（同源 join crawl_page + crawl_judge_event），
        #   recent.ann 与 annstack 共用同一映射 → 正文 chip 与右侧标注栈按 pid 一一对应。
        try:
            for a in c.execute(
                    "SELECT a.page_id AS page_id, a.tags AS tags, a.color AS color, "
                    "a.note AS note, a.author AS author, MAX(a.id) AS aid, "
                    "p.quality AS quality, p.text_len AS text_len, p.status AS status "
                    "FROM crawl_annotation a JOIN crawl_page p ON p.id=a.page_id "
                    "WHERE a.deleted=0 AND p.session_id=? "
                    "GROUP BY a.page_id ORDER BY aid DESC", (sid,)).fetchall():
                d = dict(a)
                try:
                    tag = _judge(d)
                except Exception:
                    tag = "MAYBE"
                tags_s = str(d.get("tags") or "")
                word = tags_s.split('"')[1] if '"' in tags_s else tags_s[:12]
                ann[int(d["page_id"])] = {
                    "tags": tags_s, "color": str(d.get("color") or ""),
                    "note": str(d.get("note") or ""), "source": str(d.get("author") or ""),
                    "word": word, "tag": tag, "aid": int(d.get("aid") or 0),
                }
        except Exception:
            ann = {}
        # 每页最新判定 p（项14/27: chip hover score 与标注栈真源）
        page_p = {}
        try:
            for r in c.execute(
                    "SELECT page_id, p FROM crawl_judge_event "
                    "WHERE session_id=? AND p IS NOT NULL ORDER BY id",
                    (sid,)).fetchall():
                page_p[int(r["page_id"])] = round(float(r["p"] or 0), 3)
        except Exception:
            page_p = {}
        # ★ 本窗口（项7）: 同一 ann 映射补全 p（recent 与 annstack 共用）
        for _pid, _a in ann.items():
            _a["p"] = page_p.get(_pid)
        for r in rows:
            d = dict(r)
            try:
                v = _judge(d)
            except Exception:
                v = "MAYBE"
            a = ann.get(int(d["id"]))
            out["recent"].append({
                "pid": int(d["id"]),
                "title": _fix_title(d.get("title")) or (d.get("url") or ""),
                "domain": str(d.get("domain") or ""),
                "verdict": v,
                "quality": round(float(d.get("quality") or 0), 2),
                "len": int(d.get("text_len") or 0),
                "bytes": int(d.get("size_bytes") or 0),
                "p": page_p.get(int(d["id"])),
                "status": str(d.get("status") or ""),
                "ts": (str(d.get("fetched_at") or "")[11:19]),
                "route": str(d.get("judge_route") or ""),
                "needs_review": bool(d.get("needs_review")),
                "ann": a,
            })
        out["recent"].reverse()   # 正文列按抓取顺序展示
    except Exception:
        out["recent"] = []

    # judge last60（决策流/置信度）★ 本窗口（项38）: join crawl_page 回填 verdict
    try:
        evs = c.execute(
            "SELECT e.ts AS ts, e.page_id AS page_id, e.question AS question, "
            "e.p AS p, e.route AS route, e.source AS source, "
            "p.quality AS quality, p.text_len AS text_len, p.status AS status "
            "FROM crawl_judge_event e "
            "LEFT JOIN crawl_page p ON p.id=e.page_id "
            "WHERE e.session_id=? ORDER BY e.id DESC LIMIT 60", (sid,)).fetchall()
        last60, ps = [], []
        for e in evs:
            try:
                pv = float(e["p"])
            except (TypeError, ValueError):
                pv = None
            try:
                v = _judge({"status": e["status"], "quality": e["quality"],
                            "text_len": e["text_len"]})
            except Exception:
                v = "MAYBE"
            last60.append({"ts": (str(e["ts"] or "")[11:19]),
                           "page_id": e["page_id"],
                           "q": str(e["question"] or ""),
                           "p": round(pv, 3) if pv is not None else None,
                           "route": str(e["route"] or ""),
                           "src": str(e["source"] or ""),
                           "verdict": v})
            if pv is not None:
                ps.append(pv)
        out["judge"]["last60"] = last60
        out["judge"]["avg_p"] = round(sum(ps) / len(ps), 3) if ps else 0.0
    except Exception:
        logger.debug("[A-15] stats.py 降级静默", exc_info=True)

    try:
        # ★ 本窗口（项 C1）: 当前会话无调用 → 回退全局，并标注 scope。
        # ★ 本窗口（项 B4）: tokens = prompt + completion；旧库缺列时回退 tokens。
        try:
            _cols = {r[1] for r in c.execute("PRAGMA table_info(crawl_ai_call)")}
        except Exception:
            _cols = set()
        _has_pc = ("prompt_tokens" in _cols) and ("completion_tokens" in _cols)
        _ptok_expr = "COALESCE(SUM(prompt_tokens),0)" if _has_pc else "COALESCE(SUM(tokens),0)"
        _ctok_expr = "COALESCE(SUM(completion_tokens),0)" if _has_pc else "0"
        _where, _args = "session_id=?", (sid,)
        agg = c.execute(
            "SELECT COUNT(*) AS n, COALESCE(SUM(tokens),0) AS tok, "
            f"{_ptok_expr} AS ptok, {_ctok_expr} AS ctok, "
            "COALESCE(AVG(latency_ms),0) AS lat, COALESCE(SUM(ok),0) AS okn "
            f"FROM crawl_ai_call WHERE {_where}", _args).fetchone()
        n = int(agg["n"])
        scope = "session"
        if n == 0:
            _where, _args = "1=1", ()
            agg = c.execute(
                "SELECT COUNT(*) AS n, COALESCE(SUM(tokens),0) AS tok, "
                f"{_ptok_expr} AS ptok, {_ctok_expr} AS ctok, "
                "COALESCE(AVG(latency_ms),0) AS lat, COALESCE(SUM(ok),0) AS okn "
                f"FROM crawl_ai_call WHERE {_where}", _args).fetchone()
            n = int(agg["n"])
            scope = "global" if n else "none"
        out["load"]["calls"] = n
        out["load"]["tokens"] = int(agg["ptok"]) + int(agg["ctok"])
        out["load"]["prompt_tokens"] = int(agg["ptok"])
        out["load"]["completion_tokens"] = int(agg["ctok"])
        out["load"]["avg_latency"] = round(float(agg["lat"]), 0)
        out["load"]["ok_rate"] = round(int(agg["okn"]) / n, 4) if n else 0.0
        out["load"]["scope"] = scope
        out["load"]["models"] = [
            {"model": r["model"] or "(unknown)", "calls": int(r["n"]),
             "tokens": int(r["tok"])}
            for r in c.execute(
                "SELECT model, COUNT(*) AS n, COALESCE(SUM(tokens),0) AS tok "
                f"FROM crawl_ai_call WHERE {_where} "
                "GROUP BY model ORDER BY n DESC LIMIT 6", _args).fetchall()]
        out["load"]["recent"] = [
            {"latency_ms": int(r["latency_ms"] or 0), "ok": bool(r["ok"]),
             "tokens": int(r["tokens"] or 0),
             "model": str(r["model"] or "(unknown)")}
            for r in c.execute(
                "SELECT model, tokens, latency_ms, ok FROM crawl_ai_call "
                f"WHERE {_where} ORDER BY id DESC LIMIT 96",
                _args).fetchall()][::-1]
    except Exception:
        logger.debug("[A-15] stats.py 降级静默", exc_info=True)

    try:
        for r in c.execute(
                "SELECT COALESCE(judge_route,'') AS rt, COUNT(*) AS n "
                "FROM crawl_page WHERE session_id=? GROUP BY rt", (sid,)).fetchall():
            k = str(r["rt"] or "").strip().lower()
            if k in ("rule", "model", "human"):
                out["route"][k] = int(r["n"])
        out["route"]["total"] = (out["route"]["rule"] + out["route"]["model"]
                                 + out["route"]["human"])
    except Exception:
        logger.debug("[A-15] stats.py 降级静默", exc_info=True)

    try:
        last = None
        for d in reversed(pages):
            if str(d.get("fetched_at") or ""):
                last = d
                break
        if last is not None:
            out["work"]["domain"] = str(last.get("domain") or "")
            out["work"]["page"] = _fix_title(last.get("title")) or ""
            out["work"]["page_id"] = int(last.get("id") or 0)
    except Exception:
        logger.debug("[A-15] stats.py 降级静默", exc_info=True)
    try:
        cfg = json.loads(str((sess["config_json"] if sess else "") or "{}"))
        w = int(cfg.get("workers") or 0)
        out["work"]["workers"] = max(0, w)
    except Exception:
        logger.debug("[A-15] stats.py 降级静默", exc_info=True)
    try:
        out["work"]["queue"] = int(c.execute(
            "SELECT COUNT(*) AS n FROM crawl_edge "
            "WHERE session_id=? AND state='pending'", (sid,)).fetchone()["n"])
    except Exception:
        logger.debug("[A-15] stats.py work.queue 降级静默", exc_info=True)

    try:
        keep_n = 0
        for d in pages:
            if _judge(d) == "KEEP":
                keep_n += 1
        novel_n = int(c.execute(
            "SELECT COUNT(DISTINCT content_hash) AS n FROM crawl_page "
            "WHERE session_id=? AND content_hash IS NOT NULL AND content_hash != ''",
            (sid,)).fetchone()["n"])
        out["kpi"] = {"words": len(words or {}), "runs": judged_n, "keep": keep_n,
                      "novel": novel_n, "total": len(pages)}
    except Exception:
        logger.debug("[A-15] stats.py 降级静默", exc_info=True)

    # ★ 本窗口（项7）: 标注栈与 recent.ann 同源 —— 直接派生自同一 ann 映射，
    #   按标注 id 倒序取最近 6 条；正文 chip 与右侧标注栈按 pid 一一对应。
    try:
        stack = []
        for pid, a in sorted(ann.items(),
                             key=lambda kv: kv[1].get("aid", 0), reverse=True)[:6]:
            stack.append({"pid": int(pid), "word": a.get("word") or "",
                          "tag": a.get("tag") or "MAYBE",
                          "p": a.get("p")})
        out["annstack"] = stack
    except Exception:
        logger.debug("[A-15] stats.py annstack 降级静默", exc_info=True)
        out["annstack"] = []
    return out

def _circuit_map(db_rows_by_domain: dict) -> dict:
    """域熔断状态：进程内状态机优先（与 war_room 同源）；跨进程回退库内
    failure_type='circuit_open' 真实证据。均来自真实状态/真实行，无推断伪造。"""
    out = {}
    try:
        from shared.crawler.domain_state import get_registry
        for s in get_registry().snapshot():
            out[str(s.get("domain") or "")] = (
                "open" if s.get("is_open") else
                ("half_open" if s.get("half_open_sent") else "closed"))
    except Exception:
        logger.debug("[A-15] stats.py 降级静默", exc_info=True)
    for d in db_rows_by_domain:
        if out.get(d):
            continue
        out[d] = "open" if db_rows_by_domain[d] else "closed"
    return out


def build_stats(session_id: str, db_path: Optional[str] = None,
                bypass: bool = False) -> dict:
    """★ 窗口2：只读聚合一个会话的统计层全量字段（1s 内存缓存）。

    ★ 本窗口（项27）: bypass=True 跳过缓存直读库 —— 改库后立即看到变化
      （/api/stats?bypass=1 与改库即变测试同口径）。

    返回（无数据=空数组与 0）：
      counters   {pages,ok,fail,skipped,dedup,bytes,avg_ms,rate,http_429,circuit}
      by_domain  [{domain,count,ok,fail,p50,p95,http_429,extract,circuit,fetching}]
      by_verdict {KEEP,MAYBE,CUT}  —— 复用 board_data.judge 单一真源
      quality_hist / size_hist / ms_hist  [{label,lo,hi,count}]
      timeline   末 60 个分钟桶 [{t,pages,bytes,ok,fail}]（★ 项23：按分钟分桶）
      words      标题分词 top50 [{w,n}]（中文 2-gram + 停用词）
      arcs       每页一条 [{page_id,domain,verdict,bytes,ms,quality}]
      dots       最近 400 页 [{page_id,verdict,bytes}]
      edges      from→域名 top30 [{from,to,count}]
      tags       {verdict,domain,failure_type} 各 top [{name,count}]
      kpi        五格真源（★ 项21/36，口径固定如下，改动必须同步本 docstring）：
                   words = 标题分词去重词条数（词云词典大小）
                   runs  = crawl_run 真实启动轮次行数（无 run 行=0，不回退伪造）
                   keep  = board_data.judge 判 KEEP 的页数
                   novel = 唯一 content_hash 数（新内容页，去重后真实新增）
                   total = crawl_page 行数（含 fail/dup）
      seq        stats_seq（内容变更自增，SSE 帧携带）
    """
    sid = str(session_id or "")
    key = (sid, os.path.abspath(db_path) if db_path else None)
    now = time.time()
    if not bypass:
        hit = _BUILD_CACHE.get(key)
        if hit and now - hit["ts"] < _BUILD_TTL_S:
            return hit["payload"]

    from shared.crawler.board_data import judge   # 判定唯一真源（禁止另写）

    c = ro_conn(db_path)
    if c is None:
        payload = _empty_payload(sid)
        payload["seq"] = _touch_seq(payload)
        return payload
    try:
        rows = c.execute(
            "SELECT id, url, domain, status, http_status, mode, title, text_len, "
            "quality, size_bytes, elapsed_ms, failure_type, fetched_at, judge_route "
            "FROM crawl_page WHERE session_id=? ORDER BY id LIMIT ?",
            (sid, _BUILD_ROW_CAP)).fetchall()
        # ★ 舞台 v3（项20/21/27）: 判定叙事真源 —— 每页最新判定事件的 p
        #   （crawl_judge_event 单查询建 pid→p 映射，主循环零额外查询）
        page_p = {}
        try:
            for r in c.execute(
                    "SELECT page_id, p FROM crawl_judge_event "
                    "WHERE session_id=? AND p IS NOT NULL ORDER BY id",
                    (sid,)).fetchall():
                page_p[int(r["page_id"])] = round(float(r["p"] or 0), 3)
        except Exception:
            logger.debug("[A-15] stats.py page_p 映射降级静默", exc_info=True)
            page_p = {}
        sess = c.execute(
            "SELECT session_id, name, seed_url, state, created_at, started_at, "
            "ended_at, dedup_hit, config_json FROM crawl_session WHERE session_id=?",
            (sid,)).fetchone()
        if not rows and not sess:
            payload = _empty_payload(sid)
            payload["seq"] = _touch_seq(payload)
            return payload

        pages = [dict(r) for r in rows]
        counters = {"pages": len(pages), "ok": 0, "fail": 0, "skipped": 0,
                    "dedup": 0, "bytes": 0, "avg_ms": 0, "rate": 0.0,
                    "http_429": 0, "circuit": "closed"}
        verdicts = {"KEEP": 0, "MAYBE": 0, "CUT": 0}
        dom = {}   # domain -> 聚合桶
        q_hist = [0] * len(_QUALITY_BUCKETS)
        s_hist = [0] * len(_SIZE_BUCKETS)
        m_hist = [0] * len(_MS_BUCKETS)
        words = {}
        tl = {}    # 10s 桶 epoch -> {pages,bytes,ok,fail}
        arcs, dots, page_dom = [], [], {}
        verdict_tags, domain_tags, fail_tags = {}, {}, {}
        circuit_evidence = {}   # domain -> 有 circuit_open 证据
        ms_sum, ms_n = 0, 0

        for d in pages:
            st = str(d.get("status") or "")
            ok = st in ("ok", "not_modified")
            if ok:
                counters["ok"] += 1
            elif st == "skipped":
                counters["skipped"] += 1
            elif st == "dup":
                counters["dedup"] += 1
            else:
                counters["fail"] += 1
            b = int(d.get("size_bytes") or 0)
            counters["bytes"] += b
            ms = int(d.get("elapsed_ms") or 0)
            if ms > 0:
                ms_sum += ms
                ms_n += 1
            if int(d.get("http_status") or 0) == 429:
                counters["http_429"] += 1

            # 判定：复用 board_data.judge（唯一真源）
            v = judge(d)
            verdicts[v] = verdicts.get(v, 0) + 1
            verdict_tags[v] = verdict_tags.get(v, 0) + 1

            domain = str(d.get("domain") or "") or "(unknown)"
            domain_tags[domain] = domain_tags.get(domain, 0) + 1
            page_dom[int(d["id"])] = domain
            bucket = dom.setdefault(domain, {
                "count": 0, "ok": 0, "fail": 0, "ms": [], "http_429": 0,
                "ok_text": 0, "max_fetch": "", "circuit_open": 0})
            bucket["count"] += 1
            if ok:
                bucket["ok"] += 1
                if int(d.get("text_len") or 0) > 0:
                    bucket["ok_text"] += 1
            elif st not in ("skipped", "dup"):
                bucket["fail"] += 1
            if ms > 0:
                bucket["ms"].append(ms)
            if int(d.get("http_status") or 0) == 429:
                bucket["http_429"] += 1
            ft = str(d.get("fetched_at") or "")
            if ft > bucket["max_fetch"]:
                bucket["max_fetch"] = ft
            if str(d.get("failure_type") or "") == "circuit_open":
                circuit_evidence[domain] = True
                bucket["circuit_open"] += 1
                fail_tags["circuit_open"] = fail_tags.get("circuit_open", 0) + 1
            elif d.get("failure_type"):
                fname = str(d["failure_type"])
                fail_tags[fname] = fail_tags.get(fname, 0) + 1

            # 直方图三套
            q = min(max(float(d.get("quality") or 0), 0.0), 1.0)
            for i, (_lb, lo, hi) in enumerate(_QUALITY_BUCKETS):
                if lo <= q < hi or (i == len(_QUALITY_BUCKETS) - 1 and q >= lo):
                    q_hist[i] += 1
                    break
            for i, (_lb, lo, hi) in enumerate(_SIZE_BUCKETS):
                if lo <= b < hi or (i == len(_SIZE_BUCKETS) - 1 and b >= lo):
                    s_hist[i] += 1
                    break
            for i, (_lb, lo, hi) in enumerate(_MS_BUCKETS):
                if lo <= ms < hi or (i == len(_MS_BUCKETS) - 1 and ms >= lo):
                    m_hist[i] += 1
                    break

            # 词云（标题分词）
            for tk in _title_tokens(d.get("title")):
                words[tk] = words.get(tk, 0) + 1

            # timeline 10s 桶
            if ft:
                try:
                    ts = time.mktime(time.strptime(ft[:19], "%Y-%m-%d %H:%M:%S"))
                    tb = tl.setdefault(int(ts // _TIMELINE_WINDOW_S),
                                       {"pages": 0, "bytes": 0, "ok": 0, "fail": 0})
                    tb["pages"] += 1
                    tb["bytes"] += b
                    if ok:
                        tb["ok"] += 1
                    elif st not in ("skipped", "dup"):
                        tb["fail"] += 1
                except ValueError:
                    logger.debug("[A-15] stats.py 降级静默", exc_info=True)
            # 弧线 / 点阵（★ 舞台 v3 项20/21: 弧线带 route 与 p —— 判定叙事真源）
            # ★ 本窗口（项 A1/A4）: 弧线身份补齐 —— pid 与规范化 route
            _raw_route = str(d.get("judge_route") or "")
            _route = {"rule": "code", "model": "sonnet",
                      "human": "you"}.get(_raw_route, _raw_route or "rule")
            arcs.append({"pid": int(d["id"]), "page_id": int(d["id"]),
                         "domain": domain, "verdict": v,
                         "bytes": b, "ms": ms, "quality": round(q, 2),
                         "route": _route, "route_raw": _raw_route,
                         "p": page_p.get(int(d["id"]))})
            dots.append({"page_id": int(d["id"]), "verdict": v, "bytes": b})

        counters["avg_ms"] = round(ms_sum / ms_n, 0) if ms_n else 0
        counters["dedup"] = _dedup_counter(c, sid, counters["dedup"])

        # rate：页/分钟（会话时长口径与 routes_crawl._card_from_db 一致）
        counters["rate"] = _pages_per_min(sess, len(pages))

        # by_domain 聚合 + 熔断/fetching
        state = str(sess["state"] or "") if sess else ""
        cmap = _circuit_map({d: bool(dom[d]["circuit_open"]) for d in dom})
        recent_cut = time.strftime("%Y-%m-%d %H:%M:%S",
                                   time.localtime(time.time() - _FETCH_RECENT_S))
        by_domain = []
        for dname, bk in dom.items():
            msv = sorted(bk["ms"])
            fetching = (state in ("running", "queued")
                        and bk["max_fetch"] >= recent_cut)
            by_domain.append({
                "domain": dname, "count": bk["count"], "ok": bk["ok"],
                "fail": bk["fail"], "p50": round(_percentile(msv, 0.5), 0),
                "p95": round(_percentile(msv, 0.95), 0),
                "http_429": bk["http_429"],
                "extract": round(bk["ok_text"] / bk["ok"], 4) if bk["ok"] else 0.0,
                "circuit": cmap.get(dname, "closed"),
                "fetching": bool(fetching)})
        by_domain.sort(key=lambda x: (-x["count"], x["domain"]))
        worst = {"open": 2, "half_open": 1, "closed": 0}
        counters["circuit"] = max(
            (d["circuit"] for d in by_domain), key=lambda s: worst.get(s, 0),
            default="closed")

        # timeline 末 60 桶（连续区间，真实 0 填充）
        timeline = []
        if tl:
            lo_b, hi_b = min(tl), max(tl)
            lo_b = max(lo_b, hi_b - _TIMELINE_BUCKETS + 1)
            for eb in range(lo_b, hi_b + 1):
                v0 = tl.get(eb, {"pages": 0, "bytes": 0, "ok": 0, "fail": 0})
                timeline.append({"t": time.strftime("%H:%M:%S",
                                                    time.localtime(eb * _TIMELINE_WINDOW_S)),
                                 "pages": v0["pages"], "bytes": v0["bytes"],
                                 "ok": v0["ok"], "fail": v0["fail"]})

        # edges：from_page→域名 top30（from_page_id 缺失时归到 seed 域）
        seed_domain = ""
        if sess:
            seed_domain = _host(sess["seed_url"] or "")
        edge_agg = {}
        try:
            for r in c.execute(
                    "SELECT from_page_id, to_url FROM crawl_edge "
                    "WHERE session_id=? LIMIT 5000", (sid,)).fetchall():
                fp = r["from_page_id"]
                fd = page_dom.get(int(fp)) if fp is not None else ""
                if not fd:
                    fd = seed_domain or "(seed)"
                td = _host(r["to_url"] or "")
                if not td:
                    continue
                k = (fd, td)
                edge_agg[k] = edge_agg.get(k, 0) + 1
        except Exception:
            edge_agg = {}
        edges = [{"from": k[0], "to": k[1], "count": n}
                 for k, n in sorted(edge_agg.items(),
                                    key=lambda kv: -kv[1])[:_EDGE_TOP]]

        payload = {
            "success": True, "sid": sid,
            "session": None if not sess else {
                "session_id": sess["session_id"], "name": sess["name"] or "",
                "state": state, "seed_domain": seed_domain,
                "created_at": sess["created_at"] or "",
                "started": sess["started_at"] or "", "ended": sess["ended_at"] or ""},
            "counters": counters,
            "by_verdict": verdicts,
            "by_domain": by_domain[:50],
            "quality_hist": [{"label": lb, "lo": None if math.isinf(lo) else lo,
                              "hi": None if math.isinf(hi) else hi, "count": n}
                             for (lb, lo, hi), n in zip(_QUALITY_BUCKETS, q_hist)],
            "size_hist": [{"label": lb, "lo": None if math.isinf(lo) else lo,
                           "hi": None if math.isinf(hi) else hi, "count": n}
                          for (lb, lo, hi), n in zip(_SIZE_BUCKETS, s_hist)],
            "ms_hist": [{"label": lb, "lo": None if math.isinf(lo) else lo,
                         "hi": None if math.isinf(hi) else hi, "count": n}
                        for (lb, lo, hi), n in zip(_MS_BUCKETS, m_hist)],
            "timeline": timeline,
            "words": [{"w": w, "n": n} for w, n in
                      sorted(words.items(), key=lambda kv: (-kv[1], kv[0]))[:_WORD_TOP]],
            "arcs": arcs[:_ARC_CAP],
            "dots": dots[-_DOT_CAP:],
            "edges": edges,
            "tags": {
                "verdict": [{"name": k, "count": n} for k, n in
                            sorted(verdict_tags.items(), key=lambda kv: (-kv[1], kv[0]))],
                "domain": [{"name": k, "count": n} for k, n in
                           sorted(domain_tags.items(), key=lambda kv: (-kv[1], kv[0]))[:10]],
                "failure_type": [{"name": k, "count": n} for k, n in
                                 sorted(fail_tags.items(), key=lambda kv: (-kv[1], kv[0]))[:10]],
            },
            "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        # ★ 集群A 追加键（只增不改）：pipeline/recent/judge/load/route/coverage/work
        payload.update(_build_extras(c, sid, pages, sess, words=words))
        # ★ 舞台 v3（项27/28）: p 分桶真源（KPI 脚注直读，前端不自行聚合）
        try:
            ps_all = [e.get("p") for e in (payload.get("judge") or {}).get("last60", [])
                      if isinstance(e.get("p"), (int, float))]
            b1 = sum(1 for x in ps_all if x < 0.3)
            b2 = sum(1 for x in ps_all if 0.3 <= x < 0.6)
            b3 = sum(1 for x in ps_all if x >= 0.6)
            payload.setdefault("judge", {})["buckets"] = {
                "lt030": b1, "mid": b2, "ge060": b3, "n": len(ps_all)}
        except Exception:
            logger.debug("[A-15] stats.py p 分桶降级静默", exc_info=True)
        payload["seq"] = _touch_seq(payload)
        _BUILD_CACHE[key] = {"ts": now, "payload": payload}
        return payload
    finally:
        c.close()


def _touch_seq(payload: dict) -> int:
    """内容 hash 变化才自增 stats_seq（generated_at 不参与，防止空转 bump）"""
    stable = {k: v for k, v in payload.items()
              if k not in ("generated_at", "seq")}
    h = hashlib.md5(json.dumps(stable, sort_keys=True, ensure_ascii=False,
                               default=str).encode("utf-8")).hexdigest()
    st = _BUILD_CACHE.get("_seq")
    if st is None or st["h"] != h:
        _BUILD_SEQ["n"] += 1
        _BUILD_CACHE["_seq"] = {"h": h}
    return _BUILD_SEQ["n"]


def _dedup_counter(c, sid: str, dup_rows: int) -> int:
    """dedup 计数：引擎侧 crawl_session.dedup_hit 为真源；无会话行回退 dup 行数"""
    try:
        r = c.execute("SELECT dedup_hit FROM crawl_session WHERE session_id=?",
                      (sid,)).fetchone()
        if r is not None:
            return max(int(r["dedup_hit"] or 0), dup_rows)
    except Exception:
        logger.debug("[A-15] stats.py 降级静默", exc_info=True)


def _pages_per_min(sess, total: int) -> float:
    """页/分钟（started→ended/now，除零防护；时间缺失给 0 不伪造）"""
    if not sess or total <= 0:
        return 0.0
    try:
        start = sess["started_at"] or sess["created_at"]
        end = sess["ended_at"] or ""
        if not start:
            return 0.0
        f = "%Y-%m-%d %H:%M:%S"
        t0 = time.strptime(str(start)[:19], f)
        t1 = time.strptime(str(end)[:19], f) if end else time.localtime()
        mins = max((time.mktime(t1) - time.mktime(t0)) / 60.0, 1.0 / 60.0)
        return round(total / mins, 1)
    except ValueError:
        return 0.0


if __name__ == "__main__":
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        db = os.path.join(td, "t.db")
        ensure_schema(db)
        print("空会话:", crawl_stats("none", db_path=db))
        print("非法 group_by:", crawl_stats("x", group_by="bad", db_path=db))
        st = build_stats("none", db_path=db)
        print("build_stats 空会话:", {k: st[k] for k in
              ("counters", "by_verdict", "words", "edges")})


logger = logging.getLogger(__name__)