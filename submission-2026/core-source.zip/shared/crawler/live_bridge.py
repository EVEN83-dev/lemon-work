# -*- coding: utf-8 -*-
"""★ W3: Live 卡桥（后端真的发射）

- attach(ui_callback)：只订阅一次 events.subscribe
- start_session_card(sid,name,cfg)：初始卡走 ActionCardRegistry.emit_card
- update_state / push_annotation / flush
- 事件映射：session_start→running / page_done→recent+ok / page_fail→recent+fail / session_done→completed
- 节流：pending patch 合并，600ms 刷一次；pending 上限 200
- 禁止：flusher 里做网络请求；无界缓冲；阻塞引擎线程
"""
from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

import json
import threading
import time
from typing import Optional

try:
    from . import events
    from . import (EV_SESSION_START, EV_PAGE_START, EV_PAGE_DONE, EV_PAGE_FAIL,
                   EV_SESSION_DONE, EV_CONTROL, ST_RUNNING, ST_COMPLETED, ST_FAILED)
except ImportError:
    import sys, os
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from shared.crawler import events
    from shared.crawler import (EV_SESSION_START, EV_PAGE_START, EV_PAGE_DONE,
                                EV_PAGE_FAIL, EV_SESSION_DONE, EV_CONTROL, ST_RUNNING,
                                ST_COMPLETED, ST_FAILED)

_PATCH_MS = 600
_MAX_PENDING = 200


class CrawlLiveBridge:
    """Live 卡桥单例"""

    def __init__(self):
        self._ui_callback = None
        self._attached = False
        self._lock = threading.Lock()
        self._cards = {}          # sid -> card dict
        self._pending = {}        # sid -> patch dict
        self._t0 = {}             # sid -> 会话起点（rate_per_min 分母）
        self._last_flush = 0
        self._timer = None
        self._emit_card = None    # ActionCardRegistry.emit_card

    def attach(self, ui_callback):
        """只订阅一次 events.subscribe"""
        if self._attached:
            self._ui_callback = ui_callback
            return
        self._ui_callback = ui_callback
        events.subscribe(self._on_event)
        self._attached = True

    def set_emit_card(self, fn):
        """注入 ActionCardRegistry.emit_card"""
        self._emit_card = fn

    # ── 卡片生命周期 ──
    def start_session_card(self, sid: str, name: str, cfg: dict):
        card_id = "cl_" + sid
        card = {
            "type": "crawl_live_card",
            "card_id": card_id,
            "session_id": sid,
            "title": name or ("爬取 " + sid[:20]),
            "state": ST_RUNNING,
            "overview": {"total": 0, "ok": 0, "fail": 0, "skipped": 0,
                         "dedup_hit": 0, "size_bytes": 0, "avg_ms": 0,
                         "rate_per_min": 0},
            "queue": {"pending": 0, "inflight": 0},
            "recent": [],
            "series": [],
            "annotations": [],
            "tools": [
                {"action": "crawl.pause", "label": "暂停"},
                {"action": "crawl.resume", "label": "继续"},
                {"action": "crawl.stop", "label": "停止"},
                {"action": "crawl.export", "label": "导出"},
            ],
            "notes": [],
        }
        self._cards[sid] = card
        self._t0[sid] = time.time()  # rate_per_min 分母：会话起点
        self._emit(card)
        return card_id

    def update_state(self, sid: str, state: str):
        with self._lock:
            card = self._cards.get(sid)
            if card:
                card["state"] = state
            else:
                return
        # ★ 锁外 _patch（threading.Lock 不可重入）
        self._patch(sid, {"state": state})

    def push_annotation(self, sid: str, ann: dict):
        with self._lock:
            card = self._cards.get(sid)
            if not card:
                return
            card["annotations"].append(ann)
            anns = card["annotations"]
        self._patch(sid, {"annotations": anns})

    # ── 事件映射 ──
    def _on_event(self, ev_type, payload):
        sid = payload.get("session_id")
        if not sid:
            return
        if ev_type == EV_SESSION_START:
            self.update_state(sid, ST_RUNNING)
        elif ev_type == EV_PAGE_DONE:
            with self._lock:
                card = self._cards.get(sid)
                if not card:
                    return
                ov = card["overview"]
                ov["total"] += 1
                ov["ok"] += 1
                # ★ overview 真实累加：此前 size_bytes/avg_ms/dedup_hit/rate_per_min
                #   初始化后从未更新（A-08 卡五字段常年为 0，看板与端侧无数据可显示）
                size = int(payload.get("size_bytes") or 0)
                if size:
                    ov["size_bytes"] += size
                elapsed = int(payload.get("elapsed_ms") or 0)
                ok_n = ov["ok"]
                if ok_n > 0:
                    ov["avg_ms"] = int(round((ov["avg_ms"] * (ok_n - 1) + elapsed) / ok_n))
                if payload.get("dup"):
                    ov["dedup_hit"] += 1
                self._refresh_rate(ov, sid)
                card["recent"].insert(0, {
                    "page_id": payload.get("page_id"),
                    "ts": time.strftime("%H:%M:%S"),
                    "title": payload.get("title", ""),
                    "domain": payload.get("domain", ""),
                    "status": "ok",
                    "mode": payload.get("mode", ""),
                    "text_len": payload.get("text_len", 0),
                    "elapsed_ms": payload.get("elapsed_ms", 0),
                    "dup": payload.get("dup", False),
                    "quality": payload.get("quality", 0),
                })
                card["series"].append({"t": ov["total"], "ok": ov["ok"], "fail": ov["fail"]})
                ov_out = dict(ov)
                recent_out = list(card["recent"])
                series_out = list(card["series"][-60:])
            # ★ 锁外 _patch
            self._patch(sid, {"overview": ov_out, "recent": recent_out,
                              "series": series_out})
        elif ev_type == EV_PAGE_FAIL:
            with self._lock:
                card = self._cards.get(sid)
                if not card:
                    return
                ov = card["overview"]
                ov["total"] += 1
                ov["fail"] += 1
                self._refresh_rate(ov, sid)
                card["recent"].insert(0, {
                    "page_id": payload.get("page_id"),
                    "ts": time.strftime("%H:%M:%S"),
                    "title": payload.get("title", ""),
                    "domain": payload.get("domain", ""),
                    "status": "fail",
                    "mode": payload.get("mode", ""),
                    "text_len": 0,
                    "elapsed_ms": payload.get("elapsed_ms", 0),
                    "dup": False,
                    "quality": 0,
                })
                ov_out = dict(ov)
                recent_out = list(card["recent"])
            self._patch(sid, {"overview": ov_out, "recent": recent_out})
        elif ev_type == EV_SESSION_DONE:
            # ★ 终态透传：引擎 final 可能是 failed/cancelled，不再硬编码 COMPLETED
            self.update_state(sid, payload.get("state") or ST_COMPLETED)
            self.flush(sid)
            # ★ D6-05: 爬虫终态 → 桌面/webhook 通知
            try:
                from shared.crawler.notify import send as _notify
                _ov = (self._cards.get(sid, {}).get("overview") or {})
                _notify({"type": "crawl_done", "session_id": sid,
                         "title": f"抓取{self._cards.get(sid, {}).get('state') or ''} · {sid[:20]}",
                         "message": f"ok={_ov.get('ok', 0)} fail={_ov.get('fail', 0)} "
                                    f"pages={_ov.get('total', 0)}"})
            except Exception as _exc:
                logger.debug("[A-15] live_bridge.py:195 终态通知发送异常已结构化记录: %s", _exc)
        elif ev_type == EV_CONTROL:
            # ★ D3-08: 控制面扩展事件（pause/resume）——只记 annotation，不改状态机
            #   （状态由 engine 侧 EV_SESSION_* / 桥 update_state 维护）
            with self._lock:
                card = self._cards.get(sid)
                if not card:
                    return
                card["annotations"].append({
                    "ts": time.strftime("%H:%M:%S"),
                    "kind": "control",
                    "action": payload.get("action", ""),
                    "state": payload.get("state", ""),
                })
                card["annotations"] = card["annotations"][-100:]
                ann_out = list(card["annotations"])
            self._patch(sid, {"annotations": ann_out})

    def _refresh_rate(self, ov: dict, sid: str):
        """rate_per_min = total ÷ 会话运行分钟；仅限已持 self._lock 的分支内调用。"""
        t0 = self._t0.get(sid)
        if t0 and ov.get("total"):
            mins = max((time.time() - t0) / 60.0, 1e-6)
            ov["rate_per_min"] = round(ov["total"] / mins, 1)

    # ── patch 节流 ──
    def _patch(self, sid: str, patch: dict):
        now = time.time()
        with self._lock:
            cur = self._pending.get(sid) or {}
            cur.update(patch)
            if "recent" in cur:
                cur["recent"] = cur["recent"][:200]
            self._pending[sid] = cur
            if len(self._pending) > _MAX_PENDING:
                oldest = next(iter(self._pending))
                if oldest != sid:
                    self._pending.pop(oldest, None)
            should_flush = (now - self._last_flush) >= _PATCH_MS / 1000
        # ★ 锁外调度（避免与 flush 的锁死锁）
        if should_flush:
            self.flush(sid)

    def _schedule_flush(self, sid: str):
        # ★ 简化：不启用后台 Timer（避免测试环境线程挂起）；
        #   未达 600ms 的 patch 留到下次 flush 或 session_done 时刷出
        pass

    def _do_flush(self, sid: str):
        self.flush(sid)

    def flush(self, sid: str = None):
        with self._lock:
            if sid:
                patch = self._pending.pop(sid, None)
            else:
                patch = None
        self._last_flush = time.time()
        if patch and self._ui_callback:
            try:
                js = ("if(window.updateCrawlLive)window.updateCrawlLive(%s);"
                      % json.dumps(patch, ensure_ascii=False))
                self._ui_callback(js)
            except Exception as e:
                print(f"[CrawlLiveBridge] patch 失败: {e}")

    # ── 发卡片 ──
    def _emit(self, card: dict):
        if self._emit_card:
            try:
                self._emit_card(card)
            except Exception as e:
                print(f"[CrawlLiveBridge] emit_card 失败: {e}")
        elif self._ui_callback:
            # 回退：直接推 JS
            try:
                self._ui_callback("if(window.renderCrawlLive)window.renderCrawlLive(%s);"
                                  % json.dumps(card, ensure_ascii=False))
            except Exception as _exc:
                logger.debug("[A-15] live_bridge.py:221 _emit 异常已结构化记录: %s", _exc)

    # ═══════════════════════════════════════════════════════════════
    # A-07: 卡片按钮动作接 ActionCardRegistry —— 前端点击走真实控制面，
    # 不再是纯字符串（shared/action_cards.py:92 dispatch）。
    # ═══════════════════════════════════════════════════════════════
    def register_card_actions(self, registry=None) -> dict:
        """把 crawl.pause/resume/stop/export 注册进 ActionCardRegistry。"""
        from shared.action_cards import ActionCardRegistry
        reg = registry or _CARD_ACTION_REGISTRY

        def _pause(params):
            from shared.crawler.engine import pause_session
            return pause_session(str((params or {}).get("session_id") or ""),
                                 db_path=self._db_path())

        def _resume(params):
            from shared.crawler.engine import resume_session
            return resume_session(str((params or {}).get("session_id") or ""),
                                  db_path=self._db_path())

        def _stop(params):
            from shared.crawler.engine import _LIVE_ENGINES
            sid = str((params or {}).get("session_id") or "")
            eng = _LIVE_ENGINES.get(sid)
            if eng is not None:
                import threading as _t
                _t.Thread(target=eng.stop, daemon=True).start()
                return {"success": True, "session_id": sid, "stopping": True}
            r = self.update_state(sid, "stopping")
            return {"success": True, "session_id": sid, "live": False}

        def _export(params):
            try:
                from shared.crawler.export import export_session
                sid = str((params or {}).get("session_id") or "")
                return export_session(sid, db_path=self._db_path())
            except Exception as e:
                return {"success": False, "error": f"export unavailable: {e}"}

        out = []
        for aid, handler, confirm, desc in [
            ("crawl.pause", _pause, False, "暂停爬取会话"),
            ("crawl.resume", _resume, False, "继续爬取会话"),
            ("crawl.stop", _stop, True, "停止爬取会话"),
            ("crawl.export", _export, False, "导出会话产物"),
        ]:
            r = reg.register_action(aid, handler, confirm=confirm, description=desc)
            out.append({"action_id": aid, "registered": bool(r.get("success"))})
        return {"success": all(o["registered"] for o in out), "actions": out}

    def handle_card_action(self, action_id: str, params=None, confirmed: bool = False) -> dict:
        """卡片按钮统一入口：ActionCardRegistry.dispatch（含 requires_confirm 拦截）。"""
        from shared.action_cards import ActionCardRegistry
        reg = _CARD_ACTION_REGISTRY
        if not reg.has(action_id):
            self.register_card_actions(reg)
        return reg.dispatch(action_id, params, confirmed=confirmed)

    def _db_path(self):
        try:
            from shared.crawler.engine import _DEFAULT_DB  # 若引擎模块暴露默认库
            return _DEFAULT_DB
        except Exception:
            return None


from shared.action_cards import ActionCardRegistry  # A-07: 卡片动作分派注册表

_CARD_ACTION_REGISTRY = ActionCardRegistry()

_bridge = None
_bridge_lock = threading.Lock()


def get_live_bridge() -> CrawlLiveBridge:
    global _bridge
    if _bridge is None:
        with _bridge_lock:
            if _bridge is None:
                _bridge = CrawlLiveBridge()
    return _bridge
