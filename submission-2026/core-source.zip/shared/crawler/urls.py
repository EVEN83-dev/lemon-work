# -*- coding: utf-8 -*-
"""★ A2: URL 规范化与双指纹

- normalize_url：scheme/host 小写、去 fragment、去默认端口、去 utm_*/spm/from、
  query 排序、尾斜杠归一、去空参数
- url_key = sha1(normalize_url)
- content_hash = sha1(正文前 1MB, utf-8)
- is_crawlable：仅 http/https；拒 data:/javascript:/file:/mailto:
- same_domain(url, seed_host)：host 相等或后缀匹配
"""
from __future__ import annotations

import hashlib
import re
from urllib.parse import urlparse, urlencode, urlunparse, parse_qsl

# 跟踪参数黑名单（不参与去重键）
_TRACK_KEYS = {"utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content",
               "utm_id", "utm_name", "utm_reader", "spm", "from"}

_DEFAULT_PORTS = {"http": 80, "https": 443}


def normalize_url(url: str) -> str:
    """规范化 URL（去重键用）"""
    if not url:
        return ""
    raw = url.strip()
    try:
        p = urlparse(raw)
    except Exception:
        return raw
    scheme = (p.scheme or "http").lower()
    host = (p.hostname or "").lower()
    port = p.port
    if port is not None and _DEFAULT_PORTS.get(scheme) == port:
        port = None
    # 空 host 直接返回原样（非 http 类）
    if not host:
        return raw
    # query：去跟踪参数 + 排序 + 去空值
    q = [(k, v) for k, v in parse_qsl(p.query, keep_blank_values=True)
         if k.lower() not in _TRACK_KEYS and v != ""]
    q.sort(key=lambda kv: (kv[0].lower(), kv[1]))
    query = urlencode(q, doseq=True)
    # path：尾斜杠归一（根路径除外）
    path = p.path or "/"
    if len(path) > 1 and path.endswith("/"):
        path = path.rstrip("/") or "/"
    return urlunparse((scheme, host, path, "", query, ""))


def url_key(url: str) -> str:
    return hashlib.sha1(normalize_url(url).encode("utf-8")).hexdigest()


def content_hash(text: str) -> str:
    body = (text or "")[:1024 * 1024]
    return hashlib.sha1(body.encode("utf-8")).hexdigest()


_SCHEME_RE = re.compile(r"^(https?)://", re.I)


def is_crawlable(url: str) -> bool:
    """仅 http/https；拒 data:/javascript:/file:/mailto:"""
    if not url:
        return False
    raw = url.strip()
    if raw.startswith(("data:", "javascript:", "file:", "mailto:", "tel:")):
        return False
    return bool(_SCHEME_RE.match(raw))


def same_domain(url: str, seed_host: str, subdomain: bool = True) -> bool:
    """host 相等或后缀匹配（子域开关）"""
    try:
        host = (urlparse(url).hostname or "").lower()
    except Exception:
        return False
    seed = (seed_host or "").lower()
    if not host or not seed:
        return False
    if host == seed:
        return True
    if subdomain and host.endswith("." + seed):
        return True
    return False


# ── 8 例自检 ──
if __name__ == "__main__":
    cases = [
        ("HTTP://Example.COM:80/a", "http://example.com/a"),
        ("https://example.com/a#frag", "https://example.com/a"),
        ("https://example.com/a?utm_source=x&id=1", "https://example.com/a?id=1"),
        ("https://example.com/a/", "https://example.com/a"),
        ("https://example.com:443/a", "https://example.com/a"),
        ("https://example.com/b?a=2&a=1", "https://example.com/b?a=1&a=2"),
    ]
    ok = 0
    for raw, expect in cases:
        got = normalize_url(raw)
        mark = "✅" if got == expect else "❌"
        if got == expect:
            ok += 1
        print(f"{mark} {raw} → {got}")
    print("拒绝测试:", not is_crawlable("javascript:alert(1)"), not is_crawlable("data:text/html,x"))
    print(f"URL 用例: {ok}/{len(cases)}")
