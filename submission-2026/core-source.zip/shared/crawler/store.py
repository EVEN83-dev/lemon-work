# -*- coding: utf-8 -*-
"""★ A1: 建库与迁移（data/crawl.db）

铁律：
  - 新库 data/crawl.db，旧 crawler.db 一行不动
  - 每线程一个连接，禁止全局单连接跨线程
  - ro_conn 对不存在的库返回 None，不抛异常
  - 幂等建表，连跑两次表集合不变
"""
from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

import os
import sqlite3
import threading
import time
from typing import Optional

# 项目根（shared/crawler → shared → LemonWork 根）
_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DEFAULT_DB = os.path.join(_ROOT, "data", "crawl.db")

# ── 建表 DDL（字段名不得改）──
_SCHEMA = [
    """CREATE TABLE IF NOT EXISTS crawl_session(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id TEXT UNIQUE,
        name TEXT,
        seed_url TEXT,
        config_json TEXT,
        state TEXT,
        created_at TEXT,
        started_at TEXT,
        ended_at TEXT,
        total INTEGER DEFAULT 0,
        ok INTEGER DEFAULT 0,
        fail INTEGER DEFAULT 0,
        dedup_hit INTEGER DEFAULT 0,
        size_bytes INTEGER DEFAULT 0,
        note TEXT
    )""",
    """CREATE TABLE IF NOT EXISTS crawl_page(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id TEXT,
        url TEXT,
        url_key TEXT,
        content_hash TEXT,
        domain TEXT,
        depth INTEGER,
        status TEXT,
        http_status INTEGER,
        mode TEXT,
        title TEXT,
        author TEXT,
        published_at TEXT,
        summary TEXT,
        text_len INTEGER,
        img_count INTEGER,
        link_count INTEGER,
        quality REAL,
        elapsed_ms INTEGER,
        size_bytes INTEGER,
        dup_of INTEGER,
        error TEXT,
        fetched_at TEXT
    )""",
    "CREATE UNIQUE INDEX IF NOT EXISTS ux_page ON crawl_page(session_id, url_key)",
    """CREATE TABLE IF NOT EXISTS crawl_content(
        page_id INTEGER PRIMARY KEY,
        clean_html TEXT,
        text TEXT,
        meta_json TEXT
    )""",
    """CREATE TABLE IF NOT EXISTS crawl_edge(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id TEXT,
        from_page_id INTEGER,
        to_url TEXT,
        to_url_key TEXT,
        depth INTEGER,
        state TEXT
    )""",
    """CREATE TABLE IF NOT EXISTS crawl_annotation(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        page_id INTEGER,
        field TEXT,
        quote TEXT,
        note TEXT,
        tags TEXT,
        color TEXT,
        status TEXT,
        author TEXT,
        created_at TEXT,
        updated_at TEXT,
        deleted INTEGER DEFAULT 0
    )""",
    """CREATE TABLE IF NOT EXISTS crawl_rule(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        domain TEXT,
        name TEXT,
        selectors_json TEXT,
        enabled INTEGER DEFAULT 1,
        created_at TEXT
    )""",
    """CREATE TABLE IF NOT EXISTS crawl_rule_health(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        domain TEXT,
        checked_at TEXT,
        selector TEXT,
        hits INTEGER,
        total INTEGER,
        hit_rate REAL,
        status TEXT
    )""",
    """CREATE TABLE IF NOT EXISTS crawl_watch(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        domain TEXT,
        keywords TEXT,
        threshold INTEGER,
        action_json TEXT,
        enabled INTEGER DEFAULT 1,
        last_fired TEXT
    )""",
    """CREATE TABLE IF NOT EXISTS crawl_run(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id TEXT,
        trigger TEXT,
        started_at TEXT,
        ended_at TEXT,
        pages INTEGER DEFAULT 0,
        ok INTEGER DEFAULT 0,
        fail INTEGER DEFAULT 0,
        note TEXT
    )""",
    """CREATE TABLE IF NOT EXISTS crawl_meta(
        k TEXT PRIMARY KEY,
        v TEXT
    )""",
    # ── ★ 集群A: 判定事件流 / AI 调用记录（项15/16；字段名不得改）──
    """CREATE TABLE IF NOT EXISTS crawl_judge_event(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT,
        session_id TEXT,
        page_id INTEGER,
        question TEXT,
        p REAL,
        route TEXT,
        source TEXT
    )""",
    """CREATE TABLE IF NOT EXISTS crawl_ai_call(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT,
        session_id TEXT,
        model TEXT,
        tokens INTEGER DEFAULT 0,
        latency_ms INTEGER DEFAULT 0,
        ok INTEGER DEFAULT 1,
        prompt_tokens INTEGER DEFAULT 0,
        completion_tokens INTEGER DEFAULT 0
    )""",
]


def ensure_schema(db_path: Optional[str] = None) -> None:
    """幂等建表；WAL + busy_timeout=5000"""
    path = db_path or DEFAULT_DB
    os.makedirs(os.path.dirname(path), exist_ok=True)
    conn = sqlite3.connect(path, timeout=5)
    try:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=5000")
        for ddl in _SCHEMA:
            conn.execute(ddl)
        # ★ 本窗口（项 B3）: 幂等补列（旧库无 prompt/completion 列）
        for col, typ, dflt in (
                ("prompt_tokens", "INTEGER", "0"),
                ("completion_tokens", "INTEGER", "0")):
            cols = {r[1] for r in conn.execute("PRAGMA table_info(crawl_ai_call)")}
            if col not in cols:
                conn.execute(f"ALTER TABLE crawl_ai_call ADD COLUMN {col} {typ} DEFAULT {dflt}")
        # ★ W24-1: 幂等迁移（条件请求字段）
        _migrate(conn)
        conn.commit()
    finally:
        conn.close()


def _migrate(conn):
    """幂等迁移：添加条件请求/失败分类字段"""
    existing = {r[1] for r in conn.execute("PRAGMA table_info(crawl_page)")}
    additions = [
        ("etag", "TEXT"),
        ("last_modified", "TEXT"),
        ("not_modified", "INTEGER DEFAULT 0"),
        ("failure_type", "TEXT"),
    ]
    for col, typ in additions:
        if col not in existing:
            try:
                conn.execute(f"ALTER TABLE crawl_page ADD COLUMN {col} {typ}")
            except Exception as _exc:
                logger.debug("[A-15] store.py:171 _migrate 异常已结构化记录: %s", _exc)
    try:
        conn.execute("CREATE INDEX IF NOT EXISTS ix_page_etag ON crawl_page(etag)")
    except Exception as _exc:
        logger.debug("[A-15] store.py:175 _migrate 异常已结构化记录: %s", _exc)
    # ★ W25-H: 指标表随 ensure_schema 一起迁移（生产库缺这张表）
    try:
        conn.execute(
            "CREATE TABLE IF NOT EXISTS crawl_domain_metric("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, domain TEXT, window_start TEXT, "
            "requests INTEGER DEFAULT 0, ok INTEGER DEFAULT 0, fail INTEGER DEFAULT 0, "
            "p50_ms REAL, p95_ms REAL, http_429 INTEGER DEFAULT 0, extract_hit_rate REAL)"
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS ix_domain_metric "
            "ON crawl_domain_metric(domain, window_start)"
        )
    except Exception as _exc:
        logger.debug("[A-15] store.py:189 _migrate 异常已结构化记录: %s", _exc)
    # ★ 集群A: crawl_page.judge_route(rule/model/human) + needs_review（项17），
    #   新表 crawl_judge_event / crawl_ai_call 在旧库上幂等补建（项15/16）
    try:
        page_cols = {r[1] for r in conn.execute("PRAGMA table_info(crawl_page)")}
        for col, typ in (("judge_route", "TEXT"), ("needs_review", "INTEGER DEFAULT 0")):
            if col not in page_cols:
                conn.execute(f"ALTER TABLE crawl_page ADD COLUMN {col} {typ}")
        # ★ 本窗口（项10）: crawl_session 会话末汇总列 keep/maybe/cut（幂等补列）
        sess_cols = {r[1] for r in conn.execute("PRAGMA table_info(crawl_session)")}
        for col, typ in (("keep", "INTEGER DEFAULT 0"), ("maybe", "INTEGER DEFAULT 0"),
                         ("cut", "INTEGER DEFAULT 0")):
            if col not in sess_cols:
                conn.execute(f"ALTER TABLE crawl_session ADD COLUMN {col} {typ}")
        for ddl in _SCHEMA:
            if "crawl_judge_event" in ddl or "crawl_ai_call" in ddl:
                conn.execute(ddl)
        # ★ 本窗口（项13）: session_id / ts / page_id 索引（判定流与 AI 流查询口）
        conn.execute("CREATE INDEX IF NOT EXISTS ix_judge_event "
                     "ON crawl_judge_event(session_id, id)")
        conn.execute("CREATE INDEX IF NOT EXISTS ix_judge_event_ts "
                     "ON crawl_judge_event(session_id, ts)")
        conn.execute("CREATE INDEX IF NOT EXISTS ix_judge_event_page "
                     "ON crawl_judge_event(page_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS ix_ai_call "
                     "ON crawl_ai_call(session_id, id)")
        conn.execute("CREATE INDEX IF NOT EXISTS ix_ai_call_ts "
                     "ON crawl_ai_call(session_id, ts)")
        conn.execute("CREATE INDEX IF NOT EXISTS ix_ai_call_model "
                     "ON crawl_ai_call(model)")
        conn.execute("CREATE INDEX IF NOT EXISTS ix_page_sid "
                     "ON crawl_page(session_id, id)")
    except Exception as _exc:
        logger.debug("[A-15] store.py _migrate 集群A迁移异常已结构化记录: %s", _exc)


# ── 每线程一个连接（线程本地缓存，但每次 conn() 返回当前线程的连接）──
_local = threading.local()


def conn(db_path: Optional[str] = None) -> sqlite3.Connection:
    """返回当前线程针对该库的连接（线程本地 + 按路径缓存）；row_factory=sqlite3.Row

    ★ A-07 修复：旧版线程本地只缓存单连接（无视 db_path）—— 同一线程先后
      操作两个库时，写入会静默路由到第一个库（状态迁移丢失/写错库）。
      改为按绝对路径缓存，多会话/多库线程安全。
    """
    path = os.path.abspath(db_path or DEFAULT_DB)
    conns = getattr(_local, "_conns", None)
    if conns is None:
        conns = {}
        _local._conns = conns
    c = conns.get(path)
    if c is None:
        c = sqlite3.connect(path, timeout=5)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA busy_timeout=5000")
        conns[path] = c
    return c


def close_conn(db_path: Optional[str] = None) -> None:
    """关闭当前线程的连接（测试清理用）；不传路径则全关"""
    conns = getattr(_local, "_conns", None)
    if not conns:
        return
    if db_path:
        path = os.path.abspath(db_path)
        targets = [p for p in conns if p == path]
    else:
        targets = list(conns.keys())
    for p in targets:
        try:
            conns.pop(p).close()
        except Exception as _exc:
            logger.debug("[A-15] store.py:231 close_conn 异常已结构化记录: %s", _exc)


def ro_conn(db_path: Optional[str] = None) -> Optional[sqlite3.Connection]:
    """URI mode=ro；失败返回 None，不抛异常"""
    path = db_path or DEFAULT_DB
    if not os.path.exists(path):
        return None
    try:
        from pathlib import Path
        uri = Path(path).as_uri() + "?mode=ro"
        c = sqlite3.connect(uri, uri=True, timeout=5)
        c.row_factory = sqlite3.Row
        return c
    except Exception:
        return None


# ── A7: 内容存储 ──
def save_page(row: dict, db_path: Optional[str] = None) -> dict:
    """写入 crawl_page；同 session+url_key 冲突返回已有 id 并标 dup"""
    c = conn(db_path)
    sid = row.get("session_id")
    key = row.get("url_key")
    existing = c.execute(
        "SELECT id FROM crawl_page WHERE session_id=? AND url_key=?",
        (sid, key)).fetchone()
    # ★ W24-1: 同 session+url_key 冲突 → 更新条件请求字段（不新增行）
    if existing:
        c.execute(
            "UPDATE crawl_page SET dup_of=?, etag=?, last_modified=?, "
            "not_modified=?, failure_type=?, status=?, error=?, "
            "judge_route=?, needs_review=? "
            "WHERE session_id=? AND url_key=?",
            (row.get("dup_of"), row.get("etag", ""), row.get("last_modified", ""),
             row.get("not_modified", 0), row.get("failure_type", ""),
             row.get("status"), row.get("error"),
             row.get("judge_route"), int(row.get("needs_review") or 0),
             sid, key))
        c.commit()
        return {"id": existing["id"], "dup": True}
    try:
        cur = c.execute(
            """INSERT INTO crawl_page(session_id,url,url_key,content_hash,domain,depth,status,
               http_status,mode,title,author,published_at,summary,text_len,img_count,
               link_count,quality,elapsed_ms,size_bytes,dup_of,error,fetched_at,
               etag,last_modified,not_modified,failure_type,judge_route,needs_review)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (sid, row.get("url"), key, row.get("content_hash"), row.get("domain"),
             row.get("depth"), row.get("status"), row.get("http_status"), row.get("mode"),
             row.get("title"), row.get("author"), row.get("published_at"), row.get("summary"),
             row.get("text_len"), row.get("img_count"), row.get("link_count"),
             row.get("quality"), row.get("elapsed_ms"), row.get("size_bytes"),
             row.get("dup_of"), row.get("error"), row.get("fetched_at"),
             row.get("etag", ""), row.get("last_modified", ""),
             row.get("not_modified", 0), row.get("failure_type", ""),
             row.get("judge_route"), int(row.get("needs_review") or 0)))
        c.commit()
        return {"id": cur.lastrowid, "dup": False}
    except sqlite3.IntegrityError:
        # ★ W25-H11: 并发竞态 —— 多 worker 同时抓到同一 url_key，
        #   SELECT 阶段都判为不存在，第二个 INSERT 撞唯一约束。
        #   这里回退成「已存在」分支（更新条件请求字段），不让 worker 线程崩。
        c.rollback()
        r = c.execute(
            "SELECT id FROM crawl_page WHERE session_id=? AND url_key=?",
            (sid, key)).fetchone()
        if not r:
            raise
        c.execute(
            "UPDATE crawl_page SET dup_of=?, etag=?, last_modified=?, "
            "not_modified=?, failure_type=?, status=?, error=?, "
            "judge_route=?, needs_review=? "
            "WHERE session_id=? AND url_key=?",
            (row.get("dup_of"), row.get("etag", ""), row.get("last_modified", ""),
             row.get("not_modified", 0), row.get("failure_type", ""),
             row.get("status"), row.get("error"),
             row.get("judge_route"), int(row.get("needs_review") or 0),
             sid, key))
        c.commit()
        return {"id": r["id"], "dup": True}


def set_judge_route(page_id: int, route: str, needs_review: bool = False,
                    db_path: Optional[str] = None) -> dict:
    """★ 集群A（项17）: 回写判定分流与人工复核标记。route ∈ rule|model|human"""
    c = conn(db_path)
    c.execute("UPDATE crawl_page SET judge_route=?, needs_review=? WHERE id=?",
              (str(route or ""), 1 if needs_review else 0, int(page_id)))
    c.commit()
    return {"page_id": int(page_id), "judge_route": str(route or ""),
            "needs_review": bool(needs_review)}


def record_judge_event(session_id: str, page_id: int, question: str, p: float,
                       route: str, source: str = "",
                       ts: str = "", db_path: Optional[str] = None,
                       final_only: bool = True) -> dict:
    """★ 集群A（项15）+ 本窗口（项7）: 判定事件入流（决策流真源）。

    final_only=True（默认，生产口径）：同一 (session_id, page_id, question)
    只保留最终判定 —— 新事件落库前删同键旧行，避免决策流重复计数。
    ts 缺省取当前本地时间。"""
    c = conn(db_path)
    if final_only and page_id:
        c.execute("DELETE FROM crawl_judge_event "
                  "WHERE session_id=? AND page_id=? AND question=?",
                  (str(session_id or ""), int(page_id), str(question or "")))
    c.execute(
        "INSERT INTO crawl_judge_event(ts,session_id,page_id,question,p,route,source) "
        "VALUES(?,?,?,?,?,?,?)",
        (ts or time.strftime("%Y-%m-%d %H:%M:%S"), str(session_id or ""),
         int(page_id) if page_id else None, str(question or ""),
         float(p) if p is not None else None, str(route or ""), str(source or "")))
    c.commit()
    return {"ok": True}


def record_ai_call(session_id: str, model: str, tokens: int = 0,
                   latency_ms: int = 0, ok: bool = True,
                   ts: str = "", db_path: Optional[str] = None,
                   prompt_tokens: int = 0, completion_tokens: int = 0) -> dict:
    """★ 集群A（项16）: AI 调用记录入流（模型负载真源）。

    ★ 本窗口（项 B1/B3）: 增 prompt_tokens/completion_tokens 真值列；
      未显式传入时用 tokens 兜底（保持旧调用点兼容）。"""
    pt = int(prompt_tokens or 0)
    ct = int(completion_tokens or 0)
    if not pt and not ct and tokens:
        pt, ct = int(tokens), 0
    c = conn(db_path)
    # ★ 本窗口（项 B3）: 旧库无新列时幂等补列（同一连接，避免 DDL 竞争）
    _cols = {r[1] for r in c.execute("PRAGMA table_info(crawl_ai_call)")}
    for _col in ("prompt_tokens", "completion_tokens"):
        if _col not in _cols:
            c.execute(f"ALTER TABLE crawl_ai_call ADD COLUMN {_col} INTEGER DEFAULT 0")
            c.commit()
    c.execute(
        "INSERT INTO crawl_ai_call(ts,session_id,model,tokens,latency_ms,ok,"
        "prompt_tokens,completion_tokens) VALUES(?,?,?,?,?,?,?,?)",
        (ts or time.strftime("%Y-%m-%d %H:%M:%S"), str(session_id or ""),
         str(model or ""), int(tokens or 0), int(latency_ms or 0),
         1 if ok else 0, pt, ct))
    c.commit()
    return {"ok": True}


def save_content(page_id: int, clean_html: str, text: str, meta: dict,
                 db_path: Optional[str] = None) -> dict:
    """写入 crawl_content；超限截断并标记 truncated=true"""
    from . import MAX_CONTENT_HTML, MAX_CONTENT_TEXT
    import json
    truncated = False
    html = clean_html or ""
    txt = text or ""
    if len(html) > MAX_CONTENT_HTML:
        html = html[:MAX_CONTENT_HTML]
        truncated = True
    if len(txt) > MAX_CONTENT_TEXT:
        txt = txt[:MAX_CONTENT_TEXT]
        truncated = True
    meta = dict(meta or {})
    if truncated:
        meta["truncated"] = True
    c = conn(db_path)
    c.execute(
        "INSERT OR REPLACE INTO crawl_content(page_id,clean_html,text,meta_json) VALUES(?,?,?,?)",
        (page_id, html, txt, json.dumps(meta, ensure_ascii=False)))
    c.commit()
    return {"page_id": page_id, "truncated": truncated,
            "html_len": len(html), "text_len": len(txt)}


def table_names(db_path: Optional[str] = None) -> list:
    c = conn(db_path)
    rows = c.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
    return sorted(r[0] for r in rows)


# ═══════════════════════════════════════════════════════════════════════
# ★ 本窗口（项10）: 会话结束真实汇总（pages/bytes/keep/cut —— 判定用 board_data.judge）
# ═══════════════════════════════════════════════════════════════════════
def write_session_summary(session_id: str, db_path: Optional[str] = None) -> dict:
    """会话收束时写 crawl_session 真实汇总：total/ok/fail/size_bytes/keep/maybe/cut。

    全部来自 crawl_page 真实行逐页聚合（判定复用 board_data.judge 单一真源）；
    无行时写 0（不伪造）。幂等：重复调用以最新行集覆盖。"""
    try:
        from .board_data import judge as _judge
    except ImportError:
        from shared.crawler.board_data import judge as _judge
    c = conn(db_path)
    rows = c.execute(
        "SELECT status, quality, text_len, size_bytes FROM crawl_page "
        "WHERE session_id=?", (session_id,)).fetchall()
    total = len(rows)
    ok = sum(1 for r in rows if r["status"] in ("ok", "not_modified"))
    fail = sum(1 for r in rows if r["status"] not in ("ok", "not_modified", "skipped"))
    keep = maybe = cut = 0
    for r in rows:
        v = _judge({"status": r["status"], "quality": r["quality"],
                    "text_len": r["text_len"]})
        if v == "KEEP":
            keep += 1
        elif v == "MAYBE":
            maybe += 1
        else:
            cut += 1
    c.execute(
        "UPDATE crawl_session SET total=?, ok=?, fail=?, size_bytes="
        "COALESCE((SELECT SUM(size_bytes) FROM crawl_page WHERE session_id=?),0), "
        "keep=?, maybe=?, cut=? WHERE session_id=?",
        (total, ok, fail, session_id, keep, maybe, cut, session_id))
    c.commit()
    return {"ok": True, "session_id": session_id, "pages": total,
            "bytes": int(c.execute(
                "SELECT size_bytes FROM crawl_session WHERE session_id=?",
                (session_id,)).fetchone()["size_bytes"] or 0),
            "keep": keep, "maybe": maybe, "cut": cut}


# ═══════════════════════════════════════════════════════════════════════
# ★ 本窗口（项30）: DIR 方向状态（crawl_meta 真源；GET/POST 与前端一致）
# ═══════════════════════════════════════════════════════════════════════
def get_direction(db_path: Optional[str] = None) -> int:
    c = conn(db_path)
    row = c.execute("SELECT v FROM crawl_meta WHERE k='stage3_direction'").fetchone()
    try:
        return 1 if int(row["v"]) >= 0 else -1
    except Exception:
        return 1


def set_direction(direction: int, db_path: Optional[str] = None) -> dict:
    d = 1 if int(direction) >= 0 else -1
    c = conn(db_path)
    c.execute("INSERT OR REPLACE INTO crawl_meta(k,v) VALUES('stage3_direction',?)",
              (str(d),))
    c.commit()
    return {"ok": True, "direction": d}


# ═══════════════════════════════════════════════════════════════════════
# ★ 本窗口（项14/15）: crawl.db 超 100MB 自动按 session 归档 +
#   归档后按 session 查询（统计不丢历史）
# ═══════════════════════════════════════════════════════════════════════
_ARCHIVE_DIR = os.path.join(_ROOT, "outputs", "crawl_stage", "backup")
_ARCHIVE_THRESHOLD_MB = 100
_ARCHIVE_KEEP_SESSIONS = 20    # 活跃库保留最近 20 个会话，其余归档
# ★ 2026-11-23 存储地雷修复：归档是"整库快照"，每会话一份，无上限会线性膨胀
#   （实测 279 份 = 26GB）。保留最新 N 份 + 总容量上限（至少留 1 份）。
_ARCHIVE_KEEP_FILES = 5
_ARCHIVE_MAX_MB = 600


def db_size_mb(db_path: Optional[str] = None) -> float:
    path = db_path or DEFAULT_DB
    try:
        total = os.path.getsize(path)
        for suffix in ("-wal", "-shm"):
            p = path + suffix
            if os.path.exists(p):
                total += os.path.getsize(p)
        return round(total / (1024 * 1024), 2)
    except OSError:
        return 0.0


def archive_if_large(db_path: Optional[str] = None,
                     threshold_mb: float = _ARCHIVE_THRESHOLD_MB,
                     keep_sessions: int = _ARCHIVE_KEEP_SESSIONS) -> dict:
    """db 超阈值 → 把最旧会话逐个搬去 outputs/crawl_stage/backup/<sid>.db，
    活跃库保留最近 keep_sessions 个会话。逐 session 独立归档文件（**只含该会话**），
    统计侧可经 find_session_db(sid) 继续按 session 查询（项15）。幂等：
    已归档会话跳过；不足阈值时 no-op。"""
    path = db_path or DEFAULT_DB
    if not os.path.exists(path):
        return {"ok": True, "archived": [], "note": "db_missing", "size_mb": 0.0}
    size = db_size_mb(path)
    if size < threshold_mb:
        return {"ok": True, "archived": [], "note": "below_threshold",
                "size_mb": size}
    c = conn(db_path)
    sids = [r["session_id"] for r in c.execute(
        "SELECT session_id FROM crawl_session ORDER BY created_at DESC").fetchall()]
    victims = [s for s in sids[keep_sessions:]]
    os.makedirs(_ARCHIVE_DIR, exist_ok=True)
    archived = []
    for sid in victims:
        dest = os.path.join(_ARCHIVE_DIR, f"{sid}.db")
        if os.path.exists(dest):
            archived.append({"session_id": sid, "path": dest, "note": "already"})
        else:
            try:
                info = export_session_db(path, sid, dest)
                archived.append({"session_id": sid, "path": dest,
                                 "note": "archived", "bytes": info["bytes"]})
            except Exception as _exp_err:
                # 结构漂移等极端情况：回退整库快照（保留上限会兜住体积）
                logger.warning("[A-15] 按会话导出失败，回退整库快照: %s", _exp_err)
                src = sqlite3.connect(path, timeout=10)
                dst = sqlite3.connect(dest)
                src.backup(dst)
                dst.close()
                src.close()
                archived.append({"session_id": sid, "path": dest,
                                 "note": "archived_full_fallback"})
        # 从活跃库删除该会话全部行（先删按 page_id 关联的标注，再删六表）
        try:
            c.execute(
                "DELETE FROM crawl_annotation WHERE page_id IN "
                "(SELECT id FROM crawl_page WHERE session_id=?)", (sid,))
        except sqlite3.OperationalError:
            logger.debug("[A-15] shared/crawler/store.py: 路径降级静默", exc_info=True)
        for table in ("crawl_content", "crawl_edge", "crawl_judge_event",
                      "crawl_ai_call", "crawl_run", "crawl_page"):
            try:
                c.execute(f"DELETE FROM {table} WHERE session_id=?", (sid,))
            except sqlite3.OperationalError:
                logger.debug("[A-15] shared/crawler/store.py: 路径降级静默", exc_info=True)
    if victims:
        c.execute("DELETE FROM crawl_session WHERE session_id IN (%s)"
                  % ",".join("?" * len(victims)), victims)
    c.commit()
    pruned = prune_archives() if victims else {"removed": 0}
    return {"ok": True, "archived": archived, "pruned": pruned,
            "size_mb": db_size_mb(path), "threshold_mb": threshold_mb}


def export_session_db(src_path: str, session_id: str, dest_path: str) -> dict:
    """把单个会话导出为独立库（结构同源、只含该会话数据）。

    ★ 2026-11-23 根因修复：旧实现 `src.backup(dst)` 复制整库（92MB/份，
      279 份 = 26GB）。现在按 session_id 导出 6 张会话表 + 2 张页关联表，
      归档体积降到该会话真实大小。
    """
    tmp = dest_path + ".tmp"
    for suf in ("", "-wal", "-shm"):
        if os.path.exists(tmp + suf):
            try:
                os.remove(tmp + suf)
            except OSError:
                logger.debug("suppressed exception")
    # ★ 抗结构漂移：直接复制源库的建表/索引 DDL（含历史迁移列），
    #   不再依赖 _SCHEMA/ensure_schema 的版本对齐。
    d = sqlite3.connect(tmp)
    try:
        d.execute("ATTACH DATABASE ? AS src", (src_path,))
        ddls = [r[0] for r in d.execute(
            "SELECT sql FROM src.sqlite_master WHERE type='table' "
            "AND name NOT LIKE 'sqlite_%' AND sql IS NOT NULL")]
        ddls += [r[0] for r in d.execute(
            "SELECT sql FROM src.sqlite_master WHERE type='index' AND sql IS NOT NULL")]
        for ddl in ddls:
            d.execute(ddl)
        # 逐表复制：session 维度 / page 关联 / 全局小表（规则、策略、指标等）
        tables = [r[0] for r in d.execute(
            "SELECT name FROM src.sqlite_master WHERE type='table' "
            "AND name NOT LIKE 'sqlite_%'")]
        for t in tables:
            cols = [r[1] for r in d.execute("PRAGMA src.table_info(%s)" % t)]
            if "session_id" in cols:
                d.execute("INSERT INTO main.%s SELECT * FROM src.%s "
                          "WHERE session_id=?" % (t, t), (session_id,))
            elif "page_id" in cols:
                d.execute(
                    "INSERT INTO main.%s SELECT * FROM src.%s WHERE page_id IN "
                    "(SELECT id FROM src.crawl_page WHERE session_id=?)" % (t, t),
                    (session_id,))
            else:
                d.execute("INSERT INTO main.%s SELECT * FROM src.%s" % (t, t))
        d.commit()
        n = d.execute("SELECT count(*) FROM crawl_session").fetchone()[0]
        if n != 1:
            raise RuntimeError("export_session_db: 会话行数异常 %d" % n)
        integrity = d.execute("PRAGMA integrity_check").fetchone()[0]
        if integrity != "ok":
            raise RuntimeError("export_session_db: integrity=%s" % integrity)
    finally:
        try:
            d.execute("DETACH DATABASE src")
        except Exception:
            logger.debug("suppressed exception")
        try:
            d.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            d.execute("PRAGMA journal_mode=DELETE")
        except Exception:
            logger.debug("suppressed exception")
        d.close()
    for suf in ("-wal", "-shm"):
        side = tmp + suf
        if os.path.exists(side):
            try:
                os.remove(side)
            except OSError:
                logger.debug("suppressed exception")
    os.replace(tmp, dest_path)
    return {"ok": True, "bytes": os.path.getsize(dest_path), "sessions": 1}


def prune_archives(keep_files: Optional[int] = None,
                   max_mb: Optional[float] = None) -> dict:
    """归档保留策略：只留最新 N 份，并限制总容量（至少保留 1 份）。

    只删除 outputs/crawl_stage/backup/*.db（及其 -wal/-shm），绝不碰活跃库。
    最新一份是全库快照的超集，因此删除更旧快照不会丢"最近归档时点之前的会话"。
    """
    keep = max(1, int(keep_files if keep_files is not None else _ARCHIVE_KEEP_FILES))
    cap = float(max_mb if max_mb is not None else _ARCHIVE_MAX_MB)
    try:
        names = [n for n in os.listdir(_ARCHIVE_DIR) if n.endswith(".db")]
    except OSError:
        return {"ok": True, "removed": 0, "kept": 0, "note": "dir_missing"}
    paths = [os.path.join(_ARCHIVE_DIR, n) for n in names]
    try:
        paths.sort(key=os.path.getmtime, reverse=True)
    except OSError:
        logger.debug("archive sort failed", exc_info=True)
    keep_paths, victims = paths[:keep], paths[keep:]
    removed = freed = 0
    for p in victims:
        try:
            freed += os.path.getsize(p)
            os.remove(p)
            removed += 1
            for suf in ("-wal", "-shm"):
                side = p + suf
                if os.path.exists(side):
                    os.remove(side)
        except OSError:
            logger.debug("prune archive failed", exc_info=True)
    try:
        total = sum(os.path.getsize(p) for p in keep_paths if os.path.exists(p))
        while total > cap * 1024 * 1024 and len(keep_paths) > 1:
            p = keep_paths.pop()
            sz = os.path.getsize(p)
            os.remove(p)
            removed += 1
            freed += sz
            total -= sz
            for suf in ("-wal", "-shm"):
                side = p + suf
                if os.path.exists(side):
                    os.remove(side)
    except OSError:
        logger.debug("archive cap prune failed", exc_info=True)
    return {"ok": True, "removed": removed,
            "freed_mb": round(freed / 1024 / 1024, 1),
            "kept": len([p for p in keep_paths if os.path.exists(p)])}


def find_session_db(session_id: str, db_path: Optional[str] = None) -> Optional[str]:
    """按 session 定位真实库：活跃库优先，其次归档目录（项15 统计不丢历史）。"""
    path = db_path or DEFAULT_DB
    if os.path.exists(path):
        c = ro_conn(path)
        if c is not None:
            try:
                if c.execute("SELECT 1 FROM crawl_session WHERE session_id=?",
                             (session_id,)).fetchone():
                    return path
            except sqlite3.OperationalError:
                logger.debug("[A-15] shared/crawler/store.py: 路径降级静默", exc_info=True)
            finally:
                c.close()
    try:
        for name in sorted(os.listdir(_ARCHIVE_DIR)):
            if name.endswith(".db"):
                cand = os.path.join(_ARCHIVE_DIR, name)
                c = ro_conn(cand)
                if c is None:
                    continue
                try:
                    if c.execute("SELECT 1 FROM crawl_session WHERE session_id=?",
                                 (session_id,)).fetchone():
                        return cand
                except sqlite3.OperationalError:
                    continue
                finally:
                    c.close()
    except OSError:
        logger.debug("[A-15] shared/crawler/store.py: 路径降级静默", exc_info=True)
    return None
