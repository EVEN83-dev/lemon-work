# -*- coding: utf-8 -*-
"""★ C3: 自动预标注

六类规则：金额/日期/邮箱/电话/风险词/公司后缀
产出 status=pending 候选，不冒充人工确认
同 span 不重复标注
禁止：把 pending 当 confirmed；用 LLM 生成无出处标注
"""
from __future__ import annotations

import os
import re
from typing import Dict, List

try:
    from .store import conn, ensure_schema
    from . import annotate as _anno
except ImportError:
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from shared.crawler.store import conn, ensure_schema
    from shared.crawler import annotate as _anno

# 六类规则（正则）
_RULES = [
    ("amount", re.compile(r"(?:¥|\$|€|£)\s*\d[\d,]*(?:\.\d+)?|\d+\s*(?:元|美元|欧元|英镑)")),
    ("date", re.compile(r"\d{4}[-/年]\d{1,2}[-/月]\d{1,2}[日]?")),
    ("email", re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")),
    ("phone", re.compile(r"1[3-9]\d{9}")),
    ("risk", re.compile(r"(?:风险|违规|欺诈|违约|诉讼|处罚|警示|黑名单|异常)", re.I)),
    ("company", re.compile(r"(?:有限公司|股份有限公司|集团|公司|事务所|研究院)")),
]


def scan_text(text: str) -> List[Dict]:
    """扫描文本，产出六类候选（pending）"""
    out = []
    for tag, pat in _RULES:
        for m in pat.finditer(text or ""):
            quote = m.group(0)
            # 电话脱敏
            if tag == "phone" and len(quote) == 11:
                quote = quote[:3] + "****" + quote[7:]
            out.append({
                "tag": tag,
                "quote": quote,
                "status": "pending",
                "span": [m.start(), m.end()],
            })
    return out


def apply_to_page(page_id: int, text: str, db_path=None) -> Dict:
    """把扫描结果写入库（pending，同 span 不重复）"""
    ensure_schema(db_path)
    c = conn(db_path)
    candidates = scan_text(text)
    created = 0
    skipped = 0
    for cand in candidates:
        # 同 span 去重：检查是否已有相同 page_id + quote + tags
        existing = c.execute(
            "SELECT id FROM crawl_annotation WHERE page_id=? AND quote=? AND deleted=0",
            (page_id, cand["quote"])).fetchone()
        if existing:
            skipped += 1
            continue
        _anno.create(page_id, quote=cand["quote"], note=f"自动预标注: {cand['tag']}",
                     tags=[cand["tag"]], status="pending", db_path=db_path)
        created += 1
    return {"created": created, "skipped": skipped, "total": len(candidates)}


if __name__ == "__main__":
    text = "联系我们 13800138000 或 test@example.com，金额 ¥10000.00，2026-11-10 到期。"
    cands = scan_text(text)
    for c in cands:
        print(f"  {c['tag']:8s} {c['quote']} ({c['status']})")
    print(f"命中 {len(cands)} 条")
