# -*- coding: utf-8 -*-
"""★ W25-H6-VIS: 爬虫蛛网看板数据层（纯函数，无 Qt 依赖）

效果图契约（爬虫看板效果图.html）：
  聊天流 = 白盒证据（每页一卡，KEEP/MAYBE/CUT 三色判定）
  蛛网看板 = 现场直播（中心 Agent 节点 + 每页一个节点 + 统计条）
本模块只负责把 crawl.db 会话数据组装成看板 JSON；UI 壳（独立窗口）
由 board_app.py / 集群任务实现。

判定语义（W25-H6 新增，喂 recent 行与节点颜色）：
  KEEP   quality >= 0.5 且 text_len >= 400
  MAYBE  quality >= 0.25 或 text_len >= 150
  CUT    其余
"""
from __future__ import annotations

import json
import os
import sqlite3
import time
from typing import Optional

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_DB = os.path.join(_ROOT, "data", "crawl.db")


def judge(doc: dict) -> str:
    """KEEP / MAYBE / CUT 三档判定（可独立替换为 LLM 判定）"""
    q = float(doc.get("quality") or 0)
    n = int(doc.get("text_len") or 0)
    if doc.get("status") not in ("ok", "not_modified"):
        return "CUT"
    if q >= 0.5 and n >= 400:
        return "KEEP"
    if q >= 0.25 or n >= 150:
        return "MAYBE"
    return "CUT"


def session_board(session_id: str, db_path: Optional[str] = None,
                  max_nodes: int = 60) -> Optional[dict]:
    """组装一个会话的蛛网看板数据。

    返回 None = 会话不存在。
    结构：
      session: {session_id, name, state, seed, started, ended}
      stats:   {total, ok, fail, skipped, dedup, keep, maybe, cut, bytes, avg_ms}
      nodes:   [{page_id, title, domain, verdict, quality, text_len, mode}]
      seed_domain: 中心域名
    """
    p = db_path or _DB
    if not os.path.exists(p):
        return None
    c = sqlite3.connect(f"file:{p}?mode=ro", uri=True)
    c.row_factory = sqlite3.Row
    try:
        sess = c.execute(
            "SELECT session_id, name, seed_url, state, started_at, ended_at "
            "FROM crawl_session WHERE session_id=?", (session_id,)).fetchone()
        if not sess:
            return None
        # ★ D3-05: stats 改全量聚合（磁贴/判定环用真实总数，不再受 max_nodes 截断）；
        #   nodes 仍取前 max_nodes 行作展示。
        rows = c.execute(
            "SELECT id, url, domain, status, mode, title, text_len, quality, "
            "size_bytes, elapsed_ms, fetched_at FROM crawl_page "
            "WHERE session_id=? ORDER BY id", (session_id,)).fetchall()

        stats = {"total": 0, "ok": 0, "fail": 0, "skipped": 0, "dedup": 0,
                 "keep": 0, "maybe": 0, "cut": 0, "bytes": 0, "avg_ms": 0.0}
        nodes = []
        _ms_sum, _ms_n = 0, 0
        for i, r in enumerate(rows):
            d = dict(r)
            v = judge(d)
            stats["total"] += 1
            if d["status"] in ("ok", "not_modified"):
                stats["ok"] += 1
            elif d["status"] == "skipped":
                stats["skipped"] += 1
            else:
                stats["fail"] += 1
            if d["status"] == "dup":
                stats["dedup"] += 1
            stats[v.lower()] += 1
            stats["bytes"] += int(d.get("size_bytes") or 0)
            if d.get("elapsed_ms"):
                _ms_sum += int(d["elapsed_ms"])
                _ms_n += 1
            if i < max_nodes:
                nodes.append({
                    "page_id": d["id"],
                    "title": (d.get("title") or d.get("url") or "")[:40],
                    "domain": d.get("domain", ""),
                    "verdict": v,
                    "quality": round(float(d.get("quality") or 0), 2),
                    "text_len": int(d.get("text_len") or 0),
                    "mode": d.get("mode", ""),
                })
        stats["avg_ms"] = round(_ms_sum / _ms_n, 0) if _ms_n else 0
        from urllib.parse import urlparse
        seed_domain = urlparse(sess["seed_url"] or "").hostname or ""
        return {
            "session": {
                "session_id": sess["session_id"],
                "name": sess["name"] or "",
                "state": sess["state"] or "",
                "seed": (sess["seed_url"] or "")[:120],
                "started": sess["started_at"] or "",
                "ended": sess["ended_at"] or "",
            },
            "stats": stats,
            "nodes": nodes,
            "seed_domain": seed_domain,
            "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
    finally:
        c.close()


def latest_session(db_path: Optional[str] = None) -> Optional[str]:
    """最近一个非 failed 会话的 session_id（看板缺省展示对象）"""
    p = db_path or _DB
    if not os.path.exists(p):
        return None
    c = sqlite3.connect(f"file:{p}?mode=ro", uri=True)
    try:
        r = c.execute(
            "SELECT session_id FROM crawl_session WHERE IFNULL(state,'') != 'failed' "
            "ORDER BY created_at DESC LIMIT 1").fetchone()
        return r[0] if r else None
    finally:
        c.close()


if __name__ == "__main__":
    sid = latest_session() or ""
    b = session_board(sid)
    print(json.dumps(b, ensure_ascii=False, indent=2)[:1200])
    if b:
        print(f"\n... 共 {len(b['nodes'])} 节点 | 判定: "
              f"KEEP={b['stats']['keep']} MAYBE={b['stats']['maybe']} CUT={b['stats']['cut']}")
