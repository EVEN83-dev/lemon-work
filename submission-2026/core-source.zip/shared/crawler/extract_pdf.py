# -*- coding: utf-8 -*-
"""★ W25-H2: 公告 PDF 正文抽取（pymupdf，fitz 兼容回退）

- needs_pdf(content_type, url)：响应头/URL 判定
- extract_pdf_text(bytes)：逐页抽文本，超上限截断
- extract_pdf_meta(bytes)：标题/作者/页数
铁律：解析失败返回 None/{}，不抛异常打断引擎；不落盘原始 PDF
"""
from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

from typing import Optional


def _open_pdf(data: bytes):
    try:
        import pymupdf  # PyMuPDF >= 1.24
        return pymupdf.open(stream=data, filetype="pdf")
    except ImportError as _exc:
        logger.debug("[A-15] extract_pdf.py:18 _open_pdf 异常已结构化记录: %s", _exc)
    try:
        import fitz  # 旧版 PyMuPDF
        return fitz.open(stream=data, filetype="pdf")
    except Exception:
        return None
    return None


def needs_pdf(content_type: str = "", url: str = "") -> bool:
    ct = (content_type or "").lower()
    if "application/pdf" in ct or "application/octet-stream" in ct:
        return True
    u = (url or "").lower()
    return u.endswith(".pdf") or ".pdf?" in u


def extract_pdf_text(data: bytes, max_chars: int = 200000) -> Optional[str]:
    """从 PDF 字节流抽正文；失败返回 None"""
    if not data:
        return None
    doc = _open_pdf(data)
    if doc is None:
        return None
    try:
        chunks = []
        total = 0
        for page in doc:
            try:
                text = page.get_text() or ""
            except Exception:
                text = ""
            if total + len(text) > max_chars:
                chunks.append(text[:max(0, max_chars - total)])
                break
            chunks.append(text)
            total += len(text)
        return "\n".join(chunks).strip() or None
    except Exception:
        return None
    finally:
        try:
            doc.close()
        except Exception as _exc:
            logger.debug("[A-15] extract_pdf.py:62 extract_pdf_text 异常已结构化记录: %s", _exc)


def extract_pdf_meta(data: bytes) -> dict:
    """PDF 元数据（标题/作者/页数）；失败返回 {}"""
    if not data:
        return {}
    doc = _open_pdf(data)
    if doc is None:
        return {}
    try:
        meta = doc.metadata or {}
        return {
            "pdf_title": meta.get("title", "") or "",
            "pdf_author": meta.get("author", "") or "",
            "pdf_pages": doc.page_count,
        }
    except Exception:
        return {}
    finally:
        try:
            doc.close()
        except Exception as _exc:
            logger.debug("[A-15] extract_pdf.py:85 extract_pdf_meta 异常已结构化记录: %s", _exc)


# ── 自检：程序化生成 PDF 验证抽取 ──
if __name__ == "__main__":
    try:
        import pymupdf
        doc = pymupdf.open()
        page = doc.new_page()
        page.insert_text((72, 72), "LemonWork PDF self-test 2026")
        page.insert_text((72, 100), "line2: CJK extraction check (announcement body)")
        data = doc.tobytes()
        doc.close()
        text = extract_pdf_text(data)
        meta = extract_pdf_meta(data)
        assert text and "self-test" in text and "extraction check" in text, f"text={text!r}"
        assert meta.get("pdf_pages") == 1
        assert needs_pdf("application/pdf", "") and needs_pdf("", "http://x/a.pdf")
        assert not needs_pdf("text/html", "http://x/a.html")
        print(f"self-test PASS: text_len={len(text)}, meta={meta}")
    except ImportError:
        print("pymupdf 未安装，跳过自检")
