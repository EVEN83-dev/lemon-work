# -*- coding: utf-8 -*-
"""★ 2026-11-20: 让爬虫具备 Agent 能力（抽取/记忆/反思）的统一增强层。

设计原则：零侵入 —— 不改 crawler_skills.py 的任何既有函数，只在爬虫
执行链路上提供纯函数，由调用方按需接入；任何失败静默降级，不改主行为。

三件套：
  1) agentic_extract()   —— LLM schema 语义抽取（默认跟随 LEMON_EXTRACT_LLM 开关）
  2) remember_result()   —— 把抓取结论写入 episodic 记忆（无 source 拒绝）
  3) reflect_failure()   —— 失败归因 + 下一步建议（退避已有，这里补"反思"）
"""
from __future__ import annotations

import json
import os
import time
from typing import Any, Dict, List, Optional


def agentic_extract(raw_html: str = "", text: str = "", url: str = "",
                    schema: Optional[Dict] = None, *, use_llm: bool = False) -> Dict[str, Any]:
    """统一语义抽取入口 —— 爬虫的"眼睛"。

    默认 use_llm=False 时严格遵守 LEMON_EXTRACT_LLM 环境变量；
    有 schema 走 extract_llm（失败自动降级规则式），无 schema 直接返回规则式结果。
    """
    try:
        from shared.crawler.extract import extract_structured
        if not use_llm and os.environ.get("LEMON_EXTRACT_LLM", "") == "1":
            use_llm = True
        sch = schema or {"type": "object", "properties": {
            "title": {"type": "string"}, "summary": {"type": "string"}}}
        return extract_structured(raw_html, text, url, sch, use_llm=use_llm)
    except Exception as e:
        return {"ok": False, "source": "error", "data": {}, "error": str(e)[:120]}


def remember_result(session_id: str, url: str, verdict: str = "",
                    summary: str = "", *, source: str = "crawler") -> Dict[str, Any]:
    """把一次抓取结论写入 episodic 记忆 —— 爬虫的"记忆"。

    source 是必填审计字段（无来源不写），失败返回 ok=False 不影响抓取主流程。
    """
    if not source:
        return {"ok": False, "reason": "source_required"}
    try:
        from shared.skills_builtin.memory_skills import memory_write
        content = json.dumps({
            "session_id": session_id, "url": url, "verdict": verdict,
            "summary": str(summary)[:500], "ts": time.strftime("%Y-%m-%dT%H:%M:%S"),
        }, ensure_ascii=False)
        return memory_write(kind="episodic", content=content, source=source)
    except Exception as e:
        return {"ok": False, "reason": "memory_unavailable", "error": str(e)[:120]}


def reflect_failure(url: str, error: str = "", http_status: int = 0,
                    robots_disallowed: bool = False) -> Dict[str, Any]:
    """失败归因 + 下一步建议 —— 爬虫的"反思"。

    只做分类与建议，不改 domain_state 的既有退避逻辑。
    """
    reason = "unknown"
    advice = "记录失败并继续下一页；不要无限重试"
    if robots_disallowed or "robots" in error.lower():
        reason, advice = "robots_disallowed", "跳过该 URL，不得重试（合规红线）"
    elif http_status in (401, 403):
        reason, advice = "auth_or_forbidden", "不绕过登录/验证码；标记 SKIP-ENV"
    elif http_status == 429 or "429" in error:
        reason, advice = "rate_limited", "按 Retry-After 退避；降低并发"
    elif "timeout" in error.lower() or http_status == 0:
        reason, advice = "network_timeout", "最多重试 2 次，仍失败标 fail 不阻塞会话"
    elif http_status >= 500:
        reason, advice = "server_error", "退避后重试 1 次，失败标记并继续"
    return {"ok": True, "reason": reason, "advice": advice,
            "url": url, "http_status": http_status}


def agentic_pipeline(raw_html: str, text: str, url: str, session_id: str,
                     verdict: str = "", schema: Optional[Dict] = None,
                     *, use_llm: bool = False, remember: bool = True) -> Dict[str, Any]:
    """一次抓取的 Agent 化闭环：抽取 → 记忆 → 返回（供技能/事件层消费）。"""
    ext = agentic_extract(raw_html, text, url, schema, use_llm=use_llm)
    summary = ""
    data = ext.get("data") if isinstance(ext, dict) else {}
    if isinstance(data, dict):
        summary = str(data.get("summary") or data.get("title") or "")[:500]
    mem = remember_result(session_id, url, verdict, summary) if remember else {"ok": True, "reason": "disabled"}
    return {"extract": ext, "memory": mem,
            "summary": summary, "url": url, "session_id": session_id}


if __name__ == "__main__":
    checks = [
        ("抽取默认规则式", agentic_extract("<title>T</title>", "正文", "http://x")["source"] in ("rule", "error")),
        ("记忆缺 source 拒绝", remember_result("s", "http://x", source="")["ok"] is False),
        ("robots 反思", reflect_failure("http://x", "robots disallow", robots_disallowed=True)["reason"] == "robots_disallowed"),
        ("429 反思", reflect_failure("http://x", "429", http_status=429)["reason"] == "rate_limited"),
        ("超时反思", reflect_failure("http://x", "timeout")["reason"] == "network_timeout"),
        ("闭环不抛异常", agentic_pipeline("<title>T</title>", "正文", "http://x", "s", "KEEP")["url"] == "http://x"),
    ]
    for n, ok in checks:
        print(("PASS " if ok else "FAIL ") + n)
    print("AGENTIC_CRAWLER_" + ("ALL_PASS" if all(o for _, o in checks) else "HAS_FAIL"))
