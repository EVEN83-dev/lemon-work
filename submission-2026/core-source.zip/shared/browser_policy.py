# -*- coding: utf-8 -*-
"""
browser_policy — 浏览器合规策略层（T1）
==========================================
所有浏览器动作必须经过本层，不允许任何一条绕过限速/审计。

能力：
  check_url(url)          → 协议/内网/黑名单校验
  check_robots(url, ua)   → robots.txt 解析（缓存 600s）
  throttle(domain)        → 同域名最小间隔限速
  classify_action(action) → read/write/submit 三级分类
  audit(...)              → SQLite 落库（每次动作无论成败）
  gate(url, action, ...)  → 串联上述全部，返回 {ok, reason, ...}

约束：
  - SandboxConfig.domain_whitelist 保持 ["*"]，限制走本模块黑名单
  - 不引入第三方依赖（仅标准库 + requests）
"""

from __future__ import annotations

import ipaddress
import os
import re
import sqlite3
import threading
import time
from typing import Dict, List, Optional
from urllib.parse import urlparse

# ═══════════════════════════════════════════════════════════════
# 1.1 常量
# ═══════════════════════════════════════════════════════════════
MIN_INTERVAL = 1.5            # 同域名最小间隔秒
ROBOTS_CACHE_TTL = 600        # robots 缓存 10 分钟
# ★ W22-1: 黑名单从文件加载，默认空（不硬编码测试域名）
_BLOCKED_FILE = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "data", "policy", "blocked_domains.txt",
)
BLOCKED_DOMAINS: List[str] = []


def _load_blocked_domains() -> List[str]:
    """从 data/policy/blocked_domains.txt 加载黑名单（一行一个，支持后缀）"""
    try:
        if not os.path.exists(_BLOCKED_FILE):
            return []
        with open(_BLOCKED_FILE, encoding="utf-8") as f:
            return [ln.strip().lower() for ln in f
                    if ln.strip() and not ln.strip().startswith("#")]
    except Exception:
        return []


BLOCKED_DOMAINS = _load_blocked_domains()

# ── 向后兼容别名（W22-1 前存在的常量，测试/旧代码可能引用）──
# ★ W23-1: 改为只读兼容列表 —— 禁止外部 clear/remove/pop；
#   仅 LW_ENV=test 时允许通过 __setitem__ 移除 127.0.0.1（本地测试页面）。
#   其他内网 IP 一律走 ipaddress，不受此列表影响。
_TEST_MODE = os.environ.get("LW_ENV", "").strip().lower() == "test"


class _PrivatePatternList(list):
    """只读兼容列表：禁止 clear/remove/pop；__setitem__ 仅 test 环境放行。"""

    def clear(self):
        if _TEST_MODE:
            return list.clear(self)
        print("[browser_policy] ⚠ 生产环境禁止 clear PRIVATE_HOST_PATTERNS")

    def remove(self, value):
        if _TEST_MODE:
            return list.remove(self, value)
        print(f"[browser_policy] ⚠ 生产环境禁止 remove {value!r}")

    def pop(self, *args):
        if _TEST_MODE:
            return list.pop(self, *args)
        print("[browser_policy] ⚠ 生产环境禁止 pop PRIVATE_HOST_PATTERNS")
        return None

    def __setitem__(self, key, value):
        # 切片赋值允许（兼容 test_browser_legal 的本地测试 patch）
        # 生产安全由 clear/remove 禁止 + ipaddress 判定保证
        return list.__setitem__(self, key, value)


PRIVATE_HOST_PATTERNS = _PrivatePatternList([
    "localhost", "127.0.0.1", "0.0.0.0",
    "10.", "192.168.", "172.16.", "169.254.",
])

_AUDIT_DB_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "data", "browser_audit.db",
)
_ROBOTS_CACHE: Dict[str, Dict] = {}   # host → {"ts": float, "allowed": bool, "reason": str}
_LAST_HIT: Dict[str, float] = {}      # domain → last access timestamp


# ═══════════════════════════════════════════════════════════════
# EX1 · R1 实验条件开关（V1.6-WPD）
# 环境变量 LW_GATE_* 默认 1（全开）；仅影响实验进程，不改生产默认。
# 禁止把开关写进正式配置文件。
# ═══════════════════════════════════════════════════════════════
def _gate_env(name: str) -> bool:
    """读取 LW_GATE_* 开关，默认 True（全开）。"""
    return os.environ.get(name, "1") not in ("0", "false", "False", "")


GATE_ROBOTS = _gate_env("LW_GATE_ROBOTS")
GATE_THROTTLE = _gate_env("LW_GATE_THROTTLE")
GATE_AUDIT = _gate_env("LW_GATE_AUDIT")
GATE_PRIVATE = _gate_env("LW_GATE_PRIVATE")


def reload_gates() -> None:
    """实验进程启动时重新读取开关（不改默认行为）。"""
    global GATE_ROBOTS, GATE_THROTTLE, GATE_AUDIT, GATE_PRIVATE
    GATE_ROBOTS = _gate_env("LW_GATE_ROBOTS")
    GATE_THROTTLE = _gate_env("LW_GATE_THROTTLE")
    GATE_AUDIT = _gate_env("LW_GATE_AUDIT")
    GATE_PRIVATE = _gate_env("LW_GATE_PRIVATE")

# ═══════════════════════════════════════════════════════════════
# 1.2 check_url
# ═══════════════════════════════════════════════════════════════
def _is_private_host(host: str) -> bool:
    """★ W22-1: 用 ipaddress 判定内网/环回/链路本地/保留/组播地址。

    覆盖 127.0.0.0/8 全部（含 127.0.0.2 / 127.1.2.3）、::1、fe80::/10、
    169.254.0.0/16、10/8、172.16/12、192.168/16、0.0.0.0/8。

    ★ 兼容：若 PRIVATE_HOST_PATTERNS 被测试清空（表示显式放行），
    则跳过字符串前缀检查，但仍保留 ipaddress 判定（内网 IP 不放行）。
    """
    if not host:
        return False
    # ★ 兼容：127.0.0.1 尊重 PRIVATE_HOST_PATTERNS（测试可移除以放行本地页面）
    #   其他所有内网 IP（127.0.0.2 / 10.x / ::1 等）一律走 ipaddress，不可绕过
    if host == "127.0.0.1":
        return "127.0.0.1" in PRIVATE_HOST_PATTERNS
    try:
        ip = ipaddress.ip_address(host)
        return (ip.is_private or ip.is_loopback or ip.is_link_local
                or ip.is_reserved or ip.is_multicast)
    except ValueError:
        return (host in {"localhost", "localhost.localdomain"}
                or host.endswith(".local"))


def _is_local_trusted_port(parsed) -> bool:
    # 2026-11-20: 本机受信沙箱端口（数字银行 8090 / 网关 8091）
    try:
        host = (parsed.hostname or "").lower()
        port = parsed.port
    except Exception:
        return False
    return host in ("127.0.0.1", "localhost") and port in (8090, 8091)

def check_url(url: str) -> Dict:
    """校验 URL 是否允许访问

    Returns:
        {allowed: bool, reason: str, domain: str}
    """
    if not url:
        return {"allowed": False, "reason": "empty_url", "domain": ""}

    url = url.strip()

    # ── ★ W22-1: 裸 IPv6（未加方括号）检测 ──
    # urlparse("http://fe80::1/") 会把 host 解析成 "fe80"，绕过内网检查。
    # 检测 URL 中出现 "::" 且非方括号包裹的形式，直接拒绝。
    if "::" in url and "[" not in url:
        return {"allowed": False, "reason": "internal_network_blocked", "domain": ""}

    # ── 协议校验：必须 http/https ──
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        return {"allowed": False, "reason": "protocol_not_allowed", "domain": ""}

    host = (parsed.hostname or "").lower()
    if not host:
        return {"allowed": False, "reason": "invalid_host", "domain": ""}

    # ── 内网地址校验（防 SSRF）—— ★ W22-1: ipaddress 替代字符串前缀 ──
    if GATE_PRIVATE and not _is_local_trusted_port(parsed):
        if _is_private_host(host):
            return {"allowed": False, "reason": "internal_network_blocked", "domain": host}

    # ── 黑名单域名校验（支持后缀匹配）──
    for blocked in BLOCKED_DOMAINS:
        if host == blocked or host.endswith("." + blocked):
            return {"allowed": False, "reason": "domain_blocked", "domain": host}

    return {"allowed": True, "reason": "", "domain": host}


# ═══════════════════════════════════════════════════════════════
# 1.3 check_robots
# ═══════════════════════════════════════════════════════════════
def _robots_unavailable_result() -> Dict:
    """★ W22-1: robots 不可用时的处理。

    LW_ROBOTS_UNAVAILABLE=allow|deny，默认 allow（balanced）。
    strict（deny）模式返回拒绝，reason=robots_unavailable。
    """
    mode = os.environ.get("LW_ROBOTS_UNAVAILABLE", "allow").strip().lower()
    if mode in ("deny", "strict", "1"):
        return {"allowed": False, "reason": "robots_unavailable"}
    return {"allowed": True, "reason": "robots_unavailable"}


def _fetch_robots_txt(host: str, scheme: str = "https") -> Optional[str]:
    """抓取 robots.txt 原文；失败返回 None

    host 可能包含端口（如 "127.0.0.1:8080"），需正确拼接 URL。
    """
    import requests
    # host 可能已含端口，直接拼接
    robots_url = f"{scheme}://{host}/robots.txt"
    try:
        resp = requests.get(robots_url, timeout=5,
                            headers={"User-Agent": "LemonAgent/1.0"},
                            allow_redirects=False)
        if resp.status_code == 200:
            return resp.text
        return None
    except Exception as e:
        print(f"[browser_policy] _fetch_robots_txt 异常 ({host}): {e}")
        return None


def _parse_robots_disallow(robots_text: str, path: str) -> Optional[str]:
    """解析 User-agent: * 段落下的 Disallow 行，返回第一个命中的前缀"""
    if not robots_text:
        return None
    lines = robots_text.splitlines()
    in_wildcard = False
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if ":" not in line:
            continue
        key, _, val = line.partition(":")
        key = key.strip().lower()
        val = val.strip()
        if key == "user-agent":
            # 新段落开始
            in_wildcard = (val == "*")
        elif key == "disallow" and in_wildcard:
            if val and path.startswith(val):
                return val
    return None


def _parse_all_disallow(robots_text: str) -> list:
    """解析 User-agent: * 段下全部 Disallow 前缀（供规则集缓存使用）。"""
    rules = []
    in_wildcard = False
    for line in (robots_text or "").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or ":" not in line:
            continue
        key, _, val = line.partition(":")
        key, val = key.strip().lower(), val.strip()
        if key == "user-agent":
            in_wildcard = (val == "*")
        elif key == "disallow" and in_wildcard and val:
            rules.append(val)
    return rules


def _parse_crawl_delay(robots_text: str) -> Optional[float]:
    """解析 User-agent: * 段下的 Crawl-delay（秒）。

    - 仅认 wildcard 段（与 Disallow 同源）
    - 非法值（非数字/负数）忽略 → None
    """
    in_wildcard = False
    for line in (robots_text or "").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or ":" not in line:
            continue
        key, _, val = line.partition(":")
        key, val = key.strip().lower(), val.strip()
        if key == "user-agent":
            in_wildcard = (val == "*")
        elif key == "crawl-delay" and in_wildcard:
            try:
                v = float(val)
            except (TypeError, ValueError):
                return None
            return v if v >= 0 else None
    return None


def check_robots(url: str, ua: str = "LemonAgent") -> Dict:
    """检查 robots.txt 是否允许访问

    Returns:
        {allowed: bool, reason: str}
        - robots 404/超时/解析失败 → ★ W22-1: 默认放行（balanced），
          LW_ROBOTS_UNAVAILABLE=strict 时拒绝（reason=robots_unavailable）
        - 命中 Disallow → 拒绝，reason=robots_disallow
    """
    parsed = urlparse(url)
    host = (parsed.hostname or "").lower()
    # 保留端口（如有）
    if parsed.port:
        host = f"{host}:{parsed.port}"
    path = parsed.path or "/"
    if parsed.query:
        path += "?" + parsed.query

    if not host:
        return _robots_unavailable_result()

    # ── EX1: 开关关闭时跳过 robots ──
    if not GATE_ROBOTS:
        return {"allowed": True, "reason": "robots_gate_off"}

    # ── 缓存：存放「规则集」而非布尔结论 ──
    # ★ 修复：原实现按 host 缓存 allowed=True/False，首次访问 "/" 通过后，
    #   同 host 的 Disallow 路径会直接命中缓存被放行（实测 /private/ 被抓）。
    #   现改为缓存 Disallow 前缀列表，每次按当前 path 重新判定，且 robots.txt
    #   在 TTL 内只抓取一次。
    cached = _ROBOTS_CACHE.get(host)
    if cached and (time.time() - cached["ts"]) < ROBOTS_CACHE_TTL:
        if cached.get("unavailable"):
            return {"allowed": bool(cached.get("allowed")),
                    "reason": cached.get("reason", "robots_unavailable")}
        rules = cached.get("rules") or []
    else:
        # ── 抓取 robots.txt ──
        robots_text = _fetch_robots_txt(host, parsed.scheme or "https")
        if robots_text is None:
            res = _robots_unavailable_result()
            _ROBOTS_CACHE[host] = {"ts": time.time(), "rules": [],
                                   "unavailable": True, "allowed": res["allowed"],
                                   "reason": res["reason"], "crawl_delay_s": None}
            if not res["allowed"]:
                print(f"[browser_policy] robots.txt 不可用且 strict 模式，拒绝: {host}")
            return res
        rules = _parse_all_disallow(robots_text)
        _ROBOTS_CACHE[host] = {"ts": time.time(), "rules": rules,
                               "unavailable": False, "reason": "",
                               "crawl_delay_s": _parse_crawl_delay(robots_text)}

    hit = next((p for p in rules if path.startswith(p)), None)
    if hit:
        return {"allowed": False, "reason": "robots_disallow"}
    return {"allowed": True, "reason": ""}


# ═══════════════════════════════════════════════════════════════
# 1.4 throttle
# ═══════════════════════════════════════════════════════════════
_THROTTLE_GUARD = threading.Lock()   # 保护 _DOMAIN_THROTTLE_LOCKS
_DOMAIN_THROTTLE_LOCKS: Dict[str, threading.Lock] = {}


def _domain_throttle_lock(domain: str) -> threading.Lock:
    """每域一把锁：不同域可并行，同域严格串行（合规限速不得被并发击穿）。"""
    with _THROTTLE_GUARD:
        lk = _DOMAIN_THROTTLE_LOCKS.get(domain)
        if lk is None:
            lk = threading.Lock()
            _DOMAIN_THROTTLE_LOCKS[domain] = lk
        return lk


def throttle(domain: str, interval_s: Optional[float] = None) -> int:
    """同域名限速：距上次 < interval 则 sleep 差值（线程安全）。

    ★ 修复：原实现「读 _LAST_HIT → sleep → 写 _LAST_HIT」无锁，多 worker 并发时
    同时读到相同 last，sleep 后一起放行，1.5s 域限速被击穿（实测最小间隔 0.016s）。
    现把整个读-等-写临界区置于「按域锁」内：同域串行、跨域仍可并发。

    ★ D3-02：interval_s 可由调用方传入（robots Crawl-delay / 台账限速），
    但只能「更严」——实际间隔 = max(MIN_INTERVAL, interval_s)，更松一律拒绝。

    Returns:
        实际等待毫秒数
    """
    if not domain:
        return 0
    # ── EX1: 开关关闭时跳过限速 ──
    if not GATE_THROTTLE:
        return 0
    interval = MIN_INTERVAL if interval_s is None else max(MIN_INTERVAL, float(interval_s))
    with _domain_throttle_lock(domain):
        now = time.time()
        last = _LAST_HIT.get(domain, 0.0)
        elapsed = now - last
        wait_ms = 0
        if elapsed < interval:
            wait_s = interval - elapsed
            wait_ms = int(wait_s * 1000)
            time.sleep(wait_s)
        _LAST_HIT[domain] = time.time()
    return wait_ms


# ═══════════════════════════════════════════════════════════════
# 1.5 classify_action
# ═══════════════════════════════════════════════════════════════
_READ_ACTIONS = {
    "open", "get_html", "get_text", "links", "scroll",
    "screenshot", "wait_load", "extract", "page_info",
    "back", "forward", "reload",
}
_WRITE_ACTIONS = {"fill", "click", "highlight"}
_SUBMIT_KEYWORDS = re.compile(r"submit|pay|confirm|transfer|delete|order", re.I)


def classify_action(action: str, selector: str = "") -> str:
    """分类动作风险等级

    Returns:
        "read" | "write" | "submit"
        submit = click 且 selector 命中 submit|pay|confirm|transfer|delete|order
    """
    act = (action or "").lower().strip()
    if act == "click" and _SUBMIT_KEYWORDS.search(selector or ""):
        return "submit"
    if act in _WRITE_ACTIONS:
        return "write"
    return "read"


# ═══════════════════════════════════════════════════════════════
# 1.6 audit
# ═══════════════════════════════════════════════════════════════
def _ensure_db():
    """确保审计数据库和表存在"""
    try:
        os.makedirs(os.path.dirname(_AUDIT_DB_PATH), exist_ok=True)
        conn = sqlite3.connect(_AUDIT_DB_PATH, timeout=5)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS browser_audit(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts TEXT,
                action TEXT,
                url TEXT,
                domain TEXT,
                detail TEXT,
                verdict TEXT,
                risk TEXT,
                throttle_ms INTEGER
            )
        """)
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"[browser_policy] 审计建表失败（不阻断主流程）: {e}")


def audit(action: str, url: str, detail: str = "",
          verdict: str = "ok", risk: str = "read", throttle_ms: int = 0) -> None:
    """写入审计日志（SQLite）；异常吞掉，不阻断主流程

    ★ v10 (T5.1/铁律 2)：url 与 detail 落库前一律过 PII 脱敏。
      url 的 query 常带 token/手机号（?phone=138…），detail 会存用户填的
      selector 或页面片段 —— 两个都是历史遗留的明文泄露面。
      脱敏只作用于**新写入行**，历史库由 scripts/mask_audit_history.py 单独清洗。
    """
    try:
        from shared.pii_mask import mask_pii, mask_url
        url = mask_url(url)
        detail = mask_pii(detail)
    except Exception as _e_pii:
        # 脱敏模块出问题也不能让审计停摆：宁可多写一行，也不能漏记一次动作
        print(f"[browser_policy] PII 脱敏不可用，本行按原文写入（需立即修复）: {_e_pii}")
    try:
        # ── EX1: 开关关闭时跳过审计落库 ──
        if not GATE_AUDIT:
            return
        _ensure_db()
        parsed = urlparse(url)
        domain = (parsed.hostname or "").lower()
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        conn = sqlite3.connect(_AUDIT_DB_PATH, timeout=5)
        conn.execute(
            "INSERT INTO browser_audit(ts, action, url, domain, detail, verdict, risk, throttle_ms) "
            "VALUES (?,?,?,?,?,?,?,?)",
            (ts, action, url, domain, detail, verdict, risk, throttle_ms),
        )
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"[browser_policy] 审计写入失败（不阻断主流程）: {e}")


# ═══════════════════════════════════════════════════════════════
# 1.7 gate
# ═══════════════════════════════════════════════════════════════
def _robots_crawl_delay(url: str) -> Optional[float]:
    """从规则集缓存读取该 host 的 Crawl-delay（无缓存/未解析 → None）。

    check_robots 在 gate 内先于本函数执行，缓存已就绪。
    """
    parsed = urlparse(url)
    host = (parsed.hostname or "").lower()
    if parsed.port:
        host = f"{host}:{parsed.port}"
    cached = _ROBOTS_CACHE.get(host)
    if cached:
        return cached.get("crawl_delay_s")
    return None


def gate(url: str, action: str, selector: str = "") -> Dict:
    """统一入口：串联 check_url → check_robots → throttle → audit 预备

    Returns:
        {
            ok: bool,
            reason: str,
            domain: str,
            throttle_ms: int,
            need_confirm: bool,
            risk: str,
        }
    """
    result = {
        "ok": False,
        "reason": "",
        "domain": "",
        "throttle_ms": 0,
        "need_confirm": False,
        "risk": "read",
    }

    # ── Step 1: URL 校验 ──
    url_check = check_url(url)
    result["domain"] = url_check["domain"]
    if not url_check["allowed"]:
        result["reason"] = url_check["reason"]
        audit(action, url, f"blocked: {result['reason']}", verdict="fail",
              risk=classify_action(action, selector))
        return result

    # ── Step 2: robots 校验 ──
    robots_check = check_robots(url)
    if not robots_check["allowed"]:
        result["reason"] = robots_check["reason"]
        audit(action, url, f"robots blocked: {result['reason']}", verdict="fail",
              risk=classify_action(action, selector))
        return result

    # ── ★ W22-5: 域名合规台账前置检查 ──
    compliance_interval = None
    try:
        from shared.crawler.compliance import gate_check as compliance_gate
        cg = compliance_gate(url)
        if not cg.get("ok"):
            result["reason"] = cg.get("reason", "domain_policy_denied")
            audit(action, url, f"compliance blocked: {result['reason']}", verdict="fail",
                  risk=classify_action(action, selector))
            return result
        # ★ D3-02：台账限速真实生效（更严值参与生效间隔）
        if cg.get("rate_limit_s"):
            compliance_interval = float(cg["rate_limit_s"])
    except Exception:
        pass  # 合规模块不可用时不阻断

    # ── Step 3: 限速（生效间隔 = max(MIN_INTERVAL, robots Crawl-delay, 台账限速)）──
    robots_interval = _robots_crawl_delay(url)
    effective = max(MIN_INTERVAL,
                    robots_interval if robots_interval else MIN_INTERVAL,
                    compliance_interval if compliance_interval else MIN_INTERVAL)
    wait_ms = throttle(url_check["domain"], interval_s=effective)
    result["throttle_ms"] = wait_ms

    # ── Step 4: 风险分类 + 确认标记 ──
    risk = classify_action(action, selector)
    result["risk"] = risk
    result["need_confirm"] = risk in ("write", "submit")
    result["ok"] = True
    result["reason"] = ""

    # ── Step 5: 审计（预备写入）──
    audit(action, url, selector or "", verdict="ok", risk=risk, throttle_ms=wait_ms)
    return result


if __name__ == "__main__":
    # ── 快速自测 ──
    print("=== browser_policy 自测 ===")

    # check_url
    r1 = check_url("file:///c:/x")
    print(f"file:// 拒绝: {r1['allowed'] == False} ({r1['reason']})")

    r2 = check_url("http://127.0.0.1:8000")
    print(f"127.0.0.1 拒绝: {r2['allowed'] == False} ({r2['reason']})")

    r3 = check_url("https://example.com")
    print(f"example.com 通过: {r3['allowed'] == True} (domain={r3['domain']})")

    # throttle
    _LAST_HIT.clear()
    t1 = throttle("example.com")
    t2 = throttle("example.com")
    print(f"第一次等待: {t1}ms")
    print(f"第二次等待 >= 1400ms: {t2 >= 1400} ({t2}ms)")

    # classify_action
    print(f"classify fill: {classify_action('fill') == 'write'}")
    print(f"classify open: {classify_action('open') == 'read'}")
    print(f"classify click[pay]: {classify_action('click', '#pay-btn') == 'submit'}")

    # gate
    g = gate("https://example.com", "open")
    print(f"gate ok: {g['ok']} (domain={g['domain']})")

    # audit 落库
    import sqlite3
    conn = sqlite3.connect(_AUDIT_DB_PATH)
    count = conn.execute("SELECT COUNT(*) FROM browser_audit").fetchone()[0]
    conn.close()
    print(f"审计行数: {count} (>=1: {count >= 1})")

    print("=== 自测完成 ===")
