# -*- coding: utf-8 -*-
"""
lw-vision T2: 视觉分析技能（vision_analyze）
注册模式参照 crawler_skills.py / artifact_skills.py 的 SkillDef 结构。

行为：
  capture_now=true → 先调面板截图 → 拿到 path → 调 engine_manager.vision_chat
  capture_now=false + image_paths → 直接对指定图片调 vision_chat
  无 vision 模型 → 显式返回降级提示（不静默）

隐私声明：截图仅保存在本机 data/screenshots/，不上传外网。
"""

import logging
logger = logging.getLogger(__name__)
import os
import sys

# ── SkillDef / SkillResult 导入（两种路径兼容）──
try:
    from standard_mode.core.skills_registry import SkillDef, SkillResult, get_skills_registry
except Exception:
    try:
        from core.skills_registry import SkillDef, SkillResult, get_skills_registry
    except Exception:
        from shared.core.skills_registry import SkillDef, SkillResult, get_skills_registry

# ── vision 模型白名单（与 engine_manager 一致）──
VISION_MODEL_KEYWORDS = (
    "vl", "vision", "visual", "qwen2.5-vl", "qwen3-vl", "qwen3.5", "clip",
    "llava", "bakllava", "moondream", "minicpm", "cogvlm",
    "internvl", "yi-vl", "glm-4v", "step-1v",
)

# ── 面板/引擎单例引用（注册时注入）──
_ui_callback = None
_engine_manager_ref = None
_panel_ref = None


def set_engine_manager(engine_mgr):
    """注入 engine_manager 实例（面板注册时调用）"""
    global _engine_manager_ref
    _engine_manager_ref = engine_mgr


def set_panel(panel):
    """注入面板实例（截图能力的真正持有者，注册时调用）"""
    global _panel_ref
    _panel_ref = panel


def _capture_screenshot_via_ui():
    """截取当前界面截图。

    首选注册时注入的面板实例（panel 才是截图能力的持有者）；
    回退：从 QApplication 全量 widget 中查找具备该方法的面板。
    """
    # ── 首选：注册时注入的 panel ──
    if _panel_ref is not None and hasattr(_panel_ref, "_handle_capture_screenshot"):
        try:
            return _panel_ref._handle_capture_screenshot()
        except Exception as e:
            return {"success": False, "error": f"面板截图异常: {e}"}

    if _ui_callback is None:
        return {"success": False, "error": "UI 回调未注入（面板未就绪），无法截图"}
    try:
        from PyQt5.QtWidgets import QApplication
        app = QApplication.instance()
        if app is None:
            return {"success": False, "error": "QApplication 实例不存在"}
        # ★ 用 allWidgets 而非 topLevelWidgets：panel 挂在主窗口下，不是顶层
        for w in app.allWidgets():
            if hasattr(w, "_handle_capture_screenshot"):
                try:
                    return w._handle_capture_screenshot()
                except Exception as e:
                    return {"success": False, "error": f"面板截图异常: {e}"}
        return {"success": False, "error": "未找到面板窗口实例（无法截图）"}
    except Exception as e:
        return {"success": False, "error": f"截图异常: {e}"}


def _vision_analyze(**kw):
    """视觉分析：看截图/图片并回答问题。

    Params:
        prompt: string（必填）——要问的问题，如"当前界面显示了什么"
        image_paths: array（可选）——指定图片路径列表
        capture_now: boolean（可选，默认 false）——是否先截当前界面
    """
    prompt = str(kw.get("prompt", "") or "").strip()
    if not prompt:
        return SkillResult(success=False, error="参数 prompt 不能为空（要问的问题）")

    image_paths = kw.get("image_paths")
    if isinstance(image_paths, str):
        image_paths = [image_paths]
    if not isinstance(image_paths, list):
        image_paths = []

    capture_now = bool(kw.get("capture_now", False))

    # ── Step 1: 确定图片列表 ──
    actual_paths = []
    capture_result = None

    if capture_now:
        # 先截图
        cap = _capture_screenshot_via_ui()
        if not cap.get("success"):
            return SkillResult(
                success=False,
                error=f"截图失败: {cap.get('error', '未知原因')}")
        capture_result = cap
        actual_paths.append(cap["path"])

    # 追加用户指定的图片
    for p in (image_paths or []):
        p_str = str(p)
        if os.path.exists(p_str):
            actual_paths.append(p_str)
        else:
            return SkillResult(success=False, error=f"图片不存在: {p_str}")

    if not actual_paths:
        return SkillResult(
            success=False,
            error="未提供图片：请指定 image_paths 或设置 capture_now=true")

    # ── Step 2: 检查 vision 模型 ──
    if _engine_manager_ref is None:
        return SkillResult(
            success=False,
            error="当前引擎不支持视觉（engine_manager 未注入，建议切换到 Ollama qwen2.5-vl 或配置 vision 模型）")

    # 检查当前引擎是否有 vision 模型
    try:
        has_vision = False
        active_engine = getattr(_engine_manager_ref, "_active_engine", "")
        configs = getattr(_engine_manager_ref, "_configs", {})
        engines = getattr(_engine_manager_ref, "_engines", {})

        # 检查所有引擎配置中是否有 vision 模型
        for eng_name, cfg in (configs or {}).items():
            model = getattr(cfg, "model", "") or ""
            if any(kw in model.lower() for kw in VISION_MODEL_KEYWORDS):
                has_vision = True
                break

        if not has_vision:
            # ★ 2026-11-23: 配置里没写 vision 模型名时，再问本机 Ollama
            #   capabilities —— qwen3.5 / qwen3-vl 都能识图。
            try:
                try:
                    from standard_mode.core.vision_client import pick_vision_model
                except Exception:
                    from vision_client import pick_vision_model
                has_vision = bool(pick_vision_model())
            except Exception:
                has_vision = False

        if not has_vision:
            return SkillResult(
                success=False,
                error="当前引擎不支持视觉（建议 ollama pull qwen3.5:4b / qwen3-vl:4b，或配置 vision 模型）")
    except Exception as e:
        return SkillResult(success=False, error=f"vision 模型检测异常: {e}")

    # ── Step 3: 调用 vision_chat ──
    try:
        response = _engine_manager_ref.vision_chat(
            prompt=prompt,
            image_paths=actual_paths,
        )
    except Exception as e:
        return SkillResult(success=False, error=f"vision_chat 调用失败: {e}")

    if not response or not str(response).strip():
        return SkillResult(success=False, error="vision 模型返回空结果")

    # ── Step 4: 结构化输出 ──
    paths_desc = "、".join(os.path.basename(p) for p in actual_paths)
    capture_note = "（已自动截取当前界面）" if capture_result else ""
    output = (
        f"看了图片: {paths_desc}{capture_note}\n"
        f"结论: {response}"
    )

    return SkillResult(
        success=True,
        output=output,
        data={
            "prompt": prompt,
            "image_paths": actual_paths,
            "captured": capture_result is not None,
            "capture_path": capture_result.get("path") if capture_result else None,
            "response": response,
        },
    )


def register_vision_skills(ui_callback=None, engine_manager=None, panel=None) -> dict:
    """注册视觉分析技能；返回可发现性自检结果"""
    global _ui_callback, _engine_manager_ref
    if ui_callback is not None:
        _ui_callback = ui_callback
    if engine_manager is not None:
        _engine_manager_ref = engine_manager
    if panel is not None:
        set_panel(panel)

    skills = get_skills_registry()
    specs = [
        SkillDef(
            name="vision_analyze",
            description=(
                "查看图片/截图并回答问题（多模态视觉分析）。"
                "capture_now=true 时自动截取当前界面；也可通过 image_paths 指定图片。"
                "用户说'看看当前界面/截个图看看/这张图是什么'时调用。"
                "⚠ 隐私：截图仅保存在本机 data/screenshots/，不上传外网。"),
            parameters={"type": "object", "properties": {
                "prompt": {"type": "string", "description": "要问的问题，如「当前界面显示了什么」"},
                "image_paths": {"type": "array", "items": {"type": "string"},
                               "description": "图片路径列表（可选，不填则用 capture_now 截图）"},
                "capture_now": {"type": "boolean", "description": "是否先截取当前界面（默认 false）"},
            },
                "required": ["prompt"]},
            handler=_vision_analyze, category="vision", timeout=60,
            argcheck_example={"prompt": "当前界面显示了什么", "capture_now": True}),
    ]
    for d in specs:
        skills.register(d)
    names = set()
    try:
        for d in skills.get_tool_definitions():
            names.add((d.get("function") or {}).get("name") or d.get("name") or "")
    except Exception:
        logger.debug("suppressed exception")
    missing = [s.name for s in specs if s.name not in names]
    return {"success": not missing, "skills": [s.name for s in specs],
            "error": "" if not missing else f"注册后 schema 发现失败: {missing}"}
