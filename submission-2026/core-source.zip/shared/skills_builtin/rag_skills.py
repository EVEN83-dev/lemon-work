# -*- coding: utf-8 -*-
"""★ D6-02: RAG 知识库技能（kb_upload / kb_query / kb_list / kb_rebuild）。

注册到 SkillsRegistry；handler 全部走 shared.llm.rag 真实实现。
"""
from __future__ import annotations

import json
import os
from typing import Any, Dict

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_DEFAULT_DB = os.path.join(_ROOT, "data", "rag_kb", "rag.db")


def _rag():
    from shared.llm import rag
    return rag


def _kb_upload(kw: Dict[str, Any]) -> Dict[str, Any]:
    path = str(kw.get("path") or "").strip()
    if not path:
        return {"success": False, "error": "path required"}
    r = _rag().kb_upload(path, db_path=_DEFAULT_DB)
    return {"success": bool(r.get("ok")), "output": json.dumps(r, ensure_ascii=False),
            "data": r, "error": r.get("error", "")}


def _kb_query(kw: Dict[str, Any]) -> Dict[str, Any]:
    q = str(kw.get("query") or "").strip()
    if not q:
        return {"success": False, "error": "query required"}
    top_k = int(kw.get("top_k", 3) or 3)
    r = _rag().kb_query(q, top_k=top_k, db_path=_DEFAULT_DB)
    cites = r.get("citations") or []
    return {"success": bool(r.get("ok")),
            "output": r.get("answer", ""),
            "data": {"answer": r.get("answer"), "citations": cites,
                     "card": {"type": "rag_source_card",
                              "card_id": "rag_" + str(abs(hash(q)) % 10 ** 8),
                              "title": "知识库检索 · " + q[:24],
                              "answer": r.get("answer", ""),
                              "citations": cites}},
            "error": ""}


def _kb_list(kw: Dict[str, Any]) -> Dict[str, Any]:
    lst = _rag().kb_list(db_path=_DEFAULT_DB)
    return {"success": True,
            "output": json.dumps(lst, ensure_ascii=False),
            "data": {"sources": lst}}


def _kb_rebuild(kw: Dict[str, Any]) -> Dict[str, Any]:
    r = _rag().kb_rebuild(db_path=_DEFAULT_DB)
    return {"success": bool(r.get("ok")), "output": "知识库已清空重建",
            "data": r}


def register(reg) -> int:
    """把 RAG 技能注册进给定 registry（SkillDef 兼容）。"""
    from bridge.skills.models import SkillDef

    specs = [
        ("kb_upload", "上传文档到知识库（txt/md/pdf/docx，500 字/50 重叠切块，哈希去重）",
         {"path": {"type": "string"}}, ["path"], False),
        ("kb_query", "知识库语义检索（返回带 [来源#块号] 引用的答案）",
         {"query": {"type": "string"}, "top_k": {"type": "integer"}},
         ["query"], False),
        ("kb_list", "列出知识库来源与块数", {}, [], False),
        ("kb_rebuild", "清空并重建知识库（幂等）", {}, [], True),
    ]
    handlers = {"kb_upload": _kb_upload, "kb_query": _kb_query,
                "kb_list": _kb_list, "kb_rebuild": _kb_rebuild}
    n = 0
    for name, desc, props, required, confirm in specs:
        if name in getattr(reg, "_skills", {}):
            continue
        reg.register(SkillDef(name=name, description=desc,
                             parameters={"type": "object", "properties": props,
                                         "required": required},
                             handler=handlers[name], category="rag",
                             requires_confirm=confirm, timeout=120))
        n += 1
    return n


__all__ = ["register"]
