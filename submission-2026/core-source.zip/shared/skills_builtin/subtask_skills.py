# -*- coding: utf-8 -*-
"""★ W12: 并行子任务技能

- subtask_parallel(prompts: list[str], budget=40000)
- 用 shared.subtask_runner.SubTaskRunner
- handler 内部调 engine_manager.agent_chat
- 返回 3 项结果 + 状态 + 耗时；单失败不影响其他
- 禁止：子任务共享可变全局状态；无限并发（上限 4）
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import json
import os
import time

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _get_runner():
    try:
        from shared.subtask_runner import SubTaskRunner
    except ImportError:
        import sys
        sys.path.insert(0, _ROOT)
        from shared.subtask_runner import SubTaskRunner
    return SubTaskRunner


def _parallel(prompts, budget=40000, **_kw):
    prompts = prompts or []
    if isinstance(prompts, str):
        prompts = [prompts]
    if not prompts:
        return json.dumps({"ok": False, "error": "prompts 不能为空"})
    if len(prompts) > 4:
        return json.dumps({"ok": False, "error": f"并发上限 4，当前 {len(prompts)}"})
    try:
        b = max(1000, min(int(budget or 40000), 200000))
    except (TypeError, ValueError):
        b = 40000

    try:
        Runner = _get_runner()
    except ImportError as e:
        return json.dumps({"ok": False, "error": f"subtask_runner 不可用: {e}"})

    # engine_manager 注入
    engine = None
    try:
        from shared.engine_manager import get_engine_manager
        engine = get_engine_manager()
    except Exception:
        engine = None

    def _run_one(idx_prompt):
        idx, p = idx_prompt
        t0 = time.time()
        try:
            if engine is not None and hasattr(engine, "agent_chat"):
                out = engine.agent_chat(prompt=p, max_tokens=b)
            elif engine is not None:
                out = engine.chat(p, max_tokens=b)
            else:
                return {"index": idx, "prompt": p[:40], "status": "no_engine",
                        "output": "", "elapsed_ms": int((time.time() - t0) * 1000)}
            return {"index": idx, "prompt": p[:40], "status": "ok",
                    "output": str(out)[:500], "elapsed_ms": int((time.time() - t0) * 1000)}
        except Exception as e:
            return {"index": idx, "prompt": p[:40], "status": "fail",
                    "output": str(e)[:120], "elapsed_ms": int((time.time() - t0) * 1000)}

    try:
        runner = Runner(max_workers=4)
        results = runner.run([(i, p) for i, p in enumerate(prompts)], _run_one)
    except Exception as e:
        return json.dumps({"ok": False, "error": f"并行执行失败: {str(e)[:120]}"})

    ok = sum(1 for r in results if r.get("status") == "ok")
    return json.dumps({"ok": True, "results": results, "ok_count": ok,
                       "fail_count": len(results) - ok}, ensure_ascii=False)


def register(registry=None) -> dict:
    try:
        from standard_mode.core.skills_registry import SkillDef, get_skills_registry
    except ImportError:
        try:
            from core.skills_registry import SkillDef, get_skills_registry
        except ImportError:
            return {"success": False, "error": "skills_registry 不可用"}
    reg = registry or get_skills_registry()
    reg.register(SkillDef(
        name="subtask_parallel",
        description="并行执行多个子任务（上限 4，单失败不影响其他）",
        parameters={"type": "object", "properties": {
            "prompts": {"type": "array", "items": {"type": "string"}},
            "budget": {"type": "integer"},
        }, "required": ["prompts"]},
        handler=_parallel, category="subtask", requires_confirm=False, timeout=120))
    names = set()
    try:
        for d in reg.get_tool_definitions():
            names.add((d.get("function") or {}).get("name") or d.get("name") or "")
    except Exception:
        logger.debug("suppressed exception")
    found = "subtask_parallel" in names
    return {"success": found, "found": ["subtask_parallel"] if found else [], "total": 1}


if __name__ == "__main__":
    print(register())
