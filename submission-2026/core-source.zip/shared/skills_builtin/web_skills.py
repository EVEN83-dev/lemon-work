# -*- coding: utf-8 -*-
"""★第408章 web_skills —— 网页预览卡（对话内显示，用户选型：不开侧栏）

Agent 调用 web_preview(url) → 抓取+净化 → WebPageCard 推送到消息流：
  标题 + 摘要 + [在对话中展开] 按钮 → iframe srcdoc 沙箱渲染净化 HTML
  + [打开原文] 外链。与 ActionCard/文件卡同族（第404章卡片家族）。
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

try:
    from standard_mode.core.skills_registry import SkillDef, SkillResult
except ImportError:
    from core.skills_registry import SkillDef, SkillResult


def _web_preview(url: str, mode: str = "auto") -> SkillResult:
    from shared.web_capture import fetch_page
    from shared.action_cards import get_action_card_registry
    r = fetch_page(url, mode=mode)
    if not r.get("success"):
        return SkillResult(success=False, error=r.get("error", "抓取失败"))
    card = {
        "type": "web_page_card",
        "card_id": f"wp_{int(time.time() * 1000)}",
        "url": r["url"], "title": r["title"], "preview": r["preview"],
        "clean_html": r["clean_html"], "fetched_at": r["fetched_at"],
        # 双模式渲染字段（reader=正文重排 / visual=保留原站CSS）
        "mode": r.get("mode", "reader"),
        "sandbox": r.get("sandbox", ""),
        "quality": r.get("quality", {}),
        "robots_note": r.get("robots_note", ""),
    }
    emit = get_action_card_registry().emit_card(card)
    if not emit.get("success"):
        return SkillResult(success=False, error=emit.get("error", "渲染回调失败"))
    q = r.get("quality", {})
    mode_txt = "阅读模式" if r.get("mode") == "reader" else "原貌快照"
    return SkillResult(success=True,
                       output=f"已抓取「{r['title']}」并生成对话内网页卡（{mode_txt}，"
                              f"正文 {q.get('text_chars', 0)} 字，"
                              f"样式 {q.get('style_count', 0)} 个，"
                              f"{r['html_size'] // 1024}KB）",
                       data={"url": r["url"], "title": r["title"],
                             "mode": r.get("mode"), "quality": q})


import time  # noqa: E402  （卡片时间戳用）


def register_web_skills(ui_callback=None) -> dict:
    """注册 web_preview 技能；UI 回调复用 ActionCardRegistry 通道"""
    reg = __import__("shared.action_cards", fromlist=["get_action_card_registry"]) \
        .get_action_card_registry()
    if ui_callback is not None:
        reg.set_ui_callback(ui_callback)

    try:
        from standard_mode.core.skills_registry import get_skills_registry
    except ImportError:
        from core.skills_registry import get_skills_registry
    skills = get_skills_registry()

    skills.register(SkillDef(
        name="web_preview",
        description=("抓取网页并在对话中生成可读网页卡。reader=提取正文重排（干净易读），"
                     "visual=保留原站 CSS 的原貌快照，auto=按内容质量自动选。"
                     "用户说'打开/看看这个网页'时调用。需要 JS 渲染的站点会明确提示改用内置浏览器。"),
        parameters={"type": "object",
                    "properties": {
                        "url": {"type": "string", "description": "完整 URL"},
                        "mode": {"type": "string", "enum": ["auto", "reader", "visual"],
                                 "description": "渲染模式，默认 auto"},
                    },
                    "required": ["url"]},
        handler=_web_preview, category="web", timeout=20,
        argcheck_example={"url": "https://example.com", "mode": "auto"}))

    # 注册后实测可发现
    names = set()
    try:
        for d in skills.get_tool_definitions():
            names.add((d.get("function") or {}).get("name") or d.get("name") or "")
    except Exception:
        logger.debug("suppressed exception")
    ok = "web_preview" in names
    return {"success": ok, "skills": ["web_preview"],
            "error": "" if ok else "注册后 schema 发现失败"}
