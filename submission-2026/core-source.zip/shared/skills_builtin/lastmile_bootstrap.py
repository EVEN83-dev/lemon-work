# -*- coding: utf-8 -*-
"""★ W20-2: headless 统一技能注册（幂等）

- register_lastmile_skills(ui_callback=None) -> dict
- 用 marker 判断幂等：registry 已存在同名技能则 skip_existing
- 任何一组失败只记录，不抛异常
- 双入口：GUI（mimo_panel）+ headless（engine_manager.initialize）
- 禁止：import 期自动注册；try/except 后静默成功
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import os
from typing import Any, Callable, Dict, Optional

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _registry():
    try:
        from standard_mode.core.skills_registry import get_skills_registry
    except ImportError:
        try:
            from core.skills_registry import get_skills_registry
        except ImportError:
            return None
    return get_skills_registry()


def _has_skill(reg, name: str) -> bool:
    try:
        for d in reg.get_tool_definitions():
            n = (d.get("function") or {}).get("name") or d.get("name") or ""
            if n == name:
                return True
    except Exception:
        logger.debug("suppressed exception")
    return False


def register_lastmile_skills(ui_callback=None) -> Dict[str, Any]:
    """统一注册 7 组技能；幂等，重复调用 skip_existing"""
    reg = _registry()
    result: Dict[str, Any] = {"success": True, "groups": {}, "registered": [],
                              "skipped": []}
    if reg is None:
        return {"success": False, "error": "skills_registry 不可用",
                "groups": {}, "registered": [], "skipped": []}

    # 8 组（marker → 注册函数）
    _GROUPS = [
        ("crawl_start", "crawl 引擎 8 技能",
         lambda cb: _safe_call("shared.skills_builtin.crawler_skills",
                               "register_crawl_skills", cb)),
        ("crawl_annotate", "爬虫标注/统计 10 技能",
         lambda cb: _safe_call("shared.skills_builtin.crawler_skills",
                               "register_crawl_skills_c", cb)),
        ("quant_quality_check", "量化质量检查",
         lambda cb: _safe_call("shared.skills_builtin.quant_skills",
                               "register", cb)),
        ("backtest_run", "回测",
         lambda cb: _safe_call("shared.backtest.skills", "register", cb)),
        ("memory_write", "记忆",
         lambda cb: _safe_call("shared.skills_builtin.memory_skills",
                               "register", cb)),
        ("subtask_parallel", "并行子任务",
         lambda cb: _safe_call("shared.skills_builtin.subtask_skills",
                               "register", cb)),
        ("model_route", "成本路由",
         lambda cb: _safe_call("shared.skills_builtin.router_skills",
                               "register", cb)),
        # ★ 2026-11-11: 投资复盘（TRAE 效率工具赛道扣题技能）
        ("investment_review", "投资复盘",
         lambda cb: _safe_call("shared.backtest.review", "register", cb)),
    ]

    for marker, label, fn in _GROUPS:
        try:
            if _has_skill(reg, marker):
                result["groups"][marker] = "skip_existing"
                result["skipped"].append(marker)
                continue
            r = fn(ui_callback)
            ok = True
            if isinstance(r, dict):
                ok = bool(r.get("success", True))
            if ok:
                result["groups"][marker] = "registered"
                result["registered"].append(marker)
            else:
                result["groups"][marker] = f"failed: {r}"
        except Exception as e:
            result["groups"][marker] = f"failed: {str(e)[:120]}"

    result["success"] = all(v == "registered" or v == "skip_existing"
                            for v in result["groups"].values())
    return result


def _safe_call(module_path: str, fn_name: str, ui_callback):
    """动态导入并调用注册函数"""
    import importlib
    mod = importlib.import_module(module_path)
    fn = getattr(mod, fn_name, None)
    if fn is None:
        return {"success": False, "error": f"{module_path}.{fn_name} 不存在"}
    try:
        return fn(ui_callback=ui_callback)
    except TypeError:
        try:
            return fn()
        except Exception as e:
            return {"success": False, "error": str(e)[:120]}
    except Exception as e:
        return {"success": False, "error": str(e)[:120]}


if __name__ == "__main__":
    import json
    print(json.dumps(register_lastmile_skills(), ensure_ascii=False, indent=2))
