# -*- coding: utf-8 -*-
"""artifact_skills —— 交付物技能包 V1.6-WPD

两个技能，走 SkillsRegistry 公开 API（不动冻结区）：
  save_artifact   —— 把任务产出内容写入 data/artifacts/ 并推送 artifact_card
  list_artifacts  —— 列出最近交付物（含名称/大小/时间）

注册模式参照 crawler_skills.py 的 SkillDef 结构。
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import os
import time

try:
    from standard_mode.core.skills_registry import SkillDef, SkillResult, get_skills_registry
except ImportError:
    from core.skills_registry import SkillDef, SkillResult, get_skills_registry

try:
    from shared.artifacts import get_artifact_registry
except ImportError:
    from artifacts import get_artifact_registry

_ARTIFACT_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
    "data", "artifacts")
_VALID_KINDS = {"html", "csv", "md", "json", "pptx"}


def _fmt_size(n: int) -> str:
    """字节数 → 人类可读"""
    if n < 1024:
        return f"{n} B"
    if n < 1024 * 1024:
        return f"{n / 1024:.1f} KB"
    return f"{n / 1024 / 1024:.1f} MB"


def _save_artifact(**kw) -> SkillResult:
    """保存交付物文件并推送 artifact_card。

    Params: name(str), content(str), kind(str, 默认 md)
    """
    name = str(kw.get("name") or "").strip()
    content = str(kw.get("content") or "")
    kind = str(kw.get("kind") or "md").strip().lower()
    if not name:
        return SkillResult(success=False, error="name 不能为空")
    if kind not in _VALID_KINDS:
        return SkillResult(success=False, error=f"kind 必须是 {sorted(_VALID_KINDS)} 之一，收到: {kind}")
    if not content:
        return SkillResult(success=False, error="content 不能为空")

    os.makedirs(_ARTIFACT_DIR, exist_ok=True)
    # 文件名安全化
    safe = "".join(c for c in name if c.isalnum() or c in "-_.")[:60] or "artifact"
    fname = f"{safe}_{int(time.time())}.{kind}"
    fpath = os.path.join(_ARTIFACT_DIR, fname)
    try:
        with open(fpath, "w", encoding="utf-8") as f:
            f.write(content)
    except Exception as e:
        return SkillResult(success=False, error=f"写入失败: {e}")

    size = os.path.getsize(fpath)
    reg = get_artifact_registry()
    item = reg.register(name, fpath, kind, size)
    if "error" in item:
        return SkillResult(success=False, error=item["error"])

    # 推送 artifact_card 到对话流（复用 action_card 通道）
    try:
        from shared.action_cards import get_action_card_registry
        card = {
            "type": "artifact_card",
            "card_id": item["id"],
            "name": name,
            "path": fpath,
            "kind": kind,
            "size": size,
            "size_label": _fmt_size(size),
            "created_at": item["created_at"],
        }
        emit = get_action_card_registry().emit_card(card)
        if not emit.get("success"):
            # 卡片推送失败不影响文件已保存的事实
            pass
    except Exception:
        logger.debug("suppressed exception")

    return SkillResult(
        success=True,
        output=f"已保存交付物「{name}」（{_fmt_size(size)}，{kind}）→ {fpath}",
        data=item)


def _list_artifacts(**kw) -> SkillResult:
    """列出最近交付物。Params: limit(int, 默认 10)"""
    limit = int(kw.get("limit") or 10)
    reg = get_artifact_registry()
    items = reg.list()[:limit]
    if not items:
        return SkillResult(success=True, output="暂无交付物。任务产出可交付文件时可调用 save_artifact 保存。",
                           data={"items": []})
    lines = []
    for it in items:
        ts = time.strftime("%m-%d %H:%M", time.localtime(it.get("created_at", 0)))
        lines.append(f"· [{it['kind'].upper()}] {it['name']}（{_fmt_size(it['size'])}，{ts}）")
    return SkillResult(success=True, output="\n".join(lines),
                       data={"items": items, "total": len(items)})


def register_artifact_skills(ui_callback=None) -> dict:
    """注册交付物两技能；返回可发现性自检结果"""
    # 复用 action_card 通道（与 web_skills 一致）
    if ui_callback is not None:
        try:
            from shared.action_cards import get_action_card_registry
            get_action_card_registry().set_ui_callback(ui_callback)
        except Exception:
            logger.debug("suppressed exception")

    skills = get_skills_registry()
    specs = [
        SkillDef(
            name="save_artifact",
            description=("把任务产出保存为可交付文件（html/csv/md/json/pptx），"
                         "写入 data/artifacts/ 并在对话流生成带【下载】【打开】按钮的交付物卡片。"
                         "任务产出可交付文件时调用。"),
            parameters={"type": "object", "properties": {
                "name": {"type": "string", "description": "交付物名称（用于显示与文件名）"},
                "content": {"type": "string", "description": "文件内容（html/csv/md/json/pptx 文本）"},
                "kind": {"type": "string", "description": "文件类型：html/csv/md/json/pptx，默认 md"}},
                "required": ["name", "content"]},
            handler=_save_artifact, category="artifact", timeout=15,
            argcheck_example={"name": "巡检报告", "content": "# 巡检结果\n...", "kind": "md"}),
        SkillDef(
            name="list_artifacts",
            description=("列出最近保存的交付物（名称/大小/时间）。用户说'看看交付文件/产出列表'时调用。"),
            parameters={"type": "object", "properties": {
                "limit": {"type": "integer", "description": "返回条数上限，默认 10"}},
                "required": []},
            handler=_list_artifacts, category="artifact", timeout=10,
            argcheck_example={"limit": 10}),
    ]
    for d in specs:
        skills.register(d)
    names = set()
    try:
        for d in skills.get_tool_definitions():
            names.add((d.get("function") or {}).get("name") or d.get("name") or "")
    except Exception:
        logger.debug("suppressed exception")
    missing = [s.name for s in specs if s.name not in names]
    return {"success": not missing, "skills": [s.name for s in specs],
            "error": "" if not missing else f"注册后 schema 发现失败: {missing}"}
