# -*- coding: utf-8 -*-
"""★ W13: 成本路由技能

- model_route(task_type, prompt, budget=1.0) → RouteDecision
- 记录 data/cost/model_router_log.jsonl
- budget 越线返回降级/停止原因
- 禁止：静默换模型；改默认引擎模型
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import json
import os
import time

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_LOG = os.path.join(_ROOT, "data", "cost", "model_router_log.jsonl")


def _router():
    try:
        from shared import model_router as _mr
    except ImportError:
        import sys
        sys.path.insert(0, _ROOT)
        from shared import model_router as _mr
    return _mr


def _route(task_type="", prompt="", budget=1.0, **_kw):
    mr = _router()
    try:
        b = max(0.0, min(float(budget or 1.0), 100.0))
    except (TypeError, ValueError):
        b = 1.0
    tt = str(task_type or "").strip() or "general"
    p = str(prompt or "")

    # ★ 预算硬顶：越线直接拒绝
    if b <= 0:
        rec = {"ok": False, "reason": "budget_exhausted", "model": None,
               "tier": None, "task_type": tt, "budget": b}
        _log(rec)
        return json.dumps(rec, ensure_ascii=False)

    try:
        if hasattr(mr, "RouteDecision"):
            dec = mr.RouteDecision(task_type=tt, prompt=p, budget=b)
            model = getattr(dec, "model", None)
            tier = getattr(dec, "tier", None)
            reason = getattr(dec, "reason", "")
            ok = bool(model)
        else:
            # 回退：简单预算检查
            model = "default"
            tier = "standard"
            reason = "budget_ok"
            ok = True
    except Exception as e:
        rec = {"ok": False, "reason": f"route_error: {str(e)[:80]}",
               "model": None, "tier": None, "task_type": tt, "budget": b}
        _log(rec)
        return json.dumps(rec, ensure_ascii=False)

    rec = {"ok": ok, "model": model, "tier": tier, "reason": reason,
           "task_type": tt, "budget": b}
    _log(rec)
    return json.dumps(rec, ensure_ascii=False)


def _log(rec: dict):
    try:
        os.makedirs(os.path.dirname(_LOG), exist_ok=True)
        with open(_LOG, "a", encoding="utf-8") as f:
            f.write(json.dumps({"ts": time.strftime("%Y-%m-%d %H:%M:%S"), **rec},
                               ensure_ascii=False) + "\n")
    except Exception:
        logger.debug("suppressed exception")


def register(registry=None) -> dict:
    try:
        from standard_mode.core.skills_registry import SkillDef, get_skills_registry
    except ImportError:
        try:
            from core.skills_registry import SkillDef, get_skills_registry
        except ImportError:
            return {"success": False, "error": "skills_registry 不可用"}
    reg = registry or get_skills_registry()
    reg.register(SkillDef(
        name="model_route",
        description="模型路由（按任务类型与预算选模型，越线拒绝）",
        parameters={"type": "object", "properties": {
            "task_type": {"type": "string"},
            "prompt": {"type": "string"},
            "budget": {"type": "number"},
        }, "required": ["task_type"]},
        handler=_route, category="router", requires_confirm=False, timeout=15))
    names = set()
    try:
        for d in reg.get_tool_definitions():
            names.add((d.get("function") or {}).get("name") or d.get("name") or "")
    except Exception:
        logger.debug("suppressed exception")
    found = "model_route" in names
    return {"success": found, "found": ["model_route"] if found else [], "total": 1}


if __name__ == "__main__":
    print(register())
