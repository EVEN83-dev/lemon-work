# -*- coding: utf-8 -*-
"""
Skill: bank_balance_query
描述: 查询本机数字银行服务（默认 http://127.0.0.1:8090）的账户列表与余额，返回结构与 remote_bank_accounts 一致：先做 /api/health 健康探测，再读 /api/accounts。连接失败时如实返回失败原因与启动指引，绝不返回编造数据。
自动生成时间: 2026-11-11 00:06:00
A-14: 修复缩进断裂（原文件实现代码散落在模块层 + 顶层 return，无法导入）。
"""

import os
import sys
import traceback

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from skills_registry import SkillDef, SkillResult  # noqa: E402

_NO_PROXY = {"http": None, "https": None}   # 本地服务直连，绕过系统代理


def _handle_bank_balance_query(account_id: str = "") -> SkillResult:
    """查询本机数字银行服务的账户列表与余额。

    Args:
        account_id: 可选，指定账户号（如 ACC001）；留空则返回全部账户
    """
    try:
        import requests

        base = os.environ.get("REMOTE_BANK_URL", "http://127.0.0.1:8090").rstrip("/")

        def _get(path: str):
            return requests.get(base + path, timeout=10, proxies=_NO_PROXY,
                                headers={"Content-Type": "application/json"})

        try:
            health = _get("/api/health")
            health_ok = health.status_code < 400
        except requests.exceptions.ConnectionError:
            return SkillResult(success=False,
                               error=f"数字银行服务未连接（{base} 拒绝连接）。请先在数字银行目录启动服务：python server.py",
                               data=None)
        except requests.exceptions.Timeout:
            return SkillResult(success=False,
                               error=f"数字银行响应超时（>10s）：{base}/api/health",
                               data=None)
        except Exception as e:
            return SkillResult(success=False,
                               error=f"连接数字银行异常：{type(e).__name__}: {e}",
                               data=None)

        try:
            if account_id:
                resp = _get(f"/api/accounts/{account_id}")
            else:
                resp = _get("/api/accounts")
        except Exception as e:
            return SkillResult(success=False,
                               error=f"读取账户异常：{type(e).__name__}: {e}",
                               data=None)

        if resp.status_code >= 400:
            try:
                detail = resp.json().get("error", "")
            except Exception:
                detail = resp.text[:120]
            return SkillResult(success=False,
                               error=f"数字银行 HTTP {resp.status_code}: {detail}",
                               data=None)

        data = resp.json()
        ok = bool(data.get("success", True))
        items = data.get("items") or ([data] if data.get("account_id") else [])
        lines = [f"{a.get('owner')}（{a.get('account_id')}）余额 {a.get('balance_yuan')} 元"
                 for a in items]
        return SkillResult(success=ok,
                           output=("健康：" + ("OK" if health_ok else "异常") + "；"
                                   + ("；".join(lines) if lines else "无账户数据")),
                           data=data)
    except Exception as e:
        return SkillResult(success=False, error=f"执行失败: {e}",
                           output=traceback.format_exc())


BANK_BALANCE_QUERY_SKILL = SkillDef(
    name="bank_balance_query",
    description="查询本机数字银行服务（默认 http://127.0.0.1:8090）的账户列表与余额，返回结构与 remote_bank_accounts 一致：先做 /api/health 健康探测，再读 /api/accounts。连接失败时如实返回失败原因与启动指引，绝不返回编造数据。",
    parameters={
        "type": "object",
        "properties": {
            "account_id": {"type": "string", "description": "可选，指定账户号（如 ACC001）；留空则返回全部账户"}
        },
        "required": [],
    },
    handler=_handle_bank_balance_query,
    category="system",
    timeout=30,
)
