# -*- coding: utf-8 -*-
"""crawler_skills —— 超级爬虫技能包（P0：G3 银行巡检 + G1/G2 任务墙监控）

四个技能，走 SkillsRegistry 公开 API（不动冻结区）：
  bank_patrol_scan  —— G3 高任务量级群：对数字银行 :8090 只读 API 全量巡逻，
                       逐端点记录 status/latency/摘要，落 SQLite crawler.db
  gig_wall_scan     —— G1/G2 任务墙监控：代码编写单 / 生产建设单 批量扫描评分，
                       按价格-工期比与关键词 keep/cut（含理由），落库
  crawler_report    —— 读 crawler.db 生成结构化日报（keep/cut 统计 + 明细）
  crawler_dashboard —— 可视化看板：action=dashboard 只读合并 crawler.db +
                       browser_audit.db 推三段式看板卡；action=export 全表成册
                       导出 CSV + Markdown 摘要

白盒原则：所有结果带 score 与 reason，Agent 可回放"为什么留/为什么砍"。
礼貌原则：仅只读公开数据；外部源 1.5s/页 + UA 声明。
只读边界：看板/导出侧一律 mode=ro 连接，渲染路径不可能写库或触发新的抓取。
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import json
import os
import sys
import sqlite3
import threading
import time

try:
    from standard_mode.core.skills_registry import SkillDef, SkillResult, get_skills_registry
except ImportError:
    from core.skills_registry import SkillDef, SkillResult, get_skills_registry

# LemonWork/data/crawler.db（skills_builtin → shared → LemonWork 根，共上跳三级）
_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_DB = os.path.join(_ROOT, "data", "crawler.db")
_AUDIT_DB = os.path.join(_ROOT, "data", "browser_audit.db")
_UA = {"User-Agent": "LemonWork-Crawler/1.0 (+https://github.com/EVEN83-dev/lemon-work)"}

# 铁律 4：数据量防御 —— 单次查询硬上限，看板永不整表注入前端
_MAX_QUERY_ROWS = 500
_RECENT_ROWS = 50
_BLOCKED_ROWS = 20
_DOMAIN_ROWS = 10
# 铁律 2：本地数字银行沙箱是巡检的既定目标，不是 SSRF。gate() 默认拦回环，
# 这里只放行 REMOTE_BANK_URL 实际配置的那一个 host，外部目标一律走完整策略。
_TRUSTED_LOCAL_HOSTS = set()


def _db():
    os.makedirs(os.path.dirname(_DB), exist_ok=True)
    conn = sqlite3.connect(_DB)
    conn.execute("""CREATE TABLE IF NOT EXISTS crawl_log(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT, grp TEXT, target TEXT, status TEXT, latency_ms REAL,
        verdict TEXT, score REAL, reason TEXT, payload TEXT)""")
    return conn


def _log(conn, grp, target, status, latency, verdict, score, reason, payload=""):
    conn.execute("INSERT INTO crawl_log(ts,grp,target,status,latency_ms,verdict,score,reason,payload)"
                 " VALUES (?,?,?,?,?,?,?,?,?)",
                 (time.strftime("%Y-%m-%d %H:%M:%S"), grp, target, status, latency,
                  verdict, score, reason, json.dumps(payload, ensure_ascii=False)[:2000]))
    conn.commit()


# ---------------------------------------------------------------- G3 银行巡检
_PATROL = ["/api/health", "/api/menu", "/api/accounts", "/api/transactions", "/api/audit",
           "/api/risk-events", "/api/products", "/api/subscriptions", "/api/bank-events",
           "/api/quote", "/api/deposits", "/api/social", "/api/corp-accounts",
           "/api/transfers/scheduled", "/api/bill/summary", "/api/bill/anomalies",
           "/api/cards", "/api/mall/items", "/api/birthdays", "/api/service-orders"]


def _local_sandbox_hosts():
    """可信本地沙箱 host 集合 = 显式登记 + 当前 REMOTE_BANK_URL 的实际 host。

    bank_patrol_scan 的既定目标就是本机数字银行 :8090，而 browser_policy.check_url
    把回环地址一律判为 internal_network_blocked（防 SSRF）。不例外则巡检 0 命中，
    例外只精确到"当前配置的那一个 host"，外部目标照旧走完整策略。
    """
    from urllib.parse import urlparse
    hosts = set(_TRUSTED_LOCAL_HOSTS)
    try:
        h = (urlparse(os.environ.get("REMOTE_BANK_URL", "http://127.0.0.1:8090")).hostname or "").lower()
        if h:
            hosts.add(h)
    except Exception:
        logger.debug("suppressed exception")
    return hosts


def _policy_gate(url, action="open"):
    """前置合规闸门。返回 {ok, reason, domain, throttle_ms, risk}。

    本地沙箱分支必须自己调 throttle + audit：若先 gate() 再翻案，gate 内部已经
    写下一条 verdict=fail 的 blocked 审计行，看板"被拦截数"会被巡检自己污染。
    """
    from urllib.parse import urlparse
    try:
        try:
            from shared.browser_policy import audit, classify_action, gate, throttle
        except ImportError:
            from browser_policy import audit, classify_action, gate, throttle
    except ImportError:
        return {"ok": True, "reason": "policy_unavailable", "domain": "",
                "throttle_ms": 0, "risk": "read"}
    try:
        host = (urlparse(url).hostname or "").lower()
    except Exception:
        host = ""
    if host and host in _local_sandbox_hosts():
        wait = throttle(host)
        audit(action, url, "allowed: local_sandbox", verdict="ok",
              risk=classify_action(action), throttle_ms=wait)
        return {"ok": True, "reason": "local_sandbox_trusted", "domain": host,
                "throttle_ms": wait, "risk": classify_action(action)}
    try:
        return gate(url, action)
    except Exception as e:
        return {"ok": False, "reason": f"gate_error:{str(e)[:80]}", "domain": host,
                "throttle_ms": 0, "risk": "read"}


def _bank_patrol_scan(**kw):
    """对数字银行只读 API 全量巡逻。Params: limit(int, 默认 20)"""
    import requests
    limit = int(kw.get("limit", 20) or 20)
    base = os.environ.get("REMOTE_BANK_URL", "http://127.0.0.1:8090")
    results, fails, skipped = [], [], []
    conn = _db()
    for ep in _PATROL[:max(1, min(limit, len(_PATROL)))]:
        g = _policy_gate(base + ep, "open")
        if not g.get("ok"):
            reason = f"policy:{g.get('reason', 'blocked')}"
            skipped.append({"endpoint": ep, "reason": g.get("reason", "blocked")})
            _log(conn, "G3_bank_patrol", ep, "BLOCKED", 0.0, "cut", 0.0, reason)
            continue
        t0 = time.time()
        try:
            r = requests.get(base + ep, headers=_UA, timeout=6)
            dt = round((time.time() - t0) * 1000, 1)
            body = r.json() if "json" in r.headers.get("Content-Type", "") else {}
            size = len(json.dumps(body, ensure_ascii=False))
            results.append({"endpoint": ep, "status": r.status_code, "latency_ms": dt,
                            "keys": list(body)[:6] if isinstance(body, dict) else f"list[{size}]"})
            _log(conn, "G3_bank_patrol", ep, str(r.status_code), dt,
                 "keep" if r.status_code == 200 else "cut", 1.0 if r.status_code == 200 else 0.0,
                 "200 OK" if r.status_code == 200 else f"HTTP {r.status_code}")
            time.sleep(0.15)
        except Exception as e:
            dt = round((time.time() - t0) * 1000, 1)
            fails.append({"endpoint": ep, "error": str(e)[:120]})
            _log(conn, "G3_bank_patrol", ep, "ERR", dt, "cut", 0.0, str(e)[:120])
    conn.close()
    ok = len(results)
    if ok == 0:
        if skipped:
            return SkillResult(
                success=False,
                error=f"全部端点被合规策略拦截（{len(skipped)} 个）："
                      f"{', '.join(sorted({s['reason'] for s in skipped}))}")
        return SkillResult(success=False, error=f"银行沙箱不可达（{base}）；请先启动 Lemon Work 或数字银行服务")
    return SkillResult(
        success=True,
        output=(f"银行巡检完成：{ok} 端点正常，{len(fails)} 失败"
                + (f"，本轮被合规策略拦截 {len(skipped)} 个端点" if skipped else "") + "。"
                f"正常端点：{', '.join(x['endpoint'] for x in results[:8])}"
                + (f" …等 {ok} 个" if ok > 8 else "")
                + (f"；失败：{', '.join(x['endpoint'] for x in fails)}" if fails else "")
                + (f"；拦截：{', '.join(x['endpoint'] for x in skipped[:6])}" if skipped else "")),
        data={"ok": ok, "fail": len(fails), "skipped": skipped,
              "skipped_count": len(skipped), "results": results, "fails": fails})



# ------------------------------------------------------- G1/G2 任务墙监控
_SEED = [
    # 代码编写群
    {"title": "Flutter 外包 App 开发", "price": 940, "hours": 60, "grp": "代码编写", "tags": "flutter dart 移动端"},
    {"title": "React 金融看板开发", "price": 720, "hours": 25, "grp": "代码编写", "tags": "react 前端 dashboard"},
    {"title": "Django 支付系统搭建", "price": 642, "hours": 13, "grp": "代码编写", "tags": "django python 后端 支付"},
    {"title": "Chrome 提效插件开发", "price": 760, "hours": 14, "grp": "代码编写", "tags": "chrome extension js"},
    {"title": "数据采集脚本（合规公开源）", "price": 210, "hours": 7, "grp": "代码编写", "tags": "python 爬虫 scraping"},
    {"title": "量化回测脚本调优", "price": 512, "hours": 9, "grp": "代码编写", "tags": "quant python 回测"},
    {"title": "HTML/CSS 页面修复", "price": 76, "hours": 6, "grp": "代码编写", "tags": "html css 前端"},
    {"title": "Kotlin 小工具维护", "price": 430, "hours": 30, "grp": "代码编写", "tags": "kotlin android"},
    {"title": "Logo 设计（低价走量单）", "price": 36, "hours": 24, "grp": "代码编写", "tags": "logo 设计"},
    # 生产建设群
    {"title": "Shopify 店铺生产部署", "price": 128, "hours": 4, "grp": "生产建设", "tags": "shopify 电商 上架"},
    {"title": "n8n 自动化流水线建设", "price": 642, "hours": 13, "grp": "生产建设", "tags": "n8n 自动化 workflow"},
    {"title": "定制官网建设", "price": 1490, "hours": 50, "grp": "生产建设", "tags": "website 建站 定制"},
    {"title": "落地页快速搭建", "price": 148, "hours": 4, "grp": "生产建设", "tags": "landing page 落地页"},
    {"title": "TikTok 电商店铺配置", "price": 160, "hours": 6, "grp": "生产建设", "tags": "tiktok 电商"},
    {"title": "Airtable 业务系统搭建", "price": 309, "hours": 4, "grp": "生产建设", "tags": "airtable 系统"},
    {"title": "Notion 团队模板配置", "price": 110, "hours": 3, "grp": "生产建设", "tags": "notion 模板"},
    {"title": "翻译走量单（低值）", "price": 92, "hours": 3, "grp": "生产建设", "tags": "翻译 translation"},
]


def _gig_wall_scan(**kw):
    """任务墙批量扫描评分。Params: keywords(str, 空格分隔), min_price(int, 默认 500)

    合规闸门说明：本技能是纯 _SEED 离线评分，全程不产生任何出网 URL，因此
    _policy_gate 没有可挂载的目标；skipped 恒为 0 并如实上报，不做假接线。
    接真实任务墙源（外部 URL）时，须在循环首行加 _policy_gate(item["url"], "open")。
    """
    keywords = [k for k in str(kw.get("keywords", "代码编写 生产建设") or "").split() if k]
    min_price = float(kw.get("min_price", 500) or 500)
    keep, cut = [], []
    conn = _db()
    for g in _SEED:
        text = g["title"] + " " + g["tags"] + " " + g["grp"]
        kw_hit = sum(1 for k in keywords if k in text)
        rate = g["price"] / max(1, g["hours"])  # 时薪
        score = round(rate / 100 + kw_hit * 0.8, 2)
        if g["price"] >= min_price and kw_hit > 0:
            verdict, reason = "keep", (f"时薪 ${rate:.0f}/h ≥ 门槛且命中关键词 {kw_hit} 个"
                                       f"（{', '.join(k for k in keywords if k in text)}）")
            keep.append({**g, "rate": round(rate), "score": score, "reason": reason})
        else:
            verdict = "cut"
            reason = (f"单价 ${g['price']} < 门槛 ${min_price:.0f}" if g["price"] < min_price
                      else f"未命中关键词（{g['grp']}）")
            cut.append({**g, "rate": round(rate), "score": score, "reason": reason})
        _log(conn, "G1G2_gig_wall", g["title"], "seed", 0.0, verdict, score, reason,
             {"grp": g["grp"], "price": g["price"], "hours": g["hours"]})
    conn.close()
    keep.sort(key=lambda x: -x["score"])
    return SkillResult(
        success=True,
        output=(f"任务墙扫描完成：{len(keep)} 条 KEEP / {len(cut)} 条 CUT。\n"
                + "\n".join(f"· [{x['grp']}] {x['title']} ${x['price']}/{x['hours']}h"
                            f"（时薪 ${x['rate']}/h，score {x['score']}）—— {x['reason']}"
                            for x in keep[:6])
                + (f"\n（其余 {max(0, len(keep) - 6)} 条 keep 已入库 crawler.db）" if len(keep) > 6 else "")),
        data={"keep": keep, "cut": cut, "keywords": keywords, "min_price": min_price,
              "skipped": [], "skipped_count": 0})


# ------------------------------------------------------------------ 日报
def _crawler_report(**kw):
    conn = _db()
    rows = conn.execute("SELECT grp, verdict, COUNT(*) n, ROUND(AVG(score),2) avg_score "
                        "FROM crawl_log GROUP BY grp, verdict ORDER BY grp").fetchall()
    recent = conn.execute("SELECT ts,grp,target,verdict,score,reason FROM crawl_log "
                          "ORDER BY id DESC LIMIT 10").fetchall()
    total = conn.execute("SELECT COUNT(*) FROM crawl_log").fetchone()[0]
    blocked = conn.execute("SELECT COUNT(*) FROM crawl_log WHERE status = 'BLOCKED'").fetchone()[0]
    conn.close()
    if total == 0:
        return SkillResult(success=False, error="crawler.db 为空：请先执行 bank_patrol_scan 或 gig_wall_scan")
    stat = {}
    for grp, verdict, n, avg in rows:
        stat.setdefault(grp, {})[verdict] = f"{n} 条（均分 {avg}）"
    lines = [f"## 爬虫日报（累计 {total} 条记录）", ""]
    for grp, d in stat.items():
        lines.append(f"### {grp}")
        for v, s in d.items():
            lines.append(f"- {v}: {s}")
    lines.append(f"- 本轮被合规策略拦截 {blocked} 个端点" if blocked
                 else "- 本轮无端点被合规策略拦截")
    lines += ["", "### 最近 10 条", ""]
    lines += [f"- [{r[1]}] {r[2]} → **{r[3]}** (score {r[4]}) {r[5]}" for r in recent]
    return SkillResult(success=True, output="\n".join(lines),
                       data={"total": total, "policy_blocked": blocked,
                             "stat": {k: v for k, v in stat.items()}})


# ══════════════════════════════════════════════════════════════ 看板数据层
# 铁律 2：以下所有连接都以 mode=ro 打开 —— 渲染路径在物理上不可能写库或触发抓取。
def _ro_conn(path):
    """只读连接；库缺失/驱动不支持 URI 时返回 None，由调用方降级。"""
    if not path or not os.path.exists(path):
        return None
    try:
        from pathlib import Path
        return sqlite3.connect(Path(path).as_uri() + "?mode=ro", uri=True, timeout=5)
    except Exception:
        return None


def _table_exists(conn, table):
    if conn is None:
        return False
    try:
        return conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
                            (table,)).fetchone() is not None
    except Exception:
        return False


def _count(conn, table, where="", args=()):
    if not _table_exists(conn, table):
        return None
    try:
        return conn.execute(f'SELECT COUNT(*) FROM "{table}" {where}', tuple(args)).fetchone()[0]
    except Exception:
        return None


def _rows(conn, sql, args=()):
    """sql 必须以 'LIMIT ?' 收尾，元组末位即行数上限（铁律 4 的落点）。"""
    if conn is None:
        return None
    try:
        cur = conn.execute(sql, tuple(args))
        cols = [d[0] for d in cur.description]
        return [dict(zip(cols, r)) for r in cur.fetchall()]
    except Exception:
        return None


def _state_of(row):
    """三态归一：blocked（⊘）> fail（✗）> ok（✓）"""
    detail = str(row.get("detail") or "")
    if detail.startswith("blocked:") or detail.startswith("robots blocked:"):
        return "blocked"
    verdict = str(row.get("verdict") or "").lower()
    if verdict in ("ok", "keep") or str(row.get("status")) == "200":
        return "ok"
    if verdict in ("fail", "cut") or str(row.get("status")) in ("ERR", ""):
        return "fail"
    return "ok" if verdict else "fail"


def _blocked_reason(detail):
    d = str(detail or "")
    for pre in ("robots blocked:", "blocked:"):
        if d.startswith(pre):
            return d[len(pre):].strip() or "unspecified"
    return d.strip() or "unspecified"


def _dashboard(**kw):
    """爬虫看板数据：overview / by_domain / recent / blocked 四块 + 推卡。

    Params: recent(int, 明细行数，默认 50，硬顶 500), emit(bool, 默认 True)
    只读：不写库、不发网络请求；缺表缺列一律降级并在 notes 里说明。
    """
    try:
        recent_n = max(1, min(int(kw.get("recent", _RECENT_ROWS) or _RECENT_ROWS), _MAX_QUERY_ROWS))
    except (TypeError, ValueError):
        recent_n = _RECENT_ROWS
    notes, today = [], time.strftime("%Y-%m-%d")

    conn_c, conn_a = _ro_conn(_DB), _ro_conn(_AUDIT_DB)
    if conn_c is None:
        notes.append("crawler.db 不可读，巡检/任务墙侧数据缺失")
    if conn_a is None:
        notes.append("browser_audit.db 不可读，浏览器动作/拦截侧数据缺失")

    # ── overview ──
    crawl_total = _count(conn_c, "crawl_log") or 0
    audit_total = _count(conn_a, "browser_audit") or 0
    if not _table_exists(conn_c, "crawl_log") and not _table_exists(conn_a, "browser_audit"):
        return SkillResult(success=False,
                           error="crawler.db 与 browser_audit.db 均无可用数据表，看板无法渲染")
    crawl_today = _count(conn_c, "crawl_log", "WHERE ts >= ?", (today,)) or 0
    audit_today = _count(conn_a, "browser_audit", "WHERE ts >= ?", (today,)) or 0
    ok_n = _count(conn_a, "browser_audit", "WHERE verdict = 'ok'") or 0
    fail_n = _count(conn_a, "browser_audit", "WHERE verdict = 'fail'") or 0
    denom = ok_n + fail_n
    if denom:
        ok_rate = round(100.0 * ok_n / denom, 1)
    else:
        keep_n = _count(conn_c, "crawl_log", "WHERE verdict = 'keep'") or 0
        all_n = crawl_total
        ok_rate = round(100.0 * keep_n / all_n, 1) if all_n else 0.0
    blocked_n = _count(conn_a, "browser_audit",
                       "WHERE verdict = 'fail' AND (detail LIKE 'blocked:%' "
                       "OR detail LIKE 'robots blocked:%')") or 0
    if blocked_n == 0 and _table_exists(conn_a, "browser_audit"):
        blocked_n = fail_n  # 老库 detail 无 blocked 前缀时，fail 即拦截
    domain_rows = _rows(conn_a, "SELECT COUNT(DISTINCT domain) AS n FROM browser_audit "
                                "WHERE domain IS NOT NULL AND domain <> '' LIMIT ?",
                        (_MAX_QUERY_ROWS,))
    domain_n = (domain_rows[0]["n"] if domain_rows else 0) or 0
    overview = {
        "total": crawl_total + audit_total,
        "today": crawl_today + audit_today,
        "ok_rate": ok_rate,
        "blocked": blocked_n,
        "domains": domain_n,
    }

    # ── by_domain Top10 ──
    by_domain = _rows(conn_a, "SELECT domain, COUNT(*) AS count, "
                              "ROUND(100.0 * SUM(CASE WHEN verdict = 'ok' THEN 1 ELSE 0 END) "
                              "/ COUNT(*), 1) AS ok_rate FROM browser_audit "
                              "WHERE domain IS NOT NULL AND domain <> '' "
                              "GROUP BY domain ORDER BY count DESC LIMIT ?",
                      (_DOMAIN_ROWS,))
    if by_domain is None:
        by_domain = []
        notes.append("域名分布不可用（browser_audit 缺表或缺列）")

    # ── recent：两库合并视图，字段取到哪个算哪个 ──
    merged = []
    a_rows = _rows(conn_a, "SELECT ts, action, url, domain, verdict, risk, throttle_ms, detail "
                           "FROM browser_audit ORDER BY id DESC LIMIT ?", (recent_n,))
    if a_rows is None:
        notes.append("browser_audit 明细不可用")
    else:
        for r in a_rows:
            r = dict(r)
            r["source"] = "browser_audit"
            r["state"] = _state_of(r)
            detail = r.get("detail") or ""
            r["reason"] = _blocked_reason(detail) if r["state"] == "blocked" else detail
            r["target"] = r.get("url") or ""
            merged.append(r)
    c_rows = _rows(conn_c, "SELECT ts, grp AS action, target, status, verdict, score, reason "
                           "FROM crawl_log ORDER BY id DESC LIMIT ?", (recent_n,))
    if c_rows is None:
        notes.append("crawl_log 明细不可用")
    else:
        for r in c_rows:
            r = dict(r)
            r.update(source="crawler", url=r.get("target") or "", domain="",
                     risk="", throttle_ms=0, detail="")
            r["state"] = _state_of(r)
            merged.append(r)
    merged.sort(key=lambda x: str(x.get("ts") or ""), reverse=True)
    recent = merged[:recent_n]

    # ── blocked 明细 Top20（reason 分类计数 + 样例 URL）──
    blocked = []
    b_rows = _rows(conn_a, "SELECT ts, action, url, domain, detail FROM browser_audit "
                           "WHERE verdict = 'fail' ORDER BY id DESC LIMIT ?", (_MAX_QUERY_ROWS,))
    if b_rows is None:
        notes.append("拦截明细不可用")
    else:
        buckets = {}
        for r in b_rows:
            reason = _blocked_reason(r.get("detail"))
            b = buckets.setdefault(reason, {"reason": reason, "count": 0, "sample_url": "",
                                            "sample_domain": "", "last_ts": ""})
            b["count"] += 1
            if not b["sample_url"]:
                b["sample_url"] = r.get("url") or ""
                b["sample_domain"] = r.get("domain") or ""
            b["last_ts"] = max(b["last_ts"], str(r.get("ts") or ""))
        blocked = sorted(buckets.values(), key=lambda x: -x["count"])[:_BLOCKED_ROWS]
        if len(b_rows) >= _MAX_QUERY_ROWS:
            notes.append(f"拦截分类基于最近 {_MAX_QUERY_ROWS} 条失败样本，非全量")

    payload = {
        "overview": overview,
        "by_domain": by_domain or [],
        "recent": recent,
        "blocked": blocked,
        "fetched_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "notes": notes,
    }
    if kw.get("emit", True):
        payload["card_emit"] = _emit_dashboard_card(payload)
    lines = [f"总抓取 {overview['total']} 条（今日 {overview['today']}），成功率 "
             f"{overview['ok_rate']}%，被拦截 {overview['blocked']}，涉及域名 {overview['domains']}。"]
    if by_domain:
        lines.append("域名 Top" + str(len(by_domain)) + "：" + "、".join(
            f"{d['domain']} {d['count']}（{d['ok_rate']}%）" for d in by_domain[:5]))
    if blocked:
        lines.append("拦截分布：" + "、".join(f"{b['reason']}×{b['count']}" for b in blocked[:5]))
    if notes:
        lines.append("降级说明：" + "；".join(notes))
    return SkillResult(success=True, output="\n".join(lines), data=payload)


def _crawler_dashboard(**kw):
    """技能入口：action=dashboard 渲染看板卡（只读），action=export 成册导出"""
    action = str(kw.get("action") or "dashboard").strip().lower()
    if action == "export":
        return _export(**kw)
    return _dashboard(**kw)


def _emit_dashboard_card(payload):
    """把看板数据推成 crawler_dashboard_card（前端 renderCrawlerDashboard 消费）"""
    try:
        from shared.action_cards import get_action_card_registry
    except ImportError:
        try:
            from action_cards import get_action_card_registry
        except ImportError:
            return {"success": False, "error": "action_cards 通道不可用"}
    card = {
        "type": "crawler_dashboard_card",
        "card_id": f"cdb_{int(time.time() * 1000)}",
        "title": "🕷 爬虫作战板",
        "fetched_at": payload["fetched_at"],
        "overview": payload["overview"],
        "by_domain": payload["by_domain"][:_DOMAIN_ROWS],
        "recent": payload["recent"][:_RECENT_ROWS],
        "blocked": payload["blocked"][:_BLOCKED_ROWS],
        "notes": payload["notes"],
        "page_rows": 15,
        "tools": [{"action": "crawler.dashboard_export", "label": "导出 CSV"},
                  {"action": "crawler.dashboard_refresh", "label": "刷新"}],
    }
    return get_action_card_registry().emit_card(card)


def _export(**kw):
    """crawler.db + browser_audit.db 全表 → CSV + Markdown 摘要，返回两个文件路径。

    Params: out_dir(str, 默认 data/reports), max_rows(int, 默认 200000 防御)
    非渲染路径：分块 fetchmany 流式写盘，内存与表规模解耦；CSV 用 utf-8-sig 供 Excel 直开。
    """
    out_dir = kw.get("out_dir") or os.path.join(_ROOT, "data", "reports")
    try:
        max_rows = max(1, min(int(kw.get("max_rows", 200000) or 200000), 1000000))
    except (TypeError, ValueError):
        max_rows = 200000
    chunk_size = 100000  # 铁律：CSV 行数 >10 万必须分文件
    os.makedirs(out_dir, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    header = ["source", "ts", "action", "target", "domain", "status", "verdict",
              "state", "risk", "throttle_ms", "score", "reason"]
    sources = {"crawl_log": 0, "browser_audit": 0}
    base = os.path.join(out_dir, f"crawler_export_{stamp}.csv")
    paths, part_no, buf, written_total = [], 1, [], 0

    def _flush():
        """把当前缓冲写成一个分文件；内存只驻留一个 chunk"""
        nonlocal buf, written_total, part_no
        if not buf:
            return
        p = os.path.join(out_dir, f"crawler_export_{stamp}_part{part_no}.csv")
        with open(p, "w", encoding="utf-8-sig", newline="") as fh:
            fh.write(",".join(header) + "\n")
            fh.write("".join(buf))
        paths.append(p)
        written_total += len(buf)
        buf = []
        part_no += 1

    conn_c, conn_a = _ro_conn(_DB), _ro_conn(_AUDIT_DB)
    if conn_c is None and conn_a is None:
        return SkillResult(success=False, error="两个数据库均不可读，导出中止")
    import csv as _csv
    import io as _io
    try:
        for conn, table, mapper in ((conn_c, "crawl_log", _map_crawl),
                                    (conn_a, "browser_audit", _map_audit)):
            if not _table_exists(conn, table):
                continue
            cur = conn.execute(f'SELECT * FROM "{table}" ORDER BY id')
            cols = [d[0] for d in cur.description]
            while True:
                batch = cur.fetchmany(2000)
                if not batch:
                    break
                for raw in batch:
                    if sources[table] >= max_rows:
                        break
                    row = mapper(dict(zip(cols, raw)))
                    sink = _io.StringIO()
                    _csv.writer(sink, lineterminator="\n").writerow(row)
                    buf.append(sink.getvalue())
                    sources[table] += 1
                if len(buf) >= chunk_size:
                    _flush()
                if sources[table] >= max_rows:
                    break
    finally:
        for c in (conn_c, conn_a):
            try:
                if c:
                    c.close()
            except Exception:
                logger.debug("suppressed exception")
    _flush()
    if not paths:
        return SkillResult(success=False, error="两库皆无数据行，未生成导出文件")
    if len(paths) == 1:
        try:
            os.replace(paths[0], base)   # 单文件场景回到无 _part 后缀的正名
            paths = [base]
        except OSError:
            logger.debug("suppressed exception")

    dash = _dashboard(recent=_RECENT_ROWS, emit=False)
    md_path = os.path.join(out_dir, f"crawler_export_{stamp}.md")
    with open(md_path, "w", encoding="utf-8") as fh:
        fh.write(_summary_md(dash.data, sources))
    return SkillResult(
        success=True,
        output=(f"已导出 {written_total} 行 → {len(paths)} 个 CSV"
                + ("（分文件）" if len(paths) > 1 else "") + f"\n摘要：{md_path}\n"
                + (dash.output or "")),
        data={"csv_paths": paths, "markdown_path": md_path, "csv_rows": written_total,
              "sources": sources, "chunks": len(paths)})


def _map_crawl(r):
    return ["crawler", r.get("ts", ""), r.get("grp", ""), r.get("target", ""), "",
            r.get("status", ""), r.get("verdict", ""), _state_of(r), "", 0,
            r.get("score", ""), r.get("reason", "")]


def _map_audit(r):
    detail = r.get("detail") or ""
    return ["browser_audit", r.get("ts", ""), r.get("action", ""), r.get("url", ""),
            r.get("domain", ""), "", r.get("verdict", ""), _state_of(r),
            r.get("risk", ""), r.get("throttle_ms", 0), "",
            _blocked_reason(detail) if _state_of(r) == "blocked" else detail]


def _summary_md(payload, sources):
    o = (payload or {}).get("overview", {})
    L = ["# 爬虫数据册", "",
         f"- 导出时间：{time.strftime('%Y-%m-%d %H:%M:%S')}",
         f"- 数据截至：{(payload or {}).get('fetched_at', '—')}",
         f"- 行数：crawler.db crawl_log {sources.get('crawl_log', 0)} 行 + "
         f"browser_audit.db {sources.get('browser_audit', 0)} 行", "",
         "## 总览", "",
         f"- 总抓取数：{o.get('total', 0)}",
         f"- 今日：{o.get('today', 0)}",
         f"- 成功率：{o.get('ok_rate', 0)}%",
         f"- 被拦截数：{o.get('blocked', 0)}",
         f"- 涉及域名数：{o.get('domains', 0)}", "",
         "## 域名 Top10", "", "| 域名 | 次数 | 成功率 |", "| --- | --- | --- |"]
    L += [f"| {d.get('domain')} | {d.get('count')} | {d.get('ok_rate')}% |"
          for d in (payload or {}).get("by_domain", [])]
    L += ["", "## 拦截分布", "", "| 原因 | 次数 | 样例 URL |", "| --- | --- | --- |"]
    L += [f"| {b.get('reason')} | {b.get('count')} | {b.get('sample_url') or '—'} |"
          for b in (payload or {}).get("blocked", [])] or ["| （无拦截记录） | 0 | — |"]
    if (payload or {}).get("notes"):
        L += ["", "> 降级说明：" + "；".join(payload["notes"])]
    return "\n".join(L) + "\n"


def _card_action(handler):
    """SkillResult → ActionCardRegistry.dispatch 约定的 dict（看板卡工具钮白名单入口）"""
    def _wrap(params: dict) -> dict:
        sr = handler(**(params or {}))
        out = {"success": bool(sr.success)}
        if sr.success:
            out["message"] = sr.output
            if isinstance(sr.data, dict):
                out["result_data"] = sr.data
        else:
            out["error"] = sr.error
        return out
    return _wrap


def register_crawler_skills() -> dict:
    """注册超级爬虫技能族；返回可发现性自检结果"""
    skills = get_skills_registry()
    specs = [
        SkillDef(
            name="bank_patrol_scan",
            description=("对数字银行沙箱全部只读 API 做批量巡检（健康/账户/账单/风控/产品/商城等 20 端点），"
                         "逐端点记录状态与延迟并入库，返回巡检摘要。用户说'巡检/体检/巡逻银行'时调用。"),
            parameters={"type": "object", "properties": {
                "limit": {"type": "integer", "description": "巡检端点数上限，默认 20"}},
                "required": []},
            handler=_bank_patrol_scan, category="crawler", timeout=60,
            argcheck_example={"limit": 20}),
        SkillDef(
            name="gig_wall_scan",
            description=("批量扫描任务墙（代码编写单/生产建设单），按单价-工期比与关键词计算 score，"
                         "高于门槛且命中关键词的 keep 并给出理由，其余 cut。用户说'盯单/监控任务/扫描外包'时调用。"),
            parameters={"type": "object", "properties": {
                "keywords": {"type": "string", "description": "空格分隔的关键词，如：代码编写 生产建设 flutter"},
                "min_price": {"type": "integer", "description": "KEEP 单价门槛（美元），默认 500"}},
                "required": []},
            handler=_gig_wall_scan, category="crawler", timeout=30,
            argcheck_example={"keywords": "代码编写 生产建设", "min_price": 500}),
        SkillDef(
            name="crawler_report",
            description=("读取爬虫库 crawler.db，生成结构化日报：各任务群 keep/cut 统计与最近 10 条明细。"
                         "用户说'爬虫日报/巡检报告/盯单汇总'时调用。"),
            parameters={"type": "object", "properties": {
                "scope": {"type": "string", "description": "范围：all 或任务群名，默认 all"}},
                "required": []},
            handler=_crawler_report, category="crawler", timeout=15,
            argcheck_example={"scope": "all"}),
        SkillDef(
            name="crawler_dashboard",
            description=("爬虫可视化看板。action=dashboard：只读合并 crawler.db + browser_audit.db，"
                         "在对话中渲染三段式看板卡（统计条 / 明细表 / 域名分布 + 拦截明细），"
                         "用户说'打开爬虫看板/看看抓取情况/爬虫面板'时调用；本动作不发起任何抓取。"
                         "action=export：全表成册导出 CSV + Markdown 摘要并返回文件路径，"
                         "用户说'导出爬虫数据/抓取记录成册'时调用。"),
            parameters={"type": "object", "properties": {
                "action": {"type": "string", "enum": ["dashboard", "export"],
                           "description": "dashboard=渲染看板卡（默认）；export=导出 CSV+Markdown 成册"},
                "recent": {"type": "integer", "description": "看板明细行数，默认 50，硬上限 500"},
                "out_dir": {"type": "string", "description": "导出目录，默认 data/reports"}},
                "required": []},
            handler=_crawler_dashboard, category="crawler", timeout=20,
            argcheck_example={"action": "dashboard"}),
    ]
    for d in specs:
        skills.register(d)

    # 看板卡工具钮走 ActionCard 白名单通道（未注册的动作前端点了必被拒）
    actions = []
    try:
        try:
            from shared.action_cards import get_action_card_registry
        except ImportError:
            from action_cards import get_action_card_registry
        reg_ac = get_action_card_registry()
        for aid, h, desc in (
                ("crawler.dashboard_export", _export, "导出爬虫数据 CSV + Markdown"),
                ("crawler.dashboard_refresh", lambda **kw: _dashboard(**kw), "重新读取看板数据")):
            reg_ac.register_action(aid, _card_action(h), confirm=False, description=desc)
            actions.append(aid)
    except Exception as e:
        print(f"[crawler_skills] 看板卡动作注册降级（不影响技能发现）: {e}")

    names = set()
    try:
        for d in skills.get_tool_definitions():
            names.add((d.get("function") or {}).get("name") or d.get("name") or "")
    except Exception:
        logger.debug("suppressed exception")
    missing = [s.name for s in specs if s.name not in names]
    return {"success": not missing, "skills": [s.name for s in specs],
            "card_actions": actions,
            "error": "" if not missing else f"注册后 schema 发现失败: {missing}"}



# ══════════════════════════════════════════════════════════════════
# ★ A9: Crawl Engine 8 技能（写新库 data/crawl.db，旧 crawler.db 不动）
# ══════════════════════════════════════════════════════════════════

_CRAWL_DB = os.path.join(_ROOT, "data", "crawl.db")


def _crawl_imports():
    """惰性导入，避免模块级循环"""
    try:
        from shared.crawler import store, session, urls, export as _exp, events
        from shared.crawler.fetch import fetch_url
        from shared.crawler.engine import CrawlEngine
    except ImportError:
        import sys
        sys.path.insert(0, _ROOT)
        from shared.crawler import store, session, urls, export as _exp, events
        from shared.crawler.fetch import fetch_url
        from shared.crawler.engine import CrawlEngine
    return store, session, urls, _exp, events, fetch_url, CrawlEngine


def _crawl_start(**kw):
    """启动爬取会话"""
    store, session, urls, _exp, events, fetch_url, CrawlEngine = _crawl_imports()
    seeds = kw.get("seeds") or []
    if isinstance(seeds, str):
        seeds = [seeds]
    seeds = [s for s in seeds if urls.is_crawlable(s)]
    if not seeds:
        return SkillResult(success=False, error="参数 seeds 至少需要一个 http(s) URL")
    max_pages = max(1, min(int(kw.get("max_pages", 30) or 30), 500))
    max_depth = max(0, min(int(kw.get("max_depth", 1) or 1), 3))
    cfg = {
        "max_pages": max_pages, "max_depth": max_depth,
        "same_domain": bool(kw.get("same_domain", True)),
        "same_subdomain": bool(kw.get("same_subdomain", False)),
        "include": str(kw.get("include", "") or ""),
        "exclude": str(kw.get("exclude", "") or ""),
        "refresh": bool(kw.get("refresh", False)),
        "use_js": bool(kw.get("use_js", True)),
        "delay_ms": max(0, int(kw.get("delay_ms", 1500) or 1500)),
    }
    name = str(kw.get("name") or ("crawl_" + seeds[0][:40]))
    sid = session.create_session(name, seeds[0], cfg, db_path=_CRAWL_DB)

    from urllib.parse import urlparse as _urlparse
    seed_hosts = {(_urlparse(s).hostname or "").lower() for s in seeds}

    def _fetch(url, depth):
        # ★ W25-H: 先判域再发请求；多 seed 时允许任一 seed host
        if cfg["same_domain"]:
            host = (_urlparse(url).hostname or "").lower()
            if not any(urls.same_domain(url, h,
                                        subdomain=cfg.get("same_subdomain", False))
                       for h in seed_hosts):
                return {"status": "filtered", "error": "cross_domain",
                        "no_save": True, "domain": host}
        r = fetch_url(url, depth=depth, use_js=cfg["use_js"], timeout=15,
                      db_path=_CRAWL_DB)
        if cfg["exclude"] and cfg["exclude"] in url:
            return {**r, "status": "skipped", "error": "excluded"}
        return r

    def _cb(ev_type, payload):
        try:
            events.emit(ev_type, {"session_id": sid, **payload})
        except Exception:
            logger.debug("suppressed exception")

    # ★ crawl_audit P1-3: 域限速执行 —— cfg.delay_ms 透传引擎（0 时不限速）
    engine = CrawlEngine(sid, _fetch, workers=2, db_path=_CRAWL_DB, event_cb=_cb,
                         delay_ms=cfg.get("delay_ms", 0))
    import threading as _th
    def _run():
        try:
            engine.run(max_pages=max_pages, max_depth=max_depth, seed_urls=seeds)
        except Exception as e:
            print(f"[crawl_start] 引擎异常: {e}")

    t = _th.Thread(target=_run, daemon=True)
    t.start()
    return SkillResult(
        success=True,
        output=f"爬取会话已启动：{sid}（种子 {len(seeds)} 个，上限 {max_pages} 页 / 深度 {max_depth}）",
        data={"session_id": sid, "seeds": seeds, "config": cfg, "running": True})


def _crawl_pause(session_id="", **kw):
    store, session, urls, _exp, events, fetch_url, CrawlEngine = _crawl_imports()
    sid = str(kw.get("session_id") or session_id or "").strip()
    if not sid:
        return SkillResult(success=False, error="缺少 session_id")
    # A-07: 经引擎控制面（活动引擎线程级暂停；遗留会话仅落库迁移）
    from shared.crawler.engine import pause_session
    r = pause_session(sid, db_path=str(kw.get("db_path") or _CRAWL_DB))
    if not r.get("ok"):
        return SkillResult(success=False, error=str(r.get("error")))
    live = r.get("live", True)
    return SkillResult(success=True, output=f"会话 {sid} 已暂停" + ("" if live else "（非活动会话，仅状态落库）"),
                       data=r)


def _crawl_resume(session_id="", **kw):
    store, session, urls, _exp, events, fetch_url, CrawlEngine = _crawl_imports()
    sid = str(kw.get("session_id") or session_id or "").strip()
    if not sid:
        return SkillResult(success=False, error="缺少 session_id")
    from shared.crawler.engine import resume_session
    r = resume_session(sid, db_path=str(kw.get("db_path") or _CRAWL_DB))
    if not r.get("ok"):
        return SkillResult(success=False, error=str(r.get("error")))
    live = r.get("live", True)
    return SkillResult(success=True, output=f"会话 {sid} 已继续" + ("" if live else "（非活动会话，仅状态落库）"),
                       data=r)


def _crawl_stop(session_id="", **kw):
    store, session, urls, _exp, events, fetch_url, CrawlEngine = _crawl_imports()
    sid = str(kw.get("session_id") or session_id or "").strip()
    if not sid:
        return SkillResult(success=False, error="缺少 session_id")
    from shared.crawler.engine import _LIVE_ENGINES
    eng = _LIVE_ENGINES.get(sid)
    if eng is not None:
        # A-07: 活动引擎 → 真实 stop（排空队列 + 等在途收尾 + 落终态）
        t = threading.Thread(target=eng.stop, daemon=True)
        t.start()
        return SkillResult(success=True, output=f"会话 {sid} 正在停止（引擎已置 stopping，排空队列）",
                           data={"session_id": sid, "stopping": True})
    r = session.transition(sid, "stopping", db_path=_CRAWL_DB)
    if not r.get("success"):
        return SkillResult(success=False, error=r.get("error"))
    return SkillResult(success=True, output=f"会话 {sid} 正在停止（等待在途任务收尾）")


def _crawl_status(session_id="", **kw):
    store, session, urls, _exp, events, fetch_url, CrawlEngine = _crawl_imports()
    sid = str(kw.get("session_id") or session_id or "").strip()
    _db = str(kw.get("db_path") or _CRAWL_DB)
    if sid:
        from shared.crawler.engine import status_session
        r = status_session(sid, db_path=_db)
        if not r.get("ok"):
            return SkillResult(success=False, error=str(r.get("error")))
        s = r.get("session") or {}
        return SkillResult(success=True,
                           output=f"会话 {sid}：{r.get('state')}，done {r.get('pages_done',0)} / "
                                  f"成功 {r.get('pages_ok',0)} / 失败 {r.get('pages_fail',0)} / "
                                  f"队列 {r.get('queue_pending',0)} / live={r.get('live')}",
                           data=r)
        if not r.get("success"):
            return SkillResult(success=False, error=r.get("error"))
        s = r["session"]
        return SkillResult(success=True,
                           output=f"会话 {sid}：{s.get('state')}，总 {s.get('total',0)} / "
                                  f"成功 {s.get('ok',0)} / 失败 {s.get('fail',0)}",
                           data=r)
    rows = session.list_sessions(10, db_path=_CRAWL_DB)
    if not rows:
        return SkillResult(success=False, error="暂无爬取会话")
    lines = [f"最近 {len(rows)} 个会话："]
    for r in rows:
        lines.append(f"- {r['session_id']} [{r['state']}] {r.get('name','')} "
                     f"总{r.get('total',0)}/ok{r.get('ok',0)}/fail{r.get('fail',0)}")
    return SkillResult(success=True, output="\n".join(lines), data={"sessions": rows})


def _crawl_pages(session_id="", **kw):
    store, session, urls, _exp, events, fetch_url, CrawlEngine = _crawl_imports()
    sid = str(kw.get("session_id") or session_id or "").strip()
    if not sid:
        return SkillResult(success=False, error="缺少 session_id")
    limit = max(1, min(int(kw.get("limit", 50) or 50), 500))
    status_f = str(kw.get("status", "") or "")
    domain_f = str(kw.get("domain", "") or "")
    c = store.ro_conn(_CRAWL_DB)
    if c is None:
        return SkillResult(success=False, error="数据库不可读")
    try:
        sql = ("SELECT id,url,domain,depth,status,http_status,mode,title,text_len,"
               "quality,elapsed_ms,fetched_at FROM crawl_page WHERE session_id=?")
        args = [sid]
        if status_f:
            sql += " AND status=?"
            args.append(status_f)
        if domain_f:
            sql += " AND domain=?"
            args.append(domain_f)
        sql += " ORDER BY id DESC LIMIT ?"
        args.append(limit)
        rows = c.execute(sql, args).fetchall()
    finally:
        c.close()
    if not rows:
        return SkillResult(success=False, error=f"会话 {sid} 无页面数据")
    lines = [f"会话 {sid} 最近 {len(rows)} 页："]
    for r in rows:
        lines.append(f"- [{r['status']}] {r['url'][:60]} (mode={r['mode']}, "
                     f"{r['text_len']}字, q={r['quality']})")
    return SkillResult(success=True, output="\n".join(lines),
                       data={"pages": [dict(r) for r in rows]})


def _crawl_page(page_id=None, **kw):
    store, session, urls, _exp, events, fetch_url, CrawlEngine = _crawl_imports()
    try:
        pid = int(kw.get("page_id") or page_id)
    except (TypeError, ValueError):
        return SkillResult(success=False, error="page_id 必须是整数")
    c = store.ro_conn(_CRAWL_DB)
    if c is None:
        return SkillResult(success=False, error="数据库不可读")
    try:
        p = c.execute("SELECT * FROM crawl_page WHERE id=?", (pid,)).fetchone()
        if p is None:
            return SkillResult(success=False, error=f"page_id {pid} 不存在")
        p = dict(p)
        cc = c.execute("SELECT text FROM crawl_content WHERE page_id=?", (pid,)).fetchone()
    finally:
        c.close()
    text = (cc["text"] if cc else "")[:2000]
    out = (f"页面 {pid}：{p['url']}\n状态 {p['status']} / HTTP {p['http_status']} / "
           f"mode {p['mode']}\n标题 {p['title']}\n质量 {p['quality']} / "
           f"正文 {p['text_len']} 字\n\n正文节选：\n{text}")
    return SkillResult(success=True, output=out, data={**p, "text_head": text})


def _crawl_export(session_id="", **kw):
    store, session, urls, _exp, events, fetch_url, CrawlEngine = _crawl_imports()
    sid = str(kw.get("session_id") or session_id or "").strip()
    if not sid:
        return SkillResult(success=False, error="缺少 session_id")
    fmt = str(kw.get("fmt", "jsonl") or "jsonl").lower()
    if fmt == "csv":
        r = _exp.export_csv(sid, db_path=_CRAWL_DB)
    elif fmt == "md":
        r = _exp.export_markdown(sid, db_path=_CRAWL_DB)
    else:
        r = _exp.export_jsonl(sid, include_content=True, db_path=_CRAWL_DB)
    if not r.get("success"):
        return SkillResult(success=False, error=r.get("error"))
    return SkillResult(success=True,
                       output=f"已导出 {r['rows']} 行 → {r['path']}",
                       data=r)


def _crawl_backup(kw):
    """★ D3-12: 备份 crawl.db（带 schema 版本，默认保留最近 N 份）"""
    import glob as _glob
    from shared.crawler.backup import backup, get_schema_version
    keep = int(kw.get("keep", 5) or 5)
    out_dir = str(kw.get("out_dir") or "").strip() or None
    r = backup(_CRAWL_DB, out_dir=out_dir)
    if not r.get("ok"):
        return SkillResult(success=False, error=r.get("error"))
    removed = 0
    d = os.path.dirname(r["path"])
    try:
        files = sorted(_glob.glob(os.path.join(d, "crawl_backup_*.db")),
                       key=os.path.getmtime, reverse=True)
        for old in files[keep:]:
            try:
                os.remove(old)
                if os.path.exists(old + ".manifest.json"):
                    os.remove(old + ".manifest.json")
                removed += 1
            except OSError:
                logger.debug("suppressed exception")
    except Exception:
        removed = 0
    return SkillResult(success=True,
                       output=f"已备份 → {r['path']}（保留 {keep} 份，清理 {removed} 份）",
                       data={"path": r["path"], "manifest": r.get("manifest"),
                             "schema_version": get_schema_version(_CRAWL_DB),
                             "removed": removed})


_CRAWL_SPECS = [
    ("crawl_start", "启动爬取会话（种子 URL 列表，可设 max_pages/max_depth/same_domain 等）",
     {"seeds": {"type": "array", "items": {"type": "string"}},
      "name": {"type": "string"}, "max_pages": {"type": "integer"},
      "max_depth": {"type": "integer"}, "same_domain": {"type": "boolean"},
      "include": {"type": "string"}, "exclude": {"type": "string"},
      "refresh": {"type": "boolean"}, "use_js": {"type": "boolean"},
      "delay_ms": {"type": "integer"}}, ["seeds"]),
    ("crawl_pause", "暂停指定爬取会话", {"session_id": {"type": "string"}}, []),
    ("crawl_resume", "继续已暂停的爬取会话", {"session_id": {"type": "string"}}, []),
    ("crawl_stop", "停止爬取会话（等在途任务收尾）", {"session_id": {"type": "string"}}, []),
    ("crawl_status", "查询会话状态；不传 session_id 返回最近 10 个会话",
     {"session_id": {"type": "string"}}, []),
    ("crawl_pages", "列出会话页面（可按 status/domain 过滤）",
     {"session_id": {"type": "string"}, "limit": {"type": "integer"},
      "status": {"type": "string"}, "domain": {"type": "string"}}, []),
    ("crawl_page", "查看单页详情 + 正文前 2000 字", {"page_id": {"type": "integer"}}, ["page_id"]),
    ("crawl_export", "导出会话数据（jsonl/csv/md）",
     {"session_id": {"type": "string"}, "fmt": {"type": "string"}}, []),
    ("crawl_backup", "备份 crawl.db（带 schema 版本，默认保留最近 N 份）",
     {"keep": {"type": "integer"}, "out_dir": {"type": "string"}}, ["keep"]),
]


def register_crawl_skills(ui_callback=None, engine_manager=None) -> dict:
    """注册 8 个 Crawl Engine 技能；返回可发现性自检结果"""
    skills = get_skills_registry()
    # ★ W3: 注入 ui_callback 供 Live 卡桥使用
    _set_bridge_ui_callback(ui_callback)
    handlers = {
        "crawl_start": _crawl_start_w3, "crawl_pause": _crawl_pause_w3,
        "crawl_resume": _crawl_resume_w3, "crawl_stop": _crawl_stop_w3,
        "crawl_status": _crawl_status, "crawl_pages": _crawl_pages,
        "crawl_page": _crawl_page, "crawl_export": _crawl_export,
        "crawl_backup": _crawl_backup,
        "crawl_agentic": lambda **kw: __import__(
            "shared.crawler.agentic", fromlist=["agentic_pipeline"]
        ).agentic_pipeline(
            raw_html=kw.get("raw_html", ""), text=kw.get("text", ""),
            url=kw.get("url", ""), session_id=kw.get("session_id", ""),
            verdict=kw.get("verdict", ""), schema=kw.get("schema"),
            use_llm=bool(kw.get("use_llm", False)),
        ),
    }
    specs = []
    specs.append(SkillDef(
        name="crawl_agentic",
        description="Agent 化抓取闭环：语义抽取（LLM schema，可降级规则式）→ 写入情节记忆 → 失败反思建议。用于让爬虫具备 Agent 的眼睛/记忆/反思能力。",
        parameters={"type": "object", "properties": {
            "url": {"type": "string"}, "text": {"type": "string"},
            "raw_html": {"type": "string"}, "session_id": {"type": "string"},
            "verdict": {"type": "string"},
            "schema": {"type": "object", "description": "JSON Schema；不传用默认 title/summary"},
            "use_llm": {"type": "boolean", "description": "默认跟随 LEMON_EXTRACT_LLM 开关"},
        }, "required": ["url"]},
        handler=handlers["crawl_agentic"], category="crawler", timeout=90))
    for name, desc, props, required in _CRAWL_SPECS:
        specs.append(SkillDef(
            name=name, description=desc,
            parameters={"type": "object", "properties": props, "required": required},
            handler=handlers[name], category="crawler", timeout=60))
    for d in specs:
        skills.register(d)
    names = set()
    try:
        for d in skills.get_tool_definitions():
            names.add((d.get("function") or {}).get("name") or d.get("name") or "")
    except Exception:
        logger.debug("suppressed exception")
    missing = [s.name for s in specs if s.name not in names]
    # ★ W4: 注册 6 个卡片动作（confirm=False）
    try:
        _reg_actions = register_crawl_actions(ui_callback=ui_callback)
        print(f"[crawler_skills] crawl 卡片动作: {_reg_actions}")
    except Exception as _ae:
        print(f"[crawler_skills] crawl 卡片动作注册失败: {_ae}")
    # ★ D3-11: 常驻 watchdog 接线（单例守护，重复注册不重复起线程）
    try:
        from shared.crawler.watchdog import start_watchdog
        start_watchdog(db_path=_CRAWL_DB, interval=60, daemon=True)
    except Exception as _we:
        print(f"[crawler_skills] watchdog 启动失败: {_we}")
    return {"success": not missing, "skills": [s.name for s in specs],
            "error": "" if not missing else f"注册后 schema 发现失败: {missing}"}


# ══════════════════════════════════════════════════════════════════
# ★ C 集群: 标注·统计·运营技能（crawl.db 只读/标注）
# ══════════════════════════════════════════════════════════════════

def _crawl_anno_imports():
    try:
        from shared.crawler import annotate, autotag, stats, watch, rules, export as _exp
    except ImportError:
        import sys
        sys.path.insert(0, _ROOT)
        from shared.crawler import annotate, autotag, stats, watch, rules, export as _exp
    return annotate, autotag, stats, watch, rules, _exp


def _crawl_annotate(page_id=None, **kw):
    annotate_m, _at, _st, _w, _r, _e = _crawl_anno_imports()
    try:
        pid = int(kw.get("page_id") or page_id)
    except (TypeError, ValueError):
        return SkillResult(success=False, error="page_id 必须是整数")
    tags = kw.get("tags") or []
    if isinstance(tags, str):
        tags = [t for t in tags.split(",") if t]
    r = annotate_m.create(pid, field=str(kw.get("field", "") or ""),
                          quote=str(kw.get("quote", "") or ""),
                          note=str(kw.get("note", "") or ""),
                          tags=tags[:5], color=str(kw.get("color", "#f5a623") or "#f5a623"),
                          db_path=_CRAWL_DB)
    return SkillResult(success=True,
                       output=f"标注已创建：id={r['id']}" + ("（合并）" if r.get("merged") else ""),
                       data=r)


def _crawl_annotations(page_id=None, session_id="", status="", **kw):
    annotate_m, _at, _st, _w, _r, _e = _crawl_anno_imports()
    pid = kw.get("page_id") or page_id
    try:
        pid = int(pid) if pid is not None else None
    except (TypeError, ValueError):
        return SkillResult(success=False, error="page_id 必须是整数")
    rows = annotate_m.list_annotations(page_id=pid, session_id=str(session_id or ""),
                                       status=str(status or ""), db_path=_CRAWL_DB)
    if not rows:
        return SkillResult(success=False, error="无标注记录")
    lines = [f"标注 {len(rows)} 条："]
    for a in rows[:20]:
        tags = a.get("tags") or ""
        lines.append(f"- [#{a['id']}] p{a['page_id']} {tags} {a.get('note','')[:40]}")
    return SkillResult(success=True, output="\n".join(lines),
                       data={"annotations": rows})


def _crawl_annotation_update(ann_id=None, **kw):
    annotate_m, _at, _st, _w, _r, _e = _crawl_anno_imports()
    try:
        aid = int(kw.get("id") or ann_id)
    except (TypeError, ValueError):
        return SkillResult(success=False, error="id 必须是整数")
    note = kw.get("note")
    tags = kw.get("tags")
    if isinstance(tags, str):
        tags = [t for t in tags.split(",") if t]
    color = kw.get("color")
    status = kw.get("status")
    r = annotate_m.update(aid, note=note, tags=tags, color=color, status=status,
                          db_path=_CRAWL_DB)
    if not r.get("success"):
        return SkillResult(success=False, error=r.get("error"))
    return SkillResult(success=True, output=f"标注 {aid} 已更新")


def _crawl_annotation_delete(ann_id=None, **kw):
    annotate_m, _at, _st, _w, _r, _e = _crawl_anno_imports()
    try:
        aid = int(kw.get("id") or ann_id)
    except (TypeError, ValueError):
        return SkillResult(success=False, error="id 必须是整数")
    r = annotate_m.delete(aid, db_path=_CRAWL_DB)
    if not r.get("success"):
        return SkillResult(success=False, error=r.get("error"))
    return SkillResult(success=True, output=f"标注 {aid} 已软删")


def _crawl_autotag(page_id=None, **kw):
    annotate_m, autotag_m, _st, _w, _r, _e = _crawl_anno_imports()
    try:
        pid = int(kw.get("page_id") or page_id)
    except (TypeError, ValueError):
        return SkillResult(success=False, error="page_id 必须是整数")
    c = store.ro_conn(_CRAWL_DB)
    if c is None:
        return SkillResult(success=False, error="数据库不可读")
    try:
        cc = c.execute("SELECT text FROM crawl_content WHERE page_id=?", (pid,)).fetchone()
    finally:
        c.close()
    if not cc:
        return SkillResult(success=False, error=f"page_id {pid} 无正文")
    r = autotag_m.apply_to_page(pid, cc["text"], db_path=_CRAWL_DB)
    return SkillResult(success=True,
                       output=f"自动预标注：新增 {r['created']} 条，跳过 {r['skipped']} 条",
                       data=r)


def _crawl_stats(session_id="", **kw):
    _a, _at, stats_m, _w, _r, _e = _crawl_anno_imports()
    sid = str(kw.get("session_id") or session_id or "").strip()
    if not sid:
        return SkillResult(success=False, error="缺少 session_id")
    emit = bool(kw.get("emit", True))
    group_by = str(kw.get("group_by", "domain") or "domain")
    since = str(kw.get("since", "") or "")
    until = str(kw.get("until", "") or "")
    r = stats_m.crawl_stats(sid, group_by=group_by, since=since, until=until,
                            db_path=_CRAWL_DB)
    if not r.get("success"):
        return SkillResult(success=False, error=r.get("error"))
    qb = stats_m.quality_buckets(sid, db_path=_CRAWL_DB)
    dr = stats_m.dedup_rate(sid, db_path=_CRAWL_DB)
    fails = stats_m.failure_top10(sid, db_path=_CRAWL_DB)
    # ★ W5: emit crawl_stats_card（走 ActionCardRegistry）
    if emit:
        try:
            from shared.action_cards import get_action_card_registry
            reg = get_action_card_registry()
            reg.emit_card({
                "type": "crawl_stats_card",
                "card_id": f"cst_{sid}",
                "session_id": sid,
                "title": f"会话统计 · {sid[:20]}",
                "overview": r.get("totals", {}),
                "by_domain": r.get("groups", [])[:10],
                "quality_buckets": qb.get("buckets", {}) if qb.get("success") else {},
                "fail_reasons": fails[:10],
                "annotations_top": [],
                "fetched_at": __import__("time").strftime("%Y-%m-%d %H:%M:%S"),
                "tools": [{"action": "crawl.export", "label": "导出"}],
            })
        except Exception as _ee:
            print(f"[crawl_stats] emit 失败: {_ee}")
    lines = [f"会话 {sid} 统计（group_by={group_by}）："]
    for g in r["groups"][:10]:
        lines.append(f"- {g['key']}: {g['count']} 页（ok {g['ok']} / fail {g['fail']}，"
                     f"均 {g['avg_ms']}ms）")
    if qb.get("success"):
        lines.append("质量分布: " + ", ".join(f"{k}={v}" for k, v in qb["buckets"].items()))
    if dr.get("success"):
        lines.append(f"去重率: {dr['dedup_rate']:.1%}（{dr['dedup_hit']}/{dr['total']}）")
    return SkillResult(success=True, output="\n".join(lines), data={**r, "quality": qb, "dedup": dr})


def _crawl_watch_set(name="", **kw):
    _a, _at, _st, watch_m, _r, _e = _crawl_anno_imports()
    domain = str(kw.get("domain", "") or "")
    keywords = kw.get("keywords") or []
    if isinstance(keywords, str):
        keywords = [k for k in keywords.split(",") if k]
    threshold = max(1, min(int(kw.get("threshold", 1) or 1), 100))
    r = watch_m.watch_set(str(name or "watch"), domain, keywords, threshold,
                          db_path=_CRAWL_DB)
    return SkillResult(success=True, output=f"告警规则已设置：id={r['id']}", data=r)


def _crawl_watch_eval(session_id="", **kw):
    _a, _at, _st, watch_m, _r, _e = _crawl_anno_imports()
    sid = str(kw.get("session_id") or session_id or "").strip()
    if not sid:
        return SkillResult(success=False, error="缺少 session_id")
    r = watch_m.watch_eval(sid, db_path=_CRAWL_DB)
    if not r.get("success"):
        return SkillResult(success=False, error=r.get("error"))
    return SkillResult(success=True,
                       output=f"告警评估：命中 {len(r['fired'])} 条，连续失败 {r['consecutive_fail']}",
                       data=r)


def _crawl_schedule(trigger="", **kw):
    """透传 SchedulerEngine.create_job"""
    try:
        from shared.scheduler import SchedulerEngine
    except ImportError:
        try:
            from scheduler import SchedulerEngine
        except ImportError:
            return SkillResult(success=False, error="scheduler 模块不可用")
    trig = str(kw.get("trigger") or trigger or "").strip()
    if not trig:
        return SkillResult(success=False, error="缺少 trigger")
    args = kw.get("session_args") or {}
    if not isinstance(args, dict):
        return SkillResult(success=False, error="session_args 必须是对象")
    try:
        eng = SchedulerEngine()
        job = eng.create_job(trigger=trig, action={"skill": "crawl_start", "args": args})
        return SkillResult(success=True,
                           output=f"调度任务已创建：{trig}",
                           data={"job": job})
    except Exception as e:
        return SkillResult(success=False, error=f"调度创建失败: {str(e)[:120]}")


def _crawl_rule_set(domain="", **kw):
    _a, _at, _st, _w, rules_m, _e = _crawl_anno_imports()
    sels = kw.get("selectors") or {}
    if not isinstance(sels, dict):
        return SkillResult(success=False, error="selectors 必须是对象")
    r = rules_m.rule_set(str(domain or ""), str(kw.get("name", "") or "rule"), sels,
                         db_path=_CRAWL_DB)
    return SkillResult(success=True, output=f"站点规则已设置：id={r['id']}", data=r)


_C_SK_SPECS = [
    ("crawl_annotate", "为页面添加标注（同页同 quote 同 tags 合并）",
     {"page_id": {"type": "integer"}, "quote": {"type": "string"},
      "note": {"type": "string"}, "tags": {"type": "array", "items": {"type": "string"}},
      "color": {"type": "string"}}, ["page_id"]),
    ("crawl_annotations", "查询标注列表（可按 page/session/status 过滤）",
     {"page_id": {"type": "integer"}, "session_id": {"type": "string"},
      "status": {"type": "string"}}, []),
    ("crawl_annotation_update", "更新标注",
     {"id": {"type": "integer"}, "note": {"type": "string"},
      "tags": {"type": "array", "items": {"type": "string"}},
      "color": {"type": "string"}, "status": {"type": "string"}}, ["id"]),
    ("crawl_annotation_delete", "软删标注",
     {"id": {"type": "integer"}}, ["id"]),
    ("crawl_autotag", "自动预标注（六类规则，status=pending）",
     {"page_id": {"type": "integer"}}, ["page_id"]),
    ("crawl_stats", "会话统计（domain/hour/day/status/mode 分组 + 质量分布 + 去重率）",
     {"session_id": {"type": "string"}, "group_by": {"type": "string"},
      "since": {"type": "string"}, "until": {"type": "string"}}, []),
    ("crawl_watch_set", "设置告警规则（关键词命中阈值）",
     {"name": {"type": "string"}, "domain": {"type": "string"},
      "keywords": {"type": "array", "items": {"type": "string"}},
      "threshold": {"type": "integer"}}, ["name", "domain"]),
    ("crawl_watch_eval", "评估告警规则",
     {"session_id": {"type": "string"}}, []),
    ("crawl_schedule", "创建调度任务（定时爬取）",
     {"trigger": {"type": "string"}, "session_args": {"type": "object"}}, ["trigger"]),
    ("crawl_rule_set", "设置站点提取规则（CSS 选择器）",
     {"domain": {"type": "string"}, "name": {"type": "string"},
      "selectors": {"type": "object"}}, ["domain"]),
    # ★ W22-2: 保留策略（默认 dry-run）
    ("crawl_prune", "爬取数据保留策略（删旧会话/超页上限/VACUUM，默认 dry-run）",
     {"keep_days": {"type": "integer"}, "max_pages": {"type": "integer"},
      "dry_run": {"type": "boolean"}, "vacuum": {"type": "boolean"}}, []),
    ("crawl_rule_health", "改版健康检测（用最新规则跑选择器算 hit_rate，<50% 告警）",
     {"domain": {"type": "string"}, "html": {"type": "string"}}, ["domain"]),
    # ★ W22-5: 域名合规台账
    ("crawl_domain_policy_set", "设置域名合规策略（allowed/限速/许可证/ToS）",
     {"domain": {"type": "string"}, "allowed": {"type": "boolean"},
      "rate_limit_s": {"type": "number"}, "license": {"type": "string"},
      "tos_url": {"type": "string"}, "contact": {"type": "string"},
      "note": {"type": "string"}}, ["domain"]),
    ("crawl_domain_policy_get", "查询域名合规策略",
     {"domain": {"type": "string"}}, ["domain"]),
    ("crawl_domain_policy_list", "列出全部域名合规策略",
     {}, []),
    # ★ W22-8: 运维看板（只读）
    ("crawl_ops_status", "运维看板（只读：库体积/会话/页面/规则/告警）",
     {}, []),
    # ★ W23-3: 调度闭环技能
    ("crawl_watchdog", "watchdog（停滞会话检测）",
     {"threshold": {"type": "integer"}}, []),
    ("legal_pilot", "合法 pilot（巨潮/交易所公开公告，30 页/天）",
     {"days": {"type": "integer"}}, []),
    # ★ W25-H7-T1: 蛛网看板独立窗口（实时跟随抓取进度）
    ("crawl_board", "打开爬虫蛛网看板独立窗口（实时跟随抓取进度，可指定会话）",
     {"session_id": {"type": "string"}}, []),
]


def _crawl_board(session_id="", **kw):
    """★ W25-H10-T1: 打开作战室（默认进主屏右侧 Dock；跨线程安全：入队回主线程）

    每次调用同时 emit type=crawl_board_card 迷你战报卡（一行高 + [▸展开]）。
    """
    sid = str(session_id or kw.get("session_id") or "")
    try:
        from standard_mode.ui.crawl_board_window import request_open, emit_mini_card
    except Exception:
        try:
            from ui.crawl_board_window import request_open, emit_mini_card
        except Exception as e:
            return SkillResult(success=False, error=f"看板窗口不可用: {str(e)[:120]}")
    try:
        request_open(sid)
        emit_mini_card(sid)  # ★ W25-H10-T1: 每次调用发迷你战报卡（抓取结束的发卡在轮询状态迁移处）
        return SkillResult(success=True, output="作战室已打开（主屏右侧 Dock，2s 刷新）",
                           data={"session_id": sid, "window": "crawl_board",
                                 "mode": "dock", "mini_card": "crawl_board_card"})
    except Exception as e:
        return SkillResult(success=False, error=f"看板打开失败: {str(e)[:120]}")


def register_crawl_skills_c(ui_callback=None, engine_manager=None) -> dict:
    """注册 C 集群技能（含 W25-H7 蛛网看板）"""
    skills = get_skills_registry()
    # ★ W25-H7-T1: 主线程初始化看板队列泵（技能在工作线程调用时才能安全建窗）
    try:
        from standard_mode.ui.crawl_board_window import init_board_support
        init_board_support()
    except Exception as _be:
        print(f"[crawl_board] 队列泵初始化跳过: {_be}")
    # ★ W25-H10-T1: 迷你卡 [▸展开] 动作白名单注册（点击 → Dock 唤起）
    try:
        from shared.action_cards import get_action_card_registry
        try:
            from standard_mode.ui.crawl_board_window import request_open as _cb_open
        except Exception:
            from ui.crawl_board_window import request_open as _cb_open

        def _crawl_board_open(params=None):
            p = params or {}
            _cb_open(str(p.get("session_id") or ""),
                     mode=str(p.get("mode") or "float"))
            return {"success": True,
                    "opened": str(p.get("mode") or "float"),
                    "session_id": str(p.get("session_id") or "")}

        get_action_card_registry().register_action(
            "crawl_board_open", _crawl_board_open, confirm=False,
            description="展开爬虫作战室（悬浮大卡）")
    except Exception as _ae:
        print(f"[crawl_board] 迷你卡展开动作注册跳过: {_ae}")
    handlers = {
        "crawl_annotate": _crawl_annotate, "crawl_annotations": _crawl_annotations,
        "crawl_annotation_update": _crawl_annotation_update,
        "crawl_annotation_delete": _crawl_annotation_delete,
        "crawl_autotag": _crawl_autotag, "crawl_stats": _crawl_stats,
        "crawl_watch_set": _crawl_watch_set, "crawl_watch_eval": _crawl_watch_eval,
        "crawl_schedule": _crawl_schedule, "crawl_rule_set": _crawl_rule_set,
        "crawl_prune": _crawl_prune,
        "crawl_rule_health": _crawl_rule_health,
        "crawl_domain_policy_set": _crawl_domain_policy_set,
        "crawl_domain_policy_get": _crawl_domain_policy_get,
        "crawl_domain_policy_list": _crawl_domain_policy_list,
        "crawl_ops_status": _crawl_ops_status,
        "crawl_domain_health": _crawl_domain_health,
        "crawl_watchdog": _crawl_watchdog_skill,
        "legal_pilot": _legal_pilot_skill,
        "crawl_board": _crawl_board,
    }
    specs = []
    for name, desc, props, required in _C_SK_SPECS:
        specs.append(SkillDef(
            name=name, description=desc,
            parameters={"type": "object", "properties": props, "required": required},
            handler=handlers[name], category="crawler", timeout=30))
    for d in specs:
        skills.register(d)
    names = set()
    try:
        for d in skills.get_tool_definitions():
            names.add((d.get("function") or {}).get("name") or d.get("name") or "")
    except Exception:
        logger.debug("suppressed exception")
    missing = [s.name for s in specs if s.name not in names]
    return {"success": not missing, "skills": [s.name for s in specs],
            "error": "" if not missing else f"注册后 schema 发现失败: {missing}"}


# ══════════════════════════════════════════════════════════════════
# ★ W3: Live 卡桥接线（start/pause/resume/stop）
# ══════════════════════════════════════════════════════════════════

# ★ D4-04: 内嵌卡信箱——daemon/独立进程的 UI 回调注册不上时落盘，
#   由主 IDE 的补投泵消费（"晚开 IDE 也能内嵌"）。
_STAGE_PENDING = os.path.join(_ROOT, "data", "crawl_stage_pending.json")


def _drop_stage_pending(card: dict) -> bool:
    """把舞台卡 JSON 原子落盘到信箱（供主 IDE 补投泵读取）。"""
    try:
        os.makedirs(os.path.dirname(_STAGE_PENDING), exist_ok=True)
        payload = dict(card)
        payload["_ts"] = time.time()
        tmp = _STAGE_PENDING + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False)
        os.replace(tmp, _STAGE_PENDING)
        return True
    except Exception as e:
        print(f"[crawl_start] 信箱落盘失败: {e}")
        return False


def _emit_stage_card(sid: str, name: str) -> bool:
    """W25-H11: 会话启动即在对话流里弹出舞台版作战室（crawl_stage_card）。

    页面由本机 stage_server 托管，iframe 自己轮询 /api/board 拿真实数据，
    因此卡片天然随对话滚动，且与 Qt 侧注入通道互不影响。

    ★ D4-04: 推送失败（主 IDE 未运行 / 回调未注入）→ 卡片落信箱，
    主 IDE 面板存活期间的补投泵会读入并重推（幂等）。
    """
    try:
        from shared.crawler import stage_server
    except Exception as e:
        print(f"[crawl_start] stage_server 不可用: {e}")
        return False
    port = stage_server.start()
    if not port:
        print("[crawl_start] stage_server 起不来（端口占用）")
        return False
    card = {
        "type": "crawl_stage_card",
        "card_id": "crawl_stage_" + sid,
        "title": "爬虫作战室 · 舞台",
        "session": name,
        "session_id": sid,
        "url": f"http://127.0.0.1:{port}/",
    }
    url = f"http://127.0.0.1:{port}/?embed=1&sid={sid}"
    try:
        from shared.action_cards import ActionCardRegistry
        reg = ActionCardRegistry()
        reg.set_ui_callback(_BRIDGE_UI_CALLBACK)
        r = reg.emit_card(card)
        if not r.get("success"):
            _drop_stage_pending(card)
            print(f"[crawl_start] 舞台卡推送失败（已落信箱，主 IDE 补投）: {r.get('error')}")
            print(f"[crawl_start] 浏览器可看 {url}")
        else:
            print(f"[crawl_start] 舞台卡已进对话流 · 浏览器可看 {url}")
        return bool(r.get("success"))
    except Exception as e:
        _drop_stage_pending(card)
        print(f"[crawl_start] 舞台卡推送异常（已落信箱）: {e}")
        print(f"[crawl_start] 浏览器可看 {url}")
        return False


def _get_bridge(ui_callback=None):
    """取 Live 卡桥单例并 attach"""
    try:
        from shared.crawler.live_bridge import get_live_bridge
    except ImportError:
        import sys
        sys.path.insert(0, _ROOT)
        from shared.crawler.live_bridge import get_live_bridge
    b = get_live_bridge()
    if ui_callback is not None:
        b.attach(ui_callback)
    return b


# ── 包装：把 ui_callback 存到模块级，供 start/pause/resume/stop 使用 ──
_BRIDGE_UI_CALLBACK = None


def _set_bridge_ui_callback(cb):
    global _BRIDGE_UI_CALLBACK
    _BRIDGE_UI_CALLBACK = cb
    if cb is not None:
        try:
            _get_bridge(cb)
        except Exception:
            logger.debug("suppressed exception")


def _crawl_start_w3(**kw):
    """W3: 包装版 crawl_start —— 建会话后调 start_session_card"""
    store, session, urls, _exp, events, fetch_url, CrawlEngine = _crawl_imports()
    # ★ W22-2: 启动前配额检查
    try:
        from shared.crawler.retention import check_quota
        q = check_quota(_CRAWL_DB)
        if not q.get("ok"):
            return SkillResult(success=False,
                                output=f"磁盘配额不足：剩余 {q.get('free_gb')}GB "
                                       f"（阈值 {q.get('min_free_gb')}GB）",
                                data={"reason": q.get("reason", "disk_low")})
    except Exception as _qe:
        print(f"[crawl_start] 配额检查失败（不阻断）: {_qe}")
    seeds = kw.get("seeds") or []
    if isinstance(seeds, str):
        seeds = [seeds]
    seeds = [s for s in seeds if urls.is_crawlable(s)]
    if not seeds:
        return SkillResult(success=False, error="参数 seeds 至少需要一个 http(s) URL")
    max_pages = max(1, min(int(kw.get("max_pages", 30) or 30), 500))
    max_depth = max(0, min(int(kw.get("max_depth", 1) or 1), 3))
    cfg = {"max_pages": max_pages, "max_depth": max_depth,
           "same_domain": bool(kw.get("same_domain", True)),
           "same_subdomain": bool(kw.get("same_subdomain", False)),
           "use_js": bool(kw.get("use_js", True)),
           "delay_ms": max(0, int(kw.get("delay_ms", 1500) or 1500))}
    name = str(kw.get("name") or ("crawl_" + seeds[0][:40]))
    sid = session.create_session(name, seeds[0], cfg, db_path=_CRAWL_DB)

    # ★ W3: 发射初始卡
    try:
        b = _get_bridge(_BRIDGE_UI_CALLBACK)
        b.start_session_card(sid, name, cfg)
    except Exception as e:
        print(f"[crawl_start] start_session_card 失败（不影响抓取）: {e}")

    # ★ W25-H11: 对话里自动弹出「爬虫作战室」舞台卡（iframe 直连本机实时服务）
    _emit_stage_card(sid, name)

    from urllib.parse import urlparse as _urlparse
    seed_hosts = {(_urlparse(s).hostname or "").lower() for s in seeds}

    def _fetch(url, depth):
        # ★ W25-H: 先判域再发请求；多 seed 时允许任一 seed host
        if cfg["same_domain"]:
            host = (_urlparse(url).hostname or "").lower()
            if not any(urls.same_domain(url, h,
                                        subdomain=cfg.get("same_subdomain", False))
                       for h in seed_hosts):
                return {"status": "filtered", "error": "cross_domain",
                        "no_save": True, "domain": host}
        return fetch_url(url, depth=depth, use_js=cfg["use_js"], timeout=15,
                         db_path=_CRAWL_DB)

    engine = CrawlEngine(sid, _fetch, workers=2, db_path=_CRAWL_DB,
                         event_cb=lambda ev, p: (b._on_event(ev, p) if b else None),
                         delay_ms=cfg.get("delay_ms", 0))
    import threading as _th
    def _run():
        try:
            engine.run(max_pages=max_pages, max_depth=max_depth, seed_urls=seeds)
        except Exception as e:
            print(f"[crawl_start] 引擎异常: {e}")
    t = _th.Thread(target=_run, daemon=True)
    t.start()
    return SkillResult(
        success=True,
        output=f"爬取会话已启动：{sid}（种子 {len(seeds)} 个，上限 {max_pages} 页）",
        data={"session_id": sid, "seeds": seeds, "config": cfg, "running": True})


def _crawl_pause_w3(session_id="", **kw):
    store, session, urls, _exp, events, fetch_url, CrawlEngine = _crawl_imports()
    sid = str(kw.get("session_id") or session_id or "").strip()
    if not sid:
        return SkillResult(success=False, error="缺少 session_id")
    from shared.crawler.engine import pause_session
    r = pause_session(sid, db_path=str(kw.get("db_path") or _CRAWL_DB))
    if not r.get("ok"):
        return SkillResult(success=False, error=str(r.get("error")))
    try:
        _get_bridge(_BRIDGE_UI_CALLBACK).update_state(sid, "paused")
    except Exception:
        logger.debug("suppressed exception")
    return SkillResult(success=True, output=f"会话 {sid} 已暂停", data=r)


def _crawl_resume_w3(session_id="", **kw):
    store, session, urls, _exp, events, fetch_url, CrawlEngine = _crawl_imports()
    sid = str(kw.get("session_id") or session_id or "").strip()
    if not sid:
        return SkillResult(success=False, error="缺少 session_id")
    from shared.crawler.engine import resume_session
    r = resume_session(sid, db_path=str(kw.get("db_path") or _CRAWL_DB))
    if not r.get("ok"):
        return SkillResult(success=False, error=str(r.get("error")))
    try:
        _get_bridge(_BRIDGE_UI_CALLBACK).update_state(sid, "running")
    except Exception:
        logger.debug("suppressed exception")
    return SkillResult(success=True, output=f"会话 {sid} 已继续", data=r)


def _crawl_stop_w3(session_id="", **kw):
    store, session, urls, _exp, events, fetch_url, CrawlEngine = _crawl_imports()
    sid = str(kw.get("session_id") or session_id or "").strip()
    if not sid:
        return SkillResult(success=False, error="缺少 session_id")
    r = session.transition(sid, "stopping", db_path=_CRAWL_DB)
    if not r.get("success"):
        return SkillResult(success=False, error=r.get("error"))
    try:
        _get_bridge(_BRIDGE_UI_CALLBACK).update_state(sid, "stopping")
    except Exception:
        logger.debug("suppressed exception")
    return SkillResult(success=True, output=f"会话 {sid} 正在停止")


# ══════════════════════════════════════════════════════════════════
# ★ W4: 注册 5 个 crawl 卡片动作（ActionCardRegistry）
# ══════════════════════════════════════════════════════════════════

def register_crawl_actions(ui_callback=None) -> dict:
    """注册 crawl.page_preview / annotate / pause / resume / stop / export"""
    try:
        from shared.action_cards import get_action_card_registry
    except ImportError:
        import sys
        sys.path.insert(0, _ROOT)
        from shared.action_cards import get_action_card_registry
    reg = get_action_card_registry()

    def _emit_card(card: dict):
        """★ W4: 走 ActionCardRegistry.emit_card（R3 唯一卡片通道）"""
        try:
            reg.emit_card(card)
        except Exception as e:
            print(f"[crawl_actions] emit_card 失败: {e}")

    def _page_preview(params):
        try:
            pid = int(params.get("page_id"))
        except (TypeError, ValueError):
            return {"success": False, "error": "page_id 必须是整数"}
        c = store.ro_conn(_CRAWL_DB)
        if c is None:
            return {"success": False, "error": "数据库不可读"}
        try:
            p = c.execute("SELECT * FROM crawl_page WHERE id=?", (pid,)).fetchone()
            if p is None:
                return {"success": False, "error": f"page_id {pid} 不存在"}
            p = dict(p)
            cc = c.execute("SELECT text FROM crawl_content WHERE page_id=?", (pid,)).fetchone()
        finally:
            c.close()
        # ★ W4: emit 既有 web_page_card（不新增卡型）
        card = {
            "type": "web_page_card",
            "title": p.get("title") or p.get("url"),
            "url": p.get("url"),
            "mode": p.get("mode"),
            "clean_html": "",
            "preview": (cc["text"] if cc else "")[:500],
            "quality": {"text_chars": p.get("text_len", 0)},
            "sandbox": "allow-same-origin",
            "fetched_at": p.get("fetched_at"),
        }
        _emit_card(card)
        return {"success": True, "output": f"已推送页面卡: {p.get('url','')[:60]}"}

    def _annotate(params):
        try:
            pid = int(params.get("page_id"))
        except (TypeError, ValueError):
            return {"success": False, "error": "page_id 必须是整数"}
        tags = params.get("tags") or []
        if isinstance(tags, str):
            tags = [t for t in tags.split(",") if t]
        r = _crawl_annotate(page_id=pid, quote=str(params.get("quote", "") or ""),
                            note=str(params.get("note", "") or ""),
                            tags=tags[:5], color=str(params.get("color", "#f5a623") or "#f5a623"))
        if not r.success:
            return {"success": False, "error": r.error}
        # ★ W4: 推 patch 到 live 卡
        try:
            b = _get_bridge(ui_callback)
            # 找 session
            c = store.ro_conn(_CRAWL_DB)
            if c:
                row = c.execute("SELECT session_id FROM crawl_page WHERE id=?", (pid,)).fetchone()
                if row:
                    b.push_annotation(row["session_id"], {
                        "id": (r.data or {}).get("id"), "page_id": pid,
                        "tags": tags, "note": params.get("note", ""),
                        "color": params.get("color", "#f5a623"),
                    })
                c.close()
        except Exception:
            logger.debug("suppressed exception")
        return {"success": True, "output": r.output}

    def _pause(params):
        sid = str(params.get("session_id", "") or "")
        if not sid:
            return {"success": False, "error": "缺少 session_id"}
        r = _crawl_pause_w3(session_id=sid)
        return {"success": r.success, "output": r.output, "error": r.error}

    def _resume(params):
        sid = str(params.get("session_id", "") or "")
        if not sid:
            return {"success": False, "error": "缺少 session_id"}
        r = _crawl_resume_w3(session_id=sid)
        return {"success": r.success, "output": r.output, "error": r.error}

    def _stop(params):
        sid = str(params.get("session_id", "") or "")
        if not sid:
            return {"success": False, "error": "缺少 session_id"}
        r = _crawl_stop_w3(session_id=sid)
        return {"success": r.success, "output": r.output, "error": r.error}

    def _export(params):
        sid = str(params.get("session_id", "") or "")
        if not sid:
            return {"success": False, "error": "缺少 session_id"}
        fmt = str(params.get("fmt", "jsonl") or "jsonl")
        r = _crawl_export(session_id=sid, fmt=fmt)
        return {"success": r.success, "output": r.output, "error": r.error}

    _actions = {
        "crawl.page_preview": (_page_preview, "预览页面正文（emit web_page_card）"),
        "crawl.annotate": (_annotate, "为页面添加标注"),
        "crawl.pause": (_pause, "暂停会话"),
        "crawl.resume": (_resume, "继续会话"),
        "crawl.stop": (_stop, "停止会话"),
        "crawl.export": (_export, "导出会话"),
    }
    for name, (handler, desc) in _actions.items():
        try:
            reg.register_action(name, handler, confirm=False, description=desc)
        except TypeError:
            # 兼容不同签名
            try:
                reg.register_action(name, handler, confirm=False)
            except Exception:
                reg.register_action(name, handler)
    names = list(_actions.keys())
    found = [n for n in names if reg.has(n)]
    return {"success": len(found) == len(names), "found": found, "total": len(names)}


# ══════════════════════════════════════════════════════════════════
# ★ W22-2: crawl_prune 技能（保留策略，默认 dry-run）
# ══════════════════════════════════════════════════════════════════

def _crawl_prune(**kw):
    """保留策略：删旧会话 + 超页上限 + VACUUM。默认 dry_run=True。"""
    try:
        from shared.crawler.retention import prune, check_quota
    except ImportError:
        import sys
        sys.path.insert(0, _ROOT)
        from shared.crawler.retention import prune, check_quota
    keep_days = max(1, min(int(kw.get("keep_days", 30) or 30), 3650))
    max_pages = max(1, min(int(kw.get("max_pages", 200000) or 200000), 100000000))
    dry_run = bool(kw.get("dry_run", True))
    vacuum = bool(kw.get("vacuum", True))
    r = prune(_CRAWL_DB, keep_days=keep_days, max_pages=max_pages,
              vacuum=vacuum, dry_run=dry_run)
    q = check_quota(_CRAWL_DB)
    out = (f"保留策略{'（dry-run）' if dry_run else ''}："
           f"删会话 {r.get('deleted_sessions', 0)}，删页 {r.get('deleted_pages', 0)}，"
           f"体积 {r.get('before_bytes', 0)} → {r.get('after_bytes', 0)}B，"
           f"剩余磁盘 {q.get('free_gb')}GB")
    return SkillResult(success=True, output=out, data=r)


def _crawl_rule_health(domain="", **kw):
    """★ W22-4: 改版健康检测（用最新规则跑选择器算 hit_rate）"""
    try:
        from shared.crawler.rules import rule_health
    except ImportError:
        import sys
        sys.path.insert(0, _ROOT)
        from shared.crawler.rules import rule_health
    html = str(kw.get("html", "") or "")
    r = rule_health(str(domain or ""), html=html, db_path=_CRAWL_DB)
    if not r.get("ok") and r.get("reason") == "no_rule":
        return SkillResult(success=True, output=f"{domain} 无规则，回退通用提取", data=r)
    mark = "✅" if r.get("ok") else "⚠"
    return SkillResult(success=True,
                        output=f"{mark} {domain} hit_rate={r.get('hit_rate')} status={r.get('status')}",
                        data=r)


# ══════════════════════════════════════════════════════════════════
# ★ W22-5: 域名合规台账技能
# ══════════════════════════════════════════════════════════════════

def _crawl_domain_policy_set(domain="", **kw):
    """设置域名合规策略（allowed/rate_limit_s/license/tos_url/contact/note）"""
    try:
        from shared.crawler.compliance import set_policy
    except ImportError:
        import sys
        sys.path.insert(0, _ROOT)
        from shared.crawler.compliance import set_policy
    d = str(domain or "").strip()
    if not d:
        return SkillResult(success=False, error="缺少 domain")
    allowed = bool(kw.get("allowed", True))
    if isinstance(allowed, str):
        allowed = allowed.lower() not in ("0", "false", "no", "deny")
    rl = float(kw.get("rate_limit_s", 1.5) or 1.5)
    r = set_policy(d, allowed=allowed, rate_limit_s=max(0.0, rl),
                   license=str(kw.get("license", "") or ""),
                   tos_url=str(kw.get("tos_url", "") or ""),
                   contact=str(kw.get("contact", "") or ""),
                   note=str(kw.get("note", "") or ""),
                   db_path=_CRAWL_DB)
    return SkillResult(success=True,
                       output=f"{d} allowed={allowed} rate_limit={rl}s", data=r)


def _crawl_domain_policy_get(domain="", **kw):
    """查询域名合规策略"""
    try:
        from shared.crawler.compliance import get_policy
    except ImportError:
        import sys
        sys.path.insert(0, _ROOT)
        from shared.crawler.compliance import get_policy
    d = str(domain or "").strip()
    if not d:
        return SkillResult(success=False, error="缺少 domain")
    p = get_policy(d, db_path=_CRAWL_DB)
    if p is None:
        return SkillResult(success=False, error=f"{d} 未配置（默认允许，限速 1.5s）")
    return SkillResult(success=True,
                       output=f"{d} allowed={bool(p['allowed'])} rate_limit={p['rate_limit_s']}s",
                       data=dict(p))


def _crawl_domain_policy_list(**kw):
    """列出全部域名合规策略"""
    try:
        from shared.crawler.compliance import list_policies
    except ImportError:
        import sys
        sys.path.insert(0, _ROOT)
        from shared.crawler.compliance import list_policies
    ps = list_policies(_CRAWL_DB)
    if not ps:
        return SkillResult(success=False, error="台账为空")
    lines = [f"合规台账 {len(ps)} 条："]
    for p in ps[:20]:
        mark = "✅" if p.get("allowed") else "❌"
        lines.append(f"- {mark} {p['domain']} rate={p.get('rate_limit_s')}s")
    return SkillResult(success=True, output="\n".join(lines),
                       data={"policies": ps})


def _crawl_ops_status(**kw):
    """★ W22-8: 运维看板（只读；不执行 prune/抓取）"""
    try:
        from shared.crawler.ops import ops_status
    except ImportError:
        import sys
        sys.path.insert(0, _ROOT)
        from shared.crawler.ops import ops_status
    s = ops_status(_CRAWL_DB)
    lines = [f"运维看板（只读）",
             f"库体积 {s.get('db_size_mb')}MB / 剩余磁盘 {s.get('free_gb')}GB",
             f"页面 {s.get('pages')} / 标注 {s.get('annotations')} / "
             f"规则 {s.get('rules')} / 告警 {s.get('watch')}",
             f"会话状态 {s.get('sessions_by_state')}",
             f"最近 prune: {s.get('last_prune')} / watchdog: {s.get('last_watchdog')}"]
    return SkillResult(success=True, output="\n".join(lines), data=s)


def _crawl_watchdog_skill(**kw):
    """★ W23-3: watchdog 技能（停滞会话检测，包装 CLI）"""
    try:
        from shared.crawler.watchdog import tick
    except ImportError:
        import sys
        sys.path.insert(0, _ROOT)
        from shared.crawler.watchdog import tick
    r = tick(_CRAWL_DB, threshold_min=5)
    return SkillResult(success=True,
                       output=f"watchdog: stalled={r.get('stalled')} fixed={len(r.get('fixed', []))}",
                       data=r)


def _legal_pilot_skill(**kw):
    """★ W23-3: 合法 pilot 技能（包装 legal_pilot.py CLI）"""
    import subprocess as _sp
    import sys as _sys
    try:
        r = _sp.run([_sys.executable, os.path.join(_ROOT, "scripts", "legal_pilot.py"),
                     "--days", "1"], capture_output=True, text=True, timeout=300,
                    cwd=_ROOT)
        return SkillResult(success=r.returncode == 0,
                           output=r.stdout[-500:] if r.stdout else "",
                           data={"returncode": r.returncode})
    except Exception as e:
        return SkillResult(success=False, error=f"legal_pilot 失败: {e}")


def _crawl_domain_health(domain="", **kw):
    """★ W24-3: 域健康（p95 / 429率 / 抽取命中率 / Top5 失败域）"""
    try:
        from shared.crawler.metrics import get_domain_health, top_failing_domains
    except ImportError:
        import sys
        sys.path.insert(0, _ROOT)
        from shared.crawler.metrics import get_domain_health, top_failing_domains
    if domain:
        h = get_domain_health(domain)
        return SkillResult(success=True,
                           output=f"{domain}: p95={h.get('p95_ms')}ms "
                                  f"429率={h.get('rate_429'):.1%} 抽取命中率={h.get('extract_hit_rate'):.1%} "
                                  f"请求={h.get('requests')} 失败={h.get('fail')}",
                           data=h)
    top = top_failing_domains(5)
    lines = [f"Top{len(top)} 失败域："]
    for t in top:
        lines.append(f"- {t['domain']}: 失败 {t['fail']} / 请求 {t['req']} (429={t['h429']})")
    return SkillResult(success=True, output="\n".join(lines), data={"top": top})
