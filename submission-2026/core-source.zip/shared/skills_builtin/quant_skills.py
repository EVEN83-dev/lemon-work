# -*- coding: utf-8 -*-
"""D9 · 量化质量看板卡（只读）。

卡型 quant_quality_card：9 条质量门状态、差异 Top10、覆盖率。
只读，不触发任何采集。

注册到 SkillsRegistry（若可用），否则提供 build_quality_card 供前端直接调用。
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import json
import os
from typing import Any, Dict, List, Optional

import pandas as pd

_CARD = {
    "kind": "quant_quality_card",
    "version": "1.0",
    "readonly": True,
    "title": "量化数据质量",
    "description": "9 条质量门状态 / 跨源差异 Top10 / 覆盖率",
}

CARD_TYPES = {"quant_quality_card": _CARD}


def build_quality_card(quality_report: Optional[Dict[str, Any]] = None,
                        df: Optional[pd.DataFrame] = None,
                        trade_cal: Optional[pd.DataFrame] = None,
                        expected_symbols: int = 0,
                        diff_csv: Optional[str] = None) -> Dict[str, Any]:
    """构造看板卡数据（只读，不触发抓取）。"""
    gates: List[Dict[str, Any]] = []
    if quality_report:
        gates = [{"name": r.get("name"), "ok": r.get("ok"),
                  "severity": r.get("severity"), "detail": r.get("detail")}
                 for r in quality_report.get("results", [])]
        passed = quality_report.get("passed", 0)
        total = quality_report.get("total", len(gates))
    else:
        from shared.quant import quality as _q
        rep = _q.run_all(df, trade_cal=trade_cal, expected_symbols=expected_symbols)
        gates = [{"name": r.get("name"), "ok": r.get("ok"),
                  "severity": r.get("severity"), "detail": r.get("detail")}
                 for r in rep.get("results", [])]
        passed, total = rep["passed"], rep["total"]

    diffs: List[Dict[str, Any]] = []
    if diff_csv and os.path.isfile(diff_csv):
        d = pd.read_csv(diff_csv)
        cols = [c for c in ["ts_code", "trade_date", "field", "close_a", "close_b",
                            "diff_rate"] if c in d.columns]
        diffs = d[cols].head(10).to_dict("records")

    return {
        "kind": "quant_quality_card",
        "title": "量化数据质量",
        "readonly": True,
        "gates": gates,
        "passed": passed,
        "total": total,
        "diff_top10": diffs,
        "coverage": {"expected_symbols": expected_symbols},
    }


def render_card_js(card: Dict[str, Any]) -> str:
    """输出给前端的 JS 对象字面量字符串。"""
    return json.dumps(card, ensure_ascii=False)


# ── 技能注册（可选，不动冻结区） ──────────────────────────────────
def register(registry=None):
    """★ W7: 注册 quant_quality_check / quant_pit_query（修非法参数 + 补 handler）"""
    try:
        from standard_mode.core.skills_registry import SkillDef, get_skills_registry
    except ImportError:
        try:
            from core.skills_registry import SkillDef, get_skills_registry
        except ImportError:
            return None
    reg = registry or get_skills_registry()

    def _quality_check(**kw):
        """quant_quality_check：pandas 读 parquet → 9 条质量门 → emit quant_quality_card"""
        try:
            from shared.quant.quality import run_all
        except ImportError:
            import sys
            sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
            from shared.quant.quality import run_all
        data_path = kw.get("data_path") or ""
        if not data_path:
            return json.dumps({"ok": False, "error": "缺少 data_path（不默认联网采数）"})
        if not os.path.exists(data_path):
            return json.dumps({"ok": False, "error": f"data_path 不存在: {data_path}"})
        try:
            df = pd.read_parquet(data_path)
        except Exception as e:
            return json.dumps({"ok": False, "error": f"读取失败: {str(e)[:120]}"})
        expected = int(kw.get("expected_symbols", 0) or 0)
        cal_path = str(kw.get("trade_cal_path", "") or "")
        cal = pd.read_parquet(cal_path) if cal_path and os.path.exists(cal_path) else None
        try:
            report = run_all(df, trade_cal=cal, expected_symbols=expected)
        except Exception as e:
            return json.dumps({"ok": False, "error": f"质量门失败: {str(e)[:120]}"})
        card = build_quality_card(quality_report=report, df=df, trade_cal=cal,
                                  expected_symbols=expected)
        emit = bool(kw.get("emit", True))
        if emit:
            try:
                from shared.action_cards import get_action_card_registry
                get_action_card_registry().emit_card(card)
            except Exception as e:
                print(f"[quant_skills] emit 失败: {e}")
        return json.dumps({"ok": True, "card": card, "passed": report.get("passed", 0),
                           "total": report.get("total", 0)}, ensure_ascii=False)

    def _pit_query(**kw):
        """quant_pit_query：走 shared.quant.pit 的 as_of 语义"""
        try:
            from shared.quant.pit import as_of_view
        except ImportError:
            import sys
            sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
            from shared.quant.pit import as_of_view
        data_path = kw.get("data_path") or ""
        if not data_path:
            return json.dumps({"ok": False, "error": "缺少 data_path"})
        if not os.path.exists(data_path):
            return json.dumps({"ok": False, "error": f"data_path 不存在: {data_path}"})
        as_of = str(kw.get("as_of", "") or "")
        if not as_of:
            return json.dumps({"ok": False, "error": "缺少 as_of（PIT 查询必须指定快照日）"})
        symbol = str(kw.get("symbol", "") or "")
        try:
            df = pd.read_parquet(data_path)
            # ★ as_of_view 按 available_at 过滤（无该列时用 trade_date 代替）
            date_col = "available_at" if "available_at" in df.columns else "trade_date"
            view = as_of_view(df, as_of=as_of, date_col=date_col)
            if symbol and "ts_code" in view.columns:
                view = view[view["ts_code"] == symbol]
            rows = view.head(10).to_dict(orient="records")
            return json.dumps({"ok": True, "rows": len(view), "preview": rows,
                               "as_of": as_of}, ensure_ascii=False)
        except Exception as e:
            return json.dumps({"ok": False, "error": f"PIT 查询失败: {str(e)[:120]}"})

    def _asset(**kw):
        """★ W25-H7-T2: quant_asset —— 扫描 data/quant 资产并出卡"""
        try:
            from shared.quant.asset import scan_assets
        except ImportError:
            import sys
            sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
            from shared.quant.asset import scan_assets
        root = str(kw.get("root") or "") or None
        with_codes = kw.get("with_codes", True)
        try:
            assets = scan_assets(root=root, with_codes=bool(with_codes))
        except Exception as e:
            return json.dumps({"ok": False, "error": f"资产扫描失败: {str(e)[:120]}"},
                              ensure_ascii=False)
        card = {
            "type": "quant_asset_card",
            "title": "量化数据资产",
            **assets,
        }
        if bool(kw.get("emit", True)):
            try:
                from shared.action_cards import get_action_card_registry
                get_action_card_registry().emit_card(card)
            except Exception as e:
                print(f"[quant_skills] asset emit 失败: {e}")
        return json.dumps({"ok": True, "card": card,
                           "total_rows": assets.get("total_parquet_rows", 0)},
                          ensure_ascii=False)

    reg.register(SkillDef(
        name="quant_quality_check",
        description="量化数据质量检查（9 条质量门，emit quant_quality_card）",
        category="quant", requires_confirm=False,
        parameters={"type": "object", "properties": {
            "data_path": {"type": "string"},
            "expected_symbols": {"type": "integer"},
            "trade_cal_path": {"type": "string"},
            "emit": {"type": "boolean"},
        }, "required": ["data_path"]},
        handler=_quality_check, timeout=60))
    reg.register(SkillDef(
        name="quant_pit_query",
        description="PIT 时点查询（as_of 必填，不返回未来数据）",
        category="quant", requires_confirm=False,
        parameters={"type": "object", "properties": {
            "data_path": {"type": "string"},
            "as_of": {"type": "string"},
            "symbol": {"type": "string"},
        }, "required": ["data_path", "as_of"]},
        handler=_pit_query, timeout=60))

    reg.register(SkillDef(
        name="quant_asset",
        description="量化数据资产总览（meta/raw/clean/pit 行数与覆盖，emit quant_asset_card）",
        category="quant", requires_confirm=False,
        parameters={"type": "object", "properties": {
            "root": {"type": "string"},
            "with_codes": {"type": "boolean"},
            "emit": {"type": "boolean"},
        }, "required": []},
        handler=_asset, timeout=120))

    names = set()
    try:
        for d in reg.get_tool_definitions():
            names.add((d.get("function") or {}).get("name") or d.get("name") or "")
    except Exception:
        logger.debug("suppressed exception")
    found = [n for n in ("quant_quality_check", "quant_pit_query", "quant_asset") if n in names]
    return {"success": len(found) == 3, "found": found, "total": 3}


__all__ = ["CARD_TYPES", "build_quality_card", "render_card_js", "register"]
