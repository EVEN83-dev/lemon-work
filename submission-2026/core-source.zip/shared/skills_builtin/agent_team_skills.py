# -*- coding: utf-8 -*-
"""agent_team_skills —— 内置智能体体系总管编排（v8.1 · T3）

两个技能：
  orchestrator_dispatch —— 总管按角色名册批量派发分身，出 agent_team_card 汇总卡
  agent_team_status     —— 团队展厅取数（9 张角色卡状态 + 指定角色最近执行记录）

铁律落点：
  · 分身执行一律走 engine_manager.spawn_subagent(agent_id=...) → agent_chat_guarded
    统一链（白名单 / token 预算 / 超时在那一层强制），本模块不自建线程、不自建执行路径。
  · 铁律 5（禁嵌套编排）由 engine_manager._NO_DELEGATE_TOOLS 在菜单层剔除
    orchestrator_dispatch / spawn_subagent —— 分身根本看不见这两个工具。
  · 单分身失败不阻塞其余：逐个收集，缺席者在卡上如实标 ⟲/timeout。
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import time
from typing import Any, Dict, List

try:
    from standard_mode.core.skills_registry import SkillDef, SkillResult, get_skills_registry
except ImportError:
    from core.skills_registry import SkillDef, SkillResult, get_skills_registry

_MAX_AGENTS_PER_DISPATCH = 8       # 铁律 4：总并发 ≤8
_DEFAULT_WAIT = 240
_MIN_WAIT, _MAX_WAIT = 10, 600


def _role_manager():
    try:
        from shared.role_system import get_role_manager
        return get_role_manager()
    except Exception:
        return None


def _engine():
    from shared.engine_manager import get_engine_manager
    return get_engine_manager()


def _ledger(mgr):
    """队列账本（可能为 None：编排器不可用时不阻塞派发，只是展厅少统计）"""
    try:
        return mgr.get_sub_agent_orchestrator()
    except Exception:
        return None


def _row(aid: str, role, status: str, summary: str = "", elapsed: float = 0.0,
         tokens: int = 0, denials: int = 0, task: str = "") -> Dict[str, Any]:
    return {
        "agent_id": aid,
        "role": getattr(role, "name", "") or aid,
        "icon_svg": getattr(role, "icon_svg", "") or "",
        "color": getattr(role, "color", "") or "",
        "status": status,                 # ok / fail / running
        "mark": {"ok": "✓", "fail": "✗", "running": "⟲"}.get(status, "⟲"),
        "summary": (summary or "")[:400],
        "elapsed": round(float(elapsed or 0), 1),
        "tokens": int(tokens or 0),
        "denials": int(denials or 0),
        "task": (task or "")[:120],
    }


def _synthesize(rows: List[Dict], aggregate: bool) -> str:
    """总管汇总口径：规则式合成，不再花一次 LLM 调用（可核对、不编造）。"""
    if not aggregate:
        return ""
    ok = [r for r in rows if r["status"] == "ok"]
    bad = [r for r in rows if r["status"] == "fail"]
    run = [r for r in rows if r["status"] == "running"]
    L = [f"本轮派发 {len(rows)} 个分身：成功 {len(ok)}、失败 {len(bad)}、未完成 {len(run)}。"]
    for r in rows:
        tail = f"（白名单拒绝 {r['denials']} 次）" if r["denials"] else ""
        L.append(f"· {r['mark']} {r['role']} {r['elapsed']}s/{r['tokens']}tok{tail}"
                 f"：{r['summary'][:120] or '（无输出）'}")
    return "\n".join(L)


def _orchestrator_dispatch(agents: list = None, tasks: dict = None,
                           aggregate: bool = True, wait_seconds: int = _DEFAULT_WAIT,
                           **kw) -> SkillResult:
    """按内置角色名册批量派发子任务。

    Params:
      agents: 角色 id 列表，如 ["researcher","writer","browser"]
      tasks:  {角色 id: 该角色的任务描述}
      aggregate: 是否由总管合成一段总结（规则式，不额外花 LLM 调用）
      wait_seconds: 最长等待时间（10–600s），到点未回的分身在卡上标 ⟲
    """
    ids: List[str] = [str(a).strip() for a in (agents or []) if str(a).strip()]
    tasks_map: Dict[str, Any] = dict(tasks or {})
    for k in tasks_map:
        if str(k).strip() and str(k).strip() not in ids:
            ids.append(str(k).strip())
    if not ids:
        return SkillResult(success=False,
                           error="agents 与 tasks 至少要给一个；形如 "
                                 '{"agents":["researcher","writer"],'
                                 '"tasks":{"researcher":"…","writer":"…"}}')
    if len(ids) > _MAX_AGENTS_PER_DISPATCH:
        return SkillResult(success=False,
                           error=f"单次派发上限 {_MAX_AGENTS_PER_DISPATCH} 个分身（铁律 4），"
                                 f"当前 {len(ids)} 个")
    rm = _role_manager()
    if rm is None:
        return SkillResult(success=False, error="角色体系不可用，无法按角色派发")
    unknown = [a for a in ids if rm.get_role(a) is None]
    if unknown:
        return SkillResult(success=False,
                           error=f"未知角色 {unknown}；可用: "
                                 f"{sorted(rm.get_builtin_roles().keys())}")

    try:
        wait = max(_MIN_WAIT, min(int(wait_seconds or _DEFAULT_WAIT), _MAX_WAIT))
    except (TypeError, ValueError):
        wait = _DEFAULT_WAIT

    mgr = _engine()
    orch = _ledger(mgr)

    # ── ① 全部先投出去（并发由引擎信号量夹住，不在这里串行等）──
    pending: Dict[str, Dict[str, Any]] = {}
    rows: List[Dict] = []
    for aid in ids:
        role = rm.get_role(aid)
        desc = str(tasks_map.get(aid) or "").strip()
        if not desc:
            rows.append(_row(aid, role, "fail", "缺少该角色的任务描述（tasks 未给）"))
            continue
        tid = ""
        try:
            tid = mgr.spawn_subagent(aid, desc, agent_id=aid) or ""
        except Exception as e:
            rows.append(_row(aid, role, "fail", f"派发异常: {str(e)[:120]}", task=desc))
            continue
        if not tid:
            rows.append(_row(aid, role, "fail",
                             f"并发已满（引擎上限 {mgr._SUBAGENT_MAX_CONCURRENT}），未启动",
                             task=desc))
            continue
        pending[aid] = {"tid": tid, "t0": time.time(), "task": desc, "role": role}
        if orch is not None:
            try:
                _q = orch.submit_task(desc, agent_id=aid)
                orch.assign_task(_q)
                orch.mark_running(_q, tid)
                pending[aid]["queue_task_id"] = _q
            except Exception:
                logger.debug("suppressed exception")

    # ── ② 轮询收结果：单个未完成不影响其他分身 ──
    deadline = time.time() + wait
    while pending and time.time() < deadline:
        for aid, info in list(pending.items()):
            try:
                r = mgr.get_subagent_result(info["tid"]) or {}
            except Exception:
                r = {}
            st = r.get("status", "running")
            if st == "running":
                continue
            elapsed = time.time() - info["t0"]
            denials = r.get("whitelist_denials") or []
            if st == "completed":
                summ = r.get("content", "") or ""
                if r.get("budget_truncated"):
                    summ = (summ[:360] + " …（已按 token 预算截断，任务未做完）"
                            if len(summ) > 360 else (summ + "（已按 token 预算截断，任务未做完）"))
                row = _row(aid, info["role"], "ok", summ, elapsed,
                           int(r.get("tokens_used") or 0), len(denials), info["task"])
            else:
                row = _row(aid, info["role"], "fail",
                           r.get("error") or r.get("content") or f"状态 {st}",
                           elapsed, int(r.get("tokens_used") or 0),
                           len(denials), info["task"])
            if denials:
                row["summary"] += f"｜白名单拒绝 {len(denials)} 次：" + "、".join(
                    sorted({str(d.get("tool", "")) for d in denials}))[:120]
            rows.append(row)
            if orch is not None and info.get("queue_task_id"):
                try:
                    orch.complete_task(info["queue_task_id"], result=row["summary"][:200],
                                       error=("" if row["status"] == "ok" else row["summary"][:200]),
                                       tokens=row["tokens"])
                except Exception:
                    logger.debug("suppressed exception")
            pending.pop(aid, None)
        if pending:
            time.sleep(1)

    # ── ③ 到点仍未回的分身：如实标 ⟲，不谎报成功 ──
    for aid, info in pending.items():
        rows.append(_row(aid, info["role"], "running",
                         f"等待 {wait}s 未回（分身仍在跑，可用 agent_team_status 复查）",
                         time.time() - info["t0"], 0, 0, info["task"]))
    rows.sort(key=lambda r: ids.index(r["agent_id"]) if r["agent_id"] in ids else 99)

    card_emit = _emit_team_card(rows, aggregate, wait)
    summary = _synthesize(rows, aggregate)
    ok_n = sum(1 for r in rows if r["status"] == "ok")
    fail_n = sum(1 for r in rows if r["status"] == "fail")
    run_n = sum(1 for r in rows if r["status"] == "running")
    if ok_n == 0 and run_n == 0:
        return SkillResult(success=False,
                           error=f"{len(rows)} 个分身全部失败：" + "；".join(
                               f"{r['role']}：{r['summary'][:80]}" for r in rows[:4]),
                           data={"rows": rows, "card_emit": card_emit})
    return SkillResult(
        success=True,
        output=(summary or f"已派发 {len(rows)} 个分身（成功 {ok_n}、失败 {fail_n}、"
                           f"未完成 {run_n}）"),
        data={"rows": rows, "ok": ok_n, "fail": fail_n, "running": run_n,
              "card_emit": card_emit, "wait_seconds": wait})


def _emit_team_card(rows: List[Dict], aggregate: bool, wait: int) -> Dict[str, Any]:
    try:
        from shared.action_cards import get_action_card_registry
    except ImportError:
        from action_cards import get_action_card_registry
    card = {
        "type": "agent_team_card",
        "card_id": f"atc_{int(time.time() * 1000)}",
        "title": "🤝 智能体分身战报",
        "ts": time.strftime("%Y-%m-%d %H:%M:%S"),
        "rows": rows,
        "aggregate": bool(aggregate),
        "wait_seconds": wait,
        "stat": {"total": len(rows),
                 "ok": sum(1 for r in rows if r["status"] == "ok"),
                 "fail": sum(1 for r in rows if r["status"] == "fail"),
                 "running": sum(1 for r in rows if r["status"] == "running")},
    }
    return get_action_card_registry().emit_card(card)


def _agent_team_status(role_id: str = "", limit: int = 3, **kw) -> SkillResult:
    """团队展厅数据：全部内置角色卡状态；给 role_id 则附该角色最近执行记录。"""
    mgr = _engine()
    rm = _role_manager()
    orch = _ledger(mgr)
    board = []
    if orch is not None:
        try:
            board = orch.team_board()
        except Exception:
            board = []
    if not board and rm is not None:
        # 账本不可用时降级：角色名册照常给出，状态一律 idle，不编造运行数据
        board = [{"role_id": rid, "name": r.name, "duties": r.description,
                  "state": "idle", "current_task": "", "tokens_used": 0,
                  "completed": 0, "failed": 0, "skill_count": len(r.skill_whitelist),
                  "max_token_budget": r.max_token_budget,
                  "timeout_seconds": r.timeout_seconds, "color": r.color,
                  "icon_svg": r.icon_svg, "runs": 0}
                 for rid, r in sorted(rm.get_builtin_roles().items())]
    runs: List[Dict] = []
    if role_id:
        try:
            runs = mgr.list_subagent_executions(role_id, limit)
        except Exception:
            runs = []
    status = {}
    if orch is not None:
        try:
            status = orch.get_status()
        except Exception:
            status = {}
    # ★ agent_board 窗口：get_execution_log 既有 API 的透传（后端零新增）——
    #   公司大屏 60s 柱状图消费真实执行时间戳；orch 缺席时如实为空列表
    log_tail: List[Dict] = []
    if orch is not None:
        try:
            log_tail = list(orch.get_execution_log()[-60:])
        except Exception:
            log_tail = []
    lines = [f"团队在册 {len(board)} 个内置角色（并发上限 "
             f"{status.get('subagent_max_concurrent', '未知')}/{status.get('max_concurrency', '未知')}）："]
    for b in board:
        mark = {"working": "⟲", "error": "✗"}.get(b.get("state", "idle"), "✓")
        lines.append(f"· {mark} {b.get('name')}（{b.get('role_id')}）"
                     f" 完成 {b.get('completed', 0)}/失败 {b.get('failed', 0)}"
                     f" · 工具 {b.get('skill_count', 0)} 项"
                     + (f" · 在跑：{b.get('current_task')}" if b.get("current_task") else ""))
    if runs:
        lines.append(f"\n{role_id} 最近 {len(runs)} 次执行：")
        lines += [f"· {r.get('status')} {r.get('elapsed', '—')}s/{r.get('tokens', 0)}tok "
                  f"{str(r.get('error', ''))[:60]}" for r in runs]
    return SkillResult(success=True, output="\n".join(lines),
                       data={"board": board, "status": status, "runs": runs,
                             "log_tail": log_tail, "role_id": role_id})


def register_agent_team_skills(ui_callback=None) -> dict:
    """注册总管编排两技能。ui_callback 只用于卡片通道（不改变执行链）。"""
    if ui_callback is not None:
        try:
            from shared.action_cards import get_action_card_registry
            get_action_card_registry().set_ui_callback(ui_callback)
        except Exception as e:
            print(f"[agent_team_skills] UI 回调注入失败（卡片将不可用）: {e}")

    skills = get_skills_registry()
    specs = [
        SkillDef(
            name="orchestrator_dispatch",
            description=("总管按角色名册批量派发分身。agents 传内置角色 id 列表，tasks 给每个角色的"
                         "任务描述，全部走统一执行链（角色工具白名单 + token 预算 + 超时自动生效），"
                         "完成后在对话里出「分身战报」汇总卡。用户说'让团队一起做/分派给研究员和写手/"
                         "多人协作'时调用。单个分身失败不影响其余分身。"),
            parameters={"type": "object", "properties": {
                "agents": {"type": "array", "items": {"type": "string"},
                           "description": ("角色 id 列表：researcher/writer/frontend/backend/"
                                           "tester/reviewer/analyst/browser/orchestrator")},
                "tasks": {"type": "object",
                          "description": "{角色 id: 该角色的任务描述}",
                          "additionalProperties": {"type": "string"}},
                "aggregate": {"type": "boolean",
                              "description": "是否由总管合成总结，默认 true"},
                "wait_seconds": {"type": "integer",
                                 "description": f"最长等待（{_MIN_WAIT}–{_MAX_WAIT}s），默认 {_DEFAULT_WAIT}"}},
                "required": ["agents"]},
            handler=_orchestrator_dispatch, category="orchestration",
            requires_confirm=True, timeout=660,
            argcheck_example={"agents": ["researcher", "writer"],
                              "tasks": {"researcher": "调研 X 方案", "writer": "写成结论页"}}),
        SkillDef(
            name="agent_team_status",
            description=("查询内置智能体团队看板：每个角色的工位状态、完成/失败计数、工具白名单数，"
                         "并可在传 role_id 时附带该角色最近几次执行记录。"
                         "用户说'团队状态/谁在干活/智能体列表'时调用。只读，不派发任务。"),
            parameters={"type": "object", "properties": {
                "role_id": {"type": "string", "description": "要看执行记录的角色 id，可留空"},
                "limit": {"type": "integer", "description": "最近记录条数，默认 3"}},
                "required": []},
            handler=_agent_team_status, category="orchestration", timeout=15,
            argcheck_example={"role_id": "researcher", "limit": 3}),
    ]
    for d in specs:
        skills.register(d)

    names = set()
    try:
        for d in skills.get_tool_definitions():
            names.add((d.get("function") or {}).get("name") or d.get("name") or "")
    except Exception:
        logger.debug("suppressed exception")
    # 注册后发现实测：schema 分层会把部分技能挡在 get_tool_definitions 之外，
    # 因此同时校验注册表内部键，避免把"被分层挡住"误报成"注册失败"。
    try:
        internal = set(skills._skills.keys()) if isinstance(getattr(skills, "_skills", None), dict) else set()
    except Exception:
        internal = set()
    missing = [s.name for s in specs if s.name not in names and s.name not in internal]
    return {"success": not missing, "skills": [s.name for s in specs],
            "error": "" if not missing else f"注册后 schema 发现失败: {missing}"}
