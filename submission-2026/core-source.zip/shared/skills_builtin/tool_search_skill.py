# -*- coding: utf-8 -*-
"""★ W23-8: tool_search 技能

只返回工具名/描述，不执行工具。
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import json
import os

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _search(query="", top_k=5, **_kw):
    """搜索工具（只返回名/描述，不执行）"""
    try:
        from standard_mode.core.skills_registry import get_skills_registry
    except ImportError:
        import sys
        sys.path.insert(0, _ROOT)
        from standard_mode.core.skills_registry import get_skills_registry
    reg = get_skills_registry()
    defs = reg.get_tool_definitions()
    q = (query or "").lower().strip()
    results = []
    for d in defs:
        name = (d.get("function") or {}).get("name") or d.get("name") or ""
        desc = (d.get("function") or {}).get("description") or d.get("description") or ""
        if not q:
            results.append({"name": name, "description": desc[:120]})
            continue
        score = 0
        if q in name.lower():
            score += 10
        if q in desc.lower():
            score += 5
        # 关键词分词匹配
        for kw in q.split():
            if kw in name.lower():
                score += 3
            if kw in desc.lower():
                score += 1
        if score > 0:
            results.append({"name": name, "description": desc[:120], "score": score})
    # 排序
    results.sort(key=lambda x: -x.get("score", 0))
    top = results[:max(1, min(int(top_k or 5), 20))]
    lines = [f"找到 {len(results)} 个相关工具（top {len(top)}）："]
    for r in top:
        lines.append(f"- {r['name']}: {r['description']}")
    return json.dumps({"ok": True, "results": top, "total": len(results),
                       "query": q}, ensure_ascii=False)


def register(registry=None) -> dict:
    try:
        from standard_mode.core.skills_registry import SkillDef, get_skills_registry
    except ImportError:
        import sys
        sys.path.insert(0, _ROOT)
        from standard_mode.core.skills_registry import SkillDef, get_skills_registry
    reg = registry or get_skills_registry()
    reg.register(SkillDef(
        name="tool_search",
        description="搜索可用工具（只返回名/描述，不执行工具）",
        category="meta", requires_confirm=False,
        parameters={"type": "object", "properties": {
            "query": {"type": "string"},
            "top_k": {"type": "integer"},
        }, "required": ["query"]},
        handler=_search, timeout=10))
    names = set()
    try:
        for d in reg.get_tool_definitions():
            names.add((d.get("function") or {}).get("name") or d.get("name") or "")
    except Exception:
        logger.debug("suppressed exception")
    return {"success": "tool_search" in names,
            "found": ["tool_search"] if "tool_search" in names else [], "total": 1}


if __name__ == "__main__":
    print(register())
