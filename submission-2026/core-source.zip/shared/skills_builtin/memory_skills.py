# -*- coding: utf-8 -*-
"""★ W11: 记忆三技能

- memory_write(text, source, importance) → write_semantic
- memory_recall(query, top_k) → recall_episodic + recall_semantic
- memory_forget(memory_id, source) → forget_by_id / forget_by_source
- 注册 + orchestrator/researcher/coach 白名单
- 禁止：把整段对话原样写入；无来源注入
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import json
import os

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _mem():
    try:
        from shared import memory_store as _m
    except ImportError:
        import sys
        sys.path.insert(0, _ROOT)
        from shared import memory_store as _m
    return _m


def _write(text, source, importance=1.0, **_kw):
    m = _mem()
    text = str(text or "").strip()
    if not text:
        return json.dumps({"ok": False, "error": "text 不能为空"})
    src = str(source or "").strip()
    if not src:
        return json.dumps({"ok": False, "error": "source 必填（禁止无来源注入）"})
    try:
        imp = max(0.0, min(float(importance or 1.0), 5.0))
    except (TypeError, ValueError):
        imp = 1.0
    try:
        rows = m.write_semantic(text, source=src, importance=imp)
        return json.dumps({"ok": True, "count": len(rows),
                           "ids": [r.get("id") for r in rows][:5]}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"ok": False, "error": f"写入失败: {str(e)[:120]}"})


def _recall(query, top_k=5, **_kw):
    m = _mem()
    q = str(query or "").strip()
    if not q:
        return json.dumps({"ok": False, "error": "query 不能为空"})
    try:
        k = max(1, min(int(top_k or 5), 20))
    except (TypeError, ValueError):
        k = 5
    try:
        epi = m.recall_episodic(q, top_k=k)
        sem = m.recall_semantic(q, top_k=k)
        return json.dumps({"ok": True, "episodic": epi, "semantic": sem,
                           "total": len(epi) + len(sem)}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"ok": False, "error": f"召回失败: {str(e)[:120]}"})


def _forget(memory_id="", source="", **_kw):
    m = _mem()
    mid = str(memory_id or "").strip()
    src = str(source or "").strip()
    try:
        if mid:
            ok = m.forget_by_id(mid)
            return json.dumps({"ok": bool(ok), "forgotten": mid}, ensure_ascii=False)
        if src:
            if hasattr(m, "forget_by_source"):
                ok = m.forget_by_source(src)
                return json.dumps({"ok": bool(ok), "source": src}, ensure_ascii=False)
            return json.dumps({"ok": False, "error": "forget_by_source 不可用"})
        return json.dumps({"ok": False, "error": "需要 memory_id 或 source"})
    except Exception as e:
        return json.dumps({"ok": False, "error": f"删除失败: {str(e)[:120]}"})


def register(registry=None) -> dict:
    try:
        from standard_mode.core.skills_registry import SkillDef, get_skills_registry
    except ImportError:
        try:
            from core.skills_registry import SkillDef, get_skills_registry
        except ImportError:
            return {"success": False, "error": "skills_registry 不可用"}
    reg = registry or get_skills_registry()
    specs = [
        ("memory_write", "写入语义记忆（source 必填，importance 0-5）",
         {"text": {"type": "string"}, "source": {"type": "string"},
          "importance": {"type": "number"}}, ["text", "source"], _write),
        ("memory_recall", "召回记忆（情景 + 语义）",
         {"query": {"type": "string"}, "top_k": {"type": "integer"}},
         ["query"], _recall),
        ("memory_forget", "删除记忆（按 id 或 source）",
         {"memory_id": {"type": "string"}, "source": {"type": "string"}},
         [], _forget),
    ]
    for name, desc, props, required, handler in specs:
        reg.register(SkillDef(
            name=name, description=desc,
            parameters={"type": "object", "properties": props, "required": required},
            handler=handler, category="memory", requires_confirm=False, timeout=30))
    names = set()
    try:
        for d in reg.get_tool_definitions():
            names.add((d.get("function") or {}).get("name") or d.get("name") or "")
    except Exception:
        logger.debug("suppressed exception")
    found = [n for n, _, _, _, _ in specs if n in names]
    return {"success": len(found) == len(specs), "found": found, "total": len(specs)}


if __name__ == "__main__":
    print(register())
