# -*- coding: utf-8 -*-
"""★ D6-02: RAG 知识库管线（真 embedding + 引用溯源 + 哈希去重）。

- kb_upload：txt/md/pdf/docx → 切块（500 字 / 50 重叠）→ embedding → 入库
  元数据：来源文件名 / 块号 / 内容哈希（重复上传按哈希去重）
- kb_query：检索 + 引用溯源（[来源: 文件名#块号]）
- 存储：sqlite（stdlib，无新增依赖）；ChromaDB 可选（未装则用内置余弦检索）
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import re
import sqlite3
from typing import Dict, List, Optional

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DEFAULT_KB_DIR = os.path.join(_ROOT, "data", "rag_kb")
DEFAULT_DB = os.path.join(DEFAULT_KB_DIR, "rag.db")

CHUNK_SIZE = 500
CHUNK_OVERLAP = 50


# ── 读取 ──
def read_doc(path: str) -> str:
    """读取 txt/md/pdf/docx 文本；不支持的格式抛 ValueError。"""
    ext = os.path.splitext(path)[1].lower()
    if ext in (".txt", ".md", ".markdown", ".csv", ".json", ".log"):
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return f.read()
    if ext == ".pdf":
        try:
            import fitz  # PyMuPDF
        except ImportError:
            raise ValueError("PDF 读取需 PyMuPDF")
        doc = fitz.open(path)
        try:
            return "\n".join(p.get_text() for p in doc)
        finally:
            doc.close()
    if ext == ".docx":
        try:
            import docx  # python-docx
        except ImportError:
            raise ValueError("DOCX 读取需 python-docx")
        d = docx.Document(path)
        return "\n".join(p.text for p in d.paragraphs)
    raise ValueError(f"不支持的格式: {ext}")


# ── 切块 ──
def chunk_text(text: str, size: int = CHUNK_SIZE,
               overlap: int = CHUNK_OVERLAP) -> List[str]:
    """按字符切块（size 字 / overlap 重叠）；空文本返回空列表。"""
    t = re.sub(r"\n{3,}", "\n\n", (text or "").strip())
    if not t:
        return []
    out: List[str] = []
    i = 0
    step = max(1, size - overlap)
    while i < len(t):
        piece = t[i:i + size].strip()
        if piece:
            out.append(piece)
        i += step
    return out


def _sha(s: str) -> str:
    return hashlib.sha256((s or "").encode("utf-8")).hexdigest()[:16]


# ── 存储 ──
def _conn(db_path: str):
    os.makedirs(os.path.dirname(db_path) or ".", exist_ok=True)
    c = sqlite3.connect(db_path)
    c.row_factory = sqlite3.Row
    c.execute("""CREATE TABLE IF NOT EXISTS rag_chunk(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        source TEXT NOT NULL,
        chunk_idx INTEGER NOT NULL,
        content TEXT NOT NULL,
        content_hash TEXT NOT NULL,
        embedding TEXT NOT NULL,
        dim INTEGER NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(source, content_hash))""")
    return c


def _cos(a, b) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(x * x for x in b))
    if na == 0 or nb == 0:
        return 0.0
    return sum(x * y for x, y in zip(a, b)) / (na * nb)


def kb_upload(path: str, db_path: str = DEFAULT_DB,
              source: str = None) -> Dict:
    """上传文档 → 切块 → embedding → 入库（哈希去重）。"""
    if not os.path.exists(path):
        return {"ok": False, "error": f"文件不存在: {path}"}
    src = source or os.path.basename(path)
    try:
        text = read_doc(path)
    except Exception as e:
        return {"ok": False, "error": str(e)}
    chunks = chunk_text(text)
    if not chunks:
        return {"ok": False, "error": "文档为空或无可切内容"}

    from shared.llm.embedder import get_embedder
    emb = get_embedder()
    vecs = emb.embed_batch(chunks)

    c = _conn(db_path)
    try:
        added = dup = 0
        for i, (piece, vec) in enumerate(zip(chunks, vecs)):
            h = _sha(piece)
            if c.execute("SELECT 1 FROM rag_chunk WHERE source=? AND content_hash=?",
                         (src, h)).fetchone():
                dup += 1
                continue
            c.execute(
                "INSERT INTO rag_chunk(source,chunk_idx,content,content_hash,"
                "embedding,dim) VALUES(?,?,?,?,?,?)",
                (src, i, piece, h, json.dumps(vec), len(vec)))
            added += 1
        c.commit()
        return {"ok": True, "source": src, "chunks": len(chunks),
                "added": added, "duplicated": dup,
                "degraded": getattr(emb, "degraded", False)}
    finally:
        c.close()


def kb_list(db_path: str = DEFAULT_DB) -> List[Dict]:
    c = _conn(db_path)
    try:
        rows = c.execute(
            "SELECT source, COUNT(*) n, MAX(created_at) last FROM rag_chunk "
            "GROUP BY source ORDER BY last DESC").fetchall()
        return [{"source": r["source"], "chunks": r["n"], "last": r["last"]}
                for r in rows]
    finally:
        c.close()


def kb_delete(source: str, db_path: str = DEFAULT_DB) -> Dict:
    c = _conn(db_path)
    try:
        cur = c.execute("DELETE FROM rag_chunk WHERE source=?", (source,))
        c.commit()
        return {"ok": True, "removed": cur.rowcount}
    finally:
        c.close()


def kb_query(query: str, top_k: int = 3, db_path: str = DEFAULT_DB) -> Dict:
    """检索 + 引用溯源：答案附 [来源: 文件名#块号]。"""
    c = _conn(db_path)
    try:
        rows = c.execute("SELECT source,chunk_idx,content,embedding,dim "
                         "FROM rag_chunk").fetchall()
    finally:
        c.close()
    if not rows:
        return {"ok": True, "answer": "知识库为空", "citations": []}

    from shared.llm.embedder import get_embedder
    emb = get_embedder()
    qv = emb.embed(query)
    scored = []
    for r in rows:
        try:
            v = json.loads(r["embedding"])
        except Exception:
            continue
        s = _cos(qv, v)
        scored.append((s, r))
    scored.sort(key=lambda x: x[0], reverse=True)
    top = scored[:max(1, int(top_k))]

    citations = []
    for s, r in top:
        citations.append({
            "source": r["source"], "chunk": r["chunk_idx"] + 1,
            "score": round(float(s), 4),
            "ref": f"[{r['source']}#{r['chunk_idx'] + 1}]",
            "excerpt": (r["content"] or "")[:120],
        })
    if citations:
        answer = "；".join(f"{c['excerpt']}（{c['ref']}）" for c in citations)
    else:
        answer = "无匹配"
    return {"ok": True, "answer": answer, "citations": citations,
            "degraded": getattr(emb, "degraded", False)}


def kb_rebuild(db_path: str = DEFAULT_DB) -> Dict:
    """删库重建（幂等）：清空所有块。"""
    c = _conn(db_path)
    try:
        c.execute("DELETE FROM rag_chunk")
        c.commit()
        return {"ok": True, "removed_all": True}
    finally:
        c.close()


__all__ = ["read_doc", "chunk_text", "kb_upload", "kb_query", "kb_list",
           "kb_delete", "kb_rebuild", "CHUNK_SIZE", "CHUNK_OVERLAP"]
