# -*- coding: utf-8 -*-
"""★ D6-01: 真 embedding 层（Ollama /api/embeddings）。

- 默认模型 nomic-embed-text（768 维），配置可换
- 批量化：Ollama 无批量端点 → 并发线程池批处理
- 维度落盘校验：返回维度与期望不符即显式报错并降级
- 降级链：Ollama 不可用/请求失败 → TF-IDF（日志显式标注，不静默）
"""
from __future__ import annotations

import logging
import os
from concurrent.futures import ThreadPoolExecutor
from typing import List, Optional

logger = logging.getLogger(__name__)

DEFAULT_MODEL = "nomic-embed-text"
DEFAULT_BASE_URL = "http://127.0.0.1:11434"
DEFAULT_DIM = 768


def _requests():
    try:
        import requests
        return requests
    except ImportError:
        return None


class Embedder:
    """Ollama embedding 客户端（带 TF-IDF 降级）。"""

    def __init__(self, model: str = DEFAULT_MODEL,
                 base_url: str = DEFAULT_BASE_URL,
                 dim: int = DEFAULT_DIM,
                 timeout: int = 30,
                 batch_workers: int = 4):
        self.model = model
        self.base_url = (base_url or DEFAULT_BASE_URL).rstrip("/")
        self.dim = int(dim)
        self.timeout = timeout
        self.batch_workers = max(1, int(batch_workers))
        self._req = _requests()
        self._fallback = None
        self._available = False
        self.degraded = False
        if self._req is None:
            logger.warning("[Embedder] requests 未安装 → 降级 TF-IDF")
        else:
            self._available = self._check_available()
        if not self._available:
            self.degraded = True
            logger.warning("[Embedder] Ollama 不可用/模型缺失 → 降级 TF-IDF（非静默）")

    # ── 健康检查 ──
    def _check_available(self) -> bool:
        try:
            r = self._req.get(f"{self.base_url}/api/tags", timeout=5)
            if r.status_code != 200:
                return False
            names = [m.get("name", "") for m in r.json().get("models", [])]
            base = self.model.split(":")[0]
            return any(n == self.model or n.split(":")[0] == base for n in names)
        except Exception as e:
            logger.info("[Embedder] 健康检查失败: %s", e)
            return False

    def available(self) -> bool:
        return self._available

    def _fallback_model(self):
        if self._fallback is None:
            from shared.vector_database import TFIDFEmbeddingModel
            self._fallback = TFIDFEmbeddingModel()
        return self._fallback

    # ── 单条 ──
    def embed(self, text: str) -> List[float]:
        if not self._available:
            return self._fallback_model().embed(text)
        try:
            r = self._req.post(
                f"{self.base_url}/api/embeddings",
                json={"model": self.model, "prompt": text},
                timeout=self.timeout,
            )
            if r.status_code == 200:
                vec = r.json().get("embedding")
                if isinstance(vec, list) and vec:
                    if len(vec) != self.dim:
                        logger.warning(
                            "[Embedder] 维度不符：期望 %d 实得 %d → 降级 TF-IDF",
                            self.dim, len(vec))
                        self.degraded = True
                        return self._fallback_model().embed(text)
                    return [float(x) for x in vec]
            logger.warning("[Embedder] HTTP %s → 降级 TF-IDF", r.status_code)
        except Exception as e:
            logger.warning("[Embedder] 请求异常 %s → 降级 TF-IDF", e)
        self.degraded = True
        return self._fallback_model().embed(text)

    # ── 批量 ──
    def embed_batch(self, texts: List[str], batch_size: int = 16) -> List[List[float]]:
        """批量化：按 batch_size 分块，块内并发（Ollama 无批量端点）。"""
        texts = list(texts or [])
        if not texts:
            return []
        if not self._available:
            return self._fallback_model().embed_batch(texts)
        out: List[Optional[List[float]]] = [None] * len(texts)
        with ThreadPoolExecutor(max_workers=self.batch_workers) as ex:
            for start in range(0, len(texts), max(1, batch_size)):
                chunk = texts[start:start + batch_size]
                futs = {ex.submit(self.embed, t): start + i
                        for i, t in enumerate(chunk)}
                for f, idx in futs.items():
                    try:
                        out[idx] = f.result()
                    except Exception as e:
                        logger.warning("[Embedder] 批量项失败 idx=%d: %s", idx, e)
                        out[idx] = self._fallback_model().embed(texts[idx])
        return [v if v is not None else self._fallback_model().embed(t)
                for v, t in zip(out, texts)]


_DEFAULT: Optional[Embedder] = None


def get_embedder() -> Embedder:
    """进程级单例（模型/base_url 可用 LW_EMBED_MODEL / LW_EMBED_URL 覆盖）。"""
    global _DEFAULT
    if _DEFAULT is None:
        _DEFAULT = Embedder(
            model=os.environ.get("LW_EMBED_MODEL", DEFAULT_MODEL),
            base_url=os.environ.get("LW_EMBED_URL", DEFAULT_BASE_URL),
        )
    return _DEFAULT


# ── 兼容别名（并行/历史约定：OllamaEmbedder / create_embedder）──
OllamaEmbedder = Embedder


def create_embedder(model: str = DEFAULT_MODEL, base_url: str = DEFAULT_BASE_URL,
                    dim: int = DEFAULT_DIM) -> Embedder:
    """工厂别名：返回一个新的 Embedder 实例（非单例）。"""
    return Embedder(model=model, base_url=base_url, dim=dim)


__all__ = ["Embedder", "OllamaEmbedder", "get_embedder", "create_embedder",
           "DEFAULT_MODEL", "DEFAULT_DIM"]
