# -*- coding: utf-8 -*-
"""★ D6-08: 半成品技能激活（真实现，替换占位）。

- translate：Ollama 真翻译（目标语言参数），失败降级回显 + 标注
- pdf_write / pdf_form_fields：PyMuPDF 写文本 + AcroForm 表单读取
- excel_read / excel_analyze：openpyxl 读 → 统计摘要 → 图表数据
- rolling_summary：LLM 滚动摘要（阈值触发），失败降级现行规则摘要
"""
from __future__ import annotations

import json
import logging
import os
import re
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OLLAMA_URL = os.environ.get("LW_EMBED_URL", "http://127.0.0.1:11434")
DEFAULT_CHAT_MODEL = os.environ.get("LW_CHAT_MODEL", "qwen3.5:4b-ctx8k")


def _ollama_chat(messages: List[Dict], model: str = DEFAULT_CHAT_MODEL,
                 timeout: int = 60) -> Optional[str]:
    try:
        import requests
        r = requests.post(f"{OLLAMA_URL}/api/chat",
                          json={"model": model, "messages": list(messages),
                                "stream": False}, timeout=timeout)
        if r.status_code == 200:
            return r.json().get("message", {}).get("content", "")
    except Exception as e:  # noqa: BLE001
        logger.warning("[activate] Ollama chat 失败: %s", e)
    return None


# ── ① 翻译 ──
def translate(text: str, target_lang: str = "英语",
              model: str = DEFAULT_CHAT_MODEL) -> Dict:
    """真翻译（Ollama）；失败降级为「原文 + 标注」，不假造译文。"""
    out = _ollama_chat([
        {"role": "system",
         "content": f"你是专业翻译。把用户文本翻译成{target_lang}，只输出译文，"
                    f"不要解释、不要加引号。"},
        {"role": "user", "content": str(text or "")},
    ], model=model)
    if out and out.strip():
        return {"ok": True, "text": out.strip(), "engine": "ollama",
                "target": target_lang, "degraded": False}
    return {"ok": True, "text": str(text or ""), "engine": "passthrough",
            "target": target_lang, "degraded": True,
            "reason": "Ollama 不可用或空回复（未假造译文）"}


# ── ② PDF 写 / 表单读 ──
def pdf_write(path: str, lines: List[str], title: str = "") -> Dict:
    """用 PyMuPDF 写简单文本 PDF（每行一段）。"""
    try:
        import fitz  # PyMuPDF
    except ImportError:
        return {"ok": False, "error": "PyMuPDF 未安装"}
    try:
        os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
        doc = fitz.open()
        page = doc.new_page()
        y = 60

        def _font(t: str) -> str:
            # PyMuPDF 内置 CJK 字体，中文必须指定，否则渲染为点
            return "china-s" if any("\u4e00" <= ch <= "\u9fff" for ch in str(t)) else "helv"

        if title:
            page.insert_text((50, y), str(title), fontsize=15, fontname=_font(title))
            y += 28
        for ln in lines or []:
            if y > 780:
                page = doc.new_page()
                y = 60
            page.insert_text((50, y), str(ln), fontsize=11, fontname=_font(ln))
            y += 18
        doc.save(path)
        doc.close()
        return {"ok": True, "path": path, "pages": 1 + len(lines) // 40,
                "lines": len(lines or [])}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": str(e)[:200]}


def pdf_form_fields(path: str) -> Dict:
    """读取 PDF AcroForm 表单字段（widget 名 + 当前值）。"""
    try:
        import fitz
    except ImportError:
        return {"ok": False, "error": "PyMuPDF 未安装"}
    try:
        doc = fitz.open(path)
        fields = []
        for page in doc:
            for w in page.widgets() or []:
                fields.append({"name": w.field_name,
                               "type": w.field_type_string,
                               "value": w.field_value})
        doc.close()
        return {"ok": True, "fields": fields, "n": len(fields)}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": str(e)[:200]}


# ── ③ Excel 读 / 分析 ──
def excel_read(path: str, sheet: Optional[str] = None) -> Dict:
    try:
        import openpyxl
    except ImportError:
        return {"ok": False, "error": "openpyxl 未安装"}
    try:
        wb = openpyxl.load_workbook(path, data_only=True)
        ws = wb[sheet] if sheet and sheet in wb.sheetnames else wb.active
        rows = list(ws.iter_rows(values_only=True))
        header = [str(c) if c is not None else "" for c in (rows[0] if rows else [])]
        data = [[("" if c is None else c) for c in r] for r in rows[1:]]
        wb.close()
        return {"ok": True, "sheet": ws.title, "header": header,
                "rows": data, "n_rows": len(data)}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": str(e)[:200]}


def excel_analyze(path: str, sheet: Optional[str] = None) -> Dict:
    """读 → 统计摘要（数值列 min/max/mean/sum）→ 图表数据。"""
    r = excel_read(path, sheet)
    if not r.get("ok"):
        return r
    header, rows = r["header"], r["rows"]
    summary = {}
    chart = {"labels": [], "series": []}
    for ci, name in enumerate(header):
        vals = [row[ci] for row in rows if ci < len(row)
                and isinstance(row[ci], (int, float))]
        if not vals:
            continue
        summary[str(name)] = {"n": len(vals), "min": min(vals), "max": max(vals),
                              "mean": round(sum(vals) / len(vals), 4),
                              "sum": round(sum(vals), 4)}
        chart["series"].append({"name": str(name), "values": vals})
    if rows:
        chart["labels"] = [str(x) for x in rows[0]]
    return {"ok": True, "sheet": r["sheet"], "summary": summary,
            "chart": chart, "n_rows": r["n_rows"]}


# ── ④ 滚动摘要 ──
def rolling_summary(messages: List[Dict], threshold: int = 20,
                    model: str = DEFAULT_CHAT_MODEL) -> Dict:
    """LLM 滚动摘要（超过 threshold 条触发）；失败降级为「规则摘要」。"""
    msgs = list(messages or [])
    if len(msgs) < threshold:
        return {"ok": True, "summary": "", "triggered": False,
                "engine": "skipped", "n": len(msgs)}
    convo = "\n".join(
        f"{m.get('role','?')}: {str(m.get('content',''))[:300]}" for m in msgs)
    out = _ollama_chat([
        {"role": "system",
         "content": "把下面的对话压缩成中文摘要（≤300 字，保留关键决策与待办）。"},
        {"role": "user", "content": convo},
    ], model=model)
    if out and out.strip():
        return {"ok": True, "summary": out.strip(), "triggered": True,
                "engine": "ollama", "n": len(msgs)}
    # 降级：规则摘要（首末各 2 条 + 计数）
    head = [f"{m.get('role','?')}: {str(m.get('content',''))[:80]}"
            for m in msgs[:2]]
    tail = [f"{m.get('role','?')}: {str(m.get('content',''))[:80]}"
            for m in msgs[-2:]]
    return {"ok": True,
            "summary": f"共 {len(msgs)} 条。开头：{' / '.join(head)}；"
                       f"结尾：{' / '.join(tail)}",
            "triggered": True, "engine": "rule_fallback", "n": len(msgs),
            "degraded": True}


__all__ = ["translate", "pdf_write", "pdf_form_fields", "excel_read",
           "excel_analyze", "rolling_summary"]
