# -*- coding: utf-8 -*-
"""shared/llm — 模型接入层（D6-01 真 embedding）。"""
from .embedder import OllamaEmbedder, create_embedder

__all__ = ["OllamaEmbedder", "create_embedder"]
