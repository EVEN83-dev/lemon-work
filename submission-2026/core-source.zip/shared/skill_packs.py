# -*- coding: utf-8 -*-
"""★ W23-8: 工具域包定义 + 懒加载过滤

3 个包：
  office:   核心 8 + 文档/表格/PPT/浏览器/任务/记忆
  finance:  office + crawl_* + quant_* + backtest_* + annotation/stats
  research: office + crawl_* + scholar/paper/citation/annotation

EngineManager 读取 LW_DOMAIN_PACK=office|finance|research|all（默认 office）
tests/bench 用 all
"""
from __future__ import annotations

import os
from typing import Dict, List, Optional, Set

# ── 核心工具（所有包共享）──
CORE_TOOLS: Set[str] = {
    "read_file", "write_file", "edit_file", "create_file", "delete_file",
    "move_file", "search_files", "grep_search", "list_directory",
    "execute_code", "math_solver", "math_plotter", "run_command",
    "todo_write", "ask_user",
}

# ── office 包 ──
# ★ 2026-11-22 修复: 补爬虫基础闭环 —— office 包原先一个 crawl_* 都没有，
#   而意图识别不命中 finance 时（如「爬虫抓一下这个页面」）默认走 office，
#   爬虫工具被整包裁光 → Agent 报「工具不在清单内」，抓取页面显示失效。
#   office 是日常主用包，超级爬虫作为核心能力必须可用。
OFFICE_TOOLS: Set[str] = CORE_TOOLS | {
    "doc_studio", "doc_generate", "doc_export",
    "table_studio", "spreadsheet", "csv_tool",
    "ppt_studio", "ppt_generate", "ppt_export",
    "browser_automation", "web_preview", "web_fetch", "web_search",
    "todo_write", "memory_write", "memory_recall", "memory_forget",
    "save_artifact", "list_artifacts",
    # ★ 2026-11-23 修复: 多 Agent 编排入口纳入 office 基础包 ——
    #   否则域包过滤把 spawn_subagent/subtask_parallel 整包裁掉，
    #   模型菜单里根本没有子代理能力（实测模型回答"工具不存在"）。
    "spawn_subagent", "subtask_parallel",
    # ★ 2026-11-23: 媒体阅读全家桶 —— PDF/图片/OCR/截图/视频理解
    #   此前这些 skill 虽已注册，但域包过滤后模型菜单一个都看不到。
    "pdf_reader", "image_analyzer", "image_processor", "ocr_reader",
    "screenshot_qa", "vision_analyze", "video_reader",
    # 爬虫基础闭环（抓取 → 看页 → 导出）
    "crawl_start", "crawl_agentic", "crawl_pause", "crawl_resume", "crawl_stop",
    "crawl_status", "crawl_pages", "crawl_page", "crawl_export", "crawl_stats",
}

# ── 银行工具（remote_bank_* —— 数字银行沙箱 :8090 共 35 技能）──
# ★ 2026-11-22 修复: 域包三清单原本一个 remote_bank_* 都没有，
#   银行类指令（打开银行账户/转账/查余额）被默认 office 包 200→10 裁剪，
#   Agent 报「remote_bank_* 均不在当前工具清单内」→ 转账全程未执行。
BANK_TOOLS: Set[str] = {
    "remote_bank_health", "remote_bank_accounts", "remote_bank_query_balance",
    "remote_bank_transfer", "remote_bank_reverse", "remote_bank_transactions",
    "remote_bank_audit", "remote_bank_risk_events", "remote_bank_reconcile",
    "remote_bank_compound", "remote_bank_products", "remote_bank_subscriptions",
    "remote_bank_menu", "remote_loan_list", "remote_loan_apply",
    "remote_loan_repay", "remote_fund_list", "remote_fund_buy",
    "remote_stock_list", "remote_stock_kline", "remote_stock_trade",
    "remote_bank_holdings", "remote_bank_events", "remote_bank_deposits",
    "remote_bank_social", "remote_find_account", "remote_transfer_schedule",
    "remote_transfer_aa", "remote_bill_analysis", "remote_wealth_advisor",
    "remote_card_manage", "remote_subscription_cancel", "remote_mall",
    "remote_bank_console", "remote_bank_navigate",
}

# ── finance 包（银行/贷款/基金/股票都属于金融域）──
FINANCE_TOOLS: Set[str] = OFFICE_TOOLS | BANK_TOOLS | {
    "crawl_start", "crawl_agentic", "crawl_pause", "crawl_resume", "crawl_stop",
    "crawl_status", "crawl_pages", "crawl_page", "crawl_export",
    "crawl_annotate", "crawl_annotations", "crawl_annotation_update",
    "crawl_annotation_delete", "crawl_autotag", "crawl_stats",
    "crawl_watch_set", "crawl_watch_eval", "crawl_schedule",
    "crawl_rule_set", "crawl_rule_health", "crawl_prune", "crawl_ops_status",
    "quant_quality_check", "quant_pit_query",
    "backtest_run", "backtest_cross_section",
}

# ── research 包 ──
RESEARCH_TOOLS: Set[str] = OFFICE_TOOLS | {
    "crawl_start", "crawl_agentic", "crawl_pause", "crawl_resume", "crawl_stop",
    "crawl_status", "crawl_pages", "crawl_page", "crawl_export",
    "crawl_annotate", "crawl_annotations", "crawl_annotation_update",
    "crawl_annotation_delete", "crawl_autotag", "crawl_stats",
    "scholar_search", "paper_read", "citation_format",
    "annotation", "annotation_stats",
}

PACKS: Dict[str, Set[str]] = {
    "office": OFFICE_TOOLS,
    "finance": FINANCE_TOOLS,
    "research": RESEARCH_TOOLS,
}


def get_pack(name: Optional[str] = None) -> Set[str]:
    """获取域包工具集（all=全部）"""
    name = (name or os.environ.get("LW_DOMAIN_PACK", "office")).strip().lower()
    if name == "all":
        all_tools: Set[str] = set()
        for s in PACKS.values():
            all_tools |= s
        return all_tools
    return PACKS.get(name, OFFICE_TOOLS)


def filter_tools(tools: List[Dict], pack: Optional[str] = None) -> List[Dict]:
    """按域包过滤工具定义列表"""
    allowed = get_pack(pack)
    out = []
    for t in tools:
        name = (t.get("function") or {}).get("name") or t.get("name") or ""
        if name in allowed:
            out.append(t)
    return out


def pack_menu_count(pack: Optional[str] = None) -> int:
    return len(get_pack(pack))


if __name__ == "__main__":
    import json
    print(json.dumps({k: len(v) for k, v in PACKS.items()}, ensure_ascii=False))
