# -*- coding: utf-8 -*-
"""CompanyServer — 公司模式 HTTP API（窗口3·公司模式）。

端口（任务书第 6 条）：8801-8805 依次尝试绑定，取第一个可用口。
鉴权 require_auth：启动时生成随机 token，落盘 state/company/server_token.json
（内容 {port, token, ts}）；请求需带 `Authorization: Bearer <token>` 或
`?token=<token>`（SSE 的 EventSource 无法自定义头，走查询参数）。

API（任务书第 7/8 条，统一信封 {ok, data, error}）：
  GET  /api/company/state      UI 快照（board/org/tasks/dag/approvals/artifacts/
                               sessions/config/stats/transport）
  GET  /api/company/roster     花名册（= state.board，9 工位真档案）
  GET  /api/company/agents     工位清单
  GET  /api/company/tasks      任务清单（DAG 全量）
  GET  /api/company/approvals  审批单清单
  GET  /api/company/artifacts  产物清单（?kind=&role_id= 过滤）
  GET  /api/company/config     配置（全局模型/每员工覆盖/白名单/权限矩阵/预算）
  GET  /api/company/messages   会话收件箱（?session_id=&since=）
  GET  /api/company/stats      KPI 聚合（units/agents/rejected/rules/broken/…）
  POST /api/company/start      开张（body {brief, start_instances?}）
  POST /api/company/stop       停转
  POST /api/company/assign     派发（body {role_id, task, skills?}）
  POST /api/company/approve    批准（body {approval_id, approver, reason}；双闸校验）
  POST /api/company/reject     驳回（body {approval_id, approver, reason}）
  POST /api/company/complete   任务收束（body {task_id, result, error, tokens}）
  POST /api/company/upload     上传策划书 → brief artifact + CHIEF 拆解
  POST /api/company/message    信件（bus.send 信封；越权 403 + audit）
  POST /api/company/config     配置变更（默认进 owner 审批队列）
  GET  /api/company/events     SSE 事件流（run/agent/task/approval/artifact/
                             message/audit，带 ts 与真实耗时；15s 心跳注释行）

两种运行方式：
  · 独立进程：python -m shared.company.server [--port 8801]
  · 进程内（GUI 面板旁路）：start_company_server(service) → 同一 CompanyService
    单例上开 HTTP 线程，页面 SSE 与桥轮询拿到同一份真实状态。
"""

import logging
logger = logging.getLogger(__name__)
import argparse
import json
from collections import deque as _deque
import secrets
import sys
import threading
import time
import queue as _queue
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Dict, Optional

_REPO_ROOT = None   # 由 main/start_company_server 按需注入 sys.path
_PORTS = (8801, 8802, 8803, 8804, 8805)
_TOKEN_PATH_REL = ("state", "company", "server_token.json")
_SSE_HEARTBEAT_SEC = 15.0


def _ensure_repo_root() -> str:
    global _REPO_ROOT
    if _REPO_ROOT is None:
        import os
        _REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(
            os.path.abspath(__file__))))
        if _REPO_ROOT not in sys.path:
            sys.path.insert(0, _REPO_ROOT)
    return _REPO_ROOT


def _token_file() -> str:
    import os
    root = _ensure_repo_root()
    return os.path.join(root, *_TOKEN_PATH_REL)


def _load_or_create_token(port: int) -> str:
    import os
    path = _token_file()
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if data.get("token"):
            data["port"] = port  # 端口可能轮换，令牌沿用
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False)
            return str(data["token"])
    except Exception:
        logger.debug("suppressed exception")
    token = secrets.token_hex(16)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"port": port, "token": token, "ts": time.time()}, f,
                  ensure_ascii=False, indent=1)
    return token


class _SSEClient:
    """单个 SSE 订阅者：有界队列，慢消费者丢最旧（不阻塞事件源线程）。"""

    def __init__(self):
        self.q: "_queue.Queue[Optional[Dict]]" = _queue.Queue(maxsize=256)

    def push(self, event: Dict[str, Any]) -> None:
        try:
            self.q.put_nowait(event)
        except _queue.Full:
            try:
                self.q.get_nowait()
                self.q.put_nowait(event)
            except Exception:
                logger.debug("suppressed exception")


class CompanyServer:
    """进程内可复用的 HTTP 服务壳（真实绑定端口 + 真实 token）。"""

    def __init__(self, service, port: Optional[int] = None):
        # ★ 收口项 36: SSE 事件环形缓冲（断线重连 last_ts 补发不丢事件）
        self._event_buffer = _deque(maxlen=500)
        _ensure_repo_root()
        self._service = service
        self._httpd: Optional[ThreadingHTTPServer] = None
        self._thread: Optional[threading.Thread] = None
        self._sse_clients: list = []
        self._sse_lock = threading.Lock()
        self._token = ""
        self.port = None
        self._preferred_port = port

    # ── SSE 广播：订阅 CompanyService 事件流 ──
    def _on_service_event(self, event: Dict[str, Any]) -> None:
        # ★ 收口项 36: 事件入环形缓冲（供断线重连按 last_ts 补发）
        try:
            self._event_buffer.append(dict(event))
        except Exception:
            logger.debug("suppressed exception")
        with self._sse_lock:
            clients = list(self._sse_clients)
        for c in clients:
            c.push(event)

    def sse_register(self) -> _SSEClient:
        c = _SSEClient()
        with self._sse_lock:
            self._sse_clients.append(c)
        return c

    def sse_unregister(self, c: _SSEClient) -> None:
        with self._sse_lock:
            try:
                self._sse_clients.remove(c)
            except ValueError:
                logger.debug("suppressed exception")

    def start(self) -> bool:
        """绑定 8801-8805 首个可用口；成功后把传输信息注入 service（SSE 可用）。"""
        handler = self._make_handler()
        ports = (self._preferred_port,) if self._preferred_port else _PORTS
        last_err = ""
        for p in ports:
            try:
                self._httpd = ThreadingHTTPServer(("127.0.0.1", p), handler)
                self.port = p
                break
            except OSError as e:
                last_err = str(e)
                continue
        if self._httpd is None:
            print(f"[CompanyServer] 8801-8805 全部绑定失败: {last_err}")
            return False
        self._token = _load_or_create_token(self.port)
        self._service.on_event(self._on_service_event)
        self._service.set_transport(self.port, self._token)
        self._thread = threading.Thread(target=self._httpd.serve_forever,
                                        daemon=True, name="company_server")
        self._thread.start()
        print(f"[CompanyServer] 已监听 http://127.0.0.1:{self.port} "
              f"(token 落盘 {_token_file()})")
        return True

    def stop(self) -> None:
        if self._httpd is not None:
            try:
                self._httpd.shutdown()
                self._httpd.server_close()
            except Exception:
                logger.debug("suppressed exception")
            self._httpd = None
        self._service.set_transport(None, None)

    # ── 请求处理器 ──
    def _make_handler(self):
        server = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, fmt, *args):  # 静默默认访问日志
                pass

            # ── 工具 ──
            def _send_json(self, obj: Dict[str, Any], status: int = 200) -> None:
                body = json.dumps(obj, ensure_ascii=False, default=str).encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Access-Control-Allow-Headers",
                                 "Content-Type, Authorization")
                self.send_header("Access-Control-Allow-Methods",
                                 "GET, POST, OPTIONS")
                self.end_headers()
                self.wfile.write(body)

            def _authorized(self) -> bool:
                auth = self.headers.get("Authorization", "")
                if auth.startswith("Bearer ") and auth[7:].strip() == server._token:
                    return True
                q = self.path.split("?", 1)
                if len(q) == 2:
                    from urllib.parse import parse_qs, urlparse
                    params = parse_qs(urlparse("?" + q[1]).query)
                    tok = (params.get("token") or [""])[0]
                    if tok and tok == server._token:
                        return True
                return False

            def _route(self) -> str:
                return self.path.split("?", 1)[0]

            def _read_body(self) -> Dict[str, Any]:
                try:
                    n = int(self.headers.get("Content-Length") or 0)
                except Exception:
                    n = 0
                if n <= 0:
                    return {}
                try:
                    return json.loads(self.rfile.read(n).decode("utf-8") or "{}")
                except Exception:
                    return {}

            def do_OPTIONS(self):  # file:// 页面跨源预检
                self.send_response(204)
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Access-Control-Allow-Headers",
                                 "Content-Type, Authorization")
                self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
                self.send_header("Content-Length", "0")
                self.end_headers()

            # ── GET ──
            def do_GET(self):
                route = self._route()
                if route == "/api/company/events":
                    self._handle_sse()
                    return
                if not self._authorized():
                    self._send_json({"ok": False, "data": None,
                                     "error": "unauthorized（缺 token 或 token 不符）"},
                                    status=401)
                    return
                svc = server._service
                try:
                    if route == "/api/company/roster":
                        data = svc.state()["board"]
                        self._send_json({"ok": True, "data": {"board": data,
                                        "count": len(data)}, "error": None})
                    elif route == "/api/company/state":
                        self._send_json({"ok": True, "data": svc.state(), "error": None})
                    elif route == "/api/company/stats":
                        self._send_json({"ok": True, "data": svc.stats(), "error": None})
                    elif route == "/api/company/agents":
                        self._send_json({"ok": True,
                                         "data": {"agents": svc.state()["board"]},
                                         "error": None})
                    elif route == "/api/company/tasks":
                        self._send_json({"ok": True,
                                         "data": {"tasks": svc.tasks()}, "error": None})
                    elif route == "/api/company/approvals":
                        self._send_json({"ok": True,
                                         "data": {"approvals": svc.approvals()},
                                         "error": None})
                    elif route == "/api/company/artifacts":
                        from urllib.parse import parse_qs, urlparse
                        params = parse_qs(urlparse(self.path).query)
                        arts = svc.artifacts(kind=(params.get("kind") or [""])[0],
                                             role_id=(params.get("role_id") or [""])[0])
                        self._send_json({"ok": True,
                                         "data": {"artifacts": arts}, "error": None})
                    elif route == "/api/company/config":
                        self._send_json({"ok": True, "data": svc.get_config(),
                                         "error": None})
                    elif route == "/api/company/handoffs":
                        # ★ 收口项 21: 文件交接区（跨会话可见，按部门隔离）
                        from urllib.parse import parse_qs, urlparse
                        params = parse_qs(urlparse(self.path).query)
                        r = svc.handoff_list(
                            viewer_role=(params.get("viewer") or [""])[0])
                        self._send_json({"ok": True, "data": r, "error": None})
                    elif route == "/api/company/messages":
                        from urllib.parse import parse_qs, urlparse
                        params = parse_qs(urlparse(self.path).query)
                        r = svc.inbox((params.get("session_id") or [""])[0],
                                      since=float((params.get("since") or ["0"])[0] or 0))
                        status = 200 if r.get("ok") else 404
                        self._send_json({"ok": bool(r.get("ok")),
                                         "data": {k: v for k, v in r.items()
                                                  if k in ("session", "messages")},
                                         "error": None if r.get("ok") else r.get("error")},
                                        status=status)
                    else:
                        self._send_json({"ok": False, "data": None,
                                        "error": f"未知路径 {route}"}, status=404)
                except Exception as e:
                    self._send_json({"ok": False, "data": None,
                                     "error": f"{type(e).__name__}: {e}"}, status=500)

            # ── POST ──
            def do_POST(self):
                route = self._route()
                if not self._authorized():
                    self._send_json({"ok": False, "data": None,
                                     "error": "unauthorized（缺 token 或 token 不符）"},
                                    status=401)
                    return
                svc = server._service
                body = self._read_body()
                try:
                    if route == "/api/company/start":
                        r = svc.create_run(brief=str(body.get("brief") or ""),
                                           start_instances=bool(body.get("start_instances")))
                    elif route == "/api/company/stop":
                        r = svc.stop()
                    elif route == "/api/company/assign":
                        r = svc.assign(role_id=str(body.get("role_id") or ""),
                                       task=str(body.get("task") or ""),
                                       brief=str(body.get("brief") or ""),
                                       skills=body.get("skills") or [])
                    elif route == "/api/company/pause":
                        r = svc.pause()
                    elif route == "/api/company/resume":
                        r = svc.resume()
                    elif route == "/api/company/approve":
                        r = svc.approve(int(body.get("approval_id") or 0),
                                        str(body.get("approver") or ""),
                                        str(body.get("reason") or ""))
                    elif route == "/api/company/reject":
                        r = svc.reject(int(body.get("approval_id") or 0),
                                       str(body.get("approver") or ""),
                                       str(body.get("reason") or ""))
                    elif route == "/api/company/complete":
                        r = svc.complete(int(body.get("task_id") or 0),
                                         result=str(body.get("result") or ""),
                                         error=str(body.get("error") or ""),
                                         tokens=int(body.get("tokens") or 0))
                    elif route == "/api/company/upload":
                        r = svc.upload_brief(name=str(body.get("name") or "brief"),
                                             content=str(body.get("content") or ""),
                                             uploaded_by=str(body.get("uploaded_by") or "owner"))
                    elif route == "/api/company/handoff":
                        # ★ 收口项 21: 交接区写入（can_handoff ACL 闸，403 语义）
                        r = svc.handoff_file(role_id=str(body.get("role_id") or ""),
                                             name=str(body.get("name") or ""),
                                             content=str(body.get("content") or ""))
                    elif route == "/api/company/message":
                        env = body.get("envelope") or body
                        r = svc.send_message(env)
                    elif route == "/api/company/config":
                        r = svc.set_config(body.get("updates") or {},
                                           via_approval=bool(body.get("via_approval", True)),
                                           requested_by=str(body.get("requested_by") or "owner"))
                    else:
                        self._send_json({"ok": False, "data": None,
                                         "error": f"未知路径 {route}"}, status=404)
                        return
                    status = 200 if r.get("ok") else 400
                    # 越权类业务拒绝按 403 语义返回（UI 据此展示"消息不等于授权"）
                    if not r.get("ok"):
                        status = int(r.get("http_status")
                                     or (403 if str(r.get("code") or "").startswith("ACL_")
                                         or r.get("code") == "BUS_MISSING_AUTHORIZATION"
                                         else 400))
                    self._send_json({"ok": bool(r.get("ok")),
                                     "data": r if r.get("ok") else None,
                                     "error": None if r.get("ok") else r.get("error")},
                                    status=status)
                except Exception as e:
                    self._send_json({"ok": False, "data": None,
                                     "error": f"{type(e).__name__}: {e}"}, status=500)

            # ── SSE ──
            def _handle_sse(self):
                if not self._authorized():
                    self._send_json({"ok": False, "data": None,
                                     "error": "unauthorized"}, status=401)
                    return
                # ★ 收口项 36: last_ts 补发 —— 断线重连先回放缓冲里 ts>last_ts 的事件
                from urllib.parse import parse_qs, urlparse
                _q = parse_qs(urlparse(self.path).query)
                last_ts = 0.0
                try:
                    last_ts = float((_q.get("last_ts") or ["0"])[0] or 0)
                except ValueError:
                    last_ts = 0.0
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream; charset=utf-8")
                self.send_header("Cache-Control", "no-cache")
                self.send_header("Connection", "keep-alive")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                if last_ts > 0:
                    replayed = 0
                    with server._sse_lock:
                        buffered = list(server._event_buffer)
                    for ev in buffered:
                        try:
                            if float(ev.get("ts") or 0) > last_ts:
                                body = json.dumps(ev, ensure_ascii=False, default=str)
                                self.wfile.write(
                                    ("data: " + body + "\n\n").encode("utf-8"))
                                replayed += 1
                        except Exception:
                            logger.debug("suppressed exception")
                    try:
                        self.wfile.write(
                            ("data: " + json.dumps(
                                {"type": "replayed", "count": replayed}) + "\n\n")
                            .encode("utf-8"))
                        self.wfile.flush()
                    except Exception:
                        logger.debug("suppressed exception")
                client = server.sse_register()
                try:
                    self.send_response(200)
                    self.send_header("Content-Type", "text/event-stream; charset=utf-8")
                    self.send_header("Cache-Control", "no-cache")
                    self.send_header("Connection", "keep-alive")
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.end_headers()
                    cur_run = server._service.current_run_summary()
                    hello = json.dumps({"type": "hello", "ts": time.time(),
                                        "run_id": (cur_run or {}).get("id")},
                                       ensure_ascii=False, default=str)
                    self.wfile.write(f"data: {hello}\n\n".encode("utf-8"))
                    self.wfile.flush()
                    last_beat = time.time()
                    while True:
                        try:
                            ev = client.q.get(timeout=1.0)
                        except _queue.Empty:
                            ev = None
                        if ev is not None:
                            body = json.dumps(ev, ensure_ascii=False, default=str)
                            self.wfile.write(f"data: {body}\n\n".encode("utf-8"))
                            self.wfile.flush()
                        elif time.time() - last_beat > _SSE_HEARTBEAT_SEC:
                            self.wfile.write(b": heartbeat\n\n")
                            self.wfile.flush()
                            last_beat = time.time()
                        # 客户端断开检测
                        if self.connection is None:
                            break
                except (ConnectionAbortedError, ConnectionResetError, OSError):
                    logger.debug("suppressed exception")
                finally:
                    server.sse_unregister(client)

        return Handler


def start_company_server(service, port: Optional[int] = None) -> Optional[CompanyServer]:
    """进程内启动（GUI 面板旁路用）；失败返回 None（不假装在线）。"""
    srv = CompanyServer(service, port=port)
    if srv.start():
        return srv
    return None


def main() -> int:
    parser = argparse.ArgumentParser(description="公司模式 HTTP API（8801-8805）")
    parser.add_argument("--port", type=int, default=None,
                        help="首选端口（缺省依次尝试 8801-8805）")
    args = parser.parse_args()
    _ensure_repo_root()
    from shared.company.service import CompanyService
    svc = CompanyService()
    srv = CompanyServer(svc, port=args.port)
    if not srv.start():
        return 1
    print("[CompanyServer] Ctrl+C 退出")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        srv.stop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
