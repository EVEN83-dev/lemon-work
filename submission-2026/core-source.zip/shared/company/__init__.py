# -*- coding: utf-8 -*-
"""shared.company — 公司模式持久层/服务/HTTP 服务（窗口3·公司模式）。

  store.py   五表 SQLite（WAL）：company_run / agent / task / event / output
  service.py CompanyService：start/stop/assign/pause/resume/state + 事件落库
  server.py  HTTP API 8801-8805（require_auth + SSE /api/company/events）
"""
