# -*- coding: utf-8 -*-
"""CompanyOrg — 公司组织层（窗口3·集群B·A9）。

从 role_system 真名册生成 **9 工位** 组织结构（禁静态 AGENTS 假数据：
每个工位的 name/duties/color/icon/白名单/预算一律来自 role_system
AgentRoleDefinition；本文件只补组织字段 reports_to/dept/level/approval_scope）。

编制（9 工位）：
  L0 CHIEF            = orchestrator   （总指挥，reports_to: owner 人类）
  L1 产品主管（product）= frontend       —— 审批权限：本部门
  L1 平台主管（platform）= backend      —— 审批权限：本部门
  L2 调研专员 researcher  / 写手 writer / 数据分析师 analyst   → product 部
  L2 测试工程师 tester    / 审查官 reviewer / 浏览器操作员 browser → platform 部
  （coach 为求职升学陪聊角色，不属公司编制 —— 编制外，见 EXCLUDED_ROLES）

权限铁律（任务书第 4/12/18 条）：
  · 同级（L2↔L2）消息只作 request，不得下达指令；
  · can_peer_message=0 / can_command=0 为公司默认位（session_acl 新列）；
  · 只有 owner（人类主体）与 L≤1（主管/总指挥）可批 approval；
  · scope=owner 的不可逆操作仅 owner 可批。
"""

from typing import Any, Dict, List, Optional, Tuple

OWNER_ID = "owner"          # 人类主体（唯一不可替代的审批方）
EXCLUDED_ROLES = ("coach",)  # 编制外角色（真实理由见模块 docstring）

# 组织规格：role_id → 组织字段（role 的档案本身来自 role_system，此处不复制）
_ORG_SPEC: Dict[str, Dict[str, Any]] = {
    "orchestrator": {
        "station": "CHIEF", "title": "总指挥", "level": 0, "dept": "command",
        "reports_to": "",                 # 直接对 owner（人类）负责
        "approval_scope": ["manager"],    # 可批 manager 级审批（不可逆仍归 owner）
        "approvable_depts": ["*"],        # 全部门
    },
    "frontend": {
        "station": "PRODUCT-LEAD", "title": "产品主管", "level": 1,
        "dept": "product", "reports_to": "orchestrator",
        "approval_scope": ["manager"], "approvable_depts": ["product"],
    },
    "backend": {
        "station": "PLATFORM-LEAD", "title": "平台主管", "level": 1,
        "dept": "platform", "reports_to": "orchestrator",
        "approval_scope": ["manager"], "approvable_depts": ["platform"],
    },
    "researcher": {
        "station": "RESEARCHER", "title": "调研专员", "level": 2,
        "dept": "product", "reports_to": "frontend",
        "approval_scope": [], "approvable_depts": [],
    },
    "writer": {
        "station": "WRITER", "title": "写手", "level": 2,
        "dept": "product", "reports_to": "frontend",
        "approval_scope": [], "approvable_depts": [],
    },
    "analyst": {
        "station": "ANALYST", "title": "数据分析师", "level": 2,
        "dept": "product", "reports_to": "frontend",
        "approval_scope": [], "approvable_depts": [],
    },
    "tester": {
        "station": "TESTER", "title": "测试工程师", "level": 2,
        "dept": "platform", "reports_to": "backend",
        "approval_scope": [], "approvable_depts": [],
    },
    "reviewer": {
        "station": "REVIEWER", "title": "审查官", "level": 2,
        "dept": "platform", "reports_to": "backend",
        "approval_scope": [], "approvable_depts": [],
    },
    "browser": {
        "station": "BROWSER-OP", "title": "浏览器操作员", "level": 2,
        "dept": "platform", "reports_to": "backend",
        "approval_scope": [], "approvable_depts": [],
    },
}

# 默认能力位（session_acl 新列的公司口径；fail-closed，主管可按需授予）
_DEFAULT_CAPS = {"can_peer_message": 0, "can_command": 0,
                 "can_approve": 0, "can_handoff": 0}


def get_org() -> Dict[str, Dict[str, Any]]:
    """9 工位组织表 = role_system 真档案 × 本文件组织字段。

    role_system 缺角色时该工位如实缺席（不补静态假人）；
    编制外角色一律剔除。返回按 level,role_id 排序的有序字典。
    """
    from shared.role_system import get_role_manager
    roles = get_role_manager().get_builtin_roles()
    out: Dict[str, Dict[str, Any]] = {}
    for rid, spec in sorted(_ORG_SPEC.items(),
                            key=lambda kv: (kv[1]["level"], kv[0])):
        role = roles.get(rid)
        if role is None:
            continue                    # role_system 无此角色 → 工位缺席，不造假
        if rid in EXCLUDED_ROLES:
            continue
        row = spec.copy()
        row.update({
            "role_id": rid,
            "name": role.name,            # 真名册姓名
            "duties": role.description,   # 真名册职责
            "color": role.color,
            "icon_svg": role.icon_svg,
            "whitelist": list(role.skill_whitelist),
            "max_token_budget": role.max_token_budget,
            "timeout_seconds": role.timeout_seconds,
            "caps": _caps_for(rid, spec),
        })
        out[rid] = row
    return out


def _caps_for(rid: str, spec: Dict[str, Any]) -> Dict[str, int]:
    """工位默认能力位：L≤1 可批可交接；同级互传/指令一律 0（铁律 18）。"""
    caps = _DEFAULT_CAPS.copy()
    if int(spec.get("level", 9)) <= 1:
        caps["can_approve"] = 1
        caps["can_handoff"] = 1
    return caps


def station_count() -> int:
    return len(get_org())


def get_station(role_id: str) -> Optional[Dict[str, Any]]:
    return get_org().get(str(role_id or ""))


def is_manager(role_id: str) -> bool:
    st = get_station(role_id)
    return bool(st and int(st["level"]) <= 1)


def manager_ids() -> List[str]:
    return [rid for rid, st in get_org().items() if int(st["level"]) <= 1]


def peer_level(role_a: str, role_b: str) -> bool:
    """是否同级（同级消息只作 request，禁指令）。"""
    a, b = get_station(role_a), get_station(role_b)
    if not a or not b:
        return False
    return int(a["level"]) == int(b["level"])


def level_of(role_id: str) -> int:
    st = get_station(role_id)
    return int(st["level"]) if st else 9     # 编制外按最低级处理（最受限）


def dept_of(role_id: str) -> str:
    st = get_station(role_id)
    return st["dept"] if st else ""


def approvable_depts(role_id: str) -> List[str]:
    st = get_station(role_id)
    return list(st["approvable_depts"]) if st else []


def can_approve(approver_id: str, scope: str,
                dept: str = "") -> Tuple[bool, str]:
    """审批权判定（任务书第 12 条铁律的唯一实现）。

    · scope='owner'（不可逆操作）→ 仅 owner 人类主体；
    · scope='manager' → owner 或 L≤1 工位（有 approvable_depts 约束）；
    · 编制外/L2/未知主体一律拒绝（fail-closed）。
    """
    who = str(approver_id or "").strip()
    sc = str(scope or "").strip()
    if sc not in ("manager", "owner"):
        return False, f"未知审批级别 scope={sc!r}（合法：manager/owner）"
    if who == OWNER_ID:
        return True, "owner 主体"
    st = get_station(who)
    if st is None:
        return False, f"{who!r} 不在公司编制内，无审批权"
    if sc == "owner":
        return False, "不可逆操作需 owner（人类）批准，工位不得代批"
    if int(st["level"]) > 1:
        return False, f"{st['title']}({who}) 为执行层，无审批权"
    if sc not in st["approval_scope"]:
        return False, f"{st['title']}({who}) 的审批范围不含 {sc!r}"
    if dept and "*" not in st["approvable_depts"] and dept not in st["approvable_depts"]:
        return False, f"{st['title']}({who}) 只能批 {st['approvable_depts']} 部门，不能跨批 {dept!r}"
    return True, f"{st['title']}({who})"


def permission_matrix() -> Dict[str, Any]:
    """权限矩阵（任务书第 14 条；UI 配置页展示的真源）。"""
    matrix = {}
    for rid, st in get_org().items():
        matrix[rid] = {
            "level": st["level"], "dept": st["dept"],
            "reports_to": st["reports_to"],
            "approval_scope": list(st["approval_scope"]),
            "approvable_depts": list(st["approvable_depts"]),
            "caps": dict(st["caps"]),
            "whitelist_count": len(st["whitelist"]),
            "max_token_budget": st["max_token_budget"],
        }
    return {"owner": {"level": -1, "dept": "*",
                      "approval_scope": ["manager", "owner"],
                      "approvable_depts": ["*"],
                      "caps": {"can_peer_message": 0, "can_command": 1,
                               "can_approve": 1, "can_handoff": 1}},
            **matrix}
