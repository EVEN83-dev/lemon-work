# -*- coding: utf-8 -*-
"""★ 会话级主从网格 —— 子会话执行链。

分工（与 shared/agent_orchestrator / engine_manager 的既有分工保持一致）：
  - 队列账本与状态：复用 SubAgentOrchestrator（本文件不自建第二本账）
  - 真实执行：优先走 engine_manager.spawn_subagent → agent_chat_guarded 统一链
    （白名单/预算/超时由那一层强制；需 env LEMON_SESSION_MESH_ENGINE=1 显式开启，
     因为它要求真实引擎在线）；引擎不可用时降级为本地执行器 —— 结果内容全部
     取自任务 payload 与运行时测量（耗时/库内计数），不造演示假数。
  - 回传：结果一律走"子→主 report"同一代码路径，写主会话收件箱前必须先过
    shared/session_acl.can_child_write_master（kind='result' 铁律），越权记审计。

下发一次 = orchestrator.submit_task 一次 + 后台线程收敛一次（complete_task 回写账本）。
"""
from __future__ import annotations

import os
import threading
import time
from typing import Any, Dict, Optional

from session_mesh import store
from shared import session_acl
from shared.skill_audit import record_skill_audit

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_LOCK = threading.Lock()
_ORCHESTRATOR = None          # 进程内单例（本模块是唯一持有者）
_TASKS: Dict[str, Dict[str, Any]] = {}   # dispatch_id → 运行时状态（server 查询用）

_ENGINE_ENV = "LEMON_SESSION_MESH_ENGINE"   # 显式开启真实引擎执行链
_ENGINE_POLL_SECONDS = 120                  # 引擎结果轮询上限（秒）


def _artifact_dir() -> str:
    """产物落盘目录（结果卡"产物链接"指向这里）；env 可覆盖（测试隔离用）。"""
    env = os.environ.get("LW_SESSION_MESH_ARTIFACT_DIR", "").strip()
    if env:
        return env
    return os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "outputs", "session_mesh")


def get_orchestrator():
    """SubAgentOrchestrator 进程内单例（懒建；谁先用到谁触发）。"""
    global _ORCHESTRATOR
    with _LOCK:
        if _ORCHESTRATOR is None:
            from standard_mode.core.sub_agent_orchestrator import SubAgentOrchestrator
            _ORCHESTRATOR = SubAgentOrchestrator()
        return _ORCHESTRATOR


def get_dispatch_state(dispatch_id: str) -> Optional[Dict[str, Any]]:
    return dict(_TASKS.get(dispatch_id) or None)


def list_dispatch_states() -> Dict[str, Dict[str, Any]]:
    return {k: dict(v) for k, v in _TASKS.items()}


def _describe_task(payload: Dict[str, Any]) -> str:
    """把任务 payload 压成 orchestrator 队列描述（含目标/截止，不掺硬编码文案数字）。"""
    goal = str(payload.get("goal") or payload.get("task") or payload.get("title") or "")
    deadline = str(payload.get("deadline") or "")
    note = str(payload.get("note") or "")
    parts = [p for p in ("[session-mesh 子会话任务]", goal,
                         ("截止: " + deadline) if deadline else "",
                         note) if p]
    return "\n".join(parts)


def _write_artifact(dispatch_id: str, payload: Dict[str, Any],
                    summary: str, elapsed: float) -> str:
    """产物落盘（真实运行时数据：目标原文/耗时/收件统计），返回相对项目根的链接。"""
    try:
        artifact_dir = _artifact_dir()
        os.makedirs(artifact_dir, exist_ok=True)
        path = os.path.join(artifact_dir, f"{dispatch_id}.md")
        meta = store.get_session(payload.get("child") or "") or {}
        with open(path, "w", encoding="utf-8") as f:
            f.write(f"# 会话任务产物 · {dispatch_id}\n\n"
                    f"- 目标: {payload.get('goal') or ''}\n"
                    f"- 截止: {payload.get('deadline') or '（未设定）'}\n"
                    f"- 子会话: {payload.get('child') or ''}"
                    f"（{meta.get('title') or ''}）\n"
                    f"- 主会话: {payload.get('master') or ''}\n"
                    f"- 实际耗时: {elapsed:.3f}s\n"
                    f"- 执行链: {payload.get('_chain') or 'local'}\n\n"
                    f"## 结果摘要\n\n{summary}\n")
        try:
            rel = os.path.relpath(path, _PROJECT_ROOT)     # 常态：同盘 → 相对链接
        except ValueError:                                 # 跨盘（如临时目录在 C:）
            rel = path
        return rel.replace("\\", "/")

    except OSError as e:
        # 产物写失败不阻断回传，但必须留痕（不是静默）
        record_skill_audit(tool_name="session_mesh_artifact", args={"dispatch": dispatch_id},
                           success=False, error=str(e), source="session_mesh",
                           session_id=str(payload.get("child") or ""))
        return ""


def _run_with_engine(description: str, child_session: str) -> Optional[str]:
    """真实引擎链（env 显式开启才走）。返回结果文本或 None（走降级）。"""
    if os.environ.get(_ENGINE_ENV, "").strip() != "1":
        return None
    try:
        from shared.engine_manager import EngineManager
        em = EngineManager()
        task_id = em.spawn_subagent(name=child_session, task_description=description)
        if not task_id:
            return None
        deadline = time.time() + _ENGINE_POLL_SECONDS
        res = None
        while time.time() < deadline:
            res = em.get_subagent_result(task_id)
            # ★ 状态词表断链修复：引擎实发 "completed"（engine_manager 子代理结果），
            #   此前只认 "done" → 永不匹配 → 恒轮询到超时 → 静默回落本地执行器，
            #   对外却宣称走"真实引擎链"。词表按引擎真实取值收敛。
            if res and res.get("status") in ("done", "completed", "success",
                                             "failed", "error", "timeout"):
                if res.get("status") in ("done", "completed", "success"):
                    return str(res.get("content") or "")
                record_skill_audit(
                    tool_name="session_mesh_engine",
                    args={"child": child_session, "status": res.get("status")},
                    success=False, error=str(res.get("error")
                                             or res.get("content") or "")[:200],
                    source="session_mesh", session_id=child_session)
                return None
            time.sleep(0.5)
        record_skill_audit(
            tool_name="session_mesh_engine",
            args={"child": child_session, "status": "poll_expired"},
            success=False,
            error=f"引擎回执轮询超时 {_ENGINE_POLL_SECONDS}s（最后状态 "
                  f"{(res or {}).get('status')}）",
            source="session_mesh", session_id=child_session)
        return None
    except Exception as e:
        record_skill_audit(tool_name="session_mesh_engine", args={"child": child_session},
                           success=False, error=str(e), source="session_mesh",
                           session_id=child_session)
        return None


def _report_result(child: str, master: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    """回传收口：与 HTTP report 路由同一条 ACL 铁律（kind='result' 才放行）。"""
    allowed, code = session_acl.check("child_write_master", child, master, kind="result")
    if not allowed:
        return {"ok": False, "code": code}
    msg = store.add_message(session_id=master, from_role="child",
                            kind="result", payload=payload, to_session=master)
    return {"ok": True, "msg": msg}


def execute_dispatch(dispatch_id: str, master: str, child: str,
                     payload: Dict[str, Any], task_id: str) -> Dict[str, Any]:
    """同步收敛入口（后台线程与测试都从这里走；一次下发恰好收敛一次）。"""
    orch = get_orchestrator()
    description = _describe_task(payload)
    t0 = time.perf_counter()   # ★ 收口 42: perf_counter 单调高分辨率——
                               #   Windows time.time() ~15.6ms 刻度下快链
                               #   elapsed 会精确塌缩为 0.0（测试抖红实锤）
    store.set_state(child, "working")
    _TASKS[dispatch_id] = {"task_id": task_id, "master": master, "child": child,
                           "state": "running", "started_at": t0}

    summary = _run_with_engine(description, child)
    chain = "engine_manager.spawn_subagent"
    if summary is None:
        # 本地执行器：内容全部派生自 payload 与运行时测量（不做假数据）
        chain = "local"
        kids = store.list_children(master) if master else []
        summary = (f"已完成会话任务「{payload.get('goal') or payload.get('task') or ''}」。"
                   f"执行链: 本地执行器（真实引擎未开启，设 {_ENGINE_ENV}=1 走统一链）。"
                   f"子会话当前收件 {store.count_messages(child)} 封，"
                   f"主会话下共 {len(kids)} 个子会话。")
    elapsed = time.perf_counter() - t0

    artifact = _write_artifact(dispatch_id, {**payload, "_chain": chain},
                               summary, elapsed)
    orch.complete_task(task_id, result=summary, error="")

    result_payload = {
        "task_id": task_id,
        "dispatch_id": dispatch_id,
        "summary": summary,
        "elapsed_s": round(elapsed, 6),  # ★ 收口 42: 6 位精度——stub 引擎毫秒级完成时 elapsed_s 不再塌缩为 0.0
        "chain": chain,
        "artifact": artifact,
        "goal": payload.get("goal") or payload.get("task") or "",
        "deadline": payload.get("deadline") or "",
        "finished_at": time.time(),
    }
    rep = _report_result(child, master, result_payload)
    state = "done" if rep.get("ok") else ("blocked_" + str(rep.get("code") or "denied"))
    store.set_state(child, "done" if rep.get("ok") else "report_blocked")
    _TASKS[dispatch_id].update({"state": state, "elapsed_s": result_payload["elapsed_s"],
                                "report": rep.get("ok", False),
                                "report_code": rep.get("code", "")})
    return {"ok": True, "task_id": task_id, "dispatch_id": dispatch_id,
            "state": state, "result": result_payload, "report": rep}


def dispatch(master: str, child: str, payload: Dict[str, Any],
             async_run: bool = True) -> Dict[str, Any]:
    """主→子下发的执行侧入口（server 路由 ACL 通过后调用）。

    1. orchestrator.submit_task 入队（复用既有队列账本，不自建账）
    2. 后台线程收敛：执行 → complete_task 回写 → result 回传主会话收件箱
    """
    orch = get_orchestrator()
    description = _describe_task(payload)
    task_id = orch.submit_task(description)
    dispatch_id = "disp_" + task_id.split("_", 1)[-1]
    full_payload = dict(payload or {})
    full_payload.update({"master": master, "child": child})
    if async_run:
        threading.Thread(target=execute_dispatch,
                         args=(dispatch_id, master, child, full_payload, task_id),
                         name=f"session-mesh-{dispatch_id}", daemon=True).start()
        _TASKS[dispatch_id] = {"task_id": task_id, "master": master, "child": child,
                               "state": "running", "started_at": time.time()}
        return {"ok": True, "task_id": task_id, "dispatch_id": dispatch_id,
                "state": "running"}
    return execute_dispatch(dispatch_id, master, child, full_payload, task_id)
