# -*- coding: utf-8 -*-
"""★ 会话级主从网格 —— 本机 HTTP 服务（会话层主从能力的唯一运行时入口）

路由（全部经 bridge/api/require_auth.py 鉴权 —— 铁律：新增 HTTP 路由必须走 A-05
单一收口；鉴权模块不可用时 fail-closed 401，绝不放行）：

  GET  /health                       健康检查（同 bridge 口径：带鉴权）
  GET  /api/session/list             全部会话档案（侧栏/选主会话用）
  GET  /api/session/list?scope=unified  公司/爬虫/普通三类统一字段列表（收口项 20）
  GET  /api/session/children?master= 主会话枚举直属子会话（含库内真实计数）
  GET  /api/session/overview?session= 会话视图数据（角色/父会话/子会话/芯片数字）
  GET  /api/session/messages?session=&viewer=&since=
                                     收件箱读取（自读 / 主读子走 ACL；其余 403+审计）
  POST /api/session/link             {child, master, title?}   设为子会话
  POST /api/session/unlink           {child}                    取消从属
  POST /api/session/delete           {session}                  删除（子会话降级不丢数据）
  POST /api/session/dispatch         {master, child, kind:'task', payload}
                                     主→子下发（ACL: can_master_write_child）
                                     → SubAgentOrchestrator.submit_task 触发执行
  POST /api/session/report           {child, master, kind:'result', payload}
                                     子→主回传（ACL: 只放行 kind='result'）

静态资产（仅回环 127.0.0.1，不属 API 路由）：
  GET  /ui/boot.js                   向桌面页注入令牌（令牌真源同 bridge/start.py，
                                    与本地直接读取 data/config/bridge_token.json 同信任级）
  GET  /demo                         会话网格演示页（验收截图用，数据全部来自 chat.db）

响应封套：成功 {"ok":true, "data":…}；失败 {"ok":false,"code":…,"error":…}，
HTTP 状态码 401/403/404/400 一律语义化。端口偏好 8796-8800，占用自动顺延。
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import json
import os
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Dict, Optional
from urllib.parse import parse_qs, urlparse

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

_DEMO_HTML = os.path.join(_PROJECT_ROOT, "standard_mode", "ui", "session_mesh_demo.html")
_PREFERRED_PORTS = (8796, 8797, 8798, 8799, 8800)

_server = None
_lock = threading.Lock()


# ─────────────────────────── 鉴权（A-05 单一收口） ───────────────────────────

def _require_auth():
    """bridge/api/require_auth.py 是唯一鉴权真源；导入失败 → None（fail-closed）。"""
    try:
        from bridge.api import require_auth
        return require_auth
    except ImportError:
        if _PROJECT_ROOT not in sys.path:
            sys.path.insert(0, _PROJECT_ROOT)
        try:
            from bridge.api import require_auth
            return require_auth
        except Exception as e:
            print(f"[session-mesh] require_auth 不可用，API 一律 fail-closed: {e}")
            return None


def _token() -> str:
    """令牌真源 = require_auth.auth_token()；env 缺失时回读启动器持久化令牌。"""
    ra = _require_auth()
    if ra is not None:
        tok = ra.auth_token()
        if tok:
            return tok
    token_file = os.path.join(_PROJECT_ROOT, "data", "config", "bridge_token.json")
    try:
        with open(token_file, "r", encoding="utf-8") as f:
            d = json.load(f)
        return str(d.get("token") or "")
    except (OSError, ValueError):
        return ""


# ─────────────────────────── 应用层（store / acl / worker） ───────────────────────────

def _store():
    from session_mesh import store
    return store


def _acl():
    from shared import session_acl
    return session_acl


def _worker():
    from session_mesh import worker
    return worker


def _child_counts(master_id: str) -> Dict[str, Dict[str, int]]:
    """子会话信箱真实计数（来自 chat.db，不做任何前端假数）。"""
    st = _store()
    out: Dict[str, Dict[str, int]] = {}
    for kid in st.list_children(master_id):
        sid = kid["session_id"]
        out[sid] = {"messages": st.count_messages(sid),
                    "results": st.count_messages(sid, kind="result")}
    return out


# ─────────────────────────── 业务动作（供路由与测试复用） ───────────────────────────

def action_children(master: str) -> Dict[str, Any]:
    st, acl = _store(), _acl()
    row = st.get_session(master)
    if row is None:
        return {"error": (404, "SESSION_NOT_FOUND", "主会话不存在")}
    kids = st.list_children(master)
    counts = _child_counts(master)
    return {"data": {
        "master": {"session_id": master, "title": row.get("title") or "",
                   "state": row.get("state") or ""},
        "children": [{
            "session_id": k["session_id"], "title": k.get("title") or "",
            "state": k.get("state") or "", "created_at": k.get("created_at") or 0,
            "messages": counts.get(k["session_id"], {}).get("messages", 0),
            "results": counts.get(k["session_id"], {}).get("results", 0),
        } for k in kids],
        "total": len(kids),
    }}


def action_overview(session_id: str) -> Dict[str, Any]:
    st, acl = _store(), _acl()
    row = st.get_session(session_id)
    if row is None:
        return {"error": (404, "SESSION_NOT_FOUND", "会话不存在")}
    parent_id = row.get("parent_id") or ""
    parent_title = ""
    if parent_id and acl.can_child_read_master(session_id):
        p = st.get_session(parent_id)
        parent_title = (p or {}).get("title") or ""
    kids = st.list_children(session_id) if row.get("role") == "master" else []
    counts = _child_counts(session_id) if kids else {}
    return {"data": {
        "session_id": session_id,
        "role": row.get("role") or "master",
        "parent_id": parent_id,
        "parent_title": parent_title,
        "title": row.get("title") or "",
        "state": row.get("state") or "",
        "children": [{
            "session_id": k["session_id"], "title": k.get("title") or "",
            "state": k.get("state") or "",
            "messages": counts.get(k["session_id"], {}).get("messages", 0),
            "results": counts.get(k["session_id"], {}).get("results", 0),
        } for k in kids],
        "children_total": len(kids),
        "messages": st.count_messages(session_id),
        "unread_results": st.count_messages(session_id, kind="result"),
    }}


def _clear_acl_for_child(child: str) -> None:
    """清掉该子会话的全部旧授权（一个子会话同一时刻只归属一个主会话）。"""
    import sqlite3

    from shared.session_acl import _connect
    conn = _connect()
    try:
        conn.execute("DELETE FROM session_acl WHERE child_id=?", (child,))
        conn.commit()
    finally:
        conn.close()


def action_link(child: str, master: str, child_title: str = "",
                master_title: str = "") -> Dict[str, Any]:
    """设为子会话：登记档案 → 挂 parent → 建默认 ACL（规格默认权限位）。"""
    if not child or not master:
        return {"error": (400, "SESSION_INVALID_ID", "child/master 不能为空")}
    if child == master:
        return {"error": (400, "SESSION_SELF_LOOP", "会话不能从属于自己的主会话")}
    st, acl = _store(), _acl()
    st.upsert_session(master, title=master_title or "", role="master", parent_id="")
    st.upsert_session(child, title=child_title or "", role="child", parent_id=master)
    # ★ A1 修复一: 已存在会话的 upsert 更新分支只补空字段、从不写 parent_id ——
    #   link 已存在会话此前静默失败（接口 ok 但没挂上，遗留脏 ACL 行，主读子判
    #   ACL_LINK_BROKEN）。照 action_unlink 的直改做法补写主从关系。
    from shared.session_acl import _connect
    conn = _connect()
    try:
        conn.execute("UPDATE chat_session SET parent_id=?, role='child',"
                     " state='active' WHERE session_id=?", (master, child))
        conn.commit()
    finally:
        conn.close()
    _clear_acl_for_child(child)
    acl.set_acl(master, child)          # 默认：主读子1/主写子1/子读主1/子写主0(仅result)
    st.set_state(child, "active")
    return {"data": {"child": st.get_session(child), "master": st.get_session(master)}}


def action_unlink(child: str) -> Dict[str, Any]:
    st, acl = _store(), _acl()
    row = st.get_session(child)
    if row is None:
        return {"error": (404, "SESSION_NOT_FOUND", "会话不存在")}
    master = row.get("parent_id") or ""
    if master:
        acl.remove_acl(master, child)
    else:
        _clear_acl_for_child(child)
    st.upsert_session(child, role="master", parent_id="")   # 幂等登记不会覆盖 title
    import sqlite3

    from shared.session_acl import _connect
    conn = _connect()
    try:
        conn.execute("UPDATE chat_session SET parent_id='', role='master',"
                     " state='independent' WHERE session_id=?", (child,))
        conn.commit()
    finally:
        conn.close()
    return {"data": {"child": st.get_session(child), "former_master": master}}


def action_delete(session_id: str, requester: str = "") -> Dict[str, Any]:
    """★ 收口项 35: 删除必须经授权链 —— requester 必须是该会话的主会话
    （ACL can_master_write_child 判定）或会话本人（自删独立会话）；
    陌生/兄弟会话删除一律 403 + ACL 审计（无审批删除被拦）。"""
    st, acl = _store(), _acl()
    if not requester:
        return {"error": (400, "SESSION_INVALID_ID",
                          "删除需提供 requester（授权链校验：消息≠授权）")}
    srow = st.get_session(session_id)
    if srow is None:
        return {"error": (404, "SESSION_NOT_FOUND", "会话不存在")}
    if requester != session_id:
        allowed, code = acl.check("master_write_child", requester, session_id)
        if not allowed:
            return {"error": (403, code, acl.deny_message(code))}
    res = st.delete_session(session_id)     # 内部已同步清 ACL（双向）并降级子会话
    if not res.get("deleted"):
        return {"error": (404, "SESSION_NOT_FOUND", "会话不存在")}
    return {"data": res}


def action_messages(session_id: str, viewer: str, since: float = 0.0) -> Dict[str, Any]:
    """收件箱读取收口：自读直读；跨会话一律过 ACL（含兄弟越权 403+审计）。"""
    st, acl = _store(), _acl()
    if not viewer:
        viewer = session_id
    if viewer != session_id:
        # 方向归类：viewer 是 session 的主 → master_read_child；viewer 是 session 的子
        # → child_read_master；其余（兄弟/陌生）→ 走 master_read_child 判定必然
        # 无授权行 deny（审计照记），错误码语义一致。
        vrow = st.get_session(viewer)
        trow = st.get_session(session_id)
        if trow is None:
            return {"error": (404, "SESSION_NOT_FOUND", "目标会话不存在")}
        if vrow is not None and (vrow.get("parent_id") or "") == session_id:
            allowed, code = acl.check("child_read_master", viewer)
        else:
            allowed, code = acl.check("master_read_child", viewer, session_id)
        if not allowed:
            return {"error": (403, code, acl.deny_message(code))}
    msgs = st.list_messages(session_id, since=since)
    return {"data": {"session_id": session_id, "viewer": viewer,
                     "since": since, "messages": msgs, "total": len(msgs)}}


def action_dispatch(master: str, child: str, kind: str, payload: Any,
                    async_run: bool = True) -> Dict[str, Any]:
    st, acl, wk = _store(), _acl(), _worker()
    if kind != "task":
        return {"error": (400, "ACL_MASTER_WRITE_CHILD_KIND",
                          "下发只接受 kind='task'")}
    if st.get_session(master) is None:
        return {"error": (404, "SESSION_NOT_FOUND", "主会话不存在")}
    allowed, code = acl.check("master_write_child", master, child)
    if not allowed:
        return {"error": (403, code, acl.deny_message(code))}
    if st.get_session(child) is None:
        return {"error": (404, "SESSION_NOT_FOUND", "子会话不存在")}
    msg = st.add_message(session_id=child, from_role="master", kind="task",
                         payload=payload or {}, to_session=child)
    r = wk.dispatch(master, child, dict(payload or {}), async_run=async_run)
    return {"data": {"message": {"msg_id": msg["msg_id"],
                                 "session_id": msg["session_id"],
                                 "kind": msg["kind"],
                                 "created_at": msg["created_at"]},
                     "task_id": r.get("task_id", ""),
                     "dispatch_id": r.get("dispatch_id", ""),
                     "state": r.get("state", "")}}


def action_report(child: str, master: str, kind: str, payload: Any) -> Dict[str, Any]:
    st, acl = _store(), _acl()
    # kind 铁律先行（无论 ACL 行是否存在都按越权记审计）
    allowed, code = acl.check("child_write_master", child, master, kind=kind or "")
    if not allowed:
        return {"error": (403, code, acl.deny_message(code))}
    if st.get_session(master) is None:
        return {"error": (404, "SESSION_NOT_FOUND", "主会话不存在")}
    msg = st.add_message(session_id=master, from_role="child", kind=kind,
                         payload=payload or {}, to_session=master)
    st.set_state(child, "reported")
    return {"data": {"message": {"msg_id": msg["msg_id"],
                                 "session_id": msg["session_id"],
                                 "kind": msg["kind"],
                                 "created_at": msg["created_at"]}}}


# ─────────────────────────── HTTP 层 ───────────────────────────

class _Handler(BaseHTTPRequestHandler):
    server_version = "LemonSessionMesh/1.0"

    def log_message(self, fmt, *args):   # 静默：不刷终端
        pass

    def _send(self, code: int, body: bytes, ctype: str):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        # 桌面 UI 是 file:// 宿主（Origin: null），与 stage_server 同口径放行回环读取
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "*")
        self.end_headers()
        try:
            self.wfile.write(body)
        except BrokenPipeError:
            logger.debug("suppressed exception")

    def _json(self, obj: Any, code: int = 200):
        self._send(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"),
                   "application/json; charset=utf-8")

    def _ok(self, data: Any):
        self._json({"ok": True, "data": data})

    def _err(self, status: int, code: str, message: str):
        self._json({"ok": False, "code": code, "error": message}, status)

    def _from_action(self, res: Dict[str, Any]):
        """业务动作统一出口：{"data":…} / {"error":(status, code, msg)} 两态。"""
        if "error" in res:
            status, code, msg = res["error"]
            self._err(status, code, msg)
        else:
            self._ok(res.get("data"))

    def do_OPTIONS(self):
        self._send(204, b"", "text/plain")

    def _authed(self) -> bool:
        ra = _require_auth()
        if ra is None:
            return False
        return ra.check_headers(self.headers)

    # ── GET ──
    def do_GET(self):
        u = urlparse(self.path)
        path, qs = u.path, parse_qs(u.query)

        if path == "/ui/boot.js":                      # 回环静态引导（非 API 路由）
            tok = _token()
            body = (f"window.LW_SESSION_TOKEN={json.dumps(tok)};"
                    f"window.LW_SESSION_MESH_PORT={self._mesh_port()};").encode("utf-8")
            self._send(200, body, "application/javascript; charset=utf-8")
            return

        if path == "/ui/lw_session_mesh.js":           # 前端插件静态供应（白名单单文件）
            js_path = os.path.join(_PROJECT_ROOT, "standard_mode", "ui",
                                   "lw_session_mesh.js")
            try:
                with open(js_path, "rb") as f:
                    self._send(200, f.read(), "application/javascript; charset=utf-8")
            except OSError as e:
                self._send(500, f"js missing: {e}".encode("utf-8"),
                           "text/plain; charset=utf-8")
            return

        if path == "/demo":                            # 演示/截图页（回环静态资产）
            try:
                with open(_DEMO_HTML, "rb") as f:
                    html = f.read()
            except OSError as e:
                self._send(500, f"demo html missing: {e}".encode("utf-8"),
                           "text/plain; charset=utf-8")
                return
            self._send(200, html, "text/html; charset=utf-8")
            return

        if path == "/artifact":                        # 任务产物（回环静态资产，限本目录）
            rel = (qs.get("path") or [""])[0]
            served = self._artifact_file(rel)
            if served is None:
                self._send(404, b"artifact not found", "text/plain; charset=utf-8")
                return
            self._send(200, served, "text/markdown; charset=utf-8")
            return

        if not self._authed():
            ra = _require_auth()
            payload = (ra.unauthorized_payload() if ra is not None
                       else {"ok": False, "error": "unauthorized: auth unavailable"})
            self._json(payload, 401)
            return

        if path == "/health":
            st = _store()
            self._json({"ok": True, "db": os.path.exists(st.db_path()),
                        "sessions": len(st.list_sessions())})
            return

        if path == "/api/session/list":
            # ★ 收口项 20: 支持 kind 过滤；缺省仍返回 mesh 会话（兼容不变），
            #   ?scope=unified → 公司/爬虫/普通 三类统一字段列表
            scope = (qs.get("scope") or [""])[0]
            if scope == "unified":
                from shared.session_registry import unified_sessions
                self._json({"ok": True, "data": {"sessions": unified_sessions()},
                            "error": None})
                return
            self._from_action({"data": {"sessions": _store().list_sessions()}})
            return

        if path == "/api/session/children":
            master = (qs.get("master") or [""])[0]
            if not master:
                self._err(400, "SESSION_INVALID_ID", "缺少 master 参数")
                return
            self._from_action(action_children(master))
            return

        if path == "/api/session/overview":
            sid = (qs.get("session") or [""])[0]
            if not sid:
                self._err(400, "SESSION_INVALID_ID", "缺少 session 参数")
                return
            self._from_action(action_overview(sid))
            return

        if path == "/api/session/messages":
            sid = (qs.get("session") or [""])[0]
            viewer = (qs.get("viewer") or [sid])[0] or sid
            try:
                since = float((qs.get("since") or ["0"])[0] or 0)
            except ValueError:
                since = 0.0
            if not sid:
                self._err(400, "SESSION_INVALID_ID", "缺少 session 参数")
                return
            self._from_action(action_messages(sid, viewer, since=since))
            return

        self._err(404, "NOT_FOUND", f"unknown path: {path}")

    def _mesh_port(self) -> int:
        try:
            return self.server.server_address[1]        # type: ignore[attr-defined]
        except Exception:
            return 0

    @staticmethod
    def _artifact_file(rel: str) -> Optional[bytes]:
        """产物读取：只允许 outputs/session_mesh/ 目录内的 .md 文件（防目录穿越）。"""
        from session_mesh.worker import _ARTIFACT_DIR
        base = os.path.realpath(_ARTIFACT_DIR)
        if not rel:
            return None
        full = os.path.realpath(os.path.join(base, rel))
        if not full.startswith(base + os.sep) or not full.endswith(".md"):
            return None
        try:
            with open(full, "rb") as f:
                return f.read()
        except OSError:
            return None

    # ── POST ──
    def do_POST(self):
        u = urlparse(self.path)
        path = u.path
        length = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(length) if length else b"{}"
        try:
            body = json.loads(raw.decode("utf-8") or "{}")
        except ValueError:
            body = {}
        if not isinstance(body, dict):
            body = {}

        if not self._authed():
            ra = _require_auth()
            payload = (ra.unauthorized_payload() if ra is not None
                       else {"ok": False, "error": "unauthorized: auth unavailable"})
            self._json(payload, 401)
            return

        if path == "/api/session/link":
            self._from_action(action_link(str(body.get("child") or ""),
                                          str(body.get("master") or ""),
                                          child_title=str(body.get("child_title") or ""),
                                          master_title=str(body.get("master_title") or "")))
            return

        if path == "/api/session/unlink":
            child = str(body.get("child") or "")
            if not child:
                self._err(400, "SESSION_INVALID_ID", "缺少 child")
                return
            self._from_action(action_unlink(child))
            return

        if path == "/api/session/delete":
            sid = str(body.get("session") or "")
            if not sid:
                self._err(400, "SESSION_INVALID_ID", "缺少 session")
                return
            # ★ 收口项 35: requester = 授权链主体（主会话或本人）
            self._from_action(action_delete(
                sid, requester=str(body.get("requester") or body.get("master") or "")))
            return

        if path == "/api/session/dispatch":
            self._from_action(action_dispatch(
                str(body.get("master") or ""), str(body.get("child") or ""),
                str(body.get("kind") or ""), body.get("payload") or {},
                async_run=bool(body.get("async", True))))
            return

        if path == "/api/session/report":
            self._from_action(action_report(
                str(body.get("child") or ""), str(body.get("master") or ""),
                str(body.get("kind") or ""), body.get("payload") or {}))
            return

        self._err(404, "NOT_FOUND", f"unknown path: {path}")


# ─────────────────────────── 生命周期 ───────────────────────────

def start(preferred_ports=None) -> int:
    """起服务（幂等）；返回真实端口，失败返回 0。preferred_ports=[0] 供测试用临时口。"""
    global _server
    from session_mesh import store
    store.ensure_schema()
    with _lock:
        if _server is not None:
            return _server.server_address[1]
        ports = tuple(preferred_ports or _PREFERRED_PORTS)
        for port in ports:
            try:
                srv = ThreadingHTTPServer(("127.0.0.1", port), _Handler)
            except OSError:
                continue
            srv.daemon_threads = True
            _server = srv
            threading.Thread(target=srv.serve_forever, name="session-mesh-http",
                             daemon=True).start()
            return srv.server_address[1]
        return 0


def port() -> int:
    return _server.server_address[1] if _server is not None else 0


def stop():
    global _server
    with _lock:
        if _server is not None:
            try:
                _server.shutdown()
                _server.server_close()
            except Exception as e:
                print(f"[session-mesh] stop 异常: {e}")
            _server = None


def run() -> int:
    """前台运行入口（python -m session_mesh）。令牌缺失 fail-fast，与 bridge 同口径。"""
    import time
    ra = _require_auth()
    if ra is not None:
        ra.fail_fast_or_exit("session-mesh")
    p = start()
    print("session-mesh server:", f"http://127.0.0.1:{p}" if p else "FAILED",
          "| auth:", "on" if _token() else "INSECURE(未配置 LEMON_BRIDGE_TOKEN)",
          "| demo:", f"http://127.0.0.1:{p}/demo" if p else "")
    if p:
        try:
            while True:
                time.sleep(3600)
        except KeyboardInterrupt:
            stop()
    return 0 if p else 1


if __name__ == "__main__":
    run()
