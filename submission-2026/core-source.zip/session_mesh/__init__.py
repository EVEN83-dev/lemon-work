# -*- coding: utf-8 -*-
"""★ 会话级主从网格（session mesh）—— Lemon Work 三大功能中唯一的全新能力。

一个主会话 + 多个子会话；单向下发任务、双向回传结果。

模块分工（本包只做"会话主从"一件事，不碰任务级父子关系）：
  store.py   chat.db 数据层（chat_session / session_message / session_acl 三表）
  server.py  本机 HTTP 服务（路由全部经 bridge/api/require_auth.py 鉴权）
  worker.py  子会话执行链（复用 SubAgentOrchestrator.submit_task 队列账本）
权限判定唯一入口在 shared/session_acl.py —— UI 层与路由层一律不得自行判断。

启动方式：
  _py312/python.exe -m session_mesh
"""
