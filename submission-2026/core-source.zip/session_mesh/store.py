# -*- coding: utf-8 -*-
"""★ 会话级主从网格 —— 数据层（data/chat.db）

三张新表（任务规格原文 DDL，不改 crawl_session，也不动 crawl.db）：

  chat_session     会话主从档案（session_id 主键；master 的 parent_id 为空）
  session_message  跨会话信件（task / result / note；to_session 指明收件方）
  session_acl      主↔子权限位（真源在 shared/session_acl.py 判定）

铁律：
  - 新增数据表必须带 session_id（或等价的 master_id/child_id）字段，便于审计。
  - 所有数值来自库内真实行（created_at 用运行时时间戳），禁止演示假数。
  - 会话表与消息表分开：删除主会话时只动 chat_session/session_acl，
    session_message 按 session_id 原样保留 → 子会话降级不丢数据。
"""
from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

import json
import os
import sqlite3
import threading
import time
import uuid
from typing import Any, Dict, List, Optional

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_WRITE_LOCK = threading.Lock()   # sqlite 同进程串行写，避免 database is locked


def db_path() -> str:
    """chat.db 唯一路径真源：env LW_CHAT_DB 可覆盖（测试隔离用），默认 data/chat.db。"""
    env = os.environ.get("LW_CHAT_DB", "").strip()
    if env:
        return env
    return os.path.join(_PROJECT_ROOT, "data", "chat.db")


_CONN_TLS = threading.local()   # ★ 收口 37: 线程级连接缓存（同路径复用，
                                #   state() 每次为 13 会话各开新连接 → ~100ms 热点）


def connect(db: str = "") -> sqlite3.Connection:
    path = db or db_path()
    cached = getattr(_CONN_TLS, "conns", None)
    if cached is None:
        cached = {}
        _CONN_TLS.conns = cached
    c = cached.get(path)
    if c is not None:
        try:
            c.execute("SELECT 1")
            return c
        except sqlite3.Error:
            try:
                c.close()   # 失效连接：物理关闭（缓存随后重建）
            except Exception:
                logger.debug("suppressed exception")
            cached.pop(path, None)
    d = os.path.dirname(path)
    if d and not os.path.isdir(d):
        os.makedirs(d, exist_ok=True)
    conn = sqlite3.connect(path, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    cached[path] = conn
    return conn


def _close(c: sqlite3.Connection) -> None:
    """★ 收口 37: 缓存连接不做物理关闭（归还语义）；显式关闭走 close_all()。

    旧契约里各函数 finally: c.close() —— 缓存化后物理关闭会把缓存打穿
    （下一调用重连，state() 热点回潮）。物理关闭只发生在：连接失效重建、
    close_all()、进程退出。"""
    cached = getattr(_CONN_TLS, "conns", None) or {}
    for k, v in cached.items():
        if v is c:
            return
    try:
        c.close()   # 非缓存连接：物理关闭（本函数体不参与正则替换）
    except Exception:
        logger.debug("suppressed exception")


def close_all() -> None:
    """测试隔离用：清空当前线程的连接缓存（LW_CHAT_DB 切库后调用）。"""
    cached = getattr(_CONN_TLS, "conns", None) or {}
    for c in cached.values():
        try:
            c.close()   # close_all：显式物理关闭全部缓存连接
        except Exception:
            logger.debug("suppressed exception")
    _CONN_TLS.conns = {}


DDL = """
CREATE TABLE IF NOT EXISTS chat_session(
  session_id TEXT PRIMARY KEY,
  parent_id TEXT DEFAULT '',
  role TEXT DEFAULT 'master',
  title TEXT,
  created_at REAL,
  state TEXT
);
CREATE TABLE IF NOT EXISTS session_message(
  msg_id TEXT PRIMARY KEY,
  session_id TEXT,
  from_role TEXT,
  to_session TEXT,
  kind TEXT,
  payload TEXT,
  created_at REAL
);
CREATE INDEX IF NOT EXISTS idx_session_message_box
  ON session_message(session_id, created_at);
"""

ACL_DDL = """
CREATE TABLE IF NOT EXISTS session_acl(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  master_id TEXT,
  child_id TEXT,
  can_read INTEGER DEFAULT 1,
  can_write INTEGER DEFAULT 1,
  child_can_read_master INTEGER DEFAULT 1,
  child_can_write_master INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_session_acl_child ON session_acl(child_id);
CREATE INDEX IF NOT EXISTS idx_session_acl_master ON session_acl(master_id);
"""


def ensure_schema(conn: Optional[sqlite3.Connection] = None) -> None:
    """幂等建表（store 三表 + acl 表一次建齐）。"""
    own = conn is None
    c = conn or connect()
    try:
        with _WRITE_LOCK:
            c.executescript(DDL)
            c.executescript(ACL_DDL)
        c.commit()
    finally:
        if own:
            _close(c)


# ──────────────────────────── chat_session ────────────────────────────

def upsert_session(session_id: str, title: str = "", role: str = "master",
                   parent_id: str = "", state: str = "active",
                   conn: Optional[sqlite3.Connection] = None) -> Dict[str, Any]:
    """登记/更新会话档案。已存在时只补空缺字段，绝不覆盖既有主从关系。"""
    own = conn is None
    c = conn or connect()
    try:
        ensure_schema(c)
        now = time.time()
        with _WRITE_LOCK:
            row = c.execute("SELECT * FROM chat_session WHERE session_id=?",
                            (session_id,)).fetchone()
            if row is None:
                c.execute(
                    "INSERT INTO chat_session(session_id, parent_id, role, title,"
                    " created_at, state) VALUES(?,?,?,?,?,?)",
                    (session_id, parent_id or "", role or "master",
                     title or session_id, now, state))
                c.commit()
            else:
                # 幂等登记：只把库里为空的字段补上（title 允许刷新展示名）
                sets, args = [], []
                if title:
                    sets.append("title=?"); args.append(title)
                if not row["role"]:
                    sets.append("role=?"); args.append(role or "master")
                if not row["state"]:
                    sets.append("state=?"); args.append(state)
                if sets:
                    args.append(session_id)
                    c.execute(f"UPDATE chat_session SET {', '.join(sets)} "
                              "WHERE session_id=?", args)
                    c.commit()
        return get_session(session_id, conn=c) or {}
    finally:
        if own:
            _close(c)


def get_session(session_id: str,
                conn: Optional[sqlite3.Connection] = None) -> Optional[Dict[str, Any]]:
    own = conn is None
    c = conn or connect()
    try:
        row = c.execute("SELECT * FROM chat_session WHERE session_id=?",
                        (session_id,)).fetchone()
        return dict(row) if row else None
    finally:
        if own:
            _close(c)


def list_children(master_id: str,
                  conn: Optional[sqlite3.Connection] = None) -> List[Dict[str, Any]]:
    """主会话的直属子会话（按入会时间正序）。"""
    own = conn is None
    c = conn or connect()
    try:
        rows = c.execute(
            "SELECT * FROM chat_session WHERE parent_id=? AND role='child' "
            "ORDER BY created_at ASC", (master_id,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        if own:
            _close(c)


def list_sessions(conn: Optional[sqlite3.Connection] = None) -> List[Dict[str, Any]]:
    own = conn is None
    c = conn or connect()
    try:
        rows = c.execute("SELECT * FROM chat_session ORDER BY created_at ASC").fetchall()
        return [dict(r) for r in rows]
    finally:
        if own:
            _close(c)


def delete_session(session_id: str,
                   conn: Optional[sqlite3.Connection] = None) -> Dict[str, Any]:
    """删除会话档案 + 相关 ACL 行；session_message 原样保留（审计链不断）。

    若被删的是主会话，直属子会话就地降级为独立会话（parent_id=''、role='master'，
    title/state/created_at 不变 → 数据零丢失），返回降级清单供调用方提示。
    """
    own = conn is None
    c = conn or connect()
    demoted: List[Dict[str, Any]] = []
    try:
        ensure_schema(c)
        with _WRITE_LOCK:
            row = c.execute("SELECT * FROM chat_session WHERE session_id=?",
                            (session_id,)).fetchone()
            if row is None:
                return {"deleted": False, "demoted": []}
            if row["role"] == "master":
                kids = c.execute(
                    "SELECT session_id, title FROM chat_session "
                    "WHERE parent_id=? AND role='child'",
                    (session_id,)).fetchall()
                if kids:
                    c.execute("UPDATE chat_session SET parent_id='', role='master',"
                              " state='independent' WHERE parent_id=? AND role='child'",
                              (session_id,))
                    demoted = [{"session_id": k["session_id"], "title": k["title"] or ""}
                               for k in kids]
            c.execute("DELETE FROM chat_session WHERE session_id=?", (session_id,))
            c.execute("DELETE FROM session_acl WHERE master_id=? OR child_id=?",
                      (session_id, session_id))
            c.commit()
        return {"deleted": True, "demoted": demoted}
    finally:
        if own:
            _close(c)


def set_state(session_id: str, state: str,
              conn: Optional[sqlite3.Connection] = None) -> bool:
    own = conn is None
    c = conn or connect()
    try:
        with _WRITE_LOCK:
            cur = c.execute("UPDATE chat_session SET state=? WHERE session_id=?",
                            (state, session_id))
            c.commit()
            return cur.rowcount > 0
    finally:
        if own:
            _close(c)


# ─────────────────────────── session_message ───────────────────────────

def add_message(session_id: str, from_role: str, kind: str, payload: Any,
                to_session: str = "",
                conn: Optional[sqlite3.Connection] = None) -> Dict[str, Any]:
    """投递一封跨会话信件。payload 统一 JSON 落盘（字符串原样存）。"""
    own = conn is None
    c = conn or connect()
    try:
        ensure_schema(c)
        payload_text = payload if isinstance(payload, str) else json.dumps(
            payload, ensure_ascii=False)
        msg = {
            "msg_id": "msg_" + uuid.uuid4().hex[:12],
            "session_id": session_id,       # 收件箱归属（收件方读自己的箱）
            "from_role": from_role,
            "to_session": to_session or session_id,
            "kind": kind,
            "payload": payload_text,
            "created_at": time.time(),
        }
        with _WRITE_LOCK:
            c.execute(
                "INSERT INTO session_message(msg_id, session_id, from_role,"
                " to_session, kind, payload, created_at) VALUES(?,?,?,?,?,?,?)",
                (msg["msg_id"], msg["session_id"], msg["from_role"],
                 msg["to_session"], msg["kind"], msg["payload"], msg["created_at"]))
            c.commit()
        return msg
    finally:
        if own:
            _close(c)


def list_messages(session_id: str, since: float = 0.0, limit: int = 200,
                  conn: Optional[sqlite3.Connection] = None) -> List[Dict[str, Any]]:
    """读某会话收件箱（since 之后的消息，正序）。limit 来自调用方，缺省 200 封顶。"""
    own = conn is None
    c = conn or connect()
    try:
        rows = c.execute(
            "SELECT * FROM session_message WHERE session_id=? AND created_at>? "
            "ORDER BY created_at ASC LIMIT ?",
            (session_id, float(since or 0.0), int(limit))).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            try:
                d["payload"] = json.loads(d["payload"]) if d["payload"] else {}
            except (ValueError, TypeError):
                pass                      # 非法 JSON 原样返回字符串，不静默改写
            out.append(d)
        return out
    finally:
        if own:
            _close(c)


def count_messages(session_id: str, kind: str = "",
                   conn: Optional[sqlite3.Connection] = None) -> int:
    own = conn is None
    c = conn or connect()
    try:
        if kind:
            row = c.execute("SELECT COUNT(*) AS n FROM session_message "
                            "WHERE session_id=? AND kind=?", (session_id, kind)).fetchone()
        else:
            row = c.execute("SELECT COUNT(*) AS n FROM session_message "
                            "WHERE session_id=?", (session_id,)).fetchone()
        return int(row["n"]) if row else 0
    finally:
        if own:
            _close(c)
