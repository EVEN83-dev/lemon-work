# 会话级主从网格（Session Mesh）· 一页 README

> 一个主会话 + 多个子会话：单向下发任务、双向回传结果。
> 本功能是 Lemon Work 三大功能中**唯一的全新能力**（比赛亮点），数据层/权限层/运行时/前端四层全部落地。

## 1. 30 秒上手

```bash
# ① 启动服务（端口 8796-8800 自动顺延；令牌缺失会 fail-fast，与 bridge 同口径）
LEMON_BRIDGE_TOKEN=<任意长随机串> ./_py312/python.exe -m session_mesh

# ② 打开演示页（数据全部来自 data/chat.db 实时查询）
#    http://127.0.0.1:8796/demo

# ③ 桌面端（mimo_page.html 对话流）无需任何操作：
#    standard_mode/ui/mimo_app.js 末尾的加载器会自动注入 lw_session_mesh.js，
#    芯片/右键菜单/卡片随会话切换自动出现。
```

验收一键回归：

```bash
./_py312/python.exe scripts/verify_session_acl.py   # 输出 21 项 ✅/❌ 明细 + PASS n / FAIL m
./_py312/python.exe -m pytest tests/test_session_acl_engine.py tests/test_session_mesh_routes.py -q
```

## 2. 分层结构

| 层 | 文件（全部为新增） | 职责 |
|---|---|---|
| 数据层 | `session_mesh/store.py` | `data/chat.db` 三表：`chat_session` / `session_message` / `session_acl`（任务规格原文 DDL；均带 session_id/child_id 便于审计；不动 crawl_session） |
| 权限层 | `shared/session_acl.py` | **全系统唯一权限判定入口**：`can_master_read_child / can_master_write_child / can_child_read_master / can_child_write_master`；越权 → 明确错误码 + `skill_audit` 审计 |
| 运行时 | `session_mesh/server.py` | 本机 HTTP（8796-8800）。**所有 `/api/*` 路由走 `bridge/api/require_auth.py` 鉴权**（缺令牌 fail-closed 401） |
| 执行链 | `session_mesh/worker.py` | 下发触发 `SubAgentOrchestrator.submit_task`（复用既有队列账本，不自建第二本账）；执行完经同一条 ACL 链回传 `kind=result` |
| 前端 | `standard_mode/ui/lw_session_mesh.js` | 右键菜单 / `MASTER · N children` 芯片 / `CHILD of …`+只读徽标 / 任务卡+结果卡（遵循 `lw_crawl_stage_card` 卡片规范：IIFE、自注入样式、`data-card-kind` 幂等渲染） |
| 演示 | `standard_mode/ui/session_mesh_demo.html`（经 `/demo` 供应） | 验收截图与人工演示；与桌面端共用同一渲染器 |
| 验收 | `scripts/verify_session_acl.py` | 任务规格 7 条验收逐项 PASS/FAIL |

### 唯一的共享文件改动（[SHARED]）

`standard_mode/ui/mimo_app.js` **末尾追加 14 行加载器**（动态注入 `lw_session_mesh.js`）。
原因：`mimo_page.html` 与 `mimo_panel.py` 在 code lock 保护清单内（`.code_lock_state.json` 哈希锁定），
无法加 `<script>` 标签，只能由未被锁定的 app.js 末尾装载；未改动任何既有渲染逻辑与 script 引入顺序。

## 3. API（全部带 `X-Lemon-Bridge-Token`）

| 路由 | 说明 |
|---|---|
| `GET  /api/session/children?master=` | 主会话枚举直属子会话（计数来自库内真实行） |
| `POST /api/session/dispatch` | `{master, child, kind:'task', payload}` 主→子下发（ACL: `can_master_write_child`）→ 触发 `SubAgentOrchestrator.submit_task` |
| `POST /api/session/report` | `{child, master, kind:'result', payload}` 子→主回传；**非 result 一律 403**（`ACL_CHILD_WRITE_MASTER_NON_RESULT`） |
| `GET  /api/session/messages?session=&viewer=&since=` | 收件箱读取：自读直读；跨会话过 ACL（兄弟越权 403+审计） |
| `GET  /api/session/overview?session=` | 芯片数据源（角色/父会话/子会话列表/计数） |
| `POST /api/session/link / unlink / delete` | 设为子会话 / 取消从属 / 删除（删除主会话时子会话自动降级为独立会话，消息零丢失） |
| `GET  /health` | 健康检查（同 bridge 口径：带鉴权） |

错误封套：`{"ok":false,"code":"ACL_…","error":"…"}` + 语义化 HTTP 状态码（401/403/404/400）。

## 4. 权限模型（默认位 = 任务规格）

```
session_acl: master→child  can_read=1  can_write=1            # 主读子 / 主写子
             child_can_read_master=1                              # 子读主
             child_can_write_master=0                             # 子默认只能回传 kind='result'
```

- 判定依据 = `session_acl` 行 + `chat_session.parent_id` 归属，两者不一致 **fail-closed**。
- 错误码全集：`ACL_ROW_MISSING / ACL_LINK_BROKEN / ACL_READ_DENIED / ACL_WRITE_DENIED /`
  `ACL_CHILD_READ_MASTER_DENIED / ACL_CHILD_WRITE_MASTER_NON_RESULT / SESSION_SELF_LOOP /`
  `SESSION_INVALID_ID / SESSION_NOT_FOUND`；每次 deny 同步写 `data/audit/skill_audit_YYYYMM.jsonl`
  （`source=session_acl`，可按 `session_id` 追溯）。

## 5. 关键设计决策

1. **UI 层零权限判断**：前端只呈现服务端 403 的 `code + 文案`（`DENY_MESSAGES` 真源在 session_acl.py），验收脚本有静态断言。
2. **数值零硬编码**：芯片数字/耗时/状态全部来自 `data/chat.db` 与运行时测量；执行链未配真实引擎时走"本地执行器"，摘要/产物均由任务 payload 与真实计时派生（不造演示假数）；设 `LEMON_SESSION_MESH_ENGINE=1` 可切到 `engine_manager.spawn_subagent` 真实引擎链。
3. **令牌引导**：`/ui/boot.js`（回环静态资产，非 API 路由）向桌面页注入令牌，令牌真源 = `require_auth.auth_token()` → `data/config/bridge_token.json`，与本地直接读令牌文件同信任级；所有 `/api/*` 仍强制鉴权。
4. **竞态防护**：会话快速切换时，芯片/收件箱回包校验"仍是当前会话"，旧响应直接丢弃。
5. **降级不丢数**：删除主会话只清 `chat_session`/`session_acl`，`session_message` 按 session_id 原样保留。

## 6. 交付物清单

| 交付物 | 位置 |
|---|---|
| 代码 | `session_mesh/`（4 文件）+ `shared/session_acl.py` + `standard_mode/ui/lw_session_mesh.js` + `mimo_app.js` 加载器 [SHARED] |
| 单测 | `tests/test_session_acl_engine.py`（10 用例）+ `tests/test_session_mesh_routes.py`（8 用例），18/18 过 |
| 验收脚本 | `scripts/verify_session_acl.py`（21 项 PASS/FAIL 明细） |
| 截图 | `outputs/session_acl/1_master_view.png`（主会话视图）/ `2_child_view.png`（子会话视图）/ `3_acl_denied.png`（越权拦截提示）/ `4_context_menu.png`（右键菜单·附赠） |
| README | 本文件 |

## 7. 已知边界

- 浏览器演示页与桌面端共用渲染器；桌面端芯片依赖 `mimo_app.js` 运行时全局（`_currentSessionId` / `loadSessionMessages`），均在装载时防御式包装。
- 并行窗口提示：本窗口工作期间检测到 `shared/crawler/stage_server.py` 有其他窗口的未提交改动（crawl_audit），本功能未触碰该文件；提交时只包含本清单内文件。
