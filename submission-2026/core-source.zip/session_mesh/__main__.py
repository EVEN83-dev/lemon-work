# -*- coding: utf-8 -*-
"""python -m session_mesh 入口 —— 会话级主从网格服务启动器。

    _py312/python.exe -m session_mesh            # 前台运行（Ctrl+C 停止）
    LEMON_BRIDGE_TOKEN=<token> python -m session_mesh

鉴权铁律与 bridge_server 一致：LEMON_BRIDGE_TOKEN 缺失即 fail-fast 拒绝启动
（bridge/api/require_auth.fail_fast_or_exit）。
"""
import sys

from session_mesh.server import run

if __name__ == "__main__":
    sys.exit(run())
