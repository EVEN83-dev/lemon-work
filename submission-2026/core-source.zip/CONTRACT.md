# CONTRACT — LemonWork 服务契约（收口版）

> 本文件为收口窗口（本窗口）产出的对外契约单一真源。
> 更新时间：2026-11-21 · 源码版本：4.8.6-lemonD1
> 鉴权：全部 API 路由走 `bridge/api/require_auth.py` 单一收口
> （`X-Lemon-Bridge-Token` 头 或 `Authorization: Bearer <token>`；
>   浏览器直连以 `?token=` 兜底比对同一令牌；未配置令牌 fail-closed 401，
>   仅 `LEMON_BRIDGE_INSECURE=1` 显式豁免）。

## 一、companyApi（17 个方法 —— HybridBridge.companyApi(method, payload)）

`hybrid_mode/core/hybrid_mode_bridge.py::_COMPANY_API_METHODS`（任务书口径 16 个 +
`resumeRun` 补齐运行控制三键 = 实际 17 个，全部真实转发 CompanyService）：

| # | 方法 | 语义 | 关键参数 |
|---|------|------|----------|
| 1 | uploadBrief | 上传任务简报 | name, content, uploaded_by |
| 2 | approve | 审批通过（org.can_approve + ACL can_approve 双闸） | approval_id, approver, reason |
| 3 | reject | 审批驳回 | approval_id, approver, reason |
| 4 | complete | 任务收束 | task_id, result, error, tokens |
| 5 | message | 公司消息发送（type=task 须 authorized_by 链；同级只作 request） | envelope{type,from,to,role,task_id,authorization,authorized_by,requires_approval,payload} |
| 6 | inbox | 收件箱读取 | session_id, since |
| 7 | getConfig | 读取全局配置（模型/白名单/矩阵/预算） | — |
| 8 | setConfig | 写配置（via_approval=true 走审批） | updates, via_approval, requested_by |
| 9 | recordFileChange | 文件变更 → diff → patch 产物 | role_id, path, old_text, new_text, task_id, approver |
| 10 | listApprovals | 审批单列表（任一入口同库可见） | status |
| 11 | listArtifacts | 产物列表 | kind, role_id |
| 12 | listTasks | 任务列表 | status |
| 13 | listSessions | 公司会话列表 | — |
| 14 | getState | 首屏真源快照（board/…） | — |
| 15 | stopRun | 停转（不可逆须 owner 审批） | summary |
| 16 | pauseRun | 暂停 | — |
| 17 | resumeRun | 恢复 | — |

## 二、HTTP 端点（按服务分组；全部 require_auth）

### 1. bridge 主服务（默认 127.0.0.1:8765，FastAPI 或 stdlib 同构降级）
- GET  `/health` — {status, uptime_sec, engine_ready, engine{available,primary}, skills_count, version}
- GET  `/api/engine/health` — ★收口13 引擎健康单源快照（UP/DOWN/延迟/失败计数）
- POST `/api/agent/chat` · GET `/api/agent/task/{task_id}` · GET `/api/agent/task/{task_id}/events`
- POST `/api/crawl/start|pause|resume|stop` · GET `/api/crawl/status|card|events`(SSE，帧带 `stats_seq`)
- GET  `/api/stats` — ★窗口2 build_stats 只读聚合（1s 缓存）
- GET  `/api/skills` · POST `/api/skills/{name}/execute`
- GET  `/api/mcp/tools` · GET `/api/quant/status` · POST `/api/quant/backtest`

### 2. 公司模式（8801-8805）
- GET  `/api/company/state|roster|agents|tasks|approvals|artifacts|config|stats|messages`
- GET  `/api/company/handoffs?viewer=` — ★收口21 文件交接区（跨会话可见，部门隔离）
- GET  `/api/company/events` — SSE（`?last_ts=N` 断线补发，replayed 帧报回放数 ★收口36）
- POST `/api/company/start|stop|pause|resume|assign|complete|upload|message|config`
- POST `/api/company/approve|reject` — 审批单条处理（收口22）
- POST `/api/company/handoff` — 交接区写入（can_handoff ACL 闸，403 语义 ★收口21）

### 3. 会话网格 session_mesh（8796-8800）
- GET  `/health` · `/api/session/list[?scope=unified]`（★收口20 三类统一七键）
- GET  `/api/session/children?master=` · `/api/session/overview?session=`
- GET  `/api/session/messages?session=&viewer=&since=`（跨会话读走 ACL）
- POST `/api/session/link|unlink|dispatch|report`
- POST `/api/session/delete` — ★收口35 requester 授权链校验（无授权删除 403+审计）
- 静态：`/ui/boot.js` · `/demo`（仅回环）

### 4. 爬虫作战室 stage_server（8791-8795）
- GET  `/`（蜘蛛窗口1）· `/stats`（统计层窗口2）· `/replay` · `/tokens.css` · `/ui/{白名单资源}`
- GET  `/health` · `/api/sessions` · `/api/board`（含追加键 `stats`/`stats_seq`，只增不改）
- GET  `/api/stats?sid=` · `/api/replay` · `/api/timeline` · `/api/timeline/stream`
- GET  `/api/unread` · `/api/direction` · `/api/v3/stats` · `/api/health`

## 三、统一数据契约

- **会话统一列表**（收口20）：`GET /api/session/list?scope=unified` →
  `[{session_id, name, kind∈company|crawl|normal, state, created_at, parent_id, source}]`
- **引擎健康**（收口13/5）：`GET /api/engine/health` →
  `{engines:{<id>:{up,status∈UP|DOWN|DEGRADED,available,consecutive_failures,failure_count,success_count,avg_response_time_ms,last_response_time_ms}}, primary, available}`
- **引擎事件**（收口14）：`data/audit/engine_events.jsonl`
  `[{ts, event∈engine_down|engine_failover, engine|from_engine, to_engine, reason, ...}]`
- **统计层**（窗口2）：`GET /api/stats` → `{counters{pages,ok,fail,skipped,dedup,bytes,avg_ms,rate,http_429,circuit}, by_verdict, by_domain, quality_hist×5, size_hist×6, ms_hist×6, timeline(10s桶×≤60), words≤50, arcs, dots≤400, edges≤30, tags, seq}`
- **错误语义**：越权一律 HTTP 403 + `code=ACL_*/BUS_*` + reason 文案（UI 直接展示）；
  `BUS_MISSING_AUTHORIZATION` = 指令缺 authorized_by 链（收口18）。
