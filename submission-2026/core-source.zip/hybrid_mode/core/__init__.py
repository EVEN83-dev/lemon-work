# -*- coding: utf-8 -*-
"""hybrid_mode.core — 混合模式核心桥。"""
