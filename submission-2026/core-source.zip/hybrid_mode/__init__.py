# -*- coding: utf-8 -*-
"""hybrid_mode — 混合模式（窗口3·公司模式）后端包。

补齐 hybrid_mode_web_panel._setup_bridge() 长期缺位的
`from hybrid_mode.core.hybrid_mode_bridge import HybridBridge` 导入链。

结构：
  hybrid_mode/
    __init__.py            本文件（包声明）
    core/
      __init__.py
      hybrid_mode_bridge.py   HybridBridge(engine_manager, panel) 真桥

注意分工：本包只做**桥接与取数**（role_system 名册 / SubAgentOrchestrator
账本 / EngineManager.spawn_subagent / MultiInstanceManager 集群），
真实执行链仍在 engine_manager（白名单/预算/超时在那一层强制）。
公司级持久化与事件落库在 shared/company（store/service/server）。
"""

__version__ = "1.0.0"

__all__ = ["core"]
