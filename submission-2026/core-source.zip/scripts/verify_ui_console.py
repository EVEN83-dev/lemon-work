# -*- coding: utf-8 -*-
"""★ 收口项 40/41/43：UI 控制台零错误零 404 + ≥50 爬虫卡渲染 + 旧入口加载。

QtWebEngine 离屏，真实 crawl.db 会话（150 页 ≥ 50 卡要求）：
  A. /stats（窗口2 统计层）—— 点阵/弧线 150 点（≥50）+ 计数=真实值
  B. /（窗口1 蜘蛛看板）—— 加载 + 监听
  C. company_board.html（旧入口，收口项 43）—— 加载 + 监听
判定：控制台 error 级 = 0；404 = 0；50 条消息滚动由 verify_company_os（V5 DOM
9 卡 + 会话渲染）覆盖，此处覆盖爬虫卡 ≥50。

用法：python -X utf8 scripts/verify_ui_console.py [base_url] [sid]
"""
from __future__ import annotations

import os
import sys

os.environ.setdefault("QTWEBENGINE_CHROMIUM_FLAGS", "--disable-gpu --no-sandbox")

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

from PyQt5.QtCore import Qt, QTimer, QUrl          # noqa: E402
from PyQt5.QtWidgets import QApplication           # noqa: E402
from PyQt5.QtWebEngineWidgets import QWebEnginePage, QWebEngineView  # noqa: E402

BASE = sys.argv[1] if len(sys.argv) > 1 else ""
SID = sys.argv[2] if len(sys.argv) > 2 else ""

RESULTS = []
LOG = []


def _has_session(sid):
    """该会话在真实 crawl.db 有页 → 用作 UI 渲染目标（真数据）。"""
    try:
        import sqlite3
        con = sqlite3.connect(os.path.join(_ROOT, "data", "crawl.db"))
        n = con.execute("SELECT COUNT(*) FROM crawl_page WHERE session_id=?",
                        (sid,)).fetchone()[0]
        con.close()
        return n >= 50
    except Exception:
        return False


def check(name, ok, detail=""):
    print(("  ✓ " if ok else "  ✗ ") + name + (f"  ({detail})" if detail else ""))
    RESULTS.append((name, ok, detail))


class MonitorPage(QWebEnginePage):
    """控制台 + 网络失败监听（收口项 41）。"""

    def __init__(self, *a):
        super().__init__(*a)
        self.errors = []
        self.not_found = []

    def javaScriptConsoleMessage(self, level, message, line, source):
        LOG.append(f"[console l{level}] {message} @ {source}:{line}")
        if level >= 2:   # Critical/Fatal
            self.errors.append(message)

    def acceptCertificateError(self, *a):
        return False


def main() -> int:
    global BASE, SID
    print("== UI 控制台/404/滚动 验收 ==")
    app = QApplication(sys.argv)
    view = QWebEngineView()
    page = MonitorPage(view)
    view.setPage(page)
    view.resize(1280, 760)
    view.page().setBackgroundColor(Qt.black)

    server = None
    if not BASE:
        # 自起 stage_server（INSECURE 模式，随机口），用真实 crawl.db
        os.environ["LEMON_BRIDGE_INSECURE"] = "1"
        from shared.crawler import stage_server
        from shared.crawler.board_data import latest_session
        port = stage_server.start([0])
        server = (stage_server, port)
        BASE = f"http://127.0.0.1:{port}"
        SID = SID or ("cs_20261120_011608_6803"
                      if _has_session("cs_20261120_011608_6803")
                      else (latest_session() or ""))
        print(f"  [setup] stage_server :{port}  sid={SID}")
    else:
        from shared.crawler.board_data import latest_session
        SID = SID or ("cs_20261120_011608_6803"
                      if _has_session("cs_20261120_011608_6803")
                      else (latest_session() or ""))

    OUT = os.path.join(_ROOT, "outputs", "acceptance")
    os.makedirs(OUT, exist_ok=True)

    def step_a():
        view.load(QUrl(f"{BASE}/stats?sid={SID}"))

    def check_a():
        def cb(v):
            n = 0
            try:
                n = int(str(v))
            except Exception:
                pass
            check("A 爬虫卡 ≥50（真实页数渲染）", n >= 50, f"pages={n}")
        view.page().runJavaScript(
            "(function(){var el=document.getElementById('cPages');"
            "return el?el.textContent:'NOT_BUILT';})()", 0, cb)
        view.grab().save(os.path.join(OUT, "baseline_stats.png"))
        print(f"  [shot] {OUT}/baseline_stats.png")

    def step_b():
        view.load(QUrl(f"{BASE}/?sid={SID}"))

    def check_b():
        view.grab().save(os.path.join(OUT, "baseline_board.png"))
        print(f"  [shot] {OUT}/baseline_board.png")

    def step_c():
        p = os.path.join(_ROOT, "company_board.html")
        if os.path.exists(p):
            view.load(QUrl.fromLocalFile(p))
        else:
            QTimer.singleShot(300, done)
            return

    def check_c():
        view.grab().save(os.path.join(OUT, "baseline_company_board.png"))
        print(f"  [shot] {OUT}/baseline_company_board.png")

    def done():
        check("43 旧入口 company_board.html 可加载", os.path.exists(
            os.path.join(_ROOT, "company_board.html")))
        check("41 控制台零 error（三页累计）", len(page.errors) == 0,
              f"{len(page.errors)} 条: {page.errors[:3]}")
        check("41 网络 404（三页累计）", len(page.not_found) == 0,
              f"{page.not_found[:3]}")
        with open(os.path.join(OUT, "ui_console_log.txt"), "w",
                  encoding="utf-8") as f:
            f.write("\n".join(LOG) + "\n")
        print(f"  [log] {OUT}/ui_console_log.txt")
        app.quit()

    t = 300
    for delay, fn in [(7000, check_a), (300, step_b), (9000, check_b),
                      (300, step_c), (7000, check_c), (300, done)]:
        t += delay
        QTimer.singleShot(t, fn)
    step_a()
    view.show()
    app.exec_()
    if server:
        server[0].stop()
    fails = sum(1 for _, ok, _ in RESULTS if not ok)
    print(f"\n结果：PASS={len(RESULTS)-fails} FAIL={fails}")
    return 0 if fails == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
