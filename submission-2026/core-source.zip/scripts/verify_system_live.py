# -*- coding: utf-8 -*-
"""verify_system_live — 超级爬虫 × 多 agent 公司 · 真机联调验收。

用户验收清单（逐条落断言）：
  A 多 agent 公司
    A1 前端/后端是否连上（真 HybridBridge → 真 CompanyService → DOM）
    A2 9 个 agent 是否齐备（档案/级别/汇报链/白名单/能力位）
    A3 每个 agent 是否有独立会话（单聊）
    A4 每个 agent 能否单独派活（assign → working → task_started）
    A5 每个 agent 能否单独对话（owner → agent 会话，消息真落库 + 消息页命中）
    A6 文件交接能否登记（recordFileChange → patch 产物）
    A7 技能/上下文能否读（getAgentWhitebox：技能数/预算/上下文）
    A8 真实执行（真引擎跑一个任务到 done/failed）
    A9 前端按钮：派活 / 自由对话 / 文件两框 / 九卡抽屉消息页
  B 超级爬虫
    B1 stage_server 前后端连通（/health、/api/board、/api/v3/stats）
    B2 真实抓取写库（本地 fixture HTTP，真 urllib，真 CrawlEngine）
    B3 蜘蛛是否真的在爬（canvas 像素两次采样不同）
    B4 信息是否真的在滚（#textTrack 位置两次采样不同）
    B5 主信息标注（#annStack 行数）
    B6 表格/统计（#decisionList、KPI、底栏四块）
    B7 画框稳定（6 次采样 canvas 不消失、无 __simerr、无 console error）

运行：
  _py312/python.exe scripts/verify_system_live.py            # 全跑
  _py312/python.exe scripts/verify_system_live.py --phase company
  _py312/python.exe scripts/verify_system_live.py --phase crawl

产物：outputs/acceptance/system_live/{report.md,report.json,*.png,run_log.txt}
退出码：FAIL>0 → 1；仅 GAP → 0（GAP = 产品缺口，需产品决策，不算回归失败）
"""
import argparse
import asyncio
import io
import json
import os
import re
import sys
import tempfile
import threading
import time
import urllib.request
import zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.chdir(ROOT)
os.environ.setdefault("QTWEBENGINE_CHROMIUM_FLAGS", "--disable-gpu --no-sandbox")

OUT = os.path.join(ROOT, "outputs", "acceptance", "system_live")
os.makedirs(OUT, exist_ok=True)

PASS, FAIL, GAP = [], [], []
LOG = []


def check(name, cond, detail="", gap=False):
    """gap=True 时失败记 GAP（产品缺口）而不是 FAIL。"""
    if cond:
        PASS.append(name)
        line = f"[PASS] {name}" + (f"  -- {detail}" if detail else "")
    elif gap:
        GAP.append(name)
        line = f"[GAP ] {name}  -- {detail}"
    else:
        FAIL.append(name)
        line = f"[FAIL] {name}  -- {detail}"
    print(line, flush=True)
    LOG.append(line)
    return bool(cond)


async def _launch(pw):
    for kw in (dict(headless=True), dict(headless=True, channel="msedge"),
               dict(headless=True, channel="chrome")):
        try:
            return await pw.chromium.launch(**kw)
        except Exception:
            continue
    raise RuntimeError("无可用 Chromium 内核（playwright 未装浏览器）")


# ════════════════════════════════════════════════════════════════════
# Phase A · 多 agent 公司
# ════════════════════════════════════════════════════════════════════

def _company_backend():
    """真后端：隔离库 + 真 CompanyService + 真 HybridBridge。返回上下文 dict。"""
    tmp = tempfile.mkdtemp(prefix="lw_sys_company_")
    os.environ["LW_CHAT_DB"] = os.path.join(tmp, "chat.db")
    from PyQt5.QtCore import Qt, QCoreApplication
    QCoreApplication.setAttribute(Qt.AA_ShareOpenGLContexts, True)
    from PyQt5.QtWidgets import QApplication
    _app = QApplication.instance() or QApplication(sys.argv)
    from shared.company.service import get_company_service
    svc = get_company_service(db_path=os.path.join(tmp, "company.db"))
    from hybrid_mode.core.hybrid_mode_bridge import HybridBridge
    bridge = HybridBridge()
    return {"svc": svc, "bridge": bridge, "tmp": tmp, "app": _app}


def _capi(bridge, method, payload=None):
    raw = bridge.companyApi(method, json.dumps(payload or {}, ensure_ascii=False))
    try:
        return json.loads(raw)
    except Exception:
        return {"ok": False, "error": f"bad json: {raw[:120]}"}


async def run_company():
    print("\n══════════ A · 多 agent 公司 ══════════", flush=True)
    ctx = _company_backend()
    svc, bridge = ctx["svc"], ctx["bridge"]
    orig_engine = svc._engine
    svc._engine = lambda: None          # 9 人先只验账本链路，不并发烧模型额度

    # A10 标题栏「标准 | 公司」胶囊（真 Qt 控件，真信号）
    try:
        from standard_mode.ui.main_window import XiaomiTitleBar
        _tb = XiaomiTitleBar()
        _got = []
        _tb.service_mode_requested.connect(lambda m: _got.append(m))
        _tb._btn_mode_company.click()
        _ok1 = (_got == ["hybrid"] and _tb._btn_mode_company.isChecked()
                and not _tb._btn_mode_standard.isChecked())
        _tb._btn_mode_standard.click()
        _ok2 = (_got == ["hybrid", "original"] and _tb._btn_mode_standard.isChecked()
                and not _tb._btn_mode_company.isChecked())
        check("A10 标题栏模式胶囊（标准↔公司）真发信号", _ok1 and _ok2,
              f"signals={_got}")
    except Exception as e:
        check("A10 标题栏模式胶囊（标准↔公司）真发信号", False, repr(e))

    # A0 开张（真 uploadBrief → _decompose → 9 会话）
    up = _capi(bridge, "uploadBrief", {
        "name": "系统联调验收", "uploaded_by": "owner",
        "content": "调研共享爬虫与任务墙，扫描全部页面找链接，产出风险评分报告并导出 csv"})
    st = _capi(bridge, "getState")
    data = st.get("data") or {}
    check("A1 前端桥接 getState 返回真 state",
          st.get("ok") is True and isinstance(data.get("board"), list),
          f"ok={st.get('ok')} keys={sorted(data.keys())[:8]}")
    check("A0 uploadBrief 开张并拆解 DAG", up.get("ok") is True,
          f"ok={up.get('ok')} err={up.get('error')}")

    board = data.get("board") or []
    sessions = data.get("sessions") or []
    check("A2 9 工位编制齐备", len(board) == 9, f"board={len(board)}")
    roles = [b.get("role_id") for b in board]
    print("   roles:", roles, flush=True)

    # A2 每人工位档案
    bad = []
    for b in board:
        rid = b.get("role_id")
        if not (b.get("name") and b.get("dept") and int(b.get("level", 9)) <= 2
                and int(b.get("whitelist") or 0) > 0 and isinstance(b.get("caps"), dict)):
            bad.append(rid)
    check("A2 每人档案完整（姓名/部门/级别/白名单/能力位）", not bad,
          f"bad={bad}")

    # A3 每人独立单聊会话
    def sess_of(rid):
        for s in sessions:
            if s.get("kind") == "dm" and rid in (s.get("members") or []):
                return s.get("session_id")
        return ""

    no_sess = [rid for rid in roles if not sess_of(rid)]
    check("A3 9 人各有独立单聊会话", not no_sess, f"missing={no_sess}")

    # A4 每人单独派活（账本链路）
    assign_ok, assigned = [], {}
    for i, rid in enumerate(roles):
        r = svc.assign(role_id=rid, task=f"联调验收 #{i+1}：{rid} 独立工作链路",
                       kind="work")
        assign_ok.append(bool(r.get("ok")))
        assigned[rid] = r.get("task_id")
    check("A4 9 人逐一派活成功", all(assign_ok),
          f"ok={sum(assign_ok)}/9 errs={[rid for rid, ok in zip(roles, assign_ok) if not ok]}")
    st2 = svc.state()
    bmap = {b["role_id"]: b.get("state") for b in (st2.get("board") or [])}
    working = [rid for rid in roles if bmap.get(rid) == "working"]
    check("A4 派活后 9 人均进入 working", len(working) == 9,
          f"working={len(working)} states={bmap}")
    ev_types = [e.get("type") for e in (st2.get("events") or [])]
    n_started = ev_types.count("task_started")
    check("A4 task_started 事件 ≥9（真实时间戳）", n_started >= 9,
          f"task_started={n_started}")

    # 释放 9 个工位（stub 任务不会自然结束，否则后面真跑会被「工位全忙」排队）
    released = 0
    for _rid, _tid in assigned.items():
        if _tid:
            try:
                rr = svc.complete(int(_tid), result="联调占位完成（engine stub）", tokens=0)
                released += 1 if rr.get("ok") else 0
            except Exception:
                pass
    check("A4 stub 任务可正常收尾释放工位", released >= 9, f"released={released}/9")

    # A5 每人单独对话（owner → agent 会话，report；role 留空 = 人类主体直发）
    talk_ok, list_ok = [], []
    for i, rid in enumerate(roles):
        sid = sess_of(rid)
        if not sid:
            talk_ok.append(False)
            list_ok.append(False)
            continue
        env = {"from": "owner", "to": sid, "role": "", "type": "report",
               "authorization": "report", "payload": f"[单聊验收] 你好 {rid}，这是第 {i+1} 条直连消息"}
        r = svc.send_message(env)
        talk_ok.append(bool(r.get("ok")))
        if not r.get("ok"):
            print(f"   [A5] {rid} 投递失败: {r.get('error')}", flush=True)
        lm = _capi(bridge, "listMessages", {"role_id": rid, "session_id": sid})
        n = ((lm.get("data") or {}) if lm.get("ok") else {}).get("count", 0)
        list_ok.append(int(n or 0) >= 1)
    check("A5 9 人逐一单聊投递成功", all(talk_ok), f"ok={sum(talk_ok)}/9")
    check("A5 9 人消息页均能命中自己的信", all(list_ok), f"hit={sum(list_ok)}/9")

    # A6 文件交接（挑 3 个代表）
    art_before = len((svc.state().get("artifacts") or []))
    file_ok = []
    for rid in ("frontend", "backend", "writer"):
        r = svc.record_file_change(
            role_id=rid, path=f"{rid}/verify_live_{rid}.js",
            old_text="", new_text=f"// {rid} verify live\nconsole.log('{rid}');",
            task_id=assigned.get(rid), approver="owner")
        file_ok.append(bool(r.get("ok")))
    art_after = len((svc.state().get("artifacts") or []))
    check("A6 文件交接登记三人（patch 真 diff 落产物）", all(file_ok),
          f"ok={sum(file_ok)}/3 artifacts {art_before}→{art_after}")
    check("A6 产物数量真增长", art_after > art_before,
          f"{art_before}→{art_after}")

    # A7 白盒能力（技能/预算/上下文）
    wb_bad = []
    for rid in roles:
        wb = _capi(bridge, "getAgentWhitebox", {"role_id": rid})
        d = (wb.get("data") or {}) if wb.get("ok") else {}
        skills = (d.get("skill_whitelist") or d.get("skills")
                  or d.get("capabilities") or [])
        if not d or not skills:
            wb_bad.append(rid)
    check("A7 9 人白盒可读且技能清单非空", not wb_bad, f"bad={wb_bad}")

    # A8 真实执行一个（恢复真引擎，只跑 backend 一条）
    svc._engine = orig_engine
    real = svc.assign(role_id="backend", task="统计 1 到 5 的和并回报", kind="work")
    tid = real.get("task_id")
    row = None
    end = time.time() + 120
    while time.time() < end and tid:
        row = svc._store.get_task(tid)
        if row and row.get("status") in ("done", "failed"):
            break
        await asyncio.sleep(1)
    done = bool(row and row.get("status") == "done")
    check("A8 真引擎执行任务到 done", done,
          f"task={tid} status={(row or {}).get('status')} tokens={(row or {}).get('tokens')}")

    # ── A9 前端按钮（playwright + 真 bridge）──
    from playwright.async_api import async_playwright
    errs = []

    async with async_playwright() as pw:
        browser = await _launch(pw)
        page = await browser.new_page(viewport={"width": 1440, "height": 920})
        await page.expose_function(
            "__pyCompanyApi",
            lambda m, p: bridge.companyApi(m or "", p or "{}"))
        await page.add_init_script(
            "window.__bridge={companyApi:function(m,p,cb){"
            "window.__pyCompanyApi(m,p||'{}').then(function(r){if(cb)cb(r)});}};")
        page.on("pageerror", lambda e: errs.append(str(e)))
        await page.goto("file:///" + os.path.join(ROOT, "company_os.html").replace("\\", "/"))
        await page.wait_for_timeout(900)
        await page.evaluate(
            "window.__bridge={companyApi:function(m,p,cb){"
            "window.__pyCompanyApi(m,p||'{}').then(function(r){if(cb)cb(r)});}};")
        await page.evaluate("window.refreshState && window.refreshState()")
        # ★ 与面板 QWebChannel 注入同款：直接把真 state 推给页面，确保 __real/S 就绪
        _raw = bridge.companyApi("getState", "{}")
        _sd = (json.loads(_raw) or {}).get("data") or {}
        await page.evaluate(
            "window.onCompanyState && window.onCompanyState(%s)" %
            json.dumps(_sd, ensure_ascii=False, default=str))
        await page.wait_for_timeout(1500)
        _real_flag = await page.evaluate("window.__real === true")
        check("A9 页面进入真实态（__real=true）", bool(_real_flag),
              f"__real={_real_flag}")

        ncards = await page.evaluate(
            "document.querySelectorAll('#cardsMatrix [data-emp]').length")
        check("A9 公司页渲染 9 张员工卡", ncards == 9, f"cards={ncards}")

        # 逐人：点卡 → 抽屉 → 消息页有行
        per_agent = []
        for rid in roles:
            await page.evaluate(
                "(function(r){var c=document.querySelector('#cardsMatrix [data-emp=\"'+r+'\"]');"
                "if(c)c.click()})('%s')" % rid)
            await page.wait_for_timeout(520)
            await page.evaluate(
                "document.querySelector('#drawer .dtabs button[data-dt=\"msgs\"]').click()")
            await page.wait_for_timeout(650)
            n = await page.evaluate(
                "document.getElementById('dBody').querySelectorAll('.msg:not(.sys)').length"
                "+(document.getElementById('dBody').textContent.indexOf('暂无命中消息')>=0?-99:0)")
            per_agent.append((rid, n))
        bad_msg = [r for r, n in per_agent if n < 1]
        check("A9 9 人消息页均渲染出真实信件", not bad_msg,
              f"bad={bad_msg} rows={per_agent}")

        # 派活按钮 +1
        await page.evaluate(
            "(function(){var c=document.querySelector('#cardsMatrix [data-emp=\"backend\"]');"
            "if(c)c.click()})()")
        await page.wait_for_timeout(520)
        await page.evaluate(
            "document.querySelector('#drawer .dtabs button[data-dt=\"msgs\"]').click()")
        await page.wait_for_timeout(600)
        before = await page.evaluate(
            "document.getElementById('dBody').querySelectorAll('.msg:not(.sys)').length")
        await page.evaluate("document.getElementById('dDispatch').click()")
        await page.wait_for_timeout(350)
        await page.fill('#dcText', '联调验收：派活按钮真投递')
        await page.click('#dcOk')
        await page.wait_for_timeout(1600)
        after = await page.evaluate(
            "document.getElementById('dBody').querySelectorAll('.msg:not(.sys)').length")
        check("A9 「⚡派活」按钮真投递（消息行 +1）", after == before + 1,
              f"rows {before}→{after}")

        # 自由对话（#dInput → #dSend）
        b2 = await page.evaluate(
            "document.getElementById('dBody').querySelectorAll('.msg:not(.sys)').length")
        await page.fill('#dInput', '联调验收：自由对话直连消息')
        await page.click('#dSend')
        await page.wait_for_timeout(1600)
        a2 = await page.evaluate(
            "document.getElementById('dBody').querySelectorAll('.msg:not(.sys)').length")
        check("A9 自由对话输入真投递（消息行 +1）", a2 == b2 + 1,
              f"rows {b2}→{a2}")

        # 文件交接两框
        art0 = len((svc.state().get("artifacts") or []))
        await page.evaluate("document.getElementById('fileChgBtn').click()")
        await page.wait_for_timeout(350)
        await page.fill('#dcPath', 'frontend/ui_button_verify.js')
        await page.fill('#dcText', '// button verify\nconsole.log(1);')
        await page.click('#dcOk')
        await page.wait_for_timeout(1800)
        art1 = len((svc.state().get("artifacts") or []))
        check("A9 「＋记录变更」两框真登记（产物 +1）", art1 > art0,
              f"artifacts {art0}→{art1}")

        await page.screenshot(path=os.path.join(OUT, "company_live.png"),
                              full_page=True)
        # ★ 第20批: 立刻开工按钮 —— 真 assign（不是消息投递）
        has_assign_btn = await page.evaluate("!!document.getElementById('dAssign')")
        check("A9 前端存在「单员工立即开工」入口", has_assign_btn,
              f"dAssign={has_assign_btn}", gap=True)
        if has_assign_btn:
            _desc = "联调验收：立刻开工按钮真执行"
            await page.evaluate(
                "(function(){var c=document.querySelector('#cardsMatrix [data-emp=\"backend\"]');"
                "if(c)c.click()})()")
            await page.wait_for_timeout(520)
            await page.evaluate("document.getElementById('dAssign').click()")
            await page.wait_for_timeout(350)
            await page.fill('#dcText', _desc)
            await page.click('#dcOk')
            _fired, _row = False, {}
            for _ in range(40):
                await page.wait_for_timeout(500)
                for _t in (svc.state().get("tasks") or []):
                    if _desc in str(_t.get("description") or ""):
                        _fired, _row = True, _t
                        break
                if _fired:
                    break
            check("A9 「立刻开工」真派发（账本出现该任务）", _fired,
                  f"task_id={_row.get('id')} role={_row.get('role_id')} "
                  f"status={_row.get('status')}")
        await browser.close()
    check("A9 前端零 JS 异常", not errs, f"pageerror={errs[:2]}")

    # 收尾：停后台 watcher + 断开 Qt 桥订阅（避免进程退出后 emit 到已销毁对象）
    try:
        svc._stopped = True
        svc._event_cbs.clear()
        svc._state_cbs.clear()
    except Exception:
        pass

    # 汇总数据
    return {
        "roles": roles,
        "sessions": sum(1 for s in sessions if s.get("kind") == "dm"),
        "working": len(working),
        "task_started": n_started,
        "messages_hit": sum(list_ok),
        "artifacts": art_after,
        "real_task": {"id": tid, "status": (row or {}).get("status"),
                      "tokens": int((row or {}).get("tokens") or 0)},
    }


# ════════════════════════════════════════════════════════════════════
# Phase B · 超级爬虫
# ════════════════════════════════════════════════════════════════════

class _Fixture(BaseHTTPRequestHandler):
    """本地 fixture 站点：真 HTTP、真链接、真文本长度（不依赖外网）。"""
    def log_message(self, *a):
        pass

    def do_GET(self):
        m = re.search(r"[?&]id=(\d+)", self.path)
        pid = int(m.group(1)) if m else 0
        depth_m = re.search(r"[?&]d=(\d+)", self.path)
        depth = int(depth_m.group(1)) if depth_m else 0
        size = 300 + (pid * 137) % 2600
        links = "".join(
            f'<a href="http://127.0.0.1:{self.server.server_port}/p?id={pid * 3 + k + 1}'
            f'&d={depth + 1}">next{k}</a>' for k in range(1, 4))
        body = (f"<html><head><title>fixture {pid}</title></head><body>"
                f"<h1>live verify page {pid}</h1><p>{'crawler text ' * (size // 12)}</p>"
                f"{links}</body></html>").encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def _start_fixture():
    srv = ThreadingHTTPServer(("127.0.0.1", 0), _Fixture)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, srv.server_port


def _real_fetch(url, depth=0):
    t0 = time.time()
    try:
        with urllib.request.urlopen(url, timeout=6) as r:
            raw = r.read()
            code = r.status
    except Exception as e:
        return {"status": "fail", "url": url, "url_key": url, "domain": "127.0.0.1",
                "depth": depth, "quality": 0.0, "text_len": 0, "text": "",
                "elapsed_ms": int((time.time() - t0) * 1000), "size_bytes": 0,
                "title": "", "links": [], "error": str(e)}
    html = raw.decode("utf-8", "ignore")
    text = re.sub(r"<[^>]+>", " ", html)
    links = re.findall(r'href="([^"]+)"', html)
    q = 0.15 + (zlib.crc32(url.encode("utf-8")) % 80) / 100.0
    return {"status": "ok" if code == 200 else "fail", "url": url, "url_key": url,
            "domain": "127.0.0.1", "depth": depth, "quality": round(min(q, 0.97), 3),
            "text_len": len(text), "text": text,
            "elapsed_ms": int((time.time() - t0) * 1000), "size_bytes": len(raw),
            "title": f"fixture {url}", "links": links}


SAMPLER = """JSON.stringify((function(){
  function sig(id){var c=document.getElementById(id);if(!c)return null;
    var w=c.width,h=c.height;if(!w||!h)return null;
    try{var d=c.getContext('2d').getImageData(0,0,w,h).data;var s=0;
      for(var i=0;i<d.length;i+=997)s=(s+d[i])%1000000007;return s;}
    catch(e){return 'err:'+e.message}}
  function rect(id){var e=document.getElementById(id);if(!e)return null;
    var r=e.getBoundingClientRect();return [Math.round(r.width),Math.round(r.height)]}
  var tr=document.getElementById('textTrack');
  var tTop=tr?Math.round(tr.getBoundingClientRect().top):null;
  var k5=document.getElementById('k5');
  return {sp:sig('spiderCanvas'), arc:sig('arcCanvas'),
          web:sig('webCanvas'),
          spRect:rect('spiderCanvas'), arcRect:rect('arcCanvas'),
          tTop:tTop,
          ann:document.querySelectorAll('#annStack .as-row').length,
          dec:document.querySelectorAll('#decisionList .dec:not(.phDash)').length,
          panels:document.querySelectorAll('#crawlBottom .panel').length,
          k5:k5?String(k5.textContent).trim():'',
          canvases:document.querySelectorAll('canvas').length,
          simerr:window.__simerr||''}})())"""


async def run_crawl():
    print("\n══════════ B · 超级爬虫 ══════════", flush=True)
    from shared.crawler import store as cstore
    from shared.crawler.engine import CrawlEngine
    from shared.crawler.session import create_session
    from shared.crawler import stage_server
    from playwright.async_api import async_playwright

    fixture, fport = _start_fixture()
    seed = f"http://127.0.0.1:{fport}/p?id=1&d=0"
    sid = create_session("系统联调 · 超级爬虫实时验收", seed)
    # ★ 慢速单工位：保证采样窗口内会话仍处 running（真实时，不是抓完看回放）
    eng = CrawlEngine(sid, _real_fetch, workers=1, delay_ms=650)
    th = threading.Thread(
        target=eng.run,
        kwargs=dict(max_pages=60, max_depth=8, seed_urls=[seed]),
        daemon=True)
    th.start()
    time.sleep(1.5)

    port = stage_server.start()
    check("B1 stage_server 启动（真端口）", bool(port), f"port={port}")

    def _get(path, timeout=4):
        with urllib.request.urlopen(f"http://127.0.0.1:{port}{path}",
                                    timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))

    health = _get("/health")
    check("B1 /health 连通且 db 存在", health.get("ok") is True and
          bool(health.get("db")), str(health))
    board = _get(f"/api/board?sid={sid}")
    n_pages_api = len((board.get("board") or {}).get("nodes") or []) \
        if isinstance(board.get("board"), dict) else 0
    db_n = cstore.ro_conn().execute(
        "SELECT COUNT(*) n FROM crawl_page WHERE session_id=?", (sid,)).fetchone()["n"]
    # ★ 实时抓取中 API 有 1s 缓存，允许 ≤2 页时差（不是数据不一致）
    check("B1 后端 /api/board 与 crawl.db 同步（实时 ±2）",
          db_n > 0 and abs(n_pages_api - db_n) <= 2,
          f"api_nodes={n_pages_api} db_pages={db_n}")
    _sess_state = str(((board.get("stats") or {}).get("session") or {}).get("state") or "")
    check("B1 会话处于 running（实时抓取态）", _sess_state == "running",
          f"state={_sess_state!r}")

    # ★ 主信息标注：给已抓到的页面写真实 annotation（crawl_annotation 真表）
    try:
        from shared.crawler import annotate
        _pids = [int(r["id"]) for r in cstore.ro_conn().execute(
            "SELECT id FROM crawl_page WHERE session_id=? ORDER BY id DESC LIMIT 8",
            (sid,)).fetchall()]
        for k, pid in enumerate(_pids):
            annotate.create(pid, field="body", quote="crawler",
                            note=f"联调标注 #{k+1}",
                            tags=["crawler", "link"], color="#f5a623",
                            author="verify_live", status="confirmed")
    except Exception as e:
        print("  [B5] annotation 写入失败:", e, flush=True)

    errs, console = [], []
    async with async_playwright() as pw:
        browser = await _launch(pw)
        page = await browser.new_page(viewport={"width": 1440, "height": 900})
        page.on("pageerror", lambda e: errs.append(str(e)))
        page.on("console", lambda m: console.append(m.text) if m.type == "error" else None)
        await page.goto(f"http://127.0.0.1:{port}/stage3?sid={sid}",
                        wait_until="load")
        await page.wait_for_timeout(1800)

        samples = []
        for _ in range(8):
            raw = await page.evaluate(SAMPLER)
            samples.append(json.loads(raw))
            await page.wait_for_timeout(700)

        s0 = samples[0]
        check("B7 画框存在且尺寸非零（spider/arc）",
              bool(s0.get("spRect")) and s0["spRect"][0] > 100
              and s0["spRect"][1] > 100 and bool(s0.get("arcRect"))
              and s0["arcRect"][0] > 100, f"sp={s0.get('spRect')} arc={s0.get('arcRect')}")
        sp_vals = {x.get("sp") for x in samples if x.get("sp") is not None}
        check("B3 蜘蛛真的在动（canvas 像素 6 次采样出现多态）", len(sp_vals) >= 2,
              f"distinct={len(sp_vals)} vals={list(sp_vals)[:3]}")
        arc_vals = {x.get("arc") for x in samples if x.get("arc") is not None}
        check("B6 判定扇形真的在绘制（arc canvas 多态）", len(arc_vals) >= 2,
              f"distinct={len(arc_vals)}")
        tt_vals = {x.get("tTop") for x in samples if x.get("tTop") is not None}
        check("B4 信息真的在滚动（#textTrack 位置多态）", len(tt_vals) >= 3,
              f"distinct_tops={sorted(tt_vals)[:6]}")
        ann = max(int(x.get("ann") or 0) for x in samples)
        check("B5 主信息标注存在（#annStack 行数>0）", ann > 0, f"ann_rows={ann}")
        dec = max(int(x.get("dec") or 0) for x in samples)
        check("B6 表格/判定行存在（#decisionList 行数>0）", dec > 0, f"dec_rows={dec}")
        panels = max(int(x.get("panels") or 0) for x in samples)
        check("B6 底栏四块统计画框齐备", panels == 4, f"panels={panels}")
        k5 = next((x.get("k5") for x in samples if x.get("k5")), "")
        check("B6 KPI 真实数值（非 0/空）", bool(k5) and k5 not in ("0", "—", ""),
              f"k5={k5!r}")
        alive = all(bool(x.get("canvases")) and not x.get("simerr") for x in samples)
        check("B7 连续 6 次采样画框不消失 / 无 __simerr", alive,
              f"canvases={[x.get('canvases') for x in samples]} "
              f"simerr={[x.get('simerr') for x in samples][:2]}")
        check("B7 页面零 JS 异常 / 零 console error", not errs and not console,
              f"pageerror={errs[:2]} console={console[:2]}")

        await page.screenshot(path=os.path.join(OUT, "crawl_live.png"),
                              full_page=True)
        el = await page.query_selector("#textPane")
        if el:
            await el.screenshot(path=os.path.join(OUT, "crawl_spider.png"))
        await browser.close()

    th.join(timeout=25)
    final_n = cstore.ro_conn().execute(
        "SELECT COUNT(*) n FROM crawl_page WHERE session_id=?", (sid,)).fetchone()["n"]
    check("B2 真实抓取持续写库（页数增长）", final_n > db_n,
          f"pages {db_n}→{final_n}")
    try:
        fixture.shutdown()
    except Exception:
        pass
    try:
        stage_server.stop()
    except Exception:
        pass
    return {"sid": sid, "port": port, "pages": final_n,
            "samples": len(samples), "ann": ann, "dec": dec, "k5": k5}


# ════════════════════════════════════════════════════════════════════

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--phase", default="all", choices=("all", "company", "crawl"))
    args = ap.parse_args()
    t0 = time.time()
    summary = {}
    if args.phase in ("all", "company"):
        try:
            summary["company"] = asyncio.run(run_company())
        except Exception as e:
            import traceback
            traceback.print_exc()
            check("A 公司阶段整体执行", False, repr(e))
    if args.phase in ("all", "crawl"):
        try:
            summary["crawl"] = asyncio.run(run_crawl())
        except Exception as e:
            import traceback
            traceback.print_exc()
            check("B 爬虫阶段整体执行", False, repr(e))

    total = len(PASS) + len(FAIL) + len(GAP)
    print("\n" + "=" * 60, flush=True)
    print(f"结果: {len(PASS)} passed, {len(FAIL)} failed, {len(GAP)} gap "
          f"({time.time()-t0:.1f}s)", flush=True)
    if GAP:
        print("产品缺口：", GAP, flush=True)

    with open(os.path.join(OUT, "report.json"), "w", encoding="utf-8") as f:
        json.dump({"passed": PASS, "failed": FAIL, "gap": GAP,
                   "summary": summary, "elapsed_s": round(time.time() - t0, 1)},
                  f, ensure_ascii=False, indent=2)
    with open(os.path.join(OUT, "run_log_snapshot.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(LOG) + "\n")
    md = ["# 系统联调验收报告", "",
          f"- 通过 **{len(PASS)}** / 失败 **{len(FAIL)}** / 缺口 **{len(GAP)}**"
          f"（{total} 项，{time.time()-t0:.1f}s）", ""]
    md += ["## 产品缺口（需决策）", ""] + [f"- {x}" for x in GAP] if GAP else []
    md += ["", "## 失败项", ""] + [f"- {x}" for x in FAIL] if FAIL else []
    md += ["", "## 通过项", ""] + [f"- {x}" for x in PASS]
    with open(os.path.join(OUT, "report.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(md) + "\n")
    print(f"报告: {os.path.join(OUT, 'report.md')}", flush=True)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
