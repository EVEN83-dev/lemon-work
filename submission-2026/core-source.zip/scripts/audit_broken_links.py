#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Lemon Work · 假实现/空连接审计

比对四组契约，找出"前端调了但后端没有"或"后端发了但前端不接"的断点：
  1. 前端 _callPython/callPython('Xxx', ...) 调用  vs  PyBridge 分派注册
  2. 后端 _safe_run_js 注入的 window.xxx 调用 vs 前端 JS/HTML 定义
  3. 后端 _emit_trace(kind) 事件 vs 前端 case 'kind' 分派
  4. HTML onclick/onchange 假按钮

★ 本脚本自身曾是空连接（v1 把路径写成字面量 r"<LEMON_ROOT>\\LemonWork\\..."，
  从未替换 → 四层测试防线的第①层根本跑不起来）。现从 __file__ 推导根路径，
  并把扫描面从"1 个 py + 1 个 js + 1 个 html"扩到 ui/ 下全部 JS/HTML，
  分派识别也不再只认 `elif`（漏 if/elif 与白名单转发）。
"""
import io
import os
import re
import sys

if hasattr(sys.stdout, "write") and getattr(sys.stdout, "encoding", "") \
        and sys.stdout.encoding.lower().replace("-", "") != "utf8":
    try:
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                      errors="replace", line_buffering=True)
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8",
                                      errors="replace", line_buffering=True)
    except Exception:
        pass

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)                      # LemonWork/
UI = os.path.join(ROOT, "standard_mode", "ui")

PANEL_CANDIDATES = ("mimo_panel.py", "hybrid_mode_web_panel.py")
Q = "['\"]"

# PyBridge 基础槽 / 非分派型方法（不要求 elif 注册）
PY_WHITELIST = {"sendMessage"}


def read(path):
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()


def _js_files():
    out = []
    for name in sorted(os.listdir(UI)):
        if name.endswith(".js") and not name.startswith("vendor"):
            p = os.path.join(UI, name)
            if os.path.isfile(p) and os.path.getsize(p) < 12 * 1024 * 1024:
                out.append((name, read(p)))
    libs = os.path.join(UI, "libs")
    return out


def _html_files():
    out = []
    for base in (UI, ROOT):
        if not os.path.isdir(base):
            continue
        for name in sorted(os.listdir(base)):
            if name.endswith(".html"):
                out.append((name, read(os.path.join(base, name))))
    return out


def _strip_py_comments(text):
    """去掉行内 # 注释 —— 注释里含 ASCII 括号，会把转发表正则提前截断。"""
    out = []
    for line in text.split("\n"):
        cut, in_s, q = 0, False, ""
        i = 0
        while i < len(line):
            c = line[i]
            if in_s:
                if c == "\\":
                    i += 2
                    continue
                if c == q:
                    in_s = False
            elif c in "\"'":
                in_s, q = True, c
            elif c == "#":
                cut = i
                break
            i += 1
        out.append(line[:cut] if cut else line)
    return "\n".join(out)


def _py_dispatch_names(text):
    """识别 PyBridge 注册的方法名：if/elif 相等比较 + method in (...) 分组 +
    白名单常量元组/列表（转发表）。"""
    text = _strip_py_comments(text)
    names = set(re.findall(
        r"(?:if|elif)\s+method\s*==\s*" + Q + r"([A-Za-z_]\w*)" + Q, text))
    for blob in re.findall(r"method\s+in\s*[\(\[]([^\)\]]*)[\)\]]", text):
        names |= set(re.findall(Q + r"([A-Za-z_]\w*)" + Q, blob))
    # ★ 表驱动分派：@_pb("methodName", ...) 装饰器注册（2026-11-23 重构）
    names |= set(re.findall(r"@_pb\(\s*" + Q + r"([A-Za-z_]\w*)" + Q, text))
    # _BRIDGE_FORWARD_METHODS = ('hireAgent', ...) 这类转发表也视为"已注册"，
    # 但必须能在被转发的对象上找到同名方法，否则仍是断链（见 check 1b）
    tuples = re.findall(r"_\w*(?:FORWARD|METHODS)\w*\s*=\s*[\(\[]([^\)\]]*)[\)\]]",
                        text, re.S)
    forwarded = set()
    for blob in tuples:
        forwarded |= set(re.findall(Q + r"([A-Za-z_]\w*)" + Q, blob))
    return names, forwarded


def main():
    if not os.path.isdir(UI):
        print("X 找不到 ui 目录: %s" % UI)
        return 2

    panels = {}
    for name in PANEL_CANDIDATES:
        p = os.path.join(UI, name)
        if os.path.exists(p):
            panels[name] = read(p)
    if not panels:
        print("X 找不到 PyBridge 面板文件（%s）" % ", ".join(PANEL_CANDIDATES))
        return 2

    js_files = _js_files()
    html_files = _html_files()
    js_all = "\n".join(t for _, t in js_files)
    html_all = "\n".join(t for _, t in html_files)

    py_registered, py_forwarded = set(), set()
    for text in panels.values():
        n, f = _py_dispatch_names(text)
        py_registered |= n
        py_forwarded |= f

    issues = []
    stats = {"js": len(js_files), "html": len(html_files),
             "py_registered": len(py_registered), "forwarded": len(py_forwarded)}

    # ── 1. 前端调用 vs 后端分派 ──
    pat_call = (r"(?:_callPython|window\._callPython|callPython)\s*\(\s*" + Q
                + r"([A-Za-z_]\w*)" + Q)
    js_calls = set(re.findall(pat_call, js_all))
    js_calls |= set(re.findall(pat_call, html_all))
    js_calls -= PY_WHITELIST
    miss_py = sorted(js_calls - py_registered - py_forwarded)
    if miss_py:
        issues.append("[空连接-后端缺] 前端调用但 PyBridge 未分派: %s" % miss_py)

    # ── 1b. 转发表里的名字必须在真实桥对象上有实现 ──
    bridge_impl = set()
    for text in panels.values():
        bridge_impl |= set(re.findall(r"def\s+([A-Za-z_]\w*)\s*\(", text))
    bh = os.path.join(ROOT, "hybrid_mode", "core", "hybrid_mode_bridge.py")
    if os.path.exists(bh):
        bridge_impl |= set(re.findall(r"def\s+([A-Za-z_]\w*)\s*\(", read(bh)))
    dead_fwd = sorted(x for x in py_forwarded if x not in bridge_impl
                      and x not in py_registered)
    if dead_fwd:
        issues.append("[空连接-转发缺实现] 转发表登记但桥对象无同名实现: %s" % dead_fwd)

    # ── 2. 后端 JS 注入调用 vs 前端定义 ──
    js_fns = set(re.findall(r"window\.([A-Za-z_]\w*)\s*=\s*(?:function|[\w{])", js_all))
    js_fns |= set(re.findall(r"(?:function|window\.)\s*([A-Za-z_]\w*)\s*\(", js_all))
    js_fns |= set(re.findall(r"function\s+([A-Za-z_]\w*)\s*\(", js_all))
    for _, t in html_files:
        inline = "".join(re.findall(r"<script(?![^>]*src)[^>]*>(.*?)</script>", t, re.S))
        js_fns |= set(re.findall(r"function\s+([A-Za-z_]\w*)\s*\(", inline))
        # 内联脚本里的 window.x = function 赋值同样是定义源（company_os 的
        # onCompanyState 就属于这种，v1 审计漏扫 → 误报"后端注入但前端未定义"）
        js_fns |= set(re.findall(r"window\.([A-Za-z_]\w*)\s*=\s*(?:function|[\w{])", inline))
    for text in panels.values():
        js_fns |= set(re.findall(r"window\.([A-Za-z_]\w*)\s*=\s*(?:function|[\w{])", text))
    raw_calls = set()
    for text in panels.values():
        for m in re.finditer(r"_safe_run_js\((.*?)\)\n", text, re.S):
            raw_calls |= set(re.findall(r"window\.([A-Za-z_]\w*)", m.group(1)))
        # runJavaScript(f"...window.xxx(") 也是注入调用点
        for m in re.finditer(r"runJavaScript\((.{0,400}?)\)\n", text, re.S):
            raw_calls |= set(re.findall(r"window\.([A-Za-z_]\w*)\s*\(", m.group(1)))
    miss_fn = sorted(x for x in raw_calls if x not in js_fns
                     and x != "_pybridgeCallback")
    if miss_fn:
        issues.append("[空连接-前端缺] 后端 JS 注入调用但前端未定义: %s" % miss_fn)

    # ── 3. trace 事件差集 ──
    emits = set()
    for text in panels.values():
        emits |= set(re.findall("_emit_trace\\(\\s*" + Q + r"([a-z_]+)" + Q, text))
    cases = set(re.findall(Q + r"([a-z_]+)" + Q + r"\s*:", js_all))
    miss_case = sorted(e for e in emits if e not in cases)
    if miss_case:
        issues.append("[空连接-事件] 后端 emit 但前端无 case 分派: %s" % miss_case)

    # ── 4. HTML 假按钮 ──
    html_fns = set(re.findall(
        "(?:onclick|onchange|oninput|onload|onsubmit)\\s*=\\s*" + Q
        + r"([A-Za-z_]\w*)\(", html_all))
    miss_html = sorted(x for x in html_fns if x not in js_fns and x != "if")
    if miss_html:
        issues.append("[假按钮] HTML 事件绑定但 JS 无定义: %s" % miss_html)

    # ── 5. 明示未实现的用户可见文案 ──
    not_impl = set(re.findall(
        r"['\"]([^'\"]{0,40}(?:功能开发中|敬请期待|暂未开放|暂未实现|待实现)[^'\"]{0,40})['\"]",
        js_all + html_all + "".join(panels.values())))
    if not_impl:
        print("[提示-未实现文案] 用户可见的未完成声明: %s"
              % sorted(not_impl)[:12])

    print("=" * 62)
    print("扫描面: %d 个 JS · %d 个 HTML · PyBridge 已分派 %d 个方法 · 转发表 %d 个"
          % (stats["js"], stats["html"], stats["py_registered"], stats["forwarded"]))
    if issues:
        for i in issues:
            print("X " + i)
        print("AUDIT: %d 类断点" % len(issues))
        return 1
    print("AUDIT PASS: 无空连接/假按钮/事件断点")
    return 0


if __name__ == "__main__":
    sys.exit(main())
