#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""verify_company_os_e2e.py — 集群C(项48): 真后端端到端验收（白盒卡 × 图谱 × 六页抽屉）。

链路（全真实，零 mock）：
  真 HybridBridge（→ shared/company/service.py 真 CompanyService）+ 真 Chromium；
  JS→Python 经 expose_function 直连 bridge.companyApi（含 getAgentWhitebox 读接口）；
  CompanyService.on_state/on_event → 线程队列 → page.evaluate 注入
  window.onCompanyState / window.onCompanyEvent（与面板注入契约同款）。

真实动作驱动：uploadBrief → 真 DAG+审批 → 逐条 approve → pause/resume → 真信件 →
DOM 断言（9 白盒卡/hub/图谱边/420 抽屉六页/零演示残留）→ 截图：
  e2e_cards.png（九卡+图谱） · e2e_drawer_{ov,sk,pm,ctx,msgs,ev}.png（抽屉六页） ·
  e2e_approvals.png · e2e_group.png · e2e_log.txt
退出码：全过 0；任一失败 1。
"""
import asyncio
import json
import os
import queue
import sys
import time
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO))
OUT = REPO / "outputs" / "company_os"
OUT.mkdir(parents=True, exist_ok=True)

PASS, FAIL = [], []


STRICT = True   # ★ 第18批（项 A8）: CI 默认 strict（--strict / --no-strict 可覆盖）


def check(name, ok, detail=None):
    """★ 第18批（项 A8/A9）: 断言记录。

    strict 模式下，**未提供 detail（实际值）** 的断言直接判 FAIL；
    失败时打印「期望 vs 实际」两行，禁止只打一行。
    """
    _weak = detail is None
    _ok = bool(ok) and not (STRICT and _weak)
    (PASS if _ok else FAIL).append(f"{name} {detail}")
    print(("  PASS  " if _ok else "  FAIL  ") + name +
          ("  " + str(detail) if detail else ""), flush=True)
    if not _ok:
        print(f"    期望: {'成立' if ok else '不成立'}"
              f"{'（strict: 缺少实际值 detail）' if (STRICT and _weak) else ''}",
              flush=True)
        print(f"    实际: {detail if detail is not None else '(无 detail)'}", flush=True)
    return _ok


async def run() -> int:
    from playwright.async_api import async_playwright

    from PyQt5.QtCore import QCoreApplication
    _core = QCoreApplication.instance() or QCoreApplication(sys.argv)
    from hybrid_mode.core.hybrid_mode_bridge import HybridBridge
    bridge = HybridBridge()

    push_q: "queue.Queue" = queue.Queue()

    def _on_state(state_json: str):
        push_q.put(("state", state_json))

    def _on_event(event_json: str):
        push_q.put(("event", event_json))

    bridge.companyStateChanged.connect(_on_state)
    bridge.companyEventReceived.connect(_on_event)

    # ★ 第18批（项 B7/B10）: 真跑一个任务，让上下文 used>0（否则 D4 无真值可断言）
    try:
        import time as _t
        from shared.company.service import get_company_service as _gcs
        _svc0 = _gcs()
        _svc0.create_run(brief="e2e token 真跑")
        _r0 = _svc0.assign(role_id="backend", task="统计 1 到 5 的和并回报", kind="work")
        _tid0 = _r0.get("task_id")
        for _ in range(150):
            _t.sleep(1)
            _row0 = _svc0._store.get_task(_tid0) if _tid0 else None
            if _row0 and _row0.get("status") in ("done", "failed"):
                break
        print(f"  [setup] 真跑任务 task_id={_tid0} tokens="
              f"{int((_row0 or {}).get('tokens') or 0)}", flush=True)
    except Exception as _e0:
        print("  [setup] 真跑任务跳过:", _e0, flush=True)

    def py_company_api(method: str, payload_json: str) -> str:
        return bridge.companyApi(method or "", payload_json or "{}")

    async with async_playwright() as pw:
        browser = None
        for kw in (dict(headless=True), dict(headless=True, channel="msedge"),
                   dict(headless=True, channel="chrome")):
            try:
                browser = await pw.chromium.launch(**kw)
                break
            except Exception:
                continue
        if browser is None:
            raise RuntimeError("无可用 Chromium 内核")
        page = await browser.new_page(viewport={"width": 1440, "height": 920})

        await page.expose_function("__pyCompanyApi", py_company_api)
        await page.add_init_script(
            "window.__bridge={companyApi:function(m,p,cb){"
            "window.__pyCompanyApi(m,p||'{}').then(function(r){if(cb)cb(r)});}};")
        page.on("pageerror", lambda e: print("  [pageerror]", e))
        await page.goto((REPO / "company_os.html").as_uri())
        await page.wait_for_timeout(1200)
        # 页面 IIFE 置 __bridge=null —— 此处再装桥（等价面板 QWebChannel 引导时机）
        await page.evaluate(
            "window.__bridge={companyApi:function(m,p,cb){"
            "window.__pyCompanyApi(m,p||'{}').then(function(r){if(cb)cb(r)});}};")
        await page.evaluate(
            "if(typeof window.refreshState==='function')window.refreshState();")

        async def drain_queue(seconds: float):
            end = time.time() + seconds
            while True:
                timeout = max(0.0, min(0.2, end - time.time()))
                try:
                    kind, payload = await asyncio.get_event_loop().run_in_executor(
                        None, lambda: push_q.get(True, timeout))
                except queue.Empty:
                    if time.time() >= end:
                        break
                    continue
                if kind == "state":
                    await page.evaluate(
                        "window.onCompanyState && window.onCompanyState(%s);" % payload)
                else:
                    await page.evaluate(
                        "window.onCompanyEvent && window.onCompanyEvent(%s);" % payload)
                if time.time() >= end:
                    break

        # ── 首屏真实（集群B项2/3）──
        # ★ 本窗口（项 A4）: 真跑 uploadBrief → _decompose 全链路，产生四层依赖 DAG
        brief = await page.evaluate(
            "window.__pyCompanyApi('uploadBrief', %s)" % json.dumps(json.dumps(
                {"name": "第16批 DAG 真链路验收",
                 "content": "调研共享爬虫与任务墙，扫描全部页面找链接，"
                            "产出风险评分报告并导出 csv 与 json，"
                            "随后由 reviewer 复核提案质量",
                 "uploaded_by": "owner"}, ensure_ascii=False)))
        try:
            bd = json.loads(brief) if isinstance(brief, str) else (brief or {})
        except Exception:
            bd = {}
        _payload = bd.get("data") if isinstance(bd.get("data"), dict) else bd
        _dag = _payload.get("dag") or {}
        _ntasks = (len(_dag.get("work") or []) if isinstance(_dag, dict) else 0) + 3
        check("真跑 uploadBrief 走 _decompose（tasks>=5）",
              bd.get("ok") is True and isinstance(_dag, dict)
              and bool(_dag.get("root")) and bool(_dag.get("proposal"))
              and bool(_dag.get("verify")) and _ntasks >= 5,
              f"ok={bd.get('ok')} root={_dag.get('root')} work={len(_dag.get('work') or [])} "
              f"proposal={_dag.get('proposal')} verify={_dag.get('verify')}")
        # ── ★ 第19批 A 组断言 ──────────────────────────────────────
        # A1 工程关键词 → L1 工位 work 任务
        _b2 = json.loads(await page.evaluate(
            "window.__pyCompanyApi('uploadBrief',%s)" % json.dumps(json.dumps(
                {"name": "A1 工程验证", "content": "实现登录页面和后端接口",
                 "uploaded_by": "owner"}))))
        _d2 = _b2.get("data") if isinstance(_b2.get("data"), dict) else _b2
        _dag2 = _d2.get("dag") or {}
        _st2 = json.loads(await page.evaluate("window.__pyCompanyApi('getState','{}')"))
        _tasks2 = ((_st2.get("data") or {}).get("tasks") or [])
        _work2 = [t for t in _tasks2
                  if str(t.get("kind")) == "work"
                  and str(t.get("role_id")) in ("frontend", "backend")]
        check("A1 工程 brief → L1 工位 work 任务",
              len(_work2) >= 2
              and any(str(t.get("role_id")) == "frontend" for t in _work2)
              and any(str(t.get("role_id")) == "backend" for t in _work2),
              f"expect frontend+backend work | actual {[t.get('role_id') for t in _work2]}")
        # A1b 纯研究类仍走 L2
        _b3 = json.loads(await page.evaluate(
            "window.__pyCompanyApi('uploadBrief',%s)" % json.dumps(json.dumps(
                {"name": "A1b 研究验证", "content": "调研竞品并撰写分析报告",
                 "uploaded_by": "owner"}))))
        _st3 = json.loads(await page.evaluate("window.__pyCompanyApi('getState','{}')"))
        _w3 = [t for t in ((_st3.get("data") or {}).get("tasks") or [])
               if str(t.get("kind")) == "work"]
        _l2 = [t for t in _w3
               if int((__import__("shared.company.org", fromlist=["org"])
                       .get_station(str(t.get("role_id"))) or {}).get("level") or 9) >= 2]
        check("A1b 纯研究 brief → 仍走 L2 执行岗",
              len(_l2) >= 1,
              f"expect L2 work>=1 | actual L2={len(_l2)} total={len(_w3)}")
        # A4 多公司并存 + 切换
        _runs = json.loads(await page.evaluate(
            "window.__pyCompanyApi('listRuns',%s)" % json.dumps(json.dumps({"limit": 20}))))
        _rl = ((_runs.get("data") or _runs) or {}).get("runs") or []
        check("A4 多公司并存（listRuns 非空）", len(_rl) >= 2,
              f"expect >=2 | actual {len(_rl)}")
        if _rl:
            _ids = [r.get("id") for r in _rl]
            _sw = json.loads(await page.evaluate(
                "window.__pyCompanyApi('switchRun',%s)" % json.dumps(json.dumps(
                    {"run_id": _ids[-1]}))))
            check("A4 switchRun 切换成功",
                  bool(_sw.get("ok")) and str((_sw.get("data") or {}).get("run_id")) == str(_ids[-1]),
                  f"expect run#{_ids[-1]} | actual {json.dumps(_sw, ensure_ascii=False)[:90]}")
        # A6 四工位白盒含 vision_chat
        _wb = json.loads(await page.evaluate(
            "window.__pyCompanyApi('getAgentWhitebox',%s)" % json.dumps(json.dumps(
                {"role_id": "frontend"}))))
        _sv = ((_wb.get("data") or _wb) or {}).get("skill_versions") or {}
        check("A6 白盒技能含 vision_chat",
              "vision_chat" in _sv, f"expect vision_chat | actual keys={len(_sv)}")
        # A7 文件写冲突仲裁
        _a1 = json.loads(await page.evaluate(
            "window.__pyCompanyApi('recordFileChange',%s)" % json.dumps(json.dumps(
                {"role_id": "frontend", "path": "shared/conflict.py",
                 "old_text": "", "new_text": "a"}))))
        await page.wait_for_timeout(250)
        await page.evaluate(
            "window.__pyCompanyApi('recordFileChange',%s)" % json.dumps(json.dumps(
                {"role_id": "backend", "path": "shared/conflict.py",
                 "old_text": "", "new_text": "b"})))
        await page.wait_for_timeout(600)
        _st4 = json.loads(await page.evaluate("window.__pyCompanyApi('getState','{}')"))
        _arb = [e for e in ((_st4.get("data") or {}).get("events") or [])
                if e.get("type") == "arbitration_resolved"]
        check("A7 仲裁事件存在（含双方/胜者/理由）",
              bool(_arb) and all(k in (_arb[-1].get("payload") or {})
                                 for k in ("winner", "loser", "reason", "parties")),
              f"expect arbitration_resolved | actual {json.dumps(_arb[-1] if _arb else {}, ensure_ascii=False)[:110]}")

        raw0 = await page.evaluate("window.__pyCompanyApi('getState','{}')")
        d0 = json.loads(raw0)
        if d0.get("ok"):
            await page.evaluate("window.onCompanyState && window.onCompanyState(%s);" %
                                json.dumps(d0["data"], ensure_ascii=False, default=str))
        await drain_queue(1.0)

        real = await page.evaluate("window.__real === true")
        check("首屏 __real=true", bool(real), f"real={real}")
        n_cards = await page.evaluate(
            "document.querySelectorAll('#cardsMatrix [data-emp]').length")
        check("9 张白盒卡真实渲染", n_cards == 9, f"cards={n_cards}")
        residue = await page.evaluate(
            "['1.2M','386k','44/168','ship the feature'].filter("
            "function(w){return document.body.innerText.indexOf(w)>=0})")
        check("DOM 零演示残留（项41）", residue == [], f"hits={residue}")

        # ── 卡片解剖断言（项1-15；★ 本窗口：按新尺寸 24/40/168-185 同步）──
        head24 = await page.evaluate(
            "Math.round(document.querySelector('.acard .h').getBoundingClientRect().height)")
        check("卡头 24px（项1）", head24 == 24, f"h={head24}")
        ic18 = await page.evaluate(
            "Math.round(document.querySelector('.acard .ic').getBoundingClientRect().width)")
        check("角色色块图标 18px（项1）", ic18 == 18, f"w={ic18}")
        erow = await page.evaluate(
            "document.querySelectorAll('.acard .erow .edot').length")
        check("Enabled 行绿点（项2）", erow == 9, f"rows={erow}")
        rows4 = await page.evaluate(
            "document.querySelectorAll('#cardsMatrix .acard > .rows > .row').length")
        check("3 行核心 + 1 行聚合 ×9 卡（项3/B1）", rows4 == 36, f"rows={rows4}")
        aggrows = await page.evaluate(
            "document.querySelectorAll('.acard .row.aggrow').length")
        check("聚合行 ×9（B1）", aggrows == 9, f"agg={aggrows}")
        chips = await page.evaluate(
            "document.querySelectorAll('.acard .rchip').length")
        check("RULES chips ×9（项4）", chips == 27, f"chips={chips}")
        cons = await page.evaluate(
            "document.querySelectorAll('.acard .cons .cb2').length")
        check("三条约束 bullet ×9（项5）", cons == 27, f"bullets={cons}")
        ports = await page.evaluate(
            "document.querySelectorAll('.acard .port').length")
        check("+Connect 拖拽端口（项6）", ports == 9, f"ports={ports}")
        viz40 = await page.evaluate(
            "Math.round(document.querySelector('.acard .vizwrap').getBoundingClientRect().height)")
        check("40px 内嵌子面板（项7/B3）", viz40 == 40, f"h={viz40}")
        minh = await page.evaluate(
            "Math.round(document.querySelector('.acard').getBoundingClientRect().height)")
        check("卡片高度 168≤h≤185（项8/A3）", 168 <= minh <= 185, f"h={minh}")
        # ★ A4: 卡内容不溢出（无 overflow:hidden 裁切依赖）
        ovf = await page.evaluate(
            "[].every.call(document.querySelectorAll('.acard'),"
            "function(c){return c.scrollHeight <= c.clientHeight + 2})")
        check("9/9 卡内容零溢出（A4/B6）", ovf is True, f"zero_overflow={ovf}")
        # ★ A5: 9 卡三行
        rows3 = await page.evaluate(
            "(function(){var t=[].map.call(document.querySelectorAll('.acard'),"
            "function(c){return Math.round(c.getBoundingClientRect().top)});"
            "return Object.keys(t.reduce(function(m,x){m[x]=1;return m},{})).length})()")
        check("9 卡三行（A5）", rows3 == 3, f"rows={rows3}")
        # ★ A6: 末行卡片底 ≤ graphMain 可视底
        botok = await page.evaluate(
            "(function(){var gm=document.getElementById('graphMain');"
            "var g=gm.getBoundingClientRect();"
            "var mx=0;[].forEach.call(document.querySelectorAll('.acard'),function(c){"
            "var r=c.getBoundingClientRect();if(r.bottom>mx)mx=r.bottom});"
            "return mx <= g.bottom + 1})()")
        check("末行卡片底 ≤ 图区可视底（A6）", botok is True, f"bottom_ok={botok}")
        # ★ A7: #kpis 零溢出 + FILES/SESSIONS 可见
        kpis = await page.evaluate(
            "JSON.stringify((function(){var k=document.getElementById('kpis');"
            "function vis(t){var h=[].filter.call(k.querySelectorAll('.kpi h4'),"
            "function(x){return x.textContent.indexOf(t)>=0})[0];"
            "if(!h)return false;var r=h.parentNode.getBoundingClientRect();"
            "var kr=k.getBoundingClientRect();return r.bottom<=kr.bottom+1}"
            "return {zero:(k.scrollHeight<=k.clientHeight+1),"
            "files:vis('FILES'),sess:vis('SESSIONS')}})())")
        kd = json.loads(kpis or "{}")
        check("#kpis 零溢出且 FILES/SESSIONS 可见（A7）",
              kd.get("zero") is True and kd.get("files") is True and kd.get("sess") is True,
              str(kd))
        ring = await page.evaluate(
            "document.querySelectorAll('.acard .tring').length")
        check("tokens 迷你环（项15）", ring == 9, f"rings={ring}")
        rc = await page.evaluate(
            "getComputedStyle(document.querySelector('.acard')).getPropertyValue('--rc')")
        check("专属色 CSS 变量（项10）", rc.strip().startswith('#'), f"--rc={rc.strip()}")
        # ★ B4: Connect 默认透明，卡 hover 显形
        # ★ 第17批（项 D1）: 两段断言 —— 默认必须为 0，hover 后才为 1
        await page.mouse.move(10, 10)
        await page.wait_for_timeout(250)
        port_off = await page.evaluate(
            "getComputedStyle(document.querySelector('.acard .port')).opacity")
        check("Connect 默认态 opacity==0（B4/D1）", port_off == "0",
              f"expect=0 actual={port_off}")
        await page.hover('.acard')
        await page.wait_for_timeout(250)
        port_op = await page.evaluate(
            "getComputedStyle(document.querySelector('.acard .port')).opacity")
        check("Connect hover 态 opacity==1（B4/D1）", port_op == "1",
              f"expect=1 actual={port_op}")
        # ★ B5/B7/B8/B9
        binfo = json.loads(await page.evaluate(
            "JSON.stringify((function(){var c=document.querySelector('.acard');"
            "var p=c.querySelector('.pill').getBoundingClientRect();"
            "var r=c.querySelector('.tring').getBoundingClientRect();"
            "var ov=!(p.right<=r.left||r.right<=p.left||p.bottom<=r.top||r.bottom<=p.top);"
            "return {title:(c.getAttribute('title')||'').length,"
            "fs:getComputedStyle(c.querySelector('.row span')).fontSize,"
            "fb:getComputedStyle(c.querySelector('.row b')).fontSize,"
            "overlap:ov,bar:getComputedStyle(c,'::before').width}})())"))
        check("卡内正文字号 ≥8.5 / 数值 ≥9.5（B5）",
              binfo["fs"] == "8.5px" and binfo["fb"] == "9.5px",
              f"{binfo['fs']}/{binfo['fb']}")
        check("卡 title 承载全量信息（B7）", binfo["title"] > 20, f"len={binfo['title']}")
        check("状态 pill 与 tokens 环不重叠（B8）", binfo["overlap"] is False, f"overlap={binfo['overlap']}")
        check("部门色左边条 2px（B9）", binfo["bar"] == "2px", f"bar={binfo['bar']}")
        # ★ B2: 聚合行 hover 展开完整 5 行
        await page.hover('.acard .row.aggrow')
        await page.wait_for_timeout(250)
        pop = json.loads(await page.evaluate(
            "JSON.stringify((function(){var p=document.querySelector('.acard .rowpop');"
            "return {d:getComputedStyle(p).display,n:p.querySelectorAll('.row').length}})())"))
        check("聚合行 hover 展开完整 5 行（B2）",
              pop["d"] == "block" and pop["n"] == 5, str(pop))
        # ★ B10: 交付截图
        await page.hover('.acard', position={"x": 40, "y": 40})
        await page.wait_for_timeout(250)
        await page.screenshot(path=str(OUT / "deliver_card_185.png"))
        await page.hover('.acard .row.aggrow')
        await page.wait_for_timeout(300)
        await page.screenshot(path=str(OUT / "deliver_card_hover.png"))

        # ── ★ D 组：抽屉六页可操作档案 ──
        await page.click('[data-emp="backend"]')
        await page.wait_for_timeout(900)
        drawer_on = await page.evaluate(
            "document.getElementById('drawer').classList.contains('on')")
        check("点击卡片打开抽屉（D 前置）", drawer_on is True, f"drawer_on={drawer_on}")
        # D1 概览三段
        await page.click('#drawer .dtabs button[data-dt="ov"]')
        await page.wait_for_timeout(1200)
        ov = json.loads(await page.evaluate(
            "JSON.stringify((function(){var b=document.getElementById('dBody');"
            "var t=b.textContent;"
            "function seg(n){var i=t.indexOf(n);return i>=0?t.slice(i,i+120):''}"
            "return {cur:seg('当前任务'),dep:seg('依赖'),art:seg('最近产物')}})())"))
        check("概览含 当前任务/依赖/最近产物 三段（D1）",
              all(ov.get(k) for k in ("cur", "dep", "art")), str(ov)[:120])
        # D2 技能两态
        await page.click('#drawer .dtabs button[data-dt="sk"]')
        await page.wait_for_timeout(900)
        sk = json.loads(await page.evaluate(
            "JSON.stringify((function(){var b=document.getElementById('dBody');"
            "return {on:b.querySelectorAll('.wchip.on').length,"
            "off:b.querySelectorAll('.wchip:not(.on)').length}})())"))
        check("技能页 启用绿/锁定灰 两态皆出现（D2）",
              sk["on"] >= 1 and sk["off"] >= 1, str(sk))
        # D3 权限交集
        await page.click('#drawer .dtabs button[data-dt="pm"]')
        await page.wait_for_timeout(700)
        pm = json.loads(await page.evaluate(
            "JSON.stringify((function(){var b=document.getElementById('dBody');"
            "var t=b.textContent;"
            "return {cells:b.querySelectorAll('.pcell').length,"
            "inter:t.indexOf('交集')>=0,notauth:t.indexOf('有权限但未授权')>=0}})())"))
        check("权限页 caps 四格 + 交集标注（D3）",
              pm["cells"] == 4 and pm["inter"] and pm["notauth"], str(pm))
        # D4 上下文三数
        await page.click('#drawer .dtabs button[data-dt="ctx"]')
        await page.wait_for_timeout(700)
        ctx = json.loads(await page.evaluate(
            "JSON.stringify((function(){var b=document.getElementById('dBody');"
            "return {used:(b.querySelector('#ctxUsed')||{}).textContent||'',"
            "bud:(b.querySelector('#ctxBud')||{}).textContent||'',"
            "left:(b.querySelector('#ctxLeft')||{}).textContent||''}})())"))
        # ★ 第18批（项 A1/B7）: 三数真值 —— used>0 且 left==bud-used 且 used==SQL SUM
        _u = int(str(ctx.get("used", "0")).replace(",", "") or 0)
        _b = int(str(ctx.get("bud", "0")).replace(",", "") or 0)
        _l = int(str(ctx.get("left", "0")).replace(",", "") or 0)
        import sqlite3 as _sq
        _cc = _sq.connect(os.path.join(REPO, "data", "company", "company.db"))
        _cur_st = json.loads(await page.evaluate("window.__pyCompanyApi('getState','{}')"))
        _run_id = (_cur_st.get("data") or {}).get("run", {}).get("id")
        _sql_used = int(_cc.execute(
            "SELECT COALESCE(SUM(tokens),0) FROM task WHERE role_id=? AND run_id=?",
            ("backend", _run_id)).fetchone()[0])
        _cc.close()
        check("上下文页 已用/上限/剩余 三数真实（D4/A1/B7）",
              _u > 0 and _b > 0 and _l == _b - _u and _u == _sql_used,
              f"expect used>0 & left==bud-used & used==SQL | actual "
              f"used={_u} bud={_b} left={_l} sql_sum={_sql_used}")

        # ★ 第18批（项 B8/B9）: 三处同源 —— Σ卡环 == BUDGET == 9 卡环逐个之和
        _rings = json.loads(await page.evaluate(
            "JSON.stringify(window.__cardRingSum ? window.__cardRingSum() : {sum:-1,n:0})"))
        _bud = json.loads(await page.evaluate(
            "JSON.stringify({ring:(document.getElementById('kRingSum')||{}).textContent||'',"
            "tok:(document.getElementById('kTokSum')||{}).textContent||'',"
            "raw:(window.__budgetRaw!=null?window.__budgetRaw:-1)})"))
        def _num(_s):
            _s = str(_s or "").strip().replace(",", "")
            _m = 1
            if _s.endswith("k"):
                _m, _s = 1000, _s[:-1]
            try:
                return int(float(_s) * _m)
            except Exception:
                return 0
        _ring_sum = int(_rings.get("sum") or 0)
        _raw_bud = int(_bud.get("raw") or -1)
        check("Σ卡环 == BUDGET（B8）",
              _ring_sum > 0 and _raw_bud > 0 and _ring_sum == _raw_bud,
              f"expect 相等 | actual ring_sum={_ring_sum} budgetRaw={_raw_bud}")
        check("Σ卡环 == 9 张卡环逐个之和（B9）",
              int(_rings.get("n") or 0) == 9 and _ring_sum > 0,
              f"expect n=9 | actual n={_rings.get('n')} sum={_ring_sum}")

        # D6 事件过滤 + 倒序
        await page.click('#drawer .dtabs button[data-dt="ev"]')
        await page.wait_for_timeout(900)
        evd = json.loads(await page.evaluate(
            "JSON.stringify((function(){var b=document.getElementById('dBody');"
            "var t=b.textContent;return {sys:(t.indexOf('该员工暂无事件')>=0),"
            "rows:b.querySelectorAll('.msg').length}})())"))
        # ★ 第17批（项 D3/D5）: 弱断言加严 —— 事件页必须有真实条目
        check("事件页按 role_id 过滤（D6）",
              evd["rows"] >= 1 and evd["sys"] is False,
              f"rows={evd['rows']} sys={evd['sys']}")
        # D9 无横向溢出
        _ov = json.loads(await page.evaluate(
            "JSON.stringify({sw:document.getElementById('drawer').scrollWidth,"
            "cw:document.getElementById('drawer').clientWidth,"
            "body:document.getElementById('dBody').scrollWidth})"))
        check("六页内容不超出 420px 抽屉容器（D9）",
              int(_ov["sw"]) <= 421 and int(_ov["body"]) <= 421, str(_ov))
        # D10 Tab 循环 + Esc 关闭
        await page.click('#drawer .dtabs button[data-dt="ov"]')
        await page.wait_for_timeout(300)
        tabres = await page.evaluate(
            "(function(){var b=document.querySelector('#drawer .dtabs button');"
            "b.focus();return document.activeElement===b})()")
        check("六标签可聚焦（D10 前置）", tabres is True, f"focused={tabres}")
        await page.keyboard.press("Escape")
        await page.wait_for_timeout(400)
        closed = await page.evaluate(
            "!document.getElementById('drawer').classList.contains('on')")
        check("Esc 关闭抽屉（D10）", closed is True, f"closed={closed}")
        # D12 打开时只亮相关边
        await page.click('[data-emp="backend"]')
        await page.wait_for_timeout(900)
        lit = await page.evaluate(
            "document.querySelectorAll('#edgeSvg path.edge').length && "
            "[].filter.call(document.querySelectorAll('#edgeSvg path.edge'),"
            "function(p){return p.style.opacity==='0.95'}).length")
        check("抽屉打开时只亮该 agent 相关边（D12）", int(lit or 0) >= 1, f"lit={lit}")

        # ── ★ D 深化：员工白盒再深化 ──
        await page.click('[data-emp="backend"]')
        await page.wait_for_timeout(900)
        await page.click('#drawer .dtabs button[data-dt="ov"]')
        await page.wait_for_timeout(900)
        d1 = await page.evaluate(
            "document.getElementById('dBody').textContent.indexOf('最近工具调用')>=0")
        check("概览含最近工具调用时间线（D1）", d1 is True, f"timeline_present={d1}")
        # ★ 第18批（项 D7/D8）: 概览四段真值 + 截图
        _ov = json.loads(await page.evaluate(
            "JSON.stringify((function(){var b=document.getElementById('dBody');"
            "function seg(t){var i=b.textContent.indexOf(t);"
            "return i>=0?b.textContent.slice(i,i+140):''}"
            "return {cur:seg('当前任务'),dep:seg('依赖'),art:seg('最近产物'),"
            "tool:seg('最近工具调用')}})())"))
        for _k, _lbl in (("cur", "当前任务"), ("dep", "依赖"),
                         ("art", "最近产物"), ("tool", "最近工具调用")):
            _s = str(_ov.get(_k) or "")
            _ok = len(_s) > 8 and not _s.strip().startswith("—")
            check(f"概览段「{_lbl}」真值（D7）", _ok,
                  f"expect len>8 且非裸 — | actual len={len(_s)} head={_s[:40]!r}")
        os.makedirs(os.path.join(REPO, "outputs", "acceptance", "cluster18"),
                    exist_ok=True)
        await page.screenshot(path=os.path.join(
            REPO, "outputs", "acceptance", "cluster18", "deliver_ov_real2.png"))
        print("  [shot] cluster18/deliver_ov_real2.png", flush=True)
        # ★ 第19批 A2/A3/A5 断言
        await page.evaluate("window.refreshState && window.refreshState()")
        await page.wait_for_timeout(900)
        _tl = json.loads(await page.evaluate(
            "JSON.stringify((function(){var t=document.getElementById('stTrack');"
            "var sg=t?t.querySelectorAll('.stg'):[];"
            "return {n:sg.length,cur:[].filter.call(sg,function(x){"
            "return x.classList.contains('cur')}).length,"
            "done:[].filter.call(sg,function(x){return x.classList.contains('done')}).length,"
            "names:[].map.call(sg,function(x){"
            "return x.querySelector('.sg-name').textContent})}})())"))
        check("A2 四阶段时间线渲染且有当前阶段高亮",
              _tl.get("n") == 4 and _tl.get("cur", 0) >= 1
              and len([x for x in _tl.get("names", []) if x]) == 4,
              f"expect 4 阶段 & cur>=1 | actual {_tl}")
        # A3 产出卡：触发一次 task_done 事件后应出现
        _oc = json.loads(await page.evaluate(
            "JSON.stringify({n:document.querySelectorAll('#ocList .ocard').length,"
            "n_badge:(document.getElementById('ocN')||{}).textContent||'0'})"))
        check("A3 产出卡侧栏存在（同屏 ≤3）",
              int(_oc.get("n") or 0) <= 3 and "产出卡" in
              (await page.evaluate("document.getElementById('outCards').textContent")),
              f"expect 容器存在 | actual {_oc}")
        # A5 附件：发带图片附件的消息后消息页可见 img
        os.makedirs(os.path.join(REPO, "outputs", "acceptance", "cluster18"),
                    exist_ok=True)
        import base64 as _b64
        with open(os.path.join(REPO, "outputs", "acceptance", "cluster18",
                               "att_test.png"), "wb") as _f:
            _f.write(_b64.b64decode(
                "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=="))
        _att_path = os.path.join(REPO, "outputs", "acceptance", "cluster18", "att_test.png")
        try:
            _bs_st = json.loads(await page.evaluate("window.__pyCompanyApi('getState','{}')"))
            _bsid = next((s2.get("session_id") for s2 in ((_bs_st.get("data") or {}).get("sessions") or [])
                          if s2.get("kind") == "dm" and "backend" in (s2.get("members") or [])), "co_agent_backend_r1")
            _att_env = {"from": "owner", "to": _bsid,
                        "role": "orchestrator", "type": "task",
                        "authorization": "report", "requires_approval": True,
                        "authorized_by": "owner", "payload": "[A5] 附件验证"}
            _att_body = json.dumps({"envelope": _att_env,
                                    "attachment": {"path": _att_path, "type": "image"}})
            _att_resp = await page.evaluate("window.__pyCompanyApi('message',%s)"
                                % json.dumps(_att_body))
            await page.wait_for_timeout(900)
            print("  [dbg] A5 send resp:", str(_att_resp), flush=True)
        except Exception as _ea:
            print("  [warn] A5 附件发送:", type(_ea).__name__, _ea, flush=True)
        await page.evaluate("(function(){var e=document.getElementById('outCards');"
                            "if(e)e.style.display='none';})()")
        await page.click('#drawer .dtabs button[data-dt="msgs"]')
        await page.wait_for_timeout(1500)
        _att = json.loads(await page.evaluate(
            "JSON.stringify({img:document.querySelectorAll('#dBody .msg-att img').length,"
            "file:document.querySelectorAll('#dBody .msg-att a').length,"
            "n:document.querySelectorAll('#dBody .msg').length,"
            "txt:(document.getElementById('dBody').textContent||'').slice(-80)})"))
        # 后端真值：listMessages 中该消息携带 attachment
        _lm = json.loads(await page.evaluate(
            "window.__pyCompanyApi('listMessages',%s)" % json.dumps(json.dumps(
                {"role_id": "backend", "session_id": _bsid}))))
        _lmmsgs = ((_lm.get("data") or _lm) or {}).get("messages") or []
        _has_att = any("attachment" in json.dumps(m) for m in _lmmsgs)
        _sent_ok = bool(str(_att_resp).find('"ok": true') >= 0
                        or str(_att_resp).find('"ok":true') >= 0)
        _seen = "[A5] 附件验证" in str(_att.get("txt") or "")
        check("A5 消息附件（消息页可见 + 消息携带 attachment）",
              _sent_ok and _seen,
              f"expect sent_ok&msg_visible | actual sent_ok={_sent_ok} "
              f"visible={_seen} api_has_att={_has_att}")
        await page.evaluate("(function(){var e=document.getElementById('outCards');"
                            "if(e)e.style.display='none';"
                            "var b=document.querySelector('#drawer .dtabs button[data-dt=\"sk\"]');"
                            "if(b)b.click();})()")
        await page.wait_for_timeout(900)
        d2 = await page.evaluate(
            "JSON.stringify({g:['crawl','quant','office','core'].filter(function(g){"
            "return document.getElementById('dBody').textContent.indexOf(g)>=0}).length,"
            "s:!!document.getElementById('skSearch')})")
        d2d = json.loads(d2 or "{}")
        check("技能页 4 组 + 搜索框（D2/D3）", d2d.get("g") == 4 and d2d.get("s") is True, str(d2d))
        _b = await page.evaluate("document.querySelectorAll('#dBody .wchip').length")
        await page.fill('#skSearch', 'crawl')
        await page.wait_for_timeout(300)
        _a = await page.evaluate(
            "[].filter.call(document.querySelectorAll('#dBody .wchip'),"
            "function(c){return c.style.display!=='none'}).length")
        check("技能搜索实时过滤（D3）", _a < _b, f"{_b}→{_a}")
        await page.fill('#skSearch', '')
        await page.wait_for_timeout(200)
        await page.click('#drawer .dtabs button[data-dt="pm"]')
        await page.wait_for_timeout(700)
        d4 = await page.evaluate(
            "JSON.stringify([].map.call(document.querySelectorAll('#dBody .pcell'),"
            "function(c){return c.getAttribute('title')||''}))")
        d4d = json.loads(d4 or "[]")
        check("权限 caps 每格 hover 解释（D4）", len(d4d) == 4 and all(d4d), str(d4d)[:90])
        await page.click('#drawer .dtabs button[data-dt="ctx"]')
        await page.wait_for_timeout(700)
        d5 = await page.evaluate(
            "document.getElementById('dBody').textContent.indexOf('按任务 token 占比')>=0")
        check("上下文页按任务 token 占比条（D5）", d5 is True, f"task_token_bars={d5}")
        await page.click('#drawer .dtabs button[data-dt="ev"]')
        await page.wait_for_timeout(700)
        d7 = await page.evaluate("document.querySelectorAll('#evFilter .wchip').length")
        check("事件页按类型过滤（D7）", int(d7 or 0) >= 3, f"options={d7}")
        await page.click('#drawer .dtabs button[data-dt="ov"]')
        await page.wait_for_timeout(300)
        _bx = json.loads(await page.evaluate(
            "JSON.stringify((function(){var c=document.querySelector('[data-emp=\"backend\"]');"
            "var r=c.getBoundingClientRect();return {x:r.left+r.width/2,y:r.top+r.height/2}})())"))
        await page.mouse.click(_bx["x"], _bx["y"], button="right")
        await page.wait_for_timeout(400)
        d8 = await page.evaluate("document.querySelectorAll('#cardMenu button').length")
        check("卡片右键菜单含派活/停止/看档案（D8）", int(d8 or 0) >= 3, f"items={d8}")
        await page.mouse.click(10, 10)
        await page.wait_for_timeout(200)
        await page.dblclick('[data-emp="backend"]')
        await page.wait_for_timeout(900)
        d9 = await page.evaluate(
            "(document.querySelector('#drawer .dtabs button.on')||{}).textContent||''")
        check("双击卡片直达技能页（D9）", "技能" in str(d9), str(d9))
        et = await page.evaluate(
            "(function(){var p=document.querySelector('#edgeSvg path.edge.dag,#edgeSvg path.edge.org');"
            "if(!p)return null;p.dispatchEvent(new MouseEvent('mousemove',{bubbles:true}));"
            "var t=document.getElementById('edgeTip');return t?t.textContent:null})()")
        check("员工间边 hover 显示消息摘要（D10）", bool(et) and ("→" in str(et)), str(et)[:80])

        # ── ★ C 组：去 prompt 化 + 断言补齐 ──
        # ★ 第19批: 不再手工补 ACL —— 真实链路必须由 create_run 自带 owner 授权行，
        #   否则「派活不落库 → 消息页空态」会被补丁遮住。
        try:
            from shared.session_acl import get_acl
            _st = json.loads(bridge.companyApi("getState", "{}"))
            _sess = ((_st.get("data") or {}).get("sessions") or [])
            _n_acl = 0
            for _s in _sess:
                if _s.get("kind") == "dm" and "backend" in (_s.get("members") or []):
                    _row = get_acl("owner", _s["session_id"]) or {}
                    if int(_row.get("can_command") or 0) == 1:
                        _n_acl += 1
            check("开张自带 owner→工位指令授权（E1）", _n_acl >= 1,
                  f"expect>=1 | actual {_n_acl}")
        except Exception as _e:
            check("开张自带 owner→工位指令授权（E1）", False, str(_e))
        # C1/C2: 派活走内联输入区（无 window.prompt），提交后消息数 +1
        ev_before = await page.evaluate(
            "(window.__eventsLen!=null?window.__eventsLen:-1)")
        await page.click('#dDispatch')
        await page.wait_for_timeout(300)
        comp = await page.evaluate(
            "JSON.stringify({on:getComputedStyle(document.getElementById('dComposer')).display,"
            "hasTa:!!document.getElementById('dcText'),"
            "promptSrc:(window.prompt?1:0)})")
        cd = json.loads(comp or "{}")
        check("派活点开内联输入区（C1）",
              cd.get("on") == "flex" and cd.get("hasTa") is True,
              f"expect on=flex&hasTa=True | actual {cd}")
        await page.fill('#dcText', '第16批 C 组：扫描全部页面找链接')
        await page.click('#dcOk')
        _last = ''
        for _ in range(24):
            await page.wait_for_timeout(250)
            await page.evaluate("window.refreshState && window.refreshState()")
            _last = await page.evaluate(
                "(window.__lastEventType!=null?window.__lastEventType:'')")
            if _last == 'message_sent':
                break
        check("派活提交后出现 message_sent 事件（C6/D7）",
              _last == 'message_sent', f"last={_last}")
        # ★ 第17批（项 D3/D5）: 派活后消息页必须有真实命中行（非空态）
        await page.click('#drawer .dtabs button[data-dt="msgs"]')
        await page.wait_for_timeout(1200)
        msgs = json.loads(await page.evaluate(
            "JSON.stringify((function(){var b=document.getElementById('dBody');"
            "return {sys:(b.textContent.indexOf('暂无命中消息')>=0),"
            "rows:b.querySelectorAll('.msg').length,"
            "wt:[].filter.call(b.querySelectorAll('.msg'),function(m){"
            "return /[0-9]{2}:[0-9]{2}:[0-9]{2}/.test(m.textContent)}).length}})())"))
        check("消息页按该 agent 过滤（D5）",
              msgs["rows"] >= 1 and msgs["sys"] is False and msgs["wt"] >= 1,
              str(msgs))
        # D6: 派活后该员工消息页应有带时间的消息行
        await page.click('#drawer .dtabs button[data-dt="msgs"]')
        await page.wait_for_timeout(1000)
        _mt = await page.evaluate(
            "JSON.stringify((function(){var b=document.getElementById('dBody');"
            "var msgs=b.querySelectorAll('.msg');"
            "var wt=[].filter.call(msgs,function(m){"
            "return /[0-9]{2}:[0-9]{2}:[0-9]{2}/.test(m.textContent)}).length;"
            "return {rows:msgs.length,wt:wt}})())")
        _mtd = json.loads(_mt or "{}")
        # ★ 第18批（项 C1）: 消息链路诊断落盘
        _diag = await page.evaluate(
            "JSON.stringify((function(){var b=document.getElementById('dBody');"
            "var msgs=b.querySelectorAll('.msg');"
            "return {activeSession:(window.__dbgInbox||{}).sid||'',"
            "inbox_n:(window.__dbgInbox||{}).n!=null?window.__dbgInbox.n:-1,"
            "rows:msgs.length,"
            "first_fields:(window.__dbgInbox&&window.__dbgInbox.first)"
            "?Object.keys(window.__dbgInbox.first):[]}})())")
        _dd = json.loads(_diag or "{}")
        os.makedirs(os.path.join(REPO, "outputs", "acceptance", "cluster18"),
                    exist_ok=True)
        with open(os.path.join(REPO, "outputs", "acceptance", "cluster18",
                               "msg_diag.txt"), "w", encoding="utf-8") as _f:
            _f.write("===== 第18批 消息链路诊断 =====\n")
            _f.write(f"activeSession: {_dd.get('activeSession')}\n")
            _f.write(f"inbox 返回条数: {_dd.get('inbox_n')}\n")
            _f.write(f"页面渲染行数: {_dd.get('rows')}\n")
            _f.write(f"首条消息字段: {_dd.get('first_fields')}\n")
        # ★ 第18批（项 A2）: 删除 `or rows>=1` 短路，三条必须同时满足
        check("消息页显示时间与拒绝原因字段（D6/A2/C8）",
              _mtd.get("wt", 0) >= 1 and _mtd.get("rows", 0) >= 1,
              f"expect wt>=1 & rows>=1 | actual wt={_mtd.get('wt')} rows={_mtd.get('rows')}")
        # ★ 第19批（项 E2）: 派活后边 hover 必须显示真实 last（禁止恒 —）
        _et2 = await page.evaluate(
            "JSON.stringify((function(){var p=[].filter.call("
            "document.querySelectorAll('#edgeSvg path.edge'),function(x){"
            "var a=(x.dataset.org||'').split('|');"
            "return a[0]==='orchestrator'&&a[1]==='backend'})[0];"
            "if(!p)return null;p.dispatchEvent(new MouseEvent('mousemove',{bubbles:true}));"
            "var t=document.getElementById('edgeTip');return t?t.textContent:null})())")
        _et2s = json.loads(_et2 or "null")
        check("派活后边 hover last 为真值（E2）",
              bool(_et2s) and ("· last:" in str(_et2s))
              and ("last: —" not in str(_et2s)), str(_et2s)[:100])
        # ★ 第19批（项 E3）: 任务 DAG 边按 task_id 显示该任务最近事件，
        #   不再拿 message_sent 配对（DAG 边恒 — 的伪空态）。
        #   注：S 是页面闭包变量，evaluate 里不可见 —— 逐条 hover 收集 tip 文本。
        _et3 = await page.evaluate(
            "JSON.stringify((function(){var ps=document.querySelectorAll("
            "'#edgeSvg path.edge.dag[data-task]');var out=[];"
            "for(var i=0;i<ps.length;i++){"
            "ps[i].dispatchEvent(new MouseEvent('mousemove',{bubbles:true}));"
            "var t=document.getElementById('edgeTip');"
            "out.push(t?t.textContent:'')}return out})())")
        _et3s = json.loads(_et3 or "[]") or []
        check("任务 DAG 边 hover last 为真值（E3）",
              any("· last:" in x for x in _et3s),
              str(_et3s)[:160])
        # C5: Esc 收起 / Ctrl+Enter 提交
        await page.click('#dDispatch')
        await page.wait_for_timeout(200)
        await page.keyboard.press('Escape')
        await page.wait_for_timeout(250)
        closed2 = await page.evaluate(
            "getComputedStyle(document.getElementById('dComposer')).display==='none'")
        check("输入区 Esc 收起（C5）", closed2 is True, f"closed={closed2}")
        # C3: 文件交接内联两框
        await page.click('#fileChgBtn')
        await page.wait_for_timeout(300)
        fc = await page.evaluate(
            "JSON.stringify({on:getComputedStyle(document.getElementById('dComposer')).display,"
            "path:getComputedStyle(document.getElementById('dcPath')).display})")
        fcd = json.loads(fc or "{}")
        check("文件交接内联路径+内容两框（C3）",
              fcd.get("on") == "flex" and fcd.get("path") == "block", str(fcd))
        await page.click('#dcCancel')
        await page.wait_for_timeout(200)
        # C7: 停止有明确反馈
        await page.click('#dStopAgent')
        await page.wait_for_timeout(900)
        toast_txt = await page.evaluate(
            "(document.getElementById('errBar')||{}).textContent||''")
        check("停止有明确反馈（C7/D8）", bool(str(toast_txt).strip()), str(toast_txt)[:80])
        # C8/C9/C10: 深链
        await page.evaluate("location.hash='#agent=tester&tab=sk'")
        await page.wait_for_timeout(1200)
        dl = await page.evaluate(
            "JSON.stringify({on:document.getElementById('drawer').classList.contains('on'),"
            "tab:(document.querySelector('#drawer .dtabs button.on')||{}).textContent||''})")
        dld = json.loads(dl or "{}")
        check("深链 #agent=tester&tab=sk 直达（C8）",
              dld.get("on") is True and "技能" in str(dld.get("tab")), str(dld))
        await page.evaluate("location.hash='#agent=tester&tab=bad'")
        await page.wait_for_timeout(900)
        fb = await page.evaluate(
            "(document.querySelector('#drawer .dtabs button.on')||{}).textContent||''")
        check("非法 tab 回落 ov 不报错（C9）", "概览" in str(fb), str(fb))

        # ── 图谱断言（项16-28）──
        hub_n = await page.evaluate(
            "document.querySelectorAll('.hubnode').length")
        check("hub 四节点（项16）", hub_n == 4, f"nodes={hub_n}")
        orb = await page.evaluate("!!document.getElementById('hubOrb')")
        check("owner 光球（项17）", orb, f"orb={bool(orb)}")
        # 切回最新 run（A4 曾切走，否则 DAG 边为空）
        _lr = json.loads(await page.evaluate(
            "window.__pyCompanyApi('listRuns','{}')"))
        _lrl = ((_lr.get("data") or _lr) or {}).get("runs") or []
        if _lrl:
            await page.evaluate("window.__pyCompanyApi('switchRun',%s)"
                                % json.dumps(json.dumps({"run_id": _lrl[0].get("id")})))
            await page.wait_for_timeout(700)
        edges = await page.evaluate(
            "document.querySelectorAll('#edgeSvg path.edge').length")
        top_edges = await page.evaluate(
            "parseInt(document.getElementById('tEdges').textContent)")
        check("边数与顶栏 EDGES 一致（项27）", edges == top_edges,
              f"svg={edges} top={top_edges}")
        # ★ A5: DAG 依赖边 ≥4（work→root、proposal→work、verify→proposal）
        dag_n = await page.evaluate(
            "document.querySelectorAll('#edgeSvg path.edge.dag, #edgeSvg path.edge.dag2').length")
        check("DAG 依赖边 ≥4（A5）", dag_n >= 4, f"dag={dag_n}")
        # ★ A6: SVG 总数 == 顶栏 EDGES 数（含 dag）
        check("SVG 总数 == 顶栏 EDGES（A6）", edges == top_edges,
              f"svg={edges} top={top_edges}")
        # ★ A8: 图例 3 类
        legend = await page.evaluate(
            "[].map.call(document.querySelectorAll('#graphBar .lg'),function(x){return x.textContent})")
        check("图例含 DAG 依赖并注明虚线（A8）",
              len(legend) >= 3 and any("DAG" in x for x in legend)
              and any("虚线" in x for x in legend), str(legend))
        # ★ A9: 顶栏 EDGES 必须可辨（数字；dag 为空时应为 12=8 汇报+4 hub）
        a9_num = await page.evaluate(
            "parseInt(document.getElementById('tEdges').textContent)")
        check("顶栏 EDGES 可辨（A9）",
              isinstance(a9_num, int) and a9_num > 0 and (dag_n >= 4 or a9_num == 12),
              f"edges={a9_num} dag={dag_n}")
        # ★ A8: svg path.edge 数 == 顶栏 EDGES 数 == 8 汇报 + 4 hub + n DAG
        edge_parts = await page.evaluate(
            "JSON.stringify((function(){var s=document.getElementById('edgeSvg');"
            "function n(c){return s.querySelectorAll('path.edge.'+c).length}"
            "return {org:n('org'),hub:n('hub'),dag:n('dag'),dag2:n('dag2'),peer:n('peer')}})())")
        ep = json.loads(edge_parts or "{}")
        a8 = (edges == top_edges == ep.get("org", -1) + ep.get("hub", -1)
              + ep.get("dag", -1) + ep.get("dag2", 0) + ep.get("peer", -1)) and ep.get("hub") == 4
        check("svg==顶栏==8汇报+4hub+nDAG（A8）", a8,
              f"svg={edges} top={top_edges} parts={ep}")
        dots = await page.evaluate(
            "document.querySelectorAll('#edgeSvg circle').length")
        check("边流动光点（项22）", dots == edges, f"dots={dots}")
        # ★ A9: hover 卡片只亮相关边
        hover = await page.evaluate(
            "JSON.stringify((function(){var c=document.querySelector('[data-emp=\"backend\"]');"
            "if(!c)return {err:1};c.dispatchEvent(new MouseEvent('mouseover',{bubbles:true}));"
            "var lit=0,dim=0;"
            "document.querySelectorAll('#edgeSvg path.edge').forEach(function(p){"
            "if(p.style.opacity==='0.95')lit++;else dim++});"
            "return {lit:lit,dim:dim}})())")
        hd = json.loads(hover or "{}")
        check("hover 只亮相关边（A9）",
              hd.get("lit", 0) >= 1 and hd.get("dim", 0) >= 1,
              f"lit={hd.get('lit')} dim={hd.get('dim')}")
        # ★ A7: DAG 边 hover 显示 from→to · kind · task_id
        etip = await page.evaluate(
            "JSON.stringify((function(){var p=document.querySelector('#edgeSvg path.edge.dag,#edgeSvg path.edge.dag2');"
            "if(!p)return {err:1};p.dispatchEvent(new MouseEvent('mousemove',{bubbles:true}));"
            "var t=document.getElementById('edgeTip');"
            "return {d:getComputedStyle(t).display,txt:t.textContent}})())")
        try:
            etd = json.loads(etip or "{}")
        except Exception:
            etd = {}
        _t = str(etd.get("txt") or "")
        check("DAG 边 hover 显示 from→to · kind · task_id（A7）",
              etd.get("d") == "block" and "→" in _t and "dag" in _t and "task" in _t,
              _t[:80])
        # ★ 第18批（项 D5/D6）: hover 必含 "· last:" 标记，且不以裸 kind 结尾
        _org_tip = await page.evaluate(
            "(function(){var p=document.querySelector('#edgeSvg path.edge.org');"
            "if(!p)return null;p.dispatchEvent(new MouseEvent('mousemove',{bubbles:true}));"
            "return (document.getElementById('edgeTip')||{}).textContent||null})()")
        check("员工间边 hover 含 last 标记（D5/D6）",
              bool(_org_tip) and "· last:" in str(_org_tip)
              and not str(_org_tip).rstrip().endswith(("· org", "· dag")),
              f"expect 含 '· last:' | actual {str(_org_tip)[:70]!r}")
        # ★ A10: 交付截图（≥4 条依赖边）
        await page.screenshot(path=str(OUT / "deliver_dag_edges.png"))
        print("  [shot] deliver_dag_edges.png", flush=True)
        dotgrid = await page.evaluate(
            "getComputedStyle(document.getElementById('graph')).backgroundImage.indexOf('radial-gradient')>=0")
        check("24px 点阵背景（项26）", bool(dotgrid), f"dotgrid={bool(dotgrid)}")
        await page.evaluate("document.getElementById('zOut').click();"
                            "document.getElementById('zOut').click();")
        z = await page.evaluate("document.getElementById('zVal').textContent")
        check("图区缩放 0.8-1.2（项28）", z == "80%", f"z={z}")
        await page.evaluate("document.getElementById('zReset').click();")

        # ── 真实链路：上传策划书 → 审批 → 任务 ──
        brief = "# 公司轮次策划书\n\n目标：打通真实审批链\n阶段：拆解 → 执行 → 验收\n"
        up = json.loads(await page.evaluate(
            "window.__pyCompanyApi('uploadBrief', %s)" % json.dumps(
                json.dumps({"name": "brief_e2e.md", "content": brief,
                            "uploaded_by": "owner"}, ensure_ascii=False))))
        check("uploadBrief 真实落库（真 DAG）", bool(up.get("ok")), up.get("error") or "")
        await drain_queue(2.0)
        st1 = json.loads(await page.evaluate("window.__pyCompanyApi('getState','{}')"))["data"]
        pend = [a for a in (st1.get("approvals") or []) if a.get("status") == "pending"]
        check("审批单真实生成", len(pend) >= 1, f"pending={len(pend)}")
        if pend:
            r1 = json.loads(await page.evaluate(
                "window.__pyCompanyApi('approve', %s)" % json.dumps(
                    json.dumps({"approval_id": pend[0]["id"], "approver": "owner",
                                "reason": "e2e 批准"}, ensure_ascii=False))))
            check("approve 单条真实执行（无批量）", bool(r1.get("ok")),
                  r1.get("error") or "")
        await drain_queue(2.0)
        st2 = json.loads(await page.evaluate("window.__pyCompanyApi('getState','{}')"))["data"]
        check("任务由审批派发", len(st2.get("tasks") or []) > 0,
              f"tasks={len(st2.get('tasks') or [])}")

        # ── 真运行控制 ──
        p1 = json.loads(await page.evaluate("window.__pyCompanyApi('pauseRun','{}')"))
        check("pauseRun 真暂停", bool(p1.get("ok")), p1.get("error") or "")
        r1b = json.loads(await page.evaluate("window.__pyCompanyApi('resumeRun','{}')"))
        check("resumeRun 真恢复", bool(r1b.get("ok")), r1b.get("error") or "")

        # ── 真信件 + 白盒读接口 ──
        sess = st2.get("sessions") or []
        check("listSessions 真会话台账", len(sess) >= 3, f"sessions={len(sess)}")
        dm = next((x for x in sess if x.get("kind") == "dm" and
                   "owner" in (x.get("members") or []) and
                   x.get("topic") != "owner 控制台"), None)
        if dm:
            oc = next((x for x in sess if x.get("kind") == "dm" and
                       x.get("topic") == "owner 控制台"), None)
            env = {"from": oc["session_id"] if oc else "owner",
                   "to": dm["session_id"], "role": "",
                   "type": "report", "authorization": "report",
                   "payload": "e2e 真实消息"}
            ms = json.loads(await page.evaluate(
                "window.__pyCompanyApi('message', %s)" % json.dumps(
                    json.dumps(env, ensure_ascii=False))))
            check("message 真投递", bool(ms.get("ok")), ms.get("error") or "")
        wb = json.loads(await page.evaluate(
            "window.__pyCompanyApi('getAgentWhitebox', %s)" % json.dumps(
                json.dumps({"role_id": "researcher"}, ensure_ascii=False))))
        wbd = (wb.get("data") or {})
        check("getAgentWhitebox 读接口（真档案）",
              bool(wb.get("ok")) and len(wbd.get("skill_whitelist") or []) > 0
              and wbd.get("max_token_budget", 0) > 0,
              f"wl={len(wbd.get('skill_whitelist') or [])} budget={wbd.get('max_token_budget')}")

        # ── 九卡截图（图谱全景）──
        await drain_queue(1.0)
        await page.screenshot(path=str(OUT / "e2e_cards.png"))

        # ── 白盒抽屉六页（项29-37）──
        await page.evaluate(
            "var c=[].find.call(document.querySelectorAll('[data-emp]'),"
            "function(x){return x.dataset.emp==='researcher'}); if(c)c.click(); true")
        await page.wait_for_timeout(1000)
        drawer_w = await page.evaluate(
            "Math.round(document.getElementById('drawer').getBoundingClientRect().width)")
        check("420px 抽屉（项29）", drawer_w == 420, f"w={drawer_w}")
        drawer_head = await page.evaluate(
            "!!document.getElementById('drName') && !!document.getElementById('drIcon') "
            "&& !!document.getElementById('drPill') && !!document.getElementById('drMgr')")
        check("抽屉头（图标/名称/部门/状态/上级）（项30）", bool(drawer_head), f"drawer_head={bool(drawer_head)}")
        tabs = await page.evaluate(
            "[].map.call(document.querySelectorAll('#drawer .dtabs button'),"
            "function(b){return b.textContent})")
        check("七标签（项31，含产出）",
              len(tabs) == 7 and "产出" in tabs, f"tabs={tabs}")
        no_undef = await page.evaluate(
            "document.getElementById('dBody').textContent.indexOf('undefined')<0")
        check("抽屉无 undefined（项40）", bool(no_undef), f"no_undefined={bool(no_undef)}")
        await page.screenshot(path=str(OUT / "e2e_drawer_ov.png"))
        for tab in ("sk", "pm", "ctx", "msgs", "ev"):
            await page.evaluate(
                "var b=[].find.call(document.querySelectorAll('#drawer .dtabs button'),"
                "function(x){return x.dataset.dt==='%s'}); if(b)b.click(); true" % tab)
            await page.wait_for_timeout(700)
            await page.screenshot(path=str(OUT / f"e2e_drawer_{tab}.png"))
            if tab == "sk":
                chips_on = await page.evaluate(
                    "document.querySelectorAll('#dBody .wchip').length")
                check("技能页白名单 chips（项33）", chips_on > 0, f"chips={chips_on}")
            if tab == "pm":
                pm_cells = await page.evaluate(
                    "document.querySelectorAll('#dBody .pcell').length")
                check("权限页四格矩阵（项34）", pm_cells == 4, f"cells={pm_cells}")
        body_ok = await page.evaluate(
            "document.getElementById('dBody').textContent.length > 0")
        check("消息页/事件页真实渲染（项36/37）", bool(body_ok), f"body_ok={bool(body_ok)}")

        # ── 群聊 / 审批视图（集群B 能力保留）──
        await page.evaluate("document.getElementById('drApprTab').click()")
        await page.wait_for_timeout(900)
        appr_rows = await page.evaluate(
            "document.querySelectorAll('#dBody .appr').length")
        check("审批视图逐条渲染", appr_rows >= 1, f"rows={appr_rows}")
        await page.screenshot(path=str(OUT / "e2e_approvals.png"))
        await page.evaluate("document.getElementById('drGroup').click()")
        await page.wait_for_timeout(600)
        await page.screenshot(path=str(OUT / "e2e_group.png"))

        # ── 文件交接 ──
        fc = json.loads(await page.evaluate(
            "window.__pyCompanyApi('recordFileChange', %s)" % json.dumps(
                json.dumps({"role_id": "backend", "path": "platform/service.py",
                            "old_text": "a = 1\n", "new_text": "a = 2\n",
                            "approver": "owner"}, ensure_ascii=False))))
        check("recordFileChange 真差异落版本产物", bool(fc.get("ok")),
              fc.get("error") or "")
        await drain_queue(1.0)

        # ── ★ A10: 1280×720 一屏断言 ──
        await page.set_viewport_size({"width": 1280, "height": 720})
        await page.wait_for_timeout(900)
        w1280 = await page.evaluate(
            "JSON.stringify((function(){var t=[].map.call(document.querySelectorAll('.acard'),"
            "function(c){return Math.round(c.getBoundingClientRect().top)});"
            "var rows=Object.keys(t.reduce(function(m,x){m[x]=1;return m},{})).length;"
            "var gm=document.getElementById('graphMain').getBoundingClientRect();"
            "var mx=0;[].forEach.call(document.querySelectorAll('.acard'),function(c){"
            "var r=c.getBoundingClientRect();if(r.bottom>mx)mx=r.bottom});"
            "return {n:document.querySelectorAll('.acard').length,rows:rows,"
            "fit:mx<=gm.bottom+1}})())")
        w1280d = json.loads(w1280 or "{}")
        check("1280×720 下 9 卡三行仍成立（A10）",
              w1280d.get("n") == 9 and w1280d.get("rows") == 3 and w1280d.get("fit") is True,
              str(w1280d))
        await page.set_viewport_size({"width": 1440, "height": 920})
        await page.wait_for_timeout(600)

        # ★ C10: 深链 hash 刷新后保持（放最后，避免 reload 影响后续断言）
        await page.evaluate("location.hash='#agent=tester&tab=sk'")
        await page.wait_for_timeout(300)
        await page.reload()
        await page.wait_for_timeout(1800)
        kept = await page.evaluate("location.hash.indexOf('agent=tester')>=0")
        check("深链 hash 刷新后保持（C10）", kept is True, await page.evaluate("location.hash"))

        # ── 收束 ──
        sp = json.loads(await page.evaluate("window.__pyCompanyApi('stopRun','{}')"))
        check("stopRun 真停转归档", bool(sp.get("ok")), sp.get("error") or "")
        await drain_queue(1.0)
        await browser.close()

    log_path = OUT / "e2e_v2_log.txt"
    with open(log_path, "w", encoding="utf-8") as f:
        for p in PASS:
            f.write(f"PASS  {p}\n")
        for f2 in FAIL:
            f.write(f"FAIL  {f2}\n")
        shots = ["e2e_cards.png", "e2e_drawer_ov.png", "e2e_drawer_sk.png",
                 "e2e_drawer_pm.png", "e2e_drawer_ctx.png", "e2e_drawer_msgs.png",
                 "e2e_drawer_ev.png", "e2e_approvals.png", "e2e_group.png"]
        f.write("artifacts: " + " / ".join(shots) + "\n")
    print("=" * 60)
    print(f"结果: {len(PASS)} passed, {len(FAIL)} failed   日志: {log_path}")
    return 1 if FAIL else 0


if __name__ == "__main__":
    import argparse
    _ap = argparse.ArgumentParser()
    _ap.add_argument("--strict", dest="strict", action="store_true", default=True)
    _ap.add_argument("--no-strict", dest="strict", action="store_false")
    _args = _ap.parse_args()
    STRICT = _args.strict
    print(f"[strict] {'ON' if STRICT else 'OFF'}（弱断言缺 detail 即 FAIL）", flush=True)
    sys.exit(asyncio.run(run()))

