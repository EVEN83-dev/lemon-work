# -*- coding: utf-8 -*-
"""run_app_visible — 打开真实程序窗口，肉眼可见地跑公司模式 / 超级爬虫。

与后台验收脚本的区别：这里**真的弹出 Qt 窗口**（不是 headless），
可以看着它加载、切模式、蜘蛛爬动、员工卡片变化，并自动截图留档。

运行：
  _py312/python.exe scripts/run_app_visible.py --mode company
  _py312/python.exe scripts/run_app_visible.py --mode crawl
  _py312/python.exe scripts/run_app_visible.py --mode both
  _py312/python.exe scripts/run_app_visible.py --mode crawl --source live --pages 60
  _py312/python.exe scripts/run_app_visible.py --mode company --hold 0   # 常驻不自动关

说明：
  · company —— 启动 MIMOWindow 真主窗口并切到「公司」页；失败时降级为
    HybridModeWebPanel 独立窗口（仍加载真 company_os.html + 真桥）。
  · crawl   —— 起 stage_server + 真抓取（默认本地 fixture，可 --source live），
    用 QWebEngineView 打开 /stage3，能直接看到蜘蛛与滚动。
  · 截图落在 outputs/acceptance/visible/。
退出码：窗口正常打开并截图 0；启动失败 1。
"""
import argparse
import os
import re
import sys
import threading
import time
import urllib.request
import zlib

os.environ.setdefault("QTWEBENGINE_CHROMIUM_FLAGS", "--disable-gpu --no-sandbox")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "standard_mode"))
os.chdir(ROOT)

from PyQt5.QtCore import Qt, QCoreApplication, QTimer, QUrl  # noqa: E402

QCoreApplication.setAttribute(Qt.AA_ShareOpenGLContexts, True)
from PyQt5.QtGui import QIcon  # noqa: E402
from PyQt5.QtWidgets import QApplication  # noqa: E402
from PyQt5.QtWebEngineWidgets import QWebEngineView  # noqa: E402

OUT = os.path.join(ROOT, "outputs", "acceptance", "visible")
os.makedirs(OUT, exist_ok=True)
SHOTS = []


def _shot(widget, name):
    p = os.path.join(OUT, name)
    ok = widget.grab().save(p)
    print(f"  [shot] {p} saved={ok} size={os.path.getsize(p) if os.path.exists(p) else 0}",
          flush=True)
    if ok:
        SHOTS.append(p)


# ────────────────────────── 爬虫可见窗口 ──────────────────────────
class _Fixture:
    pass


def _start_fixture():
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def do_GET(self):
            m = re.search(r"[?&]id=(\d+)", self.path)
            pid = int(m.group(1)) if m else 0
            m2 = re.search(r"[?&]d=(\d+)", self.path)
            depth = int(m2.group(1)) if m2 else 0
            txt = ("2026年二手车三季报 一季度 二季度 三季度 全国二手车销量 交易额 "
                   "客流量 品牌 比亚迪 特斯拉 大众 丰田 本田 吉利 长安 宝马 奔驰 ") * (5 + pid % 7)
            links = "".join(
                f'<a href="http://127.0.0.1:{self.server.server_port}/p?id={pid*3+k+1}'
                f'&d={depth+1}">next{k}</a>' for k in range(1, 4))
            body = (f"<html><head><title>二手车三季报 样本{pid}</title></head><body>"
                    f"<h1>第 {pid} 期</h1><p>{txt}</p>{links}</body></html>").encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

    srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, srv.server_port


def _fetch(url, depth=0):
    t0 = time.time()
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 LemonWork/visible"})
        with urllib.request.urlopen(req, timeout=10) as r:
            raw = r.read(600_000)
            code = r.status
    except Exception as e:
        return {"status": "fail", "url": url, "url_key": url, "domain": _dom(url),
                "depth": depth, "quality": 0.0, "text_len": 0, "text": "",
                "elapsed_ms": int((time.time() - t0) * 1000), "size_bytes": 0,
                "title": "", "links": [], "error": str(e)}
    enc = "utf-8"
    m = re.search(rb'charset=["\']?([\w-]+)', raw[:2048], re.I)
    if m:
        enc = m.group(1).decode("ascii", "ignore") or "utf-8"
    page = raw.decode(enc, "ignore")
    tm = re.search(r"<title[^>]*>(.*?)</title>", page, re.S | re.I)
    title = re.sub(r"\s+", " ", tm.group(1)).strip() if tm else ""
    text = re.sub(r"<(script|style)[^>]*>.*?</\1>", " ", page, flags=re.S | re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text)
    q = 0.15 + (zlib.crc32(url.encode("utf-8")) % 80) / 100.0
    return {"status": "ok" if code == 200 else "fail", "url": url, "url_key": url,
            "domain": _dom(url), "depth": depth, "quality": round(min(q, 0.97), 3),
            "text_len": len(text), "text": text,
            "elapsed_ms": int((time.time() - t0) * 1000), "size_bytes": len(raw),
            "title": title, "links": re.findall(r'href="(https?://[^"#]+)"', page)}


def _dom(url):
    m = re.match(r"https?://([^/]+)", url)
    return m.group(1) if m else ""


LIVE_SEEDS = ["https://www.autohome.com.cn/", "https://www.dongchedi.com/usedcar",
              "https://www.caam.org.cn/", "https://www.cpcaauto.com/"]


def open_crawl_window(source="fixture", pages=40):
    from shared.crawler import store as cstore
    from shared.crawler.engine import CrawlEngine
    from shared.crawler.session import create_session
    from shared.crawler import stage_server

    fixture = None
    seeds, src = [], source
    if source == "live":
        for u in LIVE_SEEDS:
            try:
                req = urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(req, timeout=6) as r:
                    if r.status == 200:
                        seeds.append(u)
            except Exception:
                continue
        if not seeds:
            print("  [crawl] live 种子全失败 → 降级 fixture", flush=True)
            src = "fixture"
    if not seeds:
        fixture, fport = _start_fixture()
        seeds = [f"http://127.0.0.1:{fport}/p?id=1&d=0"]

    sid = create_session("可见验收 · 二手车三季报", seeds[0])
    eng = CrawlEngine(sid, _fetch, workers=2, delay_ms=420)
    threading.Thread(target=eng.run,
                     kwargs=dict(max_pages=pages, max_depth=2,
                                 seed_urls=seeds, timeout_min=15),
                     daemon=True).start()
    port = stage_server.start()
    print(f"  [crawl] source={src} sid={sid} port={port} seeds={len(seeds)}", flush=True)

    v = QWebEngineView()
    v.setWindowTitle("Lemon Work · 超级爬虫实时舞台（可见验收）")
    v.resize(1440, 900)
    v.load(QUrl(f"http://127.0.0.1:{port}/stage3?sid={sid}"))
    v.show()
    QTimer.singleShot(6000, lambda: _shot(v, "crawl_window_6s.png"))
    QTimer.singleShot(14000, lambda: _shot(v, "crawl_window_14s.png"))
    return v


# ────────────────────────── 公司可见窗口 ──────────────────────────
def open_company_window():
    try:
        from ui.main_window import MIMOWindow
        w = MIMOWindow()
        w.setWindowTitle("Lemon Work · 多 Agent 公司模式（可见验收）")
        w.resize(1500, 940)
        w.show()
        QTimer.singleShot(3000, lambda: w._on_service_mode_switch("hybrid"))
        QTimer.singleShot(9000, lambda: _shot(w, "company_window_cards.png"))
        QTimer.singleShot(10000, lambda: _diag_page(w))
        QTimer.singleShot(12000, lambda: _open_first_agent(w))
        QTimer.singleShot(16000, lambda: _shot(w, "company_window_drawer.png"))
        print("  [company] MIMOWindow 已打开（真主窗口）", flush=True)
        return w
    except Exception as e:
        print(f"  [company] 整机窗口启动失败: {e} → 降级 HybridModeWebPanel", flush=True)
        from ui.hybrid_mode_web_panel import HybridModeWebPanel
        w = HybridModeWebPanel()
        w.setWindowTitle("Lemon Work · 公司 OS（面板降级窗口）")
        w.resize(1440, 900)
        w.show()
        QTimer.singleShot(9000, lambda: _shot(w, "company_window_cards.png"))
        return w


def _diag_page(w):
    """打印页内视口与 #app/#main 的真实尺寸（排查「半屏」类布局问题）。"""
    try:
        v = getattr(w, "hybrid_mode_panel", None)
        if v is None or not hasattr(v, "web_view"):
            return
        js = ("JSON.stringify({ih:innerHeight,iw:innerWidth,"
              "app:(function(){var e=document.getElementById('app');if(!e)return null;"
              "var r=e.getBoundingClientRect();"
              "return [Math.round(r.width),Math.round(r.height),Math.round(r.top)]})(),"
              "main:(function(){var e=document.getElementById('main');if(!e)return null;"
              "var r=e.getBoundingClientRect();"
              "return [Math.round(r.width),Math.round(r.height),Math.round(r.top)]})()})")
        v.web_view.page().runJavaScript(
            js, 0, lambda r: print(f"  [diag] {r}", flush=True))
    except Exception as e:
        print(f"  [diag] 失败: {e}", flush=True)


def _open_first_agent(w):
    """在主窗口里点开第一张员工卡（真实用户动作）。"""
    try:
        v = getattr(w, "hybrid_mode_panel", None)
        js = ("(function(){var c=document.querySelector('#cardsMatrix [data-emp]');"
              "if(c){c.click();return c.getAttribute('data-emp')}return ''})()")
        if v is not None and hasattr(v, "web_view"):
            v.web_view.page().runJavaScript(js)
            print("  [company] 已点击第一张员工卡", flush=True)
    except Exception as e:
        print(f"  [company] 点卡失败: {e}", flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", default="company",
                    choices=("company", "standard", "crawl", "both"))
    ap.add_argument("--source", default="fixture", choices=("fixture", "live"))
    ap.add_argument("--pages", type=int, default=40)
    ap.add_argument("--hold", type=int, default=24,
                    help="窗口保持秒数；0 = 一直开到手动关闭")
    args = ap.parse_args()

    app = QApplication.instance() or QApplication(sys.argv)
    # ★ 与正式启动器（yh_app.py）一致：品牌图标，而不是 Python 解释器默认图标
    _ico = os.path.normpath(os.path.join(ROOT, "..", "icon", "lemonwork.ico"))
    if os.path.exists(_ico):
        app.setWindowIcon(QIcon(_ico))
        print(f"  [icon] {_ico}", flush=True)
    wins = []
    if args.mode in ("company", "both"):
        wins.append(open_company_window())
    if args.mode == "standard":
        from ui.main_window import MIMOWindow
        w = MIMOWindow()
        w.setWindowTitle("Lemon Work · 标准模式（只留右栏）")
        w.resize(1500, 940)
        w.show()
        QTimer.singleShot(1500, lambda: w._on_service_mode_switch("original"))
        QTimer.singleShot(9000, lambda: _shot(w, "standard_window.png"))
        QTimer.singleShot(9500, lambda: print(
            "  [diag] bottom_visible=",
            w.bottom_panel.isVisible(),
            "parent=", type(w.bottom_panel.parent()).__name__,
            "geo=", w.bottom_panel.geometry().getRect(),
            "explorer=", w.explorer.isVisible(),
            "editor=", w.editor_area.isVisible(), flush=True))
        print("  [standard] MIMOWindow 已打开（标准模式）", flush=True)
        wins.append(w)
    if args.mode in ("crawl", "both"):
        wins.append(open_crawl_window(args.source, args.pages))

    if args.hold > 0:
        QTimer.singleShot(args.hold * 1000, app.quit)
    code = app.exec_()
    print(f"窗口已关闭；截图 {len(SHOTS)} 张：{SHOTS}", flush=True)
    return 0 if SHOTS else 1 if args.hold > 0 else code


if __name__ == "__main__":
    sys.exit(main())
