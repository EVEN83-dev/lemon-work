@echo off
chcp 65001 >nul
cd /d "%~dp0"
start "" "%~dp0_py312\pythonw.exe" "%~dp0yh_main.py"
exit
