# VISUAL_SPEC.md — 视觉与交互规范（统一与验收窗口真源）

> 适用页面：`company_os.html` / `company_board.html` / `lw_crawl_stage_v3.html`（+宿主卡 `lw_crawl_stage_card.js`）
> 运行时配套：`standard_mode/ui/lw_visual_spec.js`（`window.LWVIS`）
> 静态审计：`scripts/audit_visual_spec.py`（每次改动后必须全绿）

## 1. 色板与角色色变量（项2）

所有颜色只准从页面 `:root` CSS 变量取值；JS 侧经 `LWVIS.stateView()` 读取同名变量。

| 变量 | 值 | 语义 |
|---|---|---|
| `--bg` | `#0a0b0f` | 页面底 |
| `--pane` | `#101116` | 面板底 |
| `--pane2` | `#0d1016` | 次面板底 |
| `--line` | `rgba(255,255,255,.08)` | 边框（统一 1px，项4） |
| `--w` | `#e8eaf0` | 主文字 |
| `--dim` | `#8a90a0` | 次文字 |
| `--mut` | `#565b68` | 弱文字 |
| `--acc` | `#ff9a4a` | 主强调（琥珀） |
| `--ok` | `#3fbf6f` | 成功 |
| `--info` | `#57d4ff` | 信息（青） |
| `--err` | `#ff5d5d` | 错误 |
| `--amber` | `#ffb224` | 次强调（金） |

**角色/状态色**（11 项映射表的色源，各页 `:root` 必须定义）：

| 变量 | 值 | 状态 |
|---|---|---|
| `--st-idle` | `#8a90a0` | idle |
| `--st-queued` | `#57d4ff` | queued / discovering |
| `--st-running` | `#ffb224` | running / fetching |
| `--st-parse` | `#58e0d0` | parsing |
| `--st-judge` | `#ff9a4a` | judging |
| `--st-annotate` | `#3fbf6f` | annotating |
| `--st-wait` | `#ffb224` | waiting_approval |
| `--st-done` | `#3fbf6f` | done |
| `--st-failed` | `#ff5d5d` | failed / error |
| `--st-paused` | `#8a90a0` | paused |

判定三色（爬虫 KEEP/MAYBE/CUT 与公司审批语义共用）：KEEP=`--info` 青、MAYBE=`--ok` 绿、CUT=`--pink`(rgba 体系 `#ff5c9e`)。

## 2. 字号（项3）—— 七档收敛

```
8.5  微注（芯片内标签、图例）
9.5  次注（面板小标、图内轴注）
11   正文（表格、列表、卡片正文）
13   小标题 / 页内标题
16   大数字（KPI 主值）
22   特大数字（次级 KPI）
34   巨数字（战报/收束大数）
```

页面 body 基准 `13px`；禁止 8/9/10/10.5/11.5/12/12.5/15/26 等离档值。

## 3. 间距与边框（项4）

- 边框：一律 `1px solid var(--line)`（错误强调框同为 1px，靠色差区分，禁 2px）。
- 圆角两档：**6px**（chip/输入框/按钮）、**7px**（卡片/面板/容器）；药丸胶囊例外用 `999px`（`--pill`）。
- 间距阶（tokens.css 同源）：2 / 4 / 6 / 9 / 12 / 14 / 22 px。

## 4. 动效（项5）—— 四档时长 + 统一缓动

| 档 | 用途 |
|---|---|
| 120ms | hover / 按压反馈 |
| 200ms | 折叠展开、行高亮 |
| 300ms | 数字滚动（odometer）、面板切换 |
| 400ms | 覆盖层进出、大块过渡 |

- 缓动统一 `var(--ease)` = `cubic-bezier(.2,.7,.2,1)`；循环类动画（pulse/spin）允许 `linear`/无限次（不算过渡时长档）。
- 时长值只准写 `120ms/200ms/300ms/400ms`（或 `var(--dur-120)` 等 token）。

## 5. 状态机与映射表（项9/10/11）

**公司状态机**（`LWVIS.STATES.company`）：
`idle → queued → running → waiting_approval → done / failed`，任意态可 `paused`。

**爬虫状态机**（`LWVIS.STATES.crawler`）：
`idle → discovering → fetching → parsing → judging → annotating → done`，任意态可 `paused` / `error`。

映射表（色 / 药丸 / 动效）：

| 状态 | 颜色变量 | 药丸文案 | 动效 |
|---|---|---|---|
| idle | `--st-idle` | 空闲 / 待命 | 无 |
| queued / discovering | `--st-queued` | 排队中 / 发现链接 | 无 |
| running / fetching | `--st-running` | 运行中 / 抓取中 | pulse |
| parsing | `--st-parse` | 解析中 | pulse |
| judging | `--st-judge` | 判定中 | pulse |
| annotating | `--st-annotate` | 标注中 | 无 |
| waiting_approval | `--st-wait` | 待审批 | pulse |
| done | `--st-done` | 已完成 | 无 |
| failed / error | `--st-failed` | 失败 / 出错 | shake |
| paused | `--st-paused` | 已暂停 | 无 |

动效类页面 CSS 实现：`.lw-state-anim-pulse`（1.5s linear 循环透明度脉冲）、`.lw-state-anim-shake`（400ms 单次抖动）。

## 6. 调度器纪律（项6/7/8）

- 每 page **一个** `LWVIS.scheduler` 实例：rAF 帧回调与所有 `setInterval/setTimeout` 必须注册进调度器；散落的裸定时器禁止。
- `visibilitychange → hidden`：调度器自动挂起（rAF 停帧、周期任务 clearInterval）；回前台自动恢复（项7）。
- 组件卸载必须 `scheduler.clearAll()`（项8）——rAF、timer、visibility 监听全清。

## 7. 六态（项14）与空态文案（项15）

交互组件六态：hover / active / disabled / loading / empty / error。

| 态 | 规范 |
|---|---|
| hover | 边框转 `--acc` 40% 透明，120ms |
| active | 背景加深一档，120ms |
| disabled | opacity .4 + `cursor:not-allowed` |
| loading | 骨架屏（16，`lw-skeleton` 类：灰条 + 1.5s pulse） |
| empty | 统一文案（下表） |
| error | `LWVIS.renderError`：code + reason + 重试按钮（17） |

空态文案真源 `LWVIS.EMPTY_COPY`：数据=`等待数据`、判定=`等待判定数据`、模型=`等待模型调用`、产物=`暂无产物`、会话=`暂无会话`、轮次=`暂无历史轮次`。

## 8. 数字呈现（项13/20）

- 数字滚动：`LWVIS.odometer(el, value, {fmt:'int'|'float2'|'float3'|'pct'})`——真实差值滚动，同值不触发，隐藏页直落。
- 来源标注（20）：页面每个数字绑定 `data-src="函数名.字段"`（如 `data-src="build_stats.kpi.keep"`、`data-src="CompanyService.state().stats.units"`），tooltip 原生 `title` 同值；验收脚本静态断言 KPI 元素必须带 `data-src`。

## 9. schema 校验与降级（项18）

渲染前必须过 `LWVIS.validateState(kind, state)`：
- company 必需字段 `ts/board/tasks/events/stats`；crawler 必需 `counters/by_verdict/timeline/stats`。
- 缺字段 → 补形状（数组→`[]`、对象→`{}`、数值→`0`）并 `reportError('STATE_DEGRADED',…)`；**绝不造数**。

## 10. 错误与提示（项17/27/29）

- 错误上报唯一出口 `LWVIS.reportError(code, reason, source)` → `window.__LW_ERRORS`（200 条环形）+ `console.error`；页面禁止散落 console.error。
- error 态渲染 `code + reason + [⟳ 重试]`。
- 桥不可用 → `LWVIS.mountDemoBar(host, reason)` 顶部 `DEMO` 提示条（27），恢复后 `unmountDemoBar`；真实模式禁用一切演示计时器（28）——演示刷新只允许出现在 DEMO 条自身。

## 11. 字体栈（项33）

```
"Cascadia Mono", "Consolas", "Microsoft YaHei", monospace
```

## 12. 对比度（项32）

正文/数字对底色 ≥ 4.5:1：`--w`(12.9:1)、`--dim`(4.9:1) 达标；`--mut` 仅用于 ≥9.5px 的弱注与装饰，禁用于正文语义文本。

## 13. 静态审计口径（验收）

`scripts/audit_visual_spec.py` 断言：
① `font-size` 只出现七档；② `border-radius` 只出现 6/7/999（pill）；③ transition/animation 时长只出现 120/200/300/400ms（或 var token，pulse/spin 循环除外）；④ transition 缓动只出现 `var(--ease)`/`linear`；⑤ 前端源文件 `Math.random` 计数 = 0（项19）；⑥ 裸 `setInterval/setTimeout` 计数 = 0（全部经调度器）。
